export const environment = {
    production: false,
    graphqlUri: "http://localhost:3000/graphql",
    serverUri: "http://localhost:3000",
};
