export const environment = {
    production: true,
    graphqlUri: "/graphql",
    serverUri: "",
};
