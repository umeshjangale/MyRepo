import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { organisationDetailsRoute } from "../routes";

import { DataIO, User } from "./data-io";

@Component({
    selector: "app-organisation-create-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User;
    name = new FormControl(null, Validators.required);
    form = new FormGroup({
        name: this.name,
    });

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
    }

    async createOrganisationAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const result = await this._dataIO.createOrganisation({
                name: this.name.value,
            });
            this._router.navigate(organisationDetailsRoute.commands({ organisationId: result.id }))
                .catch(e => console.error(e));
        } catch (e) {
            this._message.withError("Failed to create organisation").showTillDismissed();
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }
}
