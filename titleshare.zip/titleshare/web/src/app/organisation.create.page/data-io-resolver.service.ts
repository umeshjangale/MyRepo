import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { CreateOrganisation, CreateOrganisationGQL, OrganisationCreateInitialDataGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _createOrganisationGQL: CreateOrganisationGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _organisationCreateInitialDataGQL: OrganisationCreateInitialDataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._organisationCreateInitialDataGQL
            .fetch()
            .pipe(
                take(1),
                // tslint:disable-next-line
                mergeMap(result => {
                    return of(this._createDataIO({
                        currentUser: result.data.me,
                    }));
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            createOrganisation: async ({ name }) => {
                const result = await this._createOrganisationGQL
                    .mutate({
                        input: {
                            name,
                        },
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    id: data.createOrganisation.id,
                };
            },
        };
    }
}
