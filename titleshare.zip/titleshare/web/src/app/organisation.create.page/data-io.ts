export interface DataIO {
    readonly initial: {
        readonly currentUser: User;
    };
    createOrganisation(parameters: { name: string }): Promise<{ id: string }>;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}
