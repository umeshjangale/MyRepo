import { Component, ContentChild, Directive, Host, HostBinding, Input, OnDestroy, OnInit, Optional, TemplateRef, ViewChild, ViewContainerRef } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";

import { routerNavigating } from "../utils/router-navigating";

import { PanelGroupComponent } from "./panel-group.component";

@Directive({
    selector: "ng-template[appPanelContent]",
})
export class PanelContentDirective {
    constructor(
        public template: TemplateRef<any>,
    ) {
    }
}

@Directive({
    selector: "ng-template[appPanelEditingContent]",
})
export class PanelEditingContentDirective {
    constructor(
        public template: TemplateRef<any>,
    ) {
    }
}

@Component({
    selector: "app-panel",
    templateUrl: "./panel.component.html",
    styleUrls: ["./panel.component.scss"],
})
export class PanelComponent implements OnDestroy, OnInit {
    private readonly _subscriptions: Subscription = new Subscription();
    private _editingFirst: boolean | undefined;
    private _busy: boolean = false;
    private _editing: boolean = false;
    private _navigating: boolean = false;

    private readonly _panelGroup: PanelGroupComponent | null;
    private _viewContainer: ViewContainerRef | undefined;
    private _content: PanelContentDirective | undefined;
    private _editingContent: PanelEditingContentDirective | undefined;
    private _currentContentTemplate: TemplateRef<any> | null = null;

    constructor(
        @Optional() @Host() panelGroup: PanelGroupComponent /* | null (see note below) */,
        router: Router,
    ) {
        // @Optional() (DI/typescript decorators) cannot handle union types
        // https://github.com/angular/angular/issues/25544
        this._panelGroup = panelGroup;
        if (this._panelGroup) {
            this._panelGroup.addPanel(this);
        }

        this._subscriptions.add(
            router.events.pipe(routerNavigating)
                .subscribe(v => {
                    this._navigating = v;
                }),
        );
    }

    ngOnDestroy(): void {
        this._subscriptions.unsubscribe();
    }

    @ViewChild("contentHost", { read: ViewContainerRef })
    set viewContainer(value: ViewContainerRef | undefined) {
        this._viewContainer = value;
        this._synchroniseState();
    }

    @ContentChild(PanelContentDirective)
    set content(value: PanelContentDirective | undefined) {
        this._content = value;
        this._synchroniseState();
    }

    @ContentChild(PanelEditingContentDirective)
    set editingContent(value: PanelEditingContentDirective | undefined) {
        this._editingContent = value;
        this._synchroniseState();
    }

    @Input("editingFirst") set editingFirst(value: any) {
        if (typeof value !== "boolean") {
            throw new Error();
        }
        this._editingFirst = value;
    }

    get disabled(): boolean {
        if (this._panelGroup) {
            return this._navigating || this._panelGroup.anyPanelBusyOrEditing && (!this._editing || this._busy);
        } else {
            return this._navigating || this._busy;
        }
    }

    get busy(): boolean {
        return this._busy;
    }

    set busy(value: boolean) {
        this._busy = value;
        if (this._panelGroup) {
            this._panelGroup.synchoniseState();
        }
        this._synchroniseState();
    }

    @HostBinding("class.editing")
    get editing(): boolean {
        return this._editing;
    }

    set editing(value: boolean) {
        this._editing = value;
        if (this._panelGroup) {
            this._panelGroup.synchoniseState();
        }
        this._synchroniseState();
    }

    ngOnInit() {
        if (this._editingFirst === undefined) {
            this._editingFirst = false;
        }
        this._editing = this._editingFirst;
        this._synchroniseState();
    }

    private _synchroniseState(): void {
        if (this._editingFirst === undefined) {
            return;
        }
        if (!this._viewContainer) {
            this._currentContentTemplate = null;
            return;
        }
        let contentTemplate: TemplateRef<any> | null = null;
        if (this._editing) {
            contentTemplate = this._editingContent ? this._editingContent.template : null;
        }
        if (!this._editing || !contentTemplate) {
            contentTemplate = this._content ? this._content.template : null;
        }
        if (contentTemplate !== this._currentContentTemplate) {
            this._viewContainer.clear();
            if (contentTemplate) {
                this._viewContainer.createEmbeddedView(contentTemplate, { $implicit: this });
            }
            this._currentContentTemplate = contentTemplate;
        }
    }
}
