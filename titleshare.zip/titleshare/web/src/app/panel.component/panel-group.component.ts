import { Component } from "@angular/core";

interface PanelLike {
    readonly busy: boolean;
    readonly editing: boolean;
}

@Component({
    selector: "app-panel-group",
    templateUrl: "./panel-group.component.html",
    styleUrls: ["./panel-group.component.scss"],
})
export class PanelGroupComponent {
    anyPanelBusyOrEditing: boolean = false;

    private readonly _panels: PanelLike[] = [];

    addPanel(panel: PanelLike): void {
        this._panels.push(panel);
    }

    synchoniseState(): void {
        this.anyPanelBusyOrEditing = this._panels.some(p => p.busy || p.editing);
    }
}
