import { Component, Directive, Input } from "@angular/core";

import { organisationDetailsRoute } from "../routes";

@Directive({
    selector: "app-panel-header-title, [appPanelHeaderTitle]",
})
export class PanelHeaderTitleDirective {
}

@Directive({
    selector: "app-panel-header-subtitle, [appPanelHeaderSubtitle]",
})
export class PanelHeaderSubtitleDirective {
}

@Directive({
    selector: "app-panel-header-action, [appPanelHeaderAction]",
})
export class PanelHeaderActionDirective {
}

interface Organisation {
    readonly id: string;
    readonly name: string;
}

@Component({
    selector: "app-panel-header",
    templateUrl: "./panel-header.component.html",
    styleUrls: ["./panel-header.component.scss"],
})
export class PanelHeaderComponent {
    @Input() organisation: Organisation | undefined;

    get organisationRouterLink(): any[] {
        if (!this.organisation) {
            throw new Error();
        }
        return organisationDetailsRoute.commands({ organisationId: this.organisation.id });
    }
}
