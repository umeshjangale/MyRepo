import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatProgressSpinnerModule, MatSelectModule, MatToolbarModule } from "@angular/material";
import { RouterModule } from "@angular/router";

import { IconsModule } from "../icons/icons.module";

import { PanelFooterActionDirective, PanelFooterComponent } from "./panel-footer.component";
import { PanelGroupComponent } from "./panel-group.component";
import { PanelHeaderActionDirective, PanelHeaderComponent, PanelHeaderSubtitleDirective, PanelHeaderTitleDirective } from "./panel-header.component";
import { PanelComponent, PanelContentDirective, PanelEditingContentDirective } from "./panel.component";

@NgModule({
    imports: [
        CommonModule,
        IconsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        MatToolbarModule,
        ReactiveFormsModule,
        RouterModule,
    ],
    declarations: [
        PanelComponent,
        PanelFooterActionDirective,
        PanelFooterComponent,
        PanelGroupComponent,
        PanelContentDirective,
        PanelEditingContentDirective,
        PanelHeaderActionDirective,
        PanelHeaderComponent,
        PanelHeaderSubtitleDirective,
        PanelHeaderTitleDirective,
    ],
    exports: [
        PanelComponent,
        PanelFooterActionDirective,
        PanelFooterComponent,
        PanelGroupComponent,
        PanelContentDirective,
        PanelEditingContentDirective,
        PanelHeaderComponent,
        PanelHeaderSubtitleDirective,
        PanelHeaderTitleDirective,
    ],
})
export class PanelModule { }
