import { Component, Directive } from "@angular/core";

@Directive({
    selector: "app-panel-footer-action, [appPanelFooterAction]",
})
export class PanelFooterActionDirective {
}

@Component({
    selector: "app-panel-footer",
    templateUrl: "./panel-footer.component.html",
    styleUrls: ["./panel-footer.component.scss"],
})
export class PanelFooterComponent {
}
