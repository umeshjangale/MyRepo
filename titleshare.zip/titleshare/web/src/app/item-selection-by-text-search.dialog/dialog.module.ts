import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatAutocompleteModule, MatButtonModule, MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatProgressSpinnerModule } from "@angular/material";

import { ItemSelectionByTextSearchDialogOpener } from "./dialog-opener.service";
import { DialogComponent } from "./dialog.component";

@NgModule({
    imports: [
        CommonModule,
        MatAutocompleteModule,
        MatButtonModule,
        MatDialogModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatProgressSpinnerModule,
        ReactiveFormsModule,
    ],
    declarations: [
        DialogComponent,
    ],
    providers: [
        ItemSelectionByTextSearchDialogOpener,
    ],
    entryComponents: [
        DialogComponent,
    ],
})
export class ItemSelectionByTextSearchDialogModule { }
