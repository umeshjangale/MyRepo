import { Component, Inject } from "@angular/core";
import { FormControl } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Observable } from "rxjs";
import { debounceTime, distinctUntilChanged, map, switchMap } from "rxjs/operators";

import { subscriptionInterceptor } from "../utils/subscription-interceptor";

import { DialogData } from "./dialog-data";

const SEARCH_DEBOUNCE_MILLIS: number = 10;

interface DisplayItem<T> {
    item: T;
    primaryLabel: string;
    secondaryLabel?: string;
}

@Component({
    selector: "app-content-selection-dialog",
    templateUrl: "./dialog.component.html",
    styleUrls: ["./dialog.component.scss"],
})
export class DialogComponent<T> {
    dialogTitle: string;
    searchTextPlaceholder: string;
    searchText = new FormControl();
    displayItems: Observable<ReadonlyArray<DisplayItem<T>>> | undefined;
    busy: boolean = false;

    constructor(
        @Inject(MAT_DIALOG_DATA) dialogData: DialogData<T>,
        private readonly _dialogRef: MatDialogRef<DialogComponent<T>, T>,
    ) {
        this.dialogTitle = dialogData.dialogTitle;
        this.searchTextPlaceholder = dialogData.searchTextPlaceholder;
        this.displayItems = this.searchText.valueChanges
            .pipe(
                debounceTime(SEARCH_DEBOUNCE_MILLIS),
                distinctUntilChanged(),
                switchMap(text =>
                    dialogData.filteredItems(typeof text === "string" ? text : "")
                        .pipe(
                            map(items => items.map(item => ({
                                item,
                                ...dialogData.displayableItem(item),
                            }))),
                            subscriptionInterceptor(() => this.busy = true, () => this.busy = false),
                        ),
                ),
            );
    }

    optionSelectedAction(value: DisplayItem<T>): void {
        this._dialogRef.close(value.item);
    }

    displayableOption(value?: DisplayItem<T>): string | undefined {
        return value && value.primaryLabel || undefined;
    }
}
