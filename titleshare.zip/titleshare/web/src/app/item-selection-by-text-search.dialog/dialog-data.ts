import { Observable } from "rxjs";

export interface DialogData<T> {
    readonly dialogTitle: string;
    readonly searchTextPlaceholder: string;
    filteredItems(searchText: string): Observable<ReadonlyArray<T>>;
    displayableItem(item: T): { primaryLabel: string; secondaryLabel?: string };
}
