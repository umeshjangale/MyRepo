import { Injectable } from "@angular/core";
import { MatDialog } from "@angular/material";

import { DialogData } from "./dialog-data";
import { DialogComponent } from "./dialog.component";

@Injectable()
export class ItemSelectionByTextSearchDialogOpener {
    constructor(
        private readonly _matDialog: MatDialog,
    ) {
    }

    async openDialog<T>(dialogData: DialogData<T>): Promise<T | undefined> {
        const dialogRef = this._matDialog.open<DialogComponent<T>, DialogData<T>, T>(DialogComponent, {
            width: "400px",
            data: dialogData,
        });
        return dialogRef.afterClosed()
            .toPromise();
    }
}
