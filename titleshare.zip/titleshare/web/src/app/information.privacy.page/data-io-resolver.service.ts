import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map } from "rxjs/operators";

import { InformationPrivacyInitialDataGQL } from "../../generated/graphql";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _informationPrivacyInitialDataGQL: InformationPrivacyInitialDataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._informationPrivacyInitialDataGQL
            .fetch(undefined, { context: { skipUnauthenticatedRedirect: true } })
            .pipe(map(result => {
                const currentUser = result.data.me || null;
                return this._createDataIO({
                    currentUser,
                });
            }))
            .pipe(catchError(() => of(this._createDataIO({ currentUser: null }))));
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,
        };
    }
}
