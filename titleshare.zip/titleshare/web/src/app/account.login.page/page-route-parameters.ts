export interface AccountLoginParameters {
    successUrl?: string;
}
