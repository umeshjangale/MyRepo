import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { isApolloError } from "apollo-client/errors/ApolloError";

import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { accountLoginRoute, informationMobileAppsRoute, informationTermsRoute, userDashboardRoute } from "../routes";
import { extractOrganisationRoles } from "../utils/user-roles";

import { DataIO, Role, User } from "./data-io";

@Component({
    selector: "app-account-login-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User | null = null;
    email = new FormControl("", [Validators.required, Validators.email]);
    password = new FormControl("", Validators.required);
    form = new FormGroup({
        email: this.email,
        password: this.password,
    });
    termsLink = informationTermsRoute.commands({});
    private readonly _dataIO: DataIO;
    private readonly _successUrlFromParameters: string | undefined;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;

        const { successUrl } = accountLoginRoute.parameters(activatedRoute.snapshot.paramMap);
        this._successUrlFromParameters = successUrl;

        if (this.currentUser) {
            this._redirectToSuccessUrl(this.currentUser.roles);
        }
    }

    async loginAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const result = await this._dataIO.login({
                email: this.email.value,
                password: this.password.value,
                useCookie: true,
            });
            this._redirectToSuccessUrl(result.user.roles);
        } catch (e) {
            let errorMessage: string | undefined;
            if (isApolloError(e)) {
                if (e.graphQLErrors && e.graphQLErrors.some(ge => !!ge && !!ge.extensions && ge.extensions.code === "BAD_USER_INPUT")) {
                    errorMessage = "Invalid username or password";
                } else if (!!e.networkError) {
                    errorMessage = "A network error occurred, please try again";
                }
            }
            this._showErrorMessage(errorMessage);
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }

    private _redirectToSuccessUrl(roles: Role[]): void {
        if (this._successUrlFromParameters) {
            this._router.navigateByUrl(this._successUrlFromParameters)
                .catch(e => console.error(e));
            return;
        }

        const organisationRoles = extractOrganisationRoles(roles);

        // If the user is NOT a system or organisation admin, redirect them to the 'Please download the mobile app' page,
        // otherwise redirect to the dashboard.
        const successUrl = !organisationRoles.sysAdmin && organisationRoles.orgAdminRolesCount === 0
            ? informationMobileAppsRoute.url(this._router, {})
            : userDashboardRoute.url(this._router, {});

        this._router.navigateByUrl(successUrl)
            .catch(e => console.error(e));
    }

    private _showErrorMessage(s: string = "An unexpected error occurred, please try again"): void {
        this._message.withError(s).showBriefly();
    }
}
