import { RoleType } from "../../generated/graphql";

export interface DataIO {
    initial: {
        currentUser: User | null;
    };
    login(parameters: { email: string; password: string; useCookie: boolean }): Promise<{ user: User }>;
}

export interface User {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}
