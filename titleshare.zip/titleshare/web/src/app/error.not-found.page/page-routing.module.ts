import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { PageComponent } from "./page.component";

const routes: Routes = [
    {
        path: "error/not-found",
        component: PageComponent,
    },
    {
        path: "**",
        redirectTo: "error/not-found",
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ],
})
export class PageRoutingModule { }
