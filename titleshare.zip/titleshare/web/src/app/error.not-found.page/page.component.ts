import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
    selector: "app-error-not-found",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
}
