import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatSelectModule } from "@angular/material";

import { PageRoutingModule } from "./page-routing.module";
import { PageComponent } from "./page.component";

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        PageRoutingModule,
        ReactiveFormsModule,
    ],
    declarations: [
        PageComponent,
    ],
})
export class ErrorNotFoundPageModule { }
