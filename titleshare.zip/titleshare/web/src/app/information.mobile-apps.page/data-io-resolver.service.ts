import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map, mergeMap, take } from "rxjs/operators";

import { InformationMobileAppsInitialDataGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _informationMobileAppsInitialDataGQL: InformationMobileAppsInitialDataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._informationMobileAppsInitialDataGQL
            .fetch(undefined, { context: { skipUnauthenticatedRedirect: true } })
            .pipe(map(result => {
                const currentUser = result.data.me || null;
                return this._createDataIO({
                    currentUser,
                });
            }))
            .pipe(catchError(() => of(this._createDataIO({ currentUser: null }))));
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,
        };
    }
}
