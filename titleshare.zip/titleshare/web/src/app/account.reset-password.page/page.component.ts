import { Component, OnDestroy } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { isApolloError } from "apollo-client/errors/ApolloError";
import { Subscription } from "rxjs";

import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { accountResetPasswordRoute, informationTermsRoute, userDashboardRoute } from "../routes";
import { matches } from "../utils/matches-validator";
import { extractOrganisationRoles } from "../utils/user-roles";

import { DataIO, User } from "./data-io";

const MINIMUM_PASSWORD_LENGTH = 6;

@Component({
    selector: "app-account-reset-password-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent implements OnDestroy {
    termsLink = informationTermsRoute.commands({});
    password = new FormControl("", [Validators.required, Validators.minLength(MINIMUM_PASSWORD_LENGTH)]);
    confirmPassword = new FormControl("", matches(this.password));
    form = new FormGroup({
        password: this.password,
        confirmPassword: this.confirmPassword,
    });
    email: string;
    dashboardLink = userDashboardRoute.commands({});
    isConsumerOnly = false;

    private readonly _subscriptions = new Subscription();
    private readonly _dataIO: DataIO;
    private readonly _token: string;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        const routeSnapshot = activatedRoute.snapshot;
        this._dataIO = routeSnapshot.data.dataIO as DataIO;
        const { email, token } = accountResetPasswordRoute.parameters(routeSnapshot.paramMap, routeSnapshot.queryParamMap);
        this.email = email;
        this._token = token;

        this._subscriptions.add(this.password.valueChanges.subscribe(() => {
            this.confirmPassword.updateValueAndValidity();
        }));
    }

    ngOnDestroy(): void {
        this._subscriptions.unsubscribe();
    }

    async saveAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const user = await this._dataIO.resetPassword({
                email: this.email,
                token: this._token,
                password: this.password.value,
            });
            panel.editing = false;
            // inhibit the browser from prompting to save this password, see: https://stackoverflow.com/a/51411352
            this.form.reset();

            this.isConsumerOnly = this._isConsumerOnly(user);

            // strip the query parameters from the history state (incase of browser refresh)
            this._router.navigate([], { replaceUrl: true, skipLocationChange: false, queryParamsHandling: "merge", queryParams: { email: null, token: null } })
                .catch(e => console.error(e));
        } catch (e) {
            let errorMessage: string | undefined;
            if (isApolloError(e)) {
                if (e.graphQLErrors && e.graphQLErrors.some(ge => !!ge && !!ge.extensions && ge.extensions.code === "BAD_USER_INPUT")) {
                    errorMessage = "Invalid password";
                } else if (e.graphQLErrors && e.graphQLErrors.some(ge => !!ge && !!ge.extensions && ge.extensions.code === "FORBIDDEN")) {
                    errorMessage = "This password reset link has already been used or is invalid";
                } else if (!!e.networkError) {
                    errorMessage = "A network error occurred, please try again";
                }
            }
            this._showErrorMessage(errorMessage);
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }

    private _isConsumerOnly(user: User): boolean {
        const roles = extractOrganisationRoles(user.roles);
        return !roles.sysAdmin && roles.orgAdminRolesCount === 0;
    }

    private _showErrorMessage(s: string = "An unexpected error occurred, please try again"): void {
        this._message.withError(s).showTillDismissed();
    }
}
