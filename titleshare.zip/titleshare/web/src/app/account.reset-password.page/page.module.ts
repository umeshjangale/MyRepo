import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatSelectModule } from "@angular/material";

import { MessageServiceModule } from "../message.service/module";
import { PanelModule } from "../panel.component/module";
import { StandardPageModule } from "../standard-page.component/module";

import { PageRoutingModule } from "./page-routing.module";
import { PageComponent } from "./page.component";

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MessageServiceModule,
        StandardPageModule,
        PageRoutingModule,
        PanelModule,
        ReactiveFormsModule,
    ],
    declarations: [
        PageComponent,
    ],
})
export class AccountResetPasswordPageModule { }
