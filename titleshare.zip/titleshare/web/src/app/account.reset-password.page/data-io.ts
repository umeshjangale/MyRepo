import { RoleType } from "../../generated/graphql";

export interface DataIO {
    initial: {
    };
    resetPassword(parameters: { email: string; token: string; password: string }): Promise<User>;
}

export interface User {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}
