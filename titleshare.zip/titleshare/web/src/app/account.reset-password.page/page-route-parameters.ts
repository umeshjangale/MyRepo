export interface AccountResetPasswordParameters {
    email: string;
    token: string;
}
