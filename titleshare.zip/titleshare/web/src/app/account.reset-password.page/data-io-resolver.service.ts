import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";

import { ResetPassword, ResetPasswordGQL } from "../../generated/graphql";
import { accountResetPasswordRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _resetPasswordGQL: ResetPasswordGQL,
        private readonly _resolverTools: ResolverTools,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        try {
            // `userResetPasswordRoute.parameters` will throw if the required query parameters are not present
            accountResetPasswordRoute.parameters(route.paramMap, route.queryParamMap);
        } catch {
            return this._resolverTools.showErrorNotFound();
        }
        return of(this._createDataIO({}));
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            resetPassword: async ({ email, token, password }) => {
                const result = await this._resetPasswordGQL
                    .mutate({
                        email,
                        resetToken: token,
                        password,
                    })
                    .toPromise();
                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return data.resetPassword.user;
            },
        };
    }
}
