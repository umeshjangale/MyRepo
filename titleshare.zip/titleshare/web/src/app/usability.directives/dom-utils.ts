export function selectOrFocusElement(element: any): void {
    if (!element) {
        return;
    }
    if (typeof element.select === "function") {
        element.select();
    } else if (typeof element.focus === "function") {
        element.focus();
    }
}
