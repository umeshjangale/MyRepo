import { Directive, ElementRef } from "@angular/core";

import { selectOrFocusElement } from "./dom-utils";

@Directive({
    selector: "[appAutoFocus]",
})
export class AutoFocusDirective {
    constructor(
        elementRef: ElementRef,
    ) {
        const element = elementRef.nativeElement;
        if (element) {
            setTimeout(() => selectOrFocusElement(element), 0);
        }
    }
}
