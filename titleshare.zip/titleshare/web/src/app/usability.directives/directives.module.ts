import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { AutoFocusSelectorDirective } from "./auto-focus-selector.directive";
import { AutoFocusDirective } from "./auto-focus.directive";

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        AutoFocusDirective,
        AutoFocusSelectorDirective,
    ],
    exports: [
        AutoFocusDirective,
        AutoFocusSelectorDirective,
    ],
})
export class UsabilityDirectivesModule { }
