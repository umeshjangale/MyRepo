import { Directive, ElementRef, Input } from "@angular/core";

import { selectOrFocusElement } from "./dom-utils";

@Directive({
    selector: "[appAutoFocusSelector]",
})
export class AutoFocusSelectorDirective {
    @Input("appAutoFocusSelector") selector: string | undefined;

    constructor(
        elementRef: ElementRef,
    ) {
        const element = elementRef.nativeElement;
        if (element && typeof element.querySelector === "function") {
            setTimeout(() => selectOrFocusElement(element.querySelector(this.selector)), 0);
        }
    }
}
