import { RoleType } from "../../generated/graphql";

export interface DataIO {
    readonly initial: {
        readonly currentUser: User;
        readonly organisations: ReadonlyArray<Organisation>;
    };
    inviteUser(parameters: { organisationId: string; email: string; firstName: string; lastName: string; roleType: RoleType }): Promise<{ id: string }>;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly roles: Role[];
}

export interface Role {
    readonly type: RoleType;
    readonly organisation?: { readonly id: string } | null;
}

export interface Organisation {
    readonly id: string;
    readonly name: string;
}
