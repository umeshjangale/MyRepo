import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { InviteUser, InviteUserGQL, UserInviteInitialDataGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class PageDataResolver implements Resolve<DataIO> {
    constructor(
        private readonly _inviteUserGQL: InviteUserGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _userInviteInitialDataGQL: UserInviteInitialDataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._userInviteInitialDataGQL
            .fetch()
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.searchOrganisations) {
                        return of(this._createDataIO({
                            currentUser: result.data.me,
                            organisations: result.data.searchOrganisations.items,
                        }));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            inviteUser: async ({ organisationId, email, firstName, lastName, roleType }) => {
                const result = await this._inviteUserGQL
                    .mutate({
                        user: {
                            organisationId,
                            email,
                            firstName,
                            lastName,
                            roleType,
                        },
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    id: data.inviteUser.user.id,
                };
            },
        };
    }
}
