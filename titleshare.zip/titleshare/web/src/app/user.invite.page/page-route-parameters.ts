export interface UserInviteParameters {
    organisationId?: string;
    roleType?: string;
    /** Both completionTitle and completionUrl must be given if functionality is required */
    completionTitle?: string;
    /** Both completionTitle and completionUrl must be given if functionality is required */
    completionUrl?: string;
}
