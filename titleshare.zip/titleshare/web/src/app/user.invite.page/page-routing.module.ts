import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { PageDataResolver } from "./data-io-resolver.service";
import { PageComponent } from "./page.component";

const routes: Routes = [
    {
        path: "",
        component: PageComponent,
        resolve: {
            dataIO: PageDataResolver,
        },
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ],
    providers: [
        PageDataResolver,
    ],
})
export class PageRoutingModule { }
