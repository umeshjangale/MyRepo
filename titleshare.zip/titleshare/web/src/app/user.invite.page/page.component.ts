import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

import { RoleType } from "../../generated/graphql";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { userDashboardRoute, userInviteRoute } from "../routes";
import { labelForRoleType } from "../utils/role-type-labels";
import { extractOrganisationRoles } from "../utils/user-roles";

import { DataIO, User } from "./data-io";

@Component({
    selector: "app-user-invite-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    readonly currentUser: User;
    readonly fixedRoleType: boolean;
    readonly fixedOrganisation: boolean;
    readonly organisations: ReadonlyArray<{ id: string; name: string }> = [];
    readonly organisationId = new FormControl(null, Validators.required);
    readonly roleType = new FormControl(null, Validators.required);
    readonly email = new FormControl("", [Validators.required, Validators.email]);
    readonly firstName = new FormControl("", Validators.required);
    readonly lastName = new FormControl("", Validators.required);
    readonly form = new FormGroup({
        organisationId: this.organisationId,
        firstName: this.firstName,
        lastName: this.lastName,
        email: this.email,
    });
    readonly roles: Array<{ roleType: RoleType; label: string }>;
    readonly roleSelectorVisible: boolean;
    readonly completionTitle: string;
    readonly completionUrl: string;

    private readonly _dataIO: DataIO;
    private _savingFields: boolean = false;

    constructor(
        readonly activatedRoute: ActivatedRoute,
        private readonly _message: Message,
        readonly router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.organisations = initial.organisations;

        const { organisationId, roleType, completionTitle, completionUrl } = userInviteRoute.parameters(activatedRoute.snapshot.paramMap);

        if (completionTitle && completionUrl) {
            this.completionTitle = completionTitle;
            this.completionUrl = completionUrl;
        } else {
            this.completionTitle = "Dashboard";
            this.completionUrl = userDashboardRoute.url(router, {});
        }

        this.fixedOrganisation = false;
        if (organisationId) {
            if (this.organisations.some(o => o.id === organisationId)) {
                this.organisationId.setValue(organisationId);
                this.fixedOrganisation = true;
            }
        } else if (this.organisations.length === 1) {
            this.organisationId.setValue(this.organisations[0].id);
        }

        this.roles = [
            // If the organisation is fixed, sys admin role is not an option
            ...this.fixedOrganisation ? [] : [{ roleType: RoleType.SysAdmin, label: labelForRoleType(RoleType.SysAdmin) }],
            { roleType: RoleType.OrgAdmin, label: labelForRoleType(RoleType.OrgAdmin) },
            { roleType: RoleType.Consumer, label: labelForRoleType(RoleType.Consumer) },
        ];

        this.fixedRoleType = false;
        const isSysAdmin = extractOrganisationRoles(this.currentUser.roles).sysAdmin;
        if (isSysAdmin) {
            this.form.addControl("roleType", this.roleType);
            if ((!this.fixedOrganisation && roleType === RoleType.SysAdmin) || roleType === RoleType.OrgAdmin || roleType === RoleType.Consumer) {
                this.roleType.setValue(roleType);
                this.fixedRoleType = true;
            }
        } else {
            this.roleType.setValue(RoleType.Consumer);
        }
        this.roleSelectorVisible = isSysAdmin;

        this.roleType.valueChanges.subscribe(() => this._synchroniseFormFieldStates());
        this._synchroniseFormFieldStates();
    }

    get savingFields(): boolean {
        return this._savingFields;
    }

    set savingFields(value: boolean) {
        this._savingFields = value;
        this._synchroniseFormFieldStates();
    }

    async inviteUserAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.savingFields = true;
        try {
            await this._dataIO.inviteUser({
                organisationId: this.organisationId.value,
                roleType: this.roleType.value,
                email: this.email.value,
                firstName: this.firstName.value,
                lastName: this.lastName.value,
            });
            panel.editing = false;
        } catch (e) {
            this._message.withError(`Failed to invite user ${this.firstName.value} ${this.lastName.value} (${this.email.value}).`).showTillDismissed();
        } finally {
            this.savingFields = false;
            panel.busy = false;
        }
    }

    addAnotherAction(panel: PanelComponent) {
        // retain the same selected organisation & roleType
        this.email.reset();
        this.firstName.reset();
        this.lastName.reset();
        panel.editing = true;
    }

    private _synchroniseFormFieldStates(): void {
        const states = this._formFieldStates();
        setEnablement(this.roleType, states.enablement.roleType);
        setEnablement(this.organisationId, states.enablement.organisationId);
        setEnablement(this.firstName, states.enablement.firstName);
        setEnablement(this.lastName, states.enablement.lastName);
        setEnablement(this.email, states.enablement.email);
        if (states.resetOrganisationId) {
            this.organisationId.setValue(null);
        }
    }

    private _formFieldStates() {
        if (this._savingFields) {
            return {
                enablement: {
                    roleType: false,
                    organisationId: false,
                    firstName: false,
                    lastName: false,
                    email: false,
                },
                resetOrganisationId: false,
            };
        }
        const sysAdminChosen = this.roleType.value === RoleType.SysAdmin;
        return {
            enablement: {
                roleType: !this.fixedRoleType,
                organisationId: !this.fixedOrganisation && !sysAdminChosen,
                firstName: true,
                lastName: true,
                email: true,
            },
            resetOrganisationId: sysAdminChosen,
        };
    }
}

function setEnablement(control: FormControl, value: boolean): void {
    if (value) {
        control.enable({ emitEvent: false });
    } else {
        control.disable({ emitEvent: false });
    }
}
