import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { RowClickDirective } from "./row-click.directive";

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        RowClickDirective,
    ],
    exports: [
        RowClickDirective,
    ],
})
export class TableDirectivesModule { }
