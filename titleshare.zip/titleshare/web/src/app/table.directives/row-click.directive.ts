import { Directive, EventEmitter, HostListener, Output } from "@angular/core";

/**
 * A directive that emits click events when a table tr is clicked,
 * but only if that click did not originate from within a nested button.
 */
@Directive({
    selector: "tr[appRowClick]",
})
export class RowClickDirective {
    // tslint:disable-next-line:no-output-rename
    @Output("appRowClick") _clickEventEmitter: EventEmitter<MouseEvent> = new EventEmitter();

    @HostListener("click", ["$event"])
    onClick(event: MouseEvent) {
        if (event.target instanceof Node) {
            let node: Node | null = event.target;
            do {
                if (node instanceof HTMLButtonElement) {
                    return;
                }
                node = node.parentNode;
            } while (node);
            this._clickEventEmitter.emit(event);
        }
    }
}
