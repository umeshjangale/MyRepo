import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { ProtectedSrcDirective } from "./protected-src.directive";

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        ProtectedSrcDirective,
    ],
    exports: [
        ProtectedSrcDirective,
    ],
})
export class ProtectedSrcDirectivesModule { }
