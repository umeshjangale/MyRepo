import { HttpClient } from "@angular/common/http";
import { Directive, ElementRef, Input, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { Subscription } from "rxjs";

@Directive({
    selector: "[appProtectedSrc]",
})
export class ProtectedSrcDirective implements OnChanges, OnDestroy {
    @Input("appProtectedSrc") protectedSrc: unknown = null;
    @Input() defaultSrc: unknown = null;
    private _saneProtectedSrc: string | null = null;
    private _saneDefaultSrc: string | null = null;
    private _objectUrl: string | null = null;
    private _blobDownloadSubscription: Subscription | null = null;

    constructor(
        private readonly _elementRef: ElementRef<HTMLElement>,
        private readonly _httpClient: HttpClient,
    ) {
    }

    ngOnChanges(changes: SimpleChanges): void {
        const saneProtectedSrc = validNonEmptyString(this.protectedSrc);
        this._saneDefaultSrc = validNonEmptyString(this.defaultSrc);
        if (saneProtectedSrc !== this._saneProtectedSrc) {
            this._saneProtectedSrc = saneProtectedSrc;
            this._stopBlobDownload();
            this._releaseObjectUrl();
            if (saneProtectedSrc !== null) {
                this._blobDownloadSubscription = this._httpClient
                    .get(saneProtectedSrc, { responseType: "blob" })
                    .subscribe(blob => {
                        this._objectUrl = URL.createObjectURL(blob);
                        this._synchroniseElementSrc();
                    });
            }
        }
        this._synchroniseElementSrc();
    }

    ngOnDestroy(): void {
        this._stopBlobDownload();
        this._releaseObjectUrl();
    }

    private _synchroniseElementSrc(): void {
        const element = this._elementRef.nativeElement;
        const src = this._objectUrl || this._saneDefaultSrc;
        if (src !== null) {
            element.setAttribute("src", src as any);
        } else {
            // Transitioning from image to no-image doesn't work
            //  reliably in Safari and causes a broken image in Chrome.
            // Don't care as that situation typically won't occur.
            element.removeAttribute("src");
        }
    }

    private _stopBlobDownload() {
        if (this._blobDownloadSubscription !== null) {
            this._blobDownloadSubscription.unsubscribe();
            this._blobDownloadSubscription = null;
        }
    }

    private _releaseObjectUrl() {
        if (this._objectUrl !== null) {
            URL.revokeObjectURL(this._objectUrl);
            this._objectUrl = null;
        }
    }
}

function validNonEmptyString(value: unknown): string | null {
    if (typeof (value) === "string" && value.trim().length !== 0) {
        return value;
    }
    return null;
}
