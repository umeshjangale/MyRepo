import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { MatButtonModule, MatDialogModule } from "@angular/material";

import { ConfirmationDialogOpener } from "./dialog-opener.service";
import { DialogComponent } from "./dialog.component";

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatDialogModule,
    ],
    declarations: [
        DialogComponent,
    ],
    providers: [
        ConfirmationDialogOpener,
    ],
    entryComponents: [
        DialogComponent,
    ],
})
export class ConfirmationDialogModule { }
