export interface DialogData {
    title: string;
    message: string;
    confirmButtonTitle: string;
    rejectButtonTitle: string;
}
