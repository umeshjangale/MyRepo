import { RoleType } from "../../generated/graphql";
import { RequestPasswordResponse } from "../models/interfaces";

export interface DataIO {
    initial: {
        currentUser: User;
        sysAdmins: Page<SysAdminUser>;
        organisations: Page<Organisation>;
        sysAdminsPerPage: number;
        organisationsPerPage: number;
    };
    sysAdminsPage(parameters: { zeroBasedPageIndex: number }): Promise<Page<SysAdminUser>>;
    organisationsPage(parameters: { zeroBasedPageIndex: number }): Promise<Page<Organisation>>;
    removeSystemAdmin(parameters: { userId: string; zeroBasedPageIndex: number }): Promise<Page<SysAdminUser>>;
    requestResetPassword(parameters: { email: string; }): Promise<RequestPasswordResponse> ;
}

export interface SysAdminUser {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
}

export interface RequestPasswordResponse {
   success:Boolean;
}

export interface Organisation {
    id: string;
    name: string;
    roleTypes: Set<RoleType>;
}

export interface User {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
