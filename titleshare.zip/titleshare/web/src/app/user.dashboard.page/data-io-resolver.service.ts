import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { RequestResetPasswordGQL, UserDashboardInitialData, UserDashboardInitialDataGQL, UserDashboardOrganisationsGQL, UserDashboardRemoveSystemAdminGQL, UserDashboardSysAdminsGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";
import { userRolesWithinOrganisation } from "../utils/user-roles";

import { DataIO, Organisation, Role } from "./data-io";

const SYS_ADMINS_PER_PAGE = 10;
const ORGANISATIONS_PER_PAGE = 30;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _userDashboardInitialDataGQL: UserDashboardInitialDataGQL,
        private readonly _userDashboardOrganisationsGQL: UserDashboardOrganisationsGQL,
        private readonly _userDashboardSysAdminsGQL: UserDashboardSysAdminsGQL,
        private readonly _removeSystemAdminGQL: UserDashboardRemoveSystemAdminGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _requestResetPasswordGQL: RequestResetPasswordGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._userDashboardInitialDataGQL
            .fetch({
                sysAdminsPageSize: SYS_ADMINS_PER_PAGE,
                organisationsPageSize: ORGANISATIONS_PER_PAGE,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    const data = result.data;
                    return of(this._createDataIO(
                        {
                            currentUser: data.me,
                            sysAdmins: {
                                ...data.searchSysAdmins,
                                zeroBasedPageIndex: 0,
                            },
                            organisations: {
                                items: augmentOrganisationsWithRoles(data.searchOrganisations.items, data.me.roles),
                                zeroBasedPageIndex: 0,
                                totalCount: data.searchOrganisations.totalCount,
                            },
                            sysAdminsPerPage: SYS_ADMINS_PER_PAGE,
                            organisationsPerPage: ORGANISATIONS_PER_PAGE,
                        },
                    ));
                }),
                catchError(e => this._resolverTools.showErrorNotFound()),
        );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            sysAdminsPage: async ({ zeroBasedPageIndex }) => {
                const result = await this._userDashboardSysAdminsGQL
                    .fetch(
                        {
                            pageSize: SYS_ADMINS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                )
                    .toPromise();
                const data = result.data;
                return {
                    ...data.searchSysAdmins,
                    zeroBasedPageIndex,
                };
            },

            organisationsPage: async ({ zeroBasedPageIndex }) => {
                const result = await this._userDashboardOrganisationsGQL
                    .fetch(
                        {
                            pageSize: ORGANISATIONS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                )
                    .toPromise();
                const data = result.data;
                return {
                    items: augmentOrganisationsWithRoles(data.searchOrganisations.items, initial.currentUser.roles),
                    zeroBasedPageIndex,
                    totalCount: data.searchOrganisations.totalCount,
                };
            },

            removeSystemAdmin: async ({ userId, zeroBasedPageIndex }) => {
                const result = await this._removeSystemAdminGQL.mutate({
                    userId,
                    pageSize: SYS_ADMINS_PER_PAGE,
                    oneBasedPageNumber: zeroBasedPageIndex + 1,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.removeSystemAdmin.searchSysAdmins,
                    zeroBasedPageIndex,
                };
            },

            requestResetPassword: async ({ email }) => {
                const result = await this._requestResetPasswordGQL.mutate({
                    email,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.requestPasswordReset
                }
            },
        };
    }
}

function augmentOrganisationsWithRoles(rawOrganisations: UserDashboardInitialData.SearchOrganisations["items"], userRoles: Role[]): Organisation[] {
    return rawOrganisations.map(organisation => ({
        ...organisation,
        roleTypes: userRolesWithinOrganisation(userRoles, organisation.id),
    }));
}
