import { Component, ViewChild } from "@angular/core";
import { MatPaginator, PageEvent } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";

import { environment } from "../../environments/environment";
import { RoleType } from "../../generated/graphql";
import { DataIOCommonServiceResolver } from "../common/data-io-resolver.service";
import { ConfirmationDialogOpener } from "../confirmation.dialog/dialog-opener.service";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { informationMobileAppsRoute, organisationCreateRoute, organisationDetailsRoute, userDetailsRoute, userInviteRoute } from "../routes";
import { labelForRoleTypes } from "../utils/role-type-labels";
import { extractOrganisationRoles, OrganisationRoles } from "../utils/user-roles";

import { DataIO, Organisation, Page, SysAdminUser, User } from "./data-io";

@Component({
    selector: "app-user-dashboard-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {

    currentUser: User;
    sysAdminList: { page: Page<SysAdminUser>; pageSize: number; columns: string[] };
    organisationList: { page: Page<Organisation>; pageSize: number; columns: string[] };
    @ViewChild(".code_contentItemsPaginator") contentItemsPaginator: MatPaginator | undefined;
    @ViewChild(".code_sysAdminsPaginator") sysAdminsPaginator: MatPaginator | undefined;
    @ViewChild(".code_organisationsPaginator") organisationsPaginator: MatPaginator | undefined;
    permissions: {
        viewSysAdmins: boolean;
        createOrganisations: boolean;
        viewBillingReport: boolean;
    };

    billingReportUri = `${environment.serverUri}/report/content-billing`;

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _confirmationDialogOpener: ConfirmationDialogOpener,
        private readonly _message: Message,
        private readonly _router: Router,
        private readonly _dataIOCommonServiceResolver: DataIOCommonServiceResolver,
    ) {


        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        const organisationRoles = extractOrganisationRoles(this.currentUser.roles);

        this.redirectIfNecessary(organisationRoles, initial);

        this.sysAdminList = {
            page: initial.sysAdmins,
            pageSize: initial.sysAdminsPerPage,
            columns: ["firstName", "lastName", "email", "actions"],
        };
        this.organisationList = {
            page: initial.organisations,
            pageSize: initial.organisationsPerPage,
            columns: ["name", "role"],
        };

        this.permissions = {
            viewSysAdmins: organisationRoles.sysAdmin,
            createOrganisations: organisationRoles.sysAdmin,
            viewBillingReport: organisationRoles.sysAdmin,
        };
    }

    labelForRoleTypes(roleTypes: Set<RoleType>): string {
        return labelForRoleTypes(roleTypes);
    }

    canGotoOrganisation(organisation: Organisation): boolean {
        const roleTypes = organisation.roleTypes;
        return roleTypes.has(RoleType.SysAdmin) || roleTypes.has(RoleType.OrgAdmin);
    }

    async sysAdminsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.sysAdminList.page = await this._dataIO.sysAdminsPage({ zeroBasedPageIndex: pageEvent.pageIndex });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.sysAdminsPaginator) {
                this.sysAdminsPaginator.pageIndex = this.sysAdminList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch system administrators.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async organisationsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.organisationList.page = await this._dataIO.organisationsPage({ zeroBasedPageIndex: pageEvent.pageIndex });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.organisationsPaginator) {
                this.organisationsPaginator.pageIndex = this.organisationList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch organisations.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async inviteSysAdminAction(): Promise<any> {
        this._router.navigate(userInviteRoute.commands({
            roleType: RoleType.SysAdmin,
            completionTitle: "Dashboard",
            completionUrl: this._router.url,
        }))
            .catch(e => console.error(e));
    }

    async removeSysAdminAction(sysAdmin: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove System Admin",
            message: `Are you sure you want to remove user "${sysAdmin.firstName} ${sysAdmin.lastName}" as a system admin? All access to content will be removed.`,
            confirmButtonTitle: "Remove System Admin",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeSysAdmin(sysAdmin, this.sysAdminsPaginator ? this.sysAdminsPaginator.pageIndex : 0, panel);
        }
    }

    async resetPasswordAction(sysAdmin: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Reset System Admin Password",
            message: `Are you sure you want to reset password for user "${sysAdmin.firstName} ${sysAdmin.lastName}"?`,
            confirmButtonTitle: "Reset Password",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._requestResetPassword(sysAdmin, panel);
        }
    }

    async createOrganisationAction(): Promise<any> {
        this._router.navigate(organisationCreateRoute.commands({}))
            .catch(e => console.error(e));
    }

    gotoSysAdminAction(user: User): void {
        this._router.navigate(userDetailsRoute.commands({ userId: user.id, organisationId: undefined }))
            .catch(e => console.error(e));
    }

    gotoOrganisationAction(organisation: Organisation): void {
        if (!this.canGotoOrganisation(organisation)) {
            return;
        }
        this._router.navigate(organisationDetailsRoute.commands({ organisationId: organisation.id }))
            .catch(e => console.error(e));
    }

    private async _removeSysAdmin(sysAdmin: User, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.sysAdminList.page = await this._dataIO.removeSystemAdmin({ userId: sysAdmin.id, zeroBasedPageIndex });
            this._message.withInfo(`Removed system admin "${sysAdmin.firstName} ${sysAdmin.lastName}"`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.sysAdminsPaginator) {
                this.sysAdminsPaginator.pageIndex = this.sysAdminList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove system admin "${sysAdmin.firstName} ${sysAdmin.lastName}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _requestResetPassword(sysAdmin: User, panel: PanelComponent): Promise<void> {
        panel.busy = true;

        this._dataIOCommonServiceResolver.requestResetPassword(sysAdmin.email)
            .then(x => {
                this._message.withInfo(`Reset password request sent for user "${sysAdmin.firstName} ${sysAdmin.lastName}"`).showBriefly();
            })
            .catch(x => this._message.withError(`Failed to send request to reset password for "${sysAdmin.firstName} ${sysAdmin.lastName}".`).showTillDismissed());

        panel.busy = false;
    }

    private redirectIfNecessary(organisationRoles: OrganisationRoles, initial: DataIO["initial"]) {
        if (organisationRoles.sysAdmin) {
            return;
        }

        // Consumers get redirected to the mobile apps info page.
        if (organisationRoles.orgAdminRolesCount === 0) {
            this._router.navigate(informationMobileAppsRoute.commands({}))
                .catch(e => console.error(e));
            return;

        }

        // Organisation admins of a single organisation get redirected to the organisation details page.
        if (organisationRoles.orgAdminRolesCount === 1 && initial.organisations.totalCount === 1) {

            this._router.navigate(organisationDetailsRoute.commands({ organisationId: initial.organisations.items[0].id }))
                .catch(e => console.error(e));
            return;
        }
    }
}
