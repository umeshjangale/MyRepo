import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { PanelModule } from "../panel.component/module";
import { StandardPageModule } from "../standard-page.component/module";

import { PageRoutingModule } from "./page-routing.module";
import { PageComponent } from "./page.component";

@NgModule({
    imports: [
        CommonModule,
        StandardPageModule,
        PageRoutingModule,
        PanelModule,
    ],
    declarations: [
        PageComponent,
    ],
})
export class InformationTermsPageModule { }
