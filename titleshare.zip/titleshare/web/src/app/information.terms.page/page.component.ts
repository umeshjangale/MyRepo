import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { DataIO, User } from "./data-io";

@Component({
    selector: "app-information-terms-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User | null;

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
    }
}
