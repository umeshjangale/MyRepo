import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { ContentCollectionCreateInitialDataGQL, CreateContentCollection, CreateContentCollectionGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _createContentCollectionGQL: CreateContentCollectionGQL,
        private readonly _contentCollectionCreateInitialDataGQL: ContentCollectionCreateInitialDataGQL,
        private readonly _resolverTools: ResolverTools,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._contentCollectionCreateInitialDataGQL
            .fetch()
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.searchOrganisations) {
                        return of(this._createDataIO({
                            currentUser: result.data.me,
                            organisations: result.data.searchOrganisations.items,
                        }));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            createContentCollection: async ({ organisationId, name, description }) => {
                const result = await this._createContentCollectionGQL
                    .mutate({
                        input: {
                            organisationId,
                            name,
                            description,
                        },
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    id: data.createContentCollection.id,
                };
            },
        };
    }
}
