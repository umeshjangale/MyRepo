export interface ContentCollectionCreateParameters {
    organisationId?: string;
}
