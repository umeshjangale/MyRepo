import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { contentCollectionCreateRoute, contentCollectionDetailsRoute } from "../routes";
import { StickyDisableFormControl } from "../utils/sticky-disable-form-control";

import { DataIO, Organisation, User } from "./data-io";

@Component({
    selector: "app-content-collection-create-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User;
    organisations: ReadonlyArray<Organisation> = [];
    organisationId = new StickyDisableFormControl(null, Validators.required);
    name = new FormControl("", Validators.required);
    description = new FormControl("");
    form = new FormGroup({
        organisationId: this.organisationId,
        name: this.name,
        description: this.description,
    });

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.organisations = initial.organisations;

        const { organisationId } = contentCollectionCreateRoute.parameters(activatedRoute.snapshot.paramMap);

        if (organisationId) {
            if (this.organisations.some(o => o.id === organisationId)) {
                this.organisationId.setValue(organisationId);
                this.organisationId.disable();
                this.organisationId.stickyDisable = true;
            } // else don't preselect anything
        } else if (this.organisations.length === 1) {
            this.organisationId.setValue(this.organisations[0].id);
        }
    }

    async createContentCollectionAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const result = await this._dataIO.createContentCollection({
                organisationId: this.organisationId.value,
                name: this.name.value,
                description: this.description.value,
            });
            this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: result.id }))
                .catch(e => console.error(e));
        } catch (e) {
            this._message.withError("Failed to create content collection").showTillDismissed();
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }
}
