import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule, MatInputModule, MatProgressSpinnerModule } from "@angular/material";

import { SearchTextComponent } from "./search-text.component";

@NgModule({
    imports: [
        CommonModule,
        MatFormFieldModule,
        MatInputModule,
        MatProgressSpinnerModule,
        ReactiveFormsModule,
    ],
    declarations: [
        SearchTextComponent,
    ],
    exports: [
        SearchTextComponent,
    ],
})
export class SearchTextModule { }
