import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { of, Subscription } from "rxjs";
import { debounceTime, distinctUntilChanged, filter, switchMap, tap } from "rxjs/operators";

const SEARCH_DEBOUNCE_MILLIS: number = 300;

export interface SearchTextEvent {
    searchText: string;
    withBusy(func: () => Promise<void>): Promise<void>;
}

@Component({
    selector: "app-search-text",
    templateUrl: "./search-text.component.html",
    styleUrls: ["./search-text.component.scss"],
})
export class SearchTextComponent implements OnDestroy {

    busy = false;
    get visible(): boolean {
        return this._visible;
    }

    get value(): string {
        return this.searchText.value || "";
    }

    @Input() searchTextPlaceholder: string = "Filter";

    @Input()
    set disabled(value: boolean) {
        this._disabled = value;
        if (this._disabled) {
            this.formGroup.disable();
        } else {
            this.formGroup.enable();
        }
    }

    @Output() search = new EventEmitter<SearchTextEvent>();

    searchText = new FormControl("");
    formGroup = new FormGroup({
        searchTextControl: this.searchText,
    });

    private _visible: boolean = false;
    private _disabled: boolean = false;
    private readonly _valueChangesSub: Subscription | undefined;

    constructor() {
        const withBusy = async (func: () => Promise<void>) => {
            this.busy = true;
            try {
                await func();
            } finally {
                this.busy = false;
            }
        };

        this._valueChangesSub = this.searchText.valueChanges
            .pipe(
                debounceTime(SEARCH_DEBOUNCE_MILLIS),
                distinctUntilChanged(),
                filter(() => !this.disabled),
                // tslint:disable-next-line: no-void-expression
                switchMap(text => of(this.search.emit({ searchText: text, withBusy })),
                ),
            ).subscribe();
    }

    ngOnDestroy(): void {
        if (this._valueChangesSub) {
            this._valueChangesSub.unsubscribe();
        }
    }

    async toggleVisibility(): Promise<void> {
        if (this._disabled) {
            return;
        }

        this._visible = !this._visible;
        if (!this._visible) {
            this.searchText.setValue("");
        }
    }
}
