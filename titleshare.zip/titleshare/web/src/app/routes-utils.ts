import { ParamMap, Router } from "@angular/router";

interface AppRoute<P> {
    url(router: Router, parameters: P): string;
    commands(parameters: P): any[];
    parameters(paramMap: ParamMap): P;
}

/** The keys of T marked as ? (optional) */
type OptionalKeys<T> = { [K in keyof T]-?: undefined extends T[K] ? K : never }[keyof T];
/** The keys of T not marked as ? (not optional) */
type NonOptionalKeys<T> = { [K in keyof T]-?: undefined extends T[K] ? never : K }[keyof T];
/** Convert properties of T to be required, retaining the same apparent type */
type Complete<T> = { [K in OptionalKeys<T>]: T[K] } & { [K in NonOptionalKeys<T>]: T[K] };

export class ParameterValues<P> {
    constructor(
        private readonly _paramMap: ParamMap,
    ) {
    }

    optional(key: Extract<OptionalKeys<P>, string>): string | undefined {
        return this._paramMap.get(key) || undefined;
    }

    required(key: Extract<NonOptionalKeys<P>, string>): string {
        const value = this._paramMap.get(key);
        if (!value) {
            throw new Error();
        }
        return value;
    }
}

// Angular treats a present property as having a value, even where that value is undefined
// This function filters said undefined properties away
function stripUndefinedCommandProperties(commands: any[]): any[] {
    return commands.map(command => {
        if (typeof command === "string") {
            return command;
        }
        const cleanCommand = Object.create({});
        for (const key of Object.keys(command)) {
            const value = command[key];
            if (value !== undefined) {
                cleanCommand[key] = value;
            }
        }
        return cleanCommand;
    });
}

interface InnerAppRoute<P> {
    commands(parameters: P): any[];
    parameters(values: ParameterValues<P>): Complete<P>;
}

export function createRoute<P>(creator: () => InnerAppRoute<P>): AppRoute<P> {
    const { commands, parameters } = creator();
    return {
        url(router, commandParameters) {
            return router.serializeUrl(router.createUrlTree(this.commands(commandParameters)));
        },
        commands: commandParameters => stripUndefinedCommandProperties(commands(commandParameters)),
        parameters: paramMap => parameters(new ParameterValues<P>(paramMap)) as P,
    };
}
