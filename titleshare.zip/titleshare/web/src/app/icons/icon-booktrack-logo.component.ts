import { Component } from "@angular/core";

@Component({
    selector: "icon-booktrack-logo",
    templateUrl: "./icon-booktrack-logo.component.html",
    styleUrls: ["./common-icon.component.scss"],
})
export class IconBooktrackLogoComponent {
}
