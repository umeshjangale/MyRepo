import { NgModule } from "@angular/core";

import { IconBooktrackLogoComponent } from "./icon-booktrack-logo.component";

@NgModule({
    declarations: [
        IconBooktrackLogoComponent,
    ],
    exports: [
        IconBooktrackLogoComponent,
    ],
})
export class IconsModule { }
