import { Observable } from "rxjs";

import { RoleType } from "../../generated/graphql";

export interface DataIO {
    readonly initial: {
        readonly currentUser: UserWithRoles;
        readonly contentCollection: ContentCollection;
        readonly contentItems: Page<Content>;
        readonly contentItemsPerPage: number;
        readonly users: Page<User>;
        readonly usersPerPage: number;
    };
    updateContentCollection(parameters: { name: string; description: string; signUpCode: string | undefined; signUpCodeEnabled: boolean | undefined }): Promise<ContentCollection>;
    contentItemsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    addContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    removeContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    suggestedContentItems(parameters: { value: string }): Observable<Content[]>;
    usersPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    addUser(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    removeUser(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    suggestedUsers(parameters: { value: string }): Observable<User[]>;
}

export interface ContentCollection {
    readonly name: string;
    readonly description: string;
    readonly signUpCodeEnabled: boolean;
    readonly signUpCode: string | null;
    readonly organisation: {
        readonly id: string;
        readonly name: string;
    };
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}

export interface UserWithRoles {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}

export interface Content {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
    readonly author: string;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
