import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map, mergeMap, take } from "rxjs/operators";

import { AddContentToContentCollection, AddContentToContentCollectionGQL, AddUserToContentCollectionGQL, ContentCollectionDetailsContentItemsGQL, ContentCollectionDetailsInitialDataGQL, ContentCollectionDetailsUsersGQL, RemoveContentFromContentCollection, RemoveContentFromContentCollectionGQL, RemoveUserFromContentCollectionGQL, SuggestedContentForContentCollectionGQL, SuggestedUsersForContentCollectionGQL, UpdateContentCollection, UpdateContentCollectionGQL } from "../../generated/graphql";
import { contentCollectionDetailsRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

const CONTENT_ITEMS_PER_PAGE = 5;
const USERS_PER_PAGE = 5;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _addContentToContentCollectionGQL: AddContentToContentCollectionGQL,
        private readonly _removeContentFromContentCollectionGQL: RemoveContentFromContentCollectionGQL,
        private readonly _suggestedContentForContentCollectionGQL: SuggestedContentForContentCollectionGQL,
        private readonly _contentCollectionDetailsContentItemsGQL: ContentCollectionDetailsContentItemsGQL,

        private readonly _addUserToContentCollectionGQL: AddUserToContentCollectionGQL,
        private readonly _removeUserFromContentCollectionGQL: RemoveUserFromContentCollectionGQL,
        private readonly _suggestedUsersForContentCollectionGQL: SuggestedUsersForContentCollectionGQL,
        private readonly _contentCollectionDetailsUsersGQL: ContentCollectionDetailsUsersGQL,

        private readonly _contentCollectionDetailsInitialDataGQL: ContentCollectionDetailsInitialDataGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _updateContentCollectionGQL: UpdateContentCollectionGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        const { contentCollectionId } = contentCollectionDetailsRoute.parameters(route.paramMap);
        return this._contentCollectionDetailsInitialDataGQL
            .fetch({
                contentCollectionId,
                contentItemsPageSize: CONTENT_ITEMS_PER_PAGE,
                usersPageSize: USERS_PER_PAGE,
                oneBasedPageNumber: 1,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.node) {
                        return of(this._createDataIO(
                            {
                                currentUser: result.data.me,
                                contentItems: {
                                    ...result.data.node.content,
                                    zeroBasedPageIndex: 0,
                                },
                                users: {
                                    ...result.data.node.users,
                                    zeroBasedPageIndex: 0,
                                },
                                contentItemsPerPage: CONTENT_ITEMS_PER_PAGE,
                                usersPerPage: USERS_PER_PAGE,
                                contentCollection: result.data.node,
                            },
                            contentCollectionId,
                        ));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"], contentCollectionId: string): DataIO {
        return {
            initial,

            updateContentCollection: async ({ name, description, signUpCode, signUpCodeEnabled }) => {
                const result = await this._updateContentCollectionGQL
                    .mutate({
                        collection: {
                            id: contentCollectionId,
                            name,
                            description,
                            signUpCode,
                            signUpCodeEnabled,
                        },
                    })
                    .toPromise();
                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...initial.contentCollection,
                    ...data.updateContentCollection,
                };
            },

            contentItemsPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._contentCollectionDetailsContentItemsGQL
                    .fetch(
                        {
                            contentCollectionId,
                            searchText,
                            pageSize: CONTENT_ITEMS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const contentCollectionNode = result.data.node;
                if (!contentCollectionNode) {
                    throw new Error();
                }
                return {
                    ...contentCollectionNode.content,
                    zeroBasedPageIndex,
                };
            },

            addContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                const result = await this._addContentToContentCollectionGQL
                    .mutate({
                        contentCollectionId,
                        contentId,
                        searchText,
                        pageSize: CONTENT_ITEMS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.addAssociation.node.content,
                    zeroBasedPageIndex,
                };
            },

            removeContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeContentFromContentCollectionGQL
                    .mutate({
                        contentCollectionId,
                        contentId,
                        searchText,
                        pageSize: CONTENT_ITEMS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.removeAssociation.node.content,
                    zeroBasedPageIndex,
                };
            },

            suggestedContentItems: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }

                return this._suggestedContentForContentCollectionGQL
                    .fetch(
                        {
                            contentCollectionId,
                            searchText: value,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            usersPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._contentCollectionDetailsUsersGQL
                    .fetch(
                        {
                            contentCollectionId,
                            searchText,
                            pageSize: USERS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const contentCollectionNode = result.data.node;
                if (!contentCollectionNode) {
                    throw new Error();
                }
                return {
                    ...contentCollectionNode.users,
                    zeroBasedPageIndex,
                };
            },

            addUser: async ({ userId, zeroBasedPageIndex, searchText }) => {
                const result = await this._addUserToContentCollectionGQL
                    .mutate({
                        contentCollectionId,
                        userId,
                        searchText,
                        pageSize: USERS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.addAssociation.node.users,
                    zeroBasedPageIndex,
                };
            },

            removeUser: async ({ userId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeUserFromContentCollectionGQL
                    .mutate({
                        contentCollectionId,
                        userId,
                        searchText,
                        pageSize: USERS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.removeAssociation.node.users,
                    zeroBasedPageIndex,
                };
            },

            suggestedUsers: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }

                return this._suggestedUsersForContentCollectionGQL
                    .fetch(
                        {
                            contentCollectionId,
                            searchText: value,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },
        };
    }
}
