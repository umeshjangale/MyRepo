export interface ContentCollectionDetailsParameters {
    contentCollectionId: string;
}
