import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule, MatCheckboxModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatTableModule } from "@angular/material";

import { ConfirmationDialogModule } from "../confirmation.dialog/dialog.module";
import { ItemSelectionByTextSearchDialogModule } from "../item-selection-by-text-search.dialog/dialog.module";
import { MessageServiceModule } from "../message.service/module";
import { NotYetImplementedDirectivesModule } from "../not-yet-implemented.directives/directives.module";
import { PanelModule } from "../panel.component/module";
import { SearchTextModule } from "../search-text.component/search-text.module";
import { StandardPageModule } from "../standard-page.component/module";
import { TableDirectivesModule } from "../table.directives/directives.module";
import { UsabilityDirectivesModule } from "../usability.directives/directives.module";

import { PageRoutingModule } from "./page-routing.module";
import { PageComponent } from "./page.component";

@NgModule({
    imports: [
        CommonModule,
        ConfirmationDialogModule,
        ItemSelectionByTextSearchDialogModule,
        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatCheckboxModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatTableModule,
        MessageServiceModule,
        NotYetImplementedDirectivesModule,
        StandardPageModule,
        PageRoutingModule,
        PanelModule,
        ReactiveFormsModule,
        TableDirectivesModule,
        UsabilityDirectivesModule,
        SearchTextModule,
    ],
    declarations: [
        PageComponent,
    ],
})
export class ContentCollectionDetailsPageModule { }
