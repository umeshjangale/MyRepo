import { Injectable } from "@angular/core";
import { MatDialog } from "@angular/material";

import { DialogData } from "./dialog-data";
import { DialogComponent } from "./dialog.component";

@Injectable()
export class ViewMetadataDialogOpener {
    constructor(
        private readonly _matDialog: MatDialog,
    ) {
    }

    async openDialog(dialogData: DialogData): Promise<true | undefined> {
        const dialogRef = this._matDialog.open<DialogComponent, DialogData, true>(DialogComponent, {
            width: "460px",
            data: dialogData,
        });

        return dialogRef.afterClosed()
            .toPromise();
    }
}
