export interface DialogData {
    title: string;
    items: Array<{
        key: string;
        value: string;
    }>;
}
