import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { MatButtonModule, MatDialogModule } from "@angular/material";

import { ViewMetadataDialogOpener } from "./dialog-opener.service";
import { DialogComponent } from "./dialog.component";

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatDialogModule,
    ],
    declarations: [
        DialogComponent,
    ],
    providers: [
        ViewMetadataDialogOpener,
    ],
    entryComponents: [
        DialogComponent,
    ],
})
export class ViewMetadataDialogModule { }
