import { Observable } from "rxjs";

import { ContentAccessSource, RoleType } from "../../generated/graphql";

export interface DataIO {
    initial: {
        organisationId: string | undefined;
        currentUser: CurrentUser;
        user: User;
        content: Page<ContentAccessDetails>;
        userGroups: Page<UserGroup>;
        contentCollections: Page<ContentCollection>;
        contentItemsPerPage: number;
        userGroupsPerPage: number;
        contentCollectionsPerPage: number;
    };
    contentListPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentAccessDetails>>;
    userGroupsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    contentCollectionsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    contentUserGroupsPageOne(parameters: { contentId: string }): Promise<Page<ContentUserGroup>>;
    contentContentCollectionsPageOne(parameters: { contentId: string }): Promise<Page<ContentContentCollection>>;
    addUserToContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentAccessDetails>>;
    removeUserFromContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentAccessDetails>>;
    addUserToUserGroup(parameters: { userGroupId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    removeUserFromUserGroup(parameters: { userGroupId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    addUserToContentCollection(parameters: { contentCollectionId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    removeUserFromContentCollection(parameters: { contentCollectionId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    suggestedContent(parameters: { value: string }): Observable<SuggestedContent[]>;
    suggestedUserGroups(parameters: { value: string }): Observable<SuggestedUserGroup[]>;
    suggestedContentCollections(parameters: { value: string }): Observable<SuggestedContentCollection[]>;
    updateUser(parameters: { firstName: string | undefined; lastName: string | undefined }): Promise<User>;
    grantOrganisationContentUploaderRole(): Promise<User>;
    revokeOrganisationContentUploaderRole(): Promise<User>;
}

export interface UserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly users: {
        readonly totalCount: number;
    };
}

export interface ContentUserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface SuggestedUserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface ContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly content: {
        readonly totalCount: number;
    };
}

export interface ContentContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface SuggestedContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface CurrentUser {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly roles: Array<{
        type: RoleType;
        organisation?: { id: string } | null;
    }>;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly roles: Array<{
        readonly type: RoleType;
        readonly organisation: {
            readonly id: string;
            readonly name: string;
        } | null;
    }>;
    readonly contentReportUri: string;
}

export interface ContentAccessDetails {
    readonly content: {
        readonly id: string;
        readonly title: string;
        readonly subtitle: string;
        readonly author: string;
        readonly organisation: {
            readonly name: string;
        };
    };
    readonly sources: Array<{
        readonly source: ContentAccessSource;
    }>;
}

export interface SuggestedContent {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
    readonly author: string;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
