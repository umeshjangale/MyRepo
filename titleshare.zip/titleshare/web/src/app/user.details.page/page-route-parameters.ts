export interface UserDetailsParameters {
    organisationId: string | undefined;
    userId: string;
}
