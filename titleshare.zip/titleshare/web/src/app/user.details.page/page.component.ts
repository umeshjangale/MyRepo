import { Component, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatPaginator, PageEvent } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";

import { ContentAccessSource, RoleType } from "../../generated/graphql";
import { ConfirmationDialogOpener } from "../confirmation.dialog/dialog-opener.service";
import { ItemSelectionByTextSearchDialogOpener } from "../item-selection-by-text-search.dialog/dialog-opener.service";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { contentCollectionDetailsRoute, contentDetailsRoute, userGroupDetailsRoute } from "../routes";
import { SearchTextComponent, SearchTextEvent } from "../search-text.component/search-text.component";
import { labelForRoleTypes } from "../utils/role-type-labels";
import { userRolesWithinOrganisation } from "../utils/user-roles";

import { ContentAccessDetails, ContentCollection, CurrentUser, DataIO, Page, SuggestedContent, SuggestedContentCollection, SuggestedUserGroup, User, UserGroup } from "./data-io";

@Component({
    selector: "app-user-details-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: CurrentUser;
    user: User;
    organisationRole: string;
    contentAccessList: { page: Page<ContentAccessDetails>; pageSize: number; columns: string[] };
    userGroupList: { page: Page<UserGroup>; pageSize: number; columns: string[] };
    contentCollectionList: { page: Page<ContentCollection>; pageSize: number; columns: string[] };
    firstName = new FormControl("", Validators.required);
    lastName = new FormControl("", Validators.required);
    form = new FormGroup({
        firstName: this.firstName,
        lastName: this.lastName,
    });
    permissions: {
        canToggleContentUploaderRole: boolean;
    };
    hasContentUploaderRole: boolean;

    @ViewChild("contentFilter") contentFilter!: SearchTextComponent;
    @ViewChild("userGroupsFilter") userGroupsFilter!: SearchTextComponent;
    @ViewChild("contentCollectionsFilter") contentCollectionsFilter!: SearchTextComponent;

    @ViewChild(".code_contentPaginator") contentPaginator: MatPaginator | undefined;
    @ViewChild(".code_userGroupsPaginator") userGroupsPaginator: MatPaginator | undefined;
    @ViewChild(".code_contentCollectionsPaginator") contentCollectionsPaginator: MatPaginator | undefined;
    currentMenuItemsForContent: Array<{ id: string; name: string }> = [];

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _confirmationDialogOpener: ConfirmationDialogOpener,
        private readonly _itemSelectionByTextSearchDialogOpener: ItemSelectionByTextSearchDialogOpener,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.user = initial.user;
        const roleInfo = this._extractRoleInfo(initial.user, initial.organisationId);
        this.organisationRole = roleInfo.roleLabel;
        this.hasContentUploaderRole = roleInfo.hasContentUploaderRole;

        this.contentAccessList = {
            page: initial.content,
            pageSize: initial.contentItemsPerPage,
            columns: initial.organisationId ? ["title", "subtitle", "author", "actions"] : ["title", "subtitle", "author", "organisation", "actions"],
        };
        this.userGroupList = {
            page: initial.userGroups,
            pageSize: initial.userGroupsPerPage,
            columns: ["name", "description", "membersCount", "actions"],
        };
        this.contentCollectionList = {
            page: initial.contentCollections,
            pageSize: initial.contentCollectionsPerPage,
            columns: ["name", "description", "contentCount", "actions"],
        };

        const currentUserRoles = userRolesWithinOrganisation(this.currentUser.roles, initial.organisationId);
        this.permissions = {
            canToggleContentUploaderRole: (currentUserRoles.has(RoleType.SysAdmin) || currentUserRoles.has(RoleType.OrgContentUploader)) && !roleInfo.sysAdmin && roleInfo.hasOrgAdminRole,
        };
    }

    editValuesAction(panel: PanelComponent): void {
        this.firstName.setValue(this.user.firstName);
        this.lastName.setValue(this.user.lastName);
        panel.editing = true;
    }

    editingFieldsCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async editingFieldsSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const user = await this._dataIO.updateUser({
                firstName: this.firstName.value,
                lastName: this.lastName.value,
            });
            this.user = {
                ...this.user,
                ...user,
            };
            panel.editing = false;
            this._message.withInfo(`Updated details of user "${this.user.firstName} ${this.user.lastName}".`).showBriefly();
        } catch (e) {
            this._message.withError(`Failed to update details of user "${this.user.firstName} ${this.user.lastName}".`).showTillDismissed();
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }

    async toggleContentUploaderRole(panel: PanelComponent): Promise<void> {
        if (!this.permissions.canToggleContentUploaderRole) {
            return;
        }
        panel.busy = true;
        const granting = !this.hasContentUploaderRole;
        try {
            const user = granting ? await this._dataIO.grantOrganisationContentUploaderRole() : await this._dataIO.revokeOrganisationContentUploaderRole();
            this.user = {
                ...this.user,
                ...user,
            };
            const roleInfo = this._extractRoleInfo(this.user, this._dataIO.initial.organisationId);
            this.organisationRole = roleInfo.roleLabel;
            this.hasContentUploaderRole = roleInfo.hasContentUploaderRole;
            if (granting) {
                this._message.withInfo(`Granted the Content Uploader role to user "${this.user.firstName} ${this.user.lastName}".`).showBriefly();
            } else {
                this._message.withInfo(`Revoked the Content Uploader role from user "${this.user.firstName} ${this.user.lastName}".`).showBriefly();
            }
        } catch (e) {
            this._message.withError(`Failed to alter role for user "${this.user.firstName} ${this.user.lastName}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    hasDirectAccess(contentAccess: ContentAccessDetails) {
        return contentAccess.sources.some(x => x.source === ContentAccessSource.Direct);
    }

    hasGroupAccess(contentAccess: ContentAccessDetails) {
        return contentAccess.sources.some(x => x.source === ContentAccessSource.UserGroup);
    }

    hasContentCollectionAccess(contentAccess: ContentAccessDetails) {
        return contentAccess.sources.some(x => x.source === ContentAccessSource.ContentCollection);
    }

    async fetchUserGroupsForContentAction(contentAccess: ContentAccessDetails): Promise<void> {
        return this._setMenuItemsForContent(contentAccess, async () => this._dataIO.contentUserGroupsPageOne({ contentId: contentAccess.content.id }));
    }

    async fetchContentCollectionsForContentAction(contentAccess: ContentAccessDetails): Promise<void> {
        return this._setMenuItemsForContent(contentAccess, async () => this._dataIO.contentContentCollectionsPageOne({ contentId: contentAccess.content.id }));
    }

    async applyContentFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentAccessList.page = await this._dataIO.contentListPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentPaginator) {
                    this.contentPaginator.pageIndex = this.contentAccessList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content.").showBriefly();
            }
        });
    }

    async contentPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentAccessList.page = await this._dataIO.contentListPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentPaginator) {
                this.contentPaginator.pageIndex = this.contentAccessList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyUserGroupsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.userGroupList.page = await this._dataIO.userGroupsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.userGroupsPaginator) {
                    this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch user groups.").showBriefly();
            }
        });
    }

    async userGroupsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.userGroupsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.userGroupsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch user groups.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyContentCollectionsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentCollectionList.page = await this._dataIO.contentCollectionsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentCollectionsPaginator) {
                    this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content collections.").showBriefly();
            }
        });
    }

    async contentCollectionsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.contentCollectionsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentCollectionsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content collections.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async addContentAction(panel: PanelComponent): Promise<any> {
        const maybeContent = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedContent>({
            dialogTitle: "Grant Content Access",
            searchTextPlaceholder: "Search by title",
            filteredItems: text => this._dataIO.suggestedContent({ value: text }),
            displayableItem: item => ({ primaryLabel: item.title, secondaryLabel: item.author }),
        });
        if (maybeContent) {
            return this._addContent(maybeContent, this.contentPaginator ? this.contentPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentAction(contentAccess: ContentAccessDetails, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove Content Access",
            message: `Are you sure you want to remove this user's access from content "${contentAccess.content.title}" ? `,
            confirmButtonTitle: "Remove Access",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContent(contentAccess, this.contentPaginator ? this.contentPaginator.pageIndex : 0, panel);
        }
    }

    async addUserGroupAction(panel: PanelComponent): Promise<any> {
        const maybeUserGroup = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedUserGroup>({
            dialogTitle: "Add User to User Group",
            searchTextPlaceholder: "Search by name",
            filteredItems: text => this._dataIO.suggestedUserGroups({ value: text }),
            displayableItem: item => ({ primaryLabel: item.name, secondaryLabel: item.description }),
        });
        if (maybeUserGroup) {
            return this._addUserGroup(maybeUserGroup, this.userGroupsPaginator ? this.userGroupsPaginator.pageIndex : 0, panel);
        }
    }

    async removeUserGroupAction(userGroup: UserGroup, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove User Group",
            message: `Are you sure you want to remove this user from user group "${userGroup.name}" ? `,
            confirmButtonTitle: "Remove from User Group",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUserGroup(userGroup, this.userGroupsPaginator ? this.userGroupsPaginator.pageIndex : 0, panel);
        }
    }

    async addContentCollectionAction(panel: PanelComponent): Promise<any> {
        const maybeContentCollection = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedContentCollection>({
            dialogTitle: "Add User Access to Content Collection",
            searchTextPlaceholder: "Search by name",
            filteredItems: text => this._dataIO.suggestedContentCollections({ value: text }),
            displayableItem: item => ({ primaryLabel: item.name, secondaryLabel: item.description }),
        });
        if (maybeContentCollection) {
            return this._addContentCollection(maybeContentCollection, this.contentCollectionsPaginator ? this.contentCollectionsPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentCollectionAction(contentCollection: ContentCollection, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove Content Collection Access",
            message: `Are you sure you want to remove this user's access from content collection "${contentCollection.name}" ? `,
            confirmButtonTitle: "Remove Access",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContentCollection(contentCollection, this.contentCollectionsPaginator ? this.contentCollectionsPaginator.pageIndex : 0, panel);
        }
    }

    gotoContentAction(contentAccess: ContentAccessDetails): void {
        this._router.navigate(contentDetailsRoute.commands({ contentId: contentAccess.content.id }))
            .catch(e => console.error(e));
    }

    gotoUserGroupAction(userGroup: UserGroup): void {
        this._router.navigate(userGroupDetailsRoute.commands({ userGroupId: userGroup.id }))
            .catch(e => console.error(e));
    }

    gotoUserGroupForContentAction(userGroup: { id: string }, contentAccess: ContentAccessDetails): void {

        // See this._setMenuItemsForUser for special id values.
        switch (userGroup.id) {
            case "error":
                return;
            case "ellipsis":
                this._router.navigate(contentDetailsRoute.commands({ contentId: contentAccess.content.id }))
                    .catch(e => console.error(e));
                break;
            default:
                this._router.navigate(userGroupDetailsRoute.commands({ userGroupId: userGroup.id }))
                    .catch(e => console.error(e));
        }
    }

    gotoContentCollectionAction(contentCollection: ContentCollection): void {
        this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: contentCollection.id }))
            .catch(e => console.error(e));
    }

    gotoContentCollectionForContentAction(contentCollection: { id: string }, contentAccess: ContentAccessDetails): void {

        // See this._setMenuItemsForUser for special id values.
        switch (contentCollection.id) {
            case "error":
                return;
            case "ellipsis":
                this._router.navigate(contentDetailsRoute.commands({ contentId: contentAccess.content.id }))
                    .catch(e => console.error(e));
                break;
            default:
                this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: contentCollection.id }))
                    .catch(e => console.error(e));
        }
    }

    private async _addUserGroup(userGroup: SuggestedUserGroup, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.addUserToUserGroup({ userGroupId: userGroup.id, zeroBasedPageIndex, searchText: this.userGroupsFilter.value });
            this._message.withInfo(`Added user "${this.user.firstName} ${this.user.lastName}" to user group "${userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user "${this.user.firstName} ${this.user.lastName}" to user group "${userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshUserContent();
        }
    }

    private async _removeUserGroup(userGroup: UserGroup, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.removeUserFromUserGroup({ userGroupId: userGroup.id, zeroBasedPageIndex, searchText: this.userGroupsFilter.value });
            this._message.withInfo(`Removed user "${this.user.firstName} ${this.user.lastName}" from user group "${userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${this.user.firstName} ${this.user.lastName}" from user group "${userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshUserContent();
        }
    }

    private async _addContent(content: SuggestedContent, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentAccessList.page = await this._dataIO.addUserToContent({ contentId: content.id, zeroBasedPageIndex, searchText: this.contentFilter.value });
            this._message.withInfo(`Added user "${this.user.firstName} ${this.user.lastName}" access to content "${content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentPaginator) {
                this.contentPaginator.pageIndex = this.contentAccessList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user "${this.user.firstName} ${this.user.lastName}" access to content "${content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeContent(contentAccess: ContentAccessDetails, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentAccessList.page = await this._dataIO.removeUserFromContent({ contentId: contentAccess.content.id, zeroBasedPageIndex, searchText: this.contentFilter.value });
            this._message.withInfo(`Removed user "${this.user.firstName} ${this.user.lastName}" access from content "${contentAccess.content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentPaginator) {
                this.contentPaginator.pageIndex = this.contentAccessList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${this.user.firstName} ${this.user.lastName}" access from content "${contentAccess.content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _addContentCollection(contentCollection: SuggestedContentCollection, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.addUserToContentCollection({ contentCollectionId: contentCollection.id, zeroBasedPageIndex, searchText: this.contentCollectionsFilter.value });
            this._message.withInfo(`Added user "${this.user.firstName} ${this.user.lastName}" access to content collection "${contentCollection.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentAccessList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user "${this.user.firstName} ${this.user.lastName}" access to content collection "${contentCollection.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshUserContent();
        }
    }

    private async _removeContentCollection(contentCollection: ContentCollection, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.removeUserFromContentCollection({ contentCollectionId: contentCollection.id, zeroBasedPageIndex, searchText: this.contentCollectionsFilter.value });
            this._message.withInfo(`Removed user "${this.user.firstName} ${this.user.lastName}" access from content collection "${contentCollection.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${this.user.firstName} ${this.user.lastName}" access from content collection "${contentCollection.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshUserContent();
        }
    }

    private async _refreshUserContent() {
        try {
            this.contentAccessList.page = await this._dataIO.contentListPage({ zeroBasedPageIndex: this.contentAccessList.page.zeroBasedPageIndex, searchText: this.contentFilter.value });
        } catch (e) {
            this._message.withError("Failed to refresh list of accessible content.").showBriefly();
        }
    }

    private async _setMenuItemsForContent(contentAccess: ContentAccessDetails, dataFetcher: () => Promise<Page<{ id: string; name: string }>>) {
        this.currentMenuItemsForContent = [];

        try {
            const page = await dataFetcher();

            const displayCount = 4;
            if (page.totalCount <= displayCount) {
                this.currentMenuItemsForContent = page.items;
                return;
            }

            const items = page.items.slice(0, displayCount - 1);
            items.push({
                id: "ellipsis",
                name: `Plus ${page.totalCount - displayCount + 1} more...`,
            });

            this.currentMenuItemsForContent = items;

        } catch (e) {
            this._message.withError(`Failed to fetch data for content "${contentAccess.content.title}".`).showBriefly();
            this.currentMenuItemsForContent = [{
                id: "error",
                name: "Error...",
            }];
        }
    }

    private _extractRoleInfo(user: User, organisationId: string | undefined): { sysAdmin: boolean; hasOrgAdminRole: boolean; hasContentUploaderRole: boolean; roleLabel: string } {
        const roles = userRolesWithinOrganisation(user.roles, organisationId);
        return {
            sysAdmin: roles.has(RoleType.SysAdmin),
            hasOrgAdminRole: roles.has(RoleType.OrgAdmin),
            hasContentUploaderRole: roles.has(RoleType.OrgContentUploader),
            roleLabel: labelForRoleTypes(roles),
        };
    }
}
