import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map, mergeMap, take } from "rxjs/operators";

import { AddAssociationGQL, RemoveAssociationGQL, RoleType, SuggestedContentCollectionsForUserGQL, SuggestedContentForUserGQL, SuggestedUserGroupsForUserGQL, UserDetailsContentCollectionsGQL, UserDetailsContentContentCollectionsGQL, UserDetailsContentGQL, UserDetailsContentUserGroupsGQL, UserDetailsGrantSpecialisedOrganisationAdminRoleGQL, UserDetailsInitialDataGQL, UserDetailsRevokeSpecialisedOrganisationAdminRoleGQL, UserDetailsUpdateUserGQL, UserDetailsUserGroupsGQL } from "../../generated/graphql";
import { userDetailsRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

const CONTENT_PER_PAGE = 5;
const USER_GROUPS_PER_PAGE = 5;
const CONTENT_COLLECTIONS_PER_PAGE = 5;

const CONTENT_USER_GROUPS_PER_PAGE = 5;
const CONTENT_CONTENT_COLLECTIONS_PER_PAGE = 5;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _userDetailsInitialDataGQL: UserDetailsInitialDataGQL,
        private readonly _userDetailsContentGQL: UserDetailsContentGQL,
        private readonly _userDetailsUserGroupsGQL: UserDetailsUserGroupsGQL,
        private readonly _userDetailsContentCollectionsGQL: UserDetailsContentCollectionsGQL,
        private readonly _userDetailsContentUserGroupsGQL: UserDetailsContentUserGroupsGQL,
        private readonly _userDetailsContentContentCollectionsGQL: UserDetailsContentContentCollectionsGQL,
        private readonly _userDetailsGrantSpecialisedOrganisationAdminRoleGQL: UserDetailsGrantSpecialisedOrganisationAdminRoleGQL,
        private readonly _userDetailsRevokeSpecialisedOrganisationAdminRoleGQL: UserDetailsRevokeSpecialisedOrganisationAdminRoleGQL,
        private readonly _addAssociationGQL: AddAssociationGQL,
        private readonly _removeAssociationGQL: RemoveAssociationGQL,
        private readonly _suggestedContentForUserGQL: SuggestedContentForUserGQL,
        private readonly _suggestedUserGroupsForUserGQL: SuggestedUserGroupsForUserGQL,
        private readonly _suggestedContentCollectionsForUserGQL: SuggestedContentCollectionsForUserGQL,
        private readonly _updateUser: UserDetailsUpdateUserGQL,
        private readonly _resolverTools: ResolverTools,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        const { userId, organisationId } = userDetailsRoute.parameters(route.paramMap);
        return this._userDetailsInitialDataGQL
            .fetch({
                userId,
                organisationId,
                contentPageSize: CONTENT_PER_PAGE,
                userGroupsPageSize: USER_GROUPS_PER_PAGE,
                contentCollectionsPageSize: CONTENT_COLLECTIONS_PER_PAGE,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    const data = result.data;
                    if (data.node) {
                        return of(this._createDataIO(
                            {
                                currentUser: data.me,
                                user: data.node,
                                content: {
                                    ...data.node.content,
                                    zeroBasedPageIndex: 0,
                                },
                                userGroups: {
                                    ...data.node.userGroups,
                                    zeroBasedPageIndex: 0,
                                },
                                contentCollections: {
                                    ...data.node.contentCollections,
                                    zeroBasedPageIndex: 0,
                                },
                                contentItemsPerPage: CONTENT_PER_PAGE,
                                userGroupsPerPage: USER_GROUPS_PER_PAGE,
                                contentCollectionsPerPage: CONTENT_COLLECTIONS_PER_PAGE,
                                organisationId,
                            },
                            userId,
                            organisationId,
                        ));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"], userId: string, organisationId: string | undefined): DataIO {
        const contentListPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._userDetailsContentGQL
                .fetch(
                    {
                        userId,
                        searchText,
                        organisationId,
                        pageSize: CONTENT_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                return { items: [], totalCount: 0, zeroBasedPageIndex };
            }

            return {
                ...data.node.content,
                zeroBasedPageIndex,
            };
        };

        const userGroupsPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._userDetailsUserGroupsGQL
                .fetch(
                    {
                        userId,
                        organisationId,
                        searchText,
                        pageSize: USER_GROUPS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                return { items: [], totalCount: 0, zeroBasedPageIndex };
            }

            return {
                ...data.node.userGroups,
                zeroBasedPageIndex,
            };
        };

        const contentCollectionsPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._userDetailsContentCollectionsGQL
                .fetch(
                    {
                        userId,
                        organisationId,
                        searchText,
                        pageSize: CONTENT_COLLECTIONS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                return { items: [], totalCount: 0, zeroBasedPageIndex };
            }

            return {
                ...data.node.contentCollections,
                zeroBasedPageIndex,
            };
        };

        return {
            initial,

            contentListPage: async ({ zeroBasedPageIndex, searchText }) => contentListPage({ zeroBasedPageIndex, searchText }),
            userGroupsPage: async ({ zeroBasedPageIndex, searchText }) => userGroupsPage({ zeroBasedPageIndex, searchText }),
            contentCollectionsPage: async ({ zeroBasedPageIndex, searchText }) => contentCollectionsPage({ zeroBasedPageIndex, searchText }),

            contentUserGroupsPageOne: async ({ contentId }) => {
                const result = await this._userDetailsContentUserGroupsGQL
                    .fetch(
                        {
                            contentId,
                            userId,
                            pageSize: CONTENT_USER_GROUPS_PER_PAGE,
                            oneBasedPageNumber: 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                return {
                    ...result.data.contentAccessReasons.userGroups,
                    zeroBasedPageIndex: 0,
                };
            },

            contentContentCollectionsPageOne: async ({ contentId }) => {
                const result = await this._userDetailsContentContentCollectionsGQL
                    .fetch(
                        {
                            contentId,
                            userId,
                            pageSize: CONTENT_CONTENT_COLLECTIONS_PER_PAGE,
                            oneBasedPageNumber: 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                return {
                    ...result.data.contentAccessReasons.contentCollections,
                    zeroBasedPageIndex: 0,
                };
            },

            addUserToContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch content users
                await this._addAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: contentId,
                    })
                    .toPromise();
                return contentListPage({ zeroBasedPageIndex, searchText });
            },

            removeUserFromContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch content users
                await this._removeAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: contentId,
                    })
                    .toPromise();
                return contentListPage({ zeroBasedPageIndex, searchText });
            },

            addUserToUserGroup: async ({ userGroupId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch content users
                await this._addAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: userGroupId,
                    })
                    .toPromise();
                return userGroupsPage({ zeroBasedPageIndex, searchText });
            },

            removeUserFromUserGroup: async ({ userGroupId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch content users
                await this._removeAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: userGroupId,
                    })
                    .toPromise();
                return userGroupsPage({ zeroBasedPageIndex, searchText });
            },

            addUserToContentCollection: async ({ contentCollectionId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch content users
                await this._addAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: contentCollectionId,
                    })
                    .toPromise();
                return contentCollectionsPage({ zeroBasedPageIndex, searchText });
            },

            removeUserFromContentCollection: async ({ contentCollectionId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch content users
                await this._removeAssociationGQL
                    .mutate({
                        id: userId,
                        associateId: contentCollectionId,
                    })
                    .toPromise();
                return contentCollectionsPage({ zeroBasedPageIndex, searchText });
            },

            suggestedContent: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }
                const lowerValue = value.toLowerCase();
                return this._suggestedContentForUserGQL
                    .fetch(
                        {
                            userId: initial.user.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            suggestedUserGroups: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }
                const lowerValue = value.toLowerCase();
                return this._suggestedUserGroupsForUserGQL
                    .fetch(
                        {
                            userId: initial.user.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            suggestedContentCollections: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }
                const lowerValue = value.toLowerCase();
                return this._suggestedContentCollectionsForUserGQL
                    .fetch(
                        {
                            userId: initial.user.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            updateUser: async ({ firstName, lastName }) => {
                const result = await this._updateUser.mutate({
                    userId: initial.user.id,
                    firstName,
                    lastName,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...initial.user,
                    ...data.updateUser,
                };
            },

            grantOrganisationContentUploaderRole: async () => {
                if (!organisationId) {
                    throw new Error();
                }
                const result = await this._userDetailsGrantSpecialisedOrganisationAdminRoleGQL.mutate({
                    input: {
                        organisationId,
                        roleType: RoleType.OrgContentUploader,
                        userId,
                    },
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...initial.user,
                    ...data.grantUserSpecialisedOrganisationAdminRole.user,
                };
            },

            revokeOrganisationContentUploaderRole: async () => {
                if (!organisationId) {
                    throw new Error();
                }
                const result = await this._userDetailsRevokeSpecialisedOrganisationAdminRoleGQL.mutate({
                    input: {
                        organisationId,
                        roleType: RoleType.OrgContentUploader,
                        userId,
                    },
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...initial.user,
                    ...data.revokeUserSpecialisedOrganisationAdminRole.user,
                };
            },
        };
    }
}
