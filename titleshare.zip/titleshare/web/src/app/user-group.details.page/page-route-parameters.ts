export interface UserGroupDetailsParameters {
    userGroupId: string;
}
