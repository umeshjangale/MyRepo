import { Component, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatPaginator, PageEvent } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";

import { DataIOCommonServiceResolver } from "../common/data-io-resolver.service";
import { ConfirmationDialogOpener } from "../confirmation.dialog/dialog-opener.service";
import { ItemSelectionByTextSearchDialogOpener } from "../item-selection-by-text-search.dialog/dialog-opener.service";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { contentDetailsRoute, userDetailsRoute } from "../routes";
import { SearchTextComponent, SearchTextEvent } from "../search-text.component/search-text.component";

import { Content, DataIO, Page, User, UserGroup } from "./data-io";

@Component({
    selector: "app-user-group-details-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User;
    userGroup: UserGroup;
    name = new FormControl("", Validators.required);
    description = new FormControl("");
    form = new FormGroup({
        name: this.name,
        description: this.description,
    });
    userList: { page: Page<User>; pageSize: number; columns: string[] };
    contentList: { page: Page<Content>; pageSize: number; columns: string[] };

    @ViewChild("usersFilter") usersFilter!: SearchTextComponent;
    @ViewChild("contentFilter") contentFilter!: SearchTextComponent;

    @ViewChild(".code_userListPaginator") usersPaginator: MatPaginator | undefined;
    @ViewChild(".code_contentListPaginator") contentItemsPaginator: MatPaginator | undefined;

    private readonly _dataIO: DataIO = null as any;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _confirmationDialogOpener: ConfirmationDialogOpener,
        private readonly _itemSelectionByTextSearchDialogOpener: ItemSelectionByTextSearchDialogOpener,
        private readonly _message: Message,
        private readonly _router: Router,
        private readonly _dataIOCommonServiceResolver: DataIOCommonServiceResolver,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.userGroup = initial.userGroup;
        this.userList = {
            page: initial.users,
            pageSize: initial.usersPerPage,
            columns: ["firstName", "lastName", "email", "actions"],
        };
        this.contentList = {
            page: initial.contentItems,
            pageSize: initial.contentItemsPerPage,
            columns: ["title", "subtitle", "author", "actions"],
        };
    }

    editValuesAction(panel: PanelComponent): void {
        this.name.setValue(this.userGroup.name);
        this.description.setValue(this.userGroup.description);
        panel.editing = true;
    }

    editingFieldsCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async editingFieldsSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.form.valid) {
            return;
        }
        panel.busy = true;
        this.form.disable();
        try {
            const userGroup = await this._dataIO.updateUserGroup({
                name: this.name.value,
                description: this.description.value,
            });
            this.userGroup = {
                ...this.userGroup,
                ...userGroup,
            };
            panel.editing = false;
            this._message.withInfo(`Updated details of group "${this.userGroup.name}".`).showBriefly();
        } catch (e) {
            this._message.withError(`Failed to update details of group "${this.userGroup.name}".`).showTillDismissed();
        } finally {
            this.form.enable();
            panel.busy = false;
        }
    }

    async applyUsersFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.userList.page = await this._dataIO.usersPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.usersPaginator) {
                    this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch users.").showBriefly();
            }
        });
    }

    async userListPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userList.page = await this._dataIO.usersPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.usersFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.usersPaginator) {
                this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch users.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyContentFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentList.page = await this._dataIO.contentItemsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentItemsPaginator) {
                    this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content.").showBriefly();
            }
        });
    }

    async contentListPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentList.page = await this._dataIO.contentItemsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentItemsPaginator) {
                this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    gotoContentAction(content: Content): void {
        this._router.navigate(contentDetailsRoute.commands({ contentId: content.id }))
            .catch(e => console.error(e));
    }

    gotoUserAction(user: User): void {
        this._router.navigate(userDetailsRoute.commands({ userId: user.id, organisationId: this.userGroup.organisation.id }))
            .catch(e => console.error(e));
    }

    async addUserAction(panel: PanelComponent): Promise<any> {
        const maybeUser = await this._itemSelectionByTextSearchDialogOpener.openDialog<User>({
            dialogTitle: "Add User To User Group",
            searchTextPlaceholder: "Search by first or last name",
            filteredItems: text => this._dataIO.suggestedUsers({ value: text }),
            displayableItem: item => ({ primaryLabel: `${item.firstName} ${item.lastName}`, secondaryLabel: item.email }),
        });
        if (maybeUser) {
            return this._addUser(maybeUser, this.usersPaginator ? this.usersPaginator.pageIndex : 0, panel);
        }
    }

    async removeUserAction(user: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove User",
            message: `Are you sure you want to remove user "${user.firstName} ${user.lastName}" from this group?`,
            confirmButtonTitle: "Remove User",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUser(user, this.usersPaginator ? this.usersPaginator.pageIndex : 0, panel);
        }
    }

    async resetPasswordAction(sysAdmin: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Reset user group member Password",
            message: `Are you sure you want to reset password for user "${sysAdmin.firstName} ${sysAdmin.lastName}"?`,
            confirmButtonTitle: "Reset Password",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._requestResetPassword(sysAdmin, panel);
        }
    }

    async addContentAction(panel: PanelComponent): Promise<any> {
        const maybeContent = await this._itemSelectionByTextSearchDialogOpener.openDialog<Content>({
            dialogTitle: "Add Content To User Group",
            searchTextPlaceholder: "Search by title",
            filteredItems: text => this._dataIO.suggestedContent({ value: text }),
            displayableItem: item => ({ primaryLabel: item.subtitle ? `${item.title} - ${item.subtitle}` : item.title, secondaryLabel: item.author }),
        });
        if (maybeContent) {
            return this._addContent(maybeContent, this.contentItemsPaginator ? this.contentItemsPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentAction(content: Content, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove Content",
            message: `Are you sure you want to remove content "${content.title}" from this group?`,
            confirmButtonTitle: "Remove Content",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContent(content, this.contentItemsPaginator ? this.contentItemsPaginator.pageIndex : 0, panel);
        }
    }

    private async _requestResetPassword(sysAdmin: User, panel: PanelComponent): Promise<void> {
        panel.busy = true;

        this._dataIOCommonServiceResolver.requestResetPassword(sysAdmin.email)
            .then(x => {
                this._message.withInfo(`Reset password request sent for user "${sysAdmin.firstName} ${sysAdmin.lastName}"`).showBriefly();
            })
            .catch(x => this._message.withError(`Failed to send request to reset password for "${sysAdmin.firstName} ${sysAdmin.lastName}".`).showTillDismissed());

        panel.busy = false;
    }

    private async _addUser(user: User, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userList.page = await this._dataIO.addUser({ userId: user.id, zeroBasedPageIndex, searchText: this.usersFilter.value });
            this._message.withInfo(`Added user "${user.firstName} ${user.lastName}" to group "${this.userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.usersPaginator) {
                this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user "${user.firstName} ${user.lastName}" to group "${this.userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeUser(user: User, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userList.page = await this._dataIO.removeUser({ userId: user.id, zeroBasedPageIndex, searchText: this.usersFilter.value });
            this._message.withInfo(`Removed user "${user.firstName} ${user.lastName}" from group "${this.userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.usersPaginator) {
                this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${user.firstName} ${user.lastName}" from group "${this.userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _addContent(content: Content, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentList.page = await this._dataIO.addContent({ contentId: content.id, zeroBasedPageIndex, searchText: this.contentFilter.value });
            this._message.withInfo(`Added content "${content.title}" to group "${this.userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentItemsPaginator) {
                this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add content "${content.title}" to group "${this.userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeContent(content: Content, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentList.page = await this._dataIO.removeContent({ contentId: content.id, zeroBasedPageIndex, searchText: this.contentFilter.value });
            this._message.withInfo(`Removed content "${content.title}" from group "${this.userGroup.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentItemsPaginator) {
                this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove content "${content.title}" from group "${this.userGroup.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }
}
