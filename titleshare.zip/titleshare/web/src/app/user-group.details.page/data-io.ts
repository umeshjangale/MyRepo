import { Observable } from "rxjs";

export interface DataIO {
    readonly initial: {
        readonly currentUser: User;
        readonly userGroup: UserGroup;
        readonly users: Page<User>;
        readonly contentItems: Page<Content>;
        readonly usersPerPage: number;
        readonly contentItemsPerPage: number;
    };
    updateUserGroup(parameters: { name: string; description: string }): Promise<UserGroup>;
    usersPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    contentItemsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    addUser(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    removeUser(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    suggestedUsers(parameters: { value: string }): Observable<User[]>;
    addContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    removeContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    suggestedContent(parameters: { value: string }): Observable<Content[]>;
}

export interface UserGroup {
    readonly name: string;
    readonly description: string;
    readonly organisation: {
        readonly id: string;
        readonly name: string;
    };
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}

export interface Content {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
    readonly author: string;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
