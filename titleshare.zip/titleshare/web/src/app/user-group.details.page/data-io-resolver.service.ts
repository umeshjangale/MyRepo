import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map, mergeMap, take } from "rxjs/operators";

import { AddContentToUserGroupGQL, AddUserToUserGroup, AddUserToUserGroupGQL, RemoveContentFromUserGroupGQL, RemoveUserFromUserGroup, RemoveUserFromUserGroupGQL, SuggestedContentForAddingToUserGroupGQL, SuggestedUsersForAddingToUserGroupGQL, UpdateUserGroup, UpdateUserGroupGQL, UserGroupDetailsContentItemsGQL, UserGroupDetailsInitialDataGQL, UserGroupDetailsUsersGQL } from "../../generated/graphql";
import { userGroupDetailsRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

const USERS_PER_PAGE = 5;
const CONTENT_ITEMS_PER_PAGE = 5;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _addUserToUserGroupGQL: AddUserToUserGroupGQL,
        private readonly _removeUserFromUserGroupGQL: RemoveUserFromUserGroupGQL,
        private readonly _addContentToUserGroupGQL: AddContentToUserGroupGQL,
        private readonly _removeContentFromUserGroupGQL: RemoveContentFromUserGroupGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _suggestedUsersForAddingToUserGroupGQL: SuggestedUsersForAddingToUserGroupGQL,
        private readonly _suggestedContentForAddingToUserGroupGQL: SuggestedContentForAddingToUserGroupGQL,
        private readonly _updateUserGroupGQL: UpdateUserGroupGQL,
        private readonly _userGroupDetailsInitialDataGQL: UserGroupDetailsInitialDataGQL,
        private readonly _userGroupDetailsUsersGQL: UserGroupDetailsUsersGQL,
        private readonly _userGroupDetailsContentItemsGQL: UserGroupDetailsContentItemsGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        const { userGroupId } = userGroupDetailsRoute.parameters(route.paramMap);
        return this._userGroupDetailsInitialDataGQL
            .fetch({
                userGroupId,
                usersPageSize: USERS_PER_PAGE,
                contentItemsPageSize: CONTENT_ITEMS_PER_PAGE,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.node) {
                        return of(this._createDataIO(
                            {
                                currentUser: result.data.me,
                                users: {
                                    ...result.data.node.users,
                                    zeroBasedPageIndex: 0,
                                },
                                contentItems: {
                                    ...result.data.node.content,
                                    zeroBasedPageIndex: 0,
                                },
                                usersPerPage: USERS_PER_PAGE,
                                contentItemsPerPage: CONTENT_ITEMS_PER_PAGE,
                                userGroup: result.data.node,
                            },
                            userGroupId,
                        ));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"], userGroupId: string): DataIO {
        return {
            initial,

            updateUserGroup: async ({ name, description }) => {
                const result = await this._updateUserGroupGQL
                    .mutate({
                        group: {
                            id: userGroupId,
                            name,
                            description,
                        },
                    })
                    .toPromise();
                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...initial.userGroup,
                    ...data.updateUserGroup,
                };
            },

            usersPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._userGroupDetailsUsersGQL
                    .fetch(
                        {
                            userGroupId,
                            searchText,
                            pageSize: USERS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const userGroupNode = result.data.node;
                if (!userGroupNode) {
                    throw new Error();
                }
                return {
                    ...userGroupNode.users,
                    zeroBasedPageIndex,
                };
            },

            contentItemsPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._userGroupDetailsContentItemsGQL
                    .fetch(
                        {
                            userGroupId,
                            searchText,
                            pageSize: CONTENT_ITEMS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const userGroupNode = result.data.node;
                if (!userGroupNode) {
                    throw new Error();
                }
                return {
                    ...userGroupNode.content,
                    zeroBasedPageIndex,
                };
            },

            addUser: async ({ userId, zeroBasedPageIndex, searchText }) => {
                const result = await this._addUserToUserGroupGQL
                    .mutate({
                        userGroupId,
                        userId,
                        searchText,
                        pageSize: USERS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.addAssociation.node.users,
                    zeroBasedPageIndex,
                };
            },

            removeUser: async ({ userId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeUserFromUserGroupGQL
                    .mutate({
                        userGroupId,
                        userId,
                        searchText,
                        pageSize: USERS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.removeAssociation.node.users,
                    zeroBasedPageIndex,
                };
            },

            suggestedUsers: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }

                return this._suggestedUsersForAddingToUserGroupGQL
                    .fetch(
                        {
                            userGroupId,
                            searchText: value,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            addContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                const result = await this._addContentToUserGroupGQL
                    .mutate({
                        userGroupId,
                        contentId,
                        searchText,
                        pageSize: CONTENT_ITEMS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.addAssociation.node.content,
                    zeroBasedPageIndex,
                };
            },

            removeContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeContentFromUserGroupGQL
                    .mutate({
                        userGroupId,
                        contentId,
                        searchText,
                        pageSize: CONTENT_ITEMS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    ...data.removeAssociation.node.content,
                    zeroBasedPageIndex,
                };
            },

            suggestedContent: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }

                return this._suggestedContentForAddingToUserGroupGQL
                    .fetch(
                        {
                            userGroupId,
                            searchText: value,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },
        };
    }
}
