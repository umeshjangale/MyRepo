export interface UserGroupCreateParameters {
    organisationId?: string;
}
