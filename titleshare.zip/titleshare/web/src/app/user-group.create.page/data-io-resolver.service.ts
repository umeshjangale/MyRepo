import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { CreateUserGroup, CreateUserGroupGQL, UserGroupCreateInitialDataGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _createUserGroupGQL: CreateUserGroupGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _userGroupCreateInitialDataGQL: UserGroupCreateInitialDataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._userGroupCreateInitialDataGQL
            .fetch()
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.searchOrganisations) {
                        return of(this._createDataIO({
                            currentUser: result.data.me,
                            organisations: result.data.searchOrganisations.items,
                        }));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            createUserGroup: async ({ organisationId, name, description }) => {
                const result = await this._createUserGroupGQL
                    .mutate({
                        input: {
                            organisationId,
                            name,
                            description,
                        },
                    })
                    .toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return {
                    id: data.createUserGroup.id,
                };
            },
        };
    }
}
