export interface DataIO {
    readonly initial: {
        readonly currentUser: User;
        readonly organisations: ReadonlyArray<Organisation>;
    };
    createUserGroup(parameters: { organisationId: string; name: string; description: string }): Promise<{ id: string }>;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}

export interface Organisation {
    readonly id: string;
    readonly name: string;
}
