export interface DataIO {
    readonly initial: {
        readonly currentUser: User;
    };
    updateSelf(parameters: { firstName?: string; lastName?: string; currentPassword?: string; newPassword?: string }): Promise<User>;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}
