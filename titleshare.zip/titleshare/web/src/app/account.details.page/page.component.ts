import { Component, OnDestroy } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";

import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { matches } from "../utils/matches-validator";

import { DataIO, User } from "./data-io";

const MINIMUM_PASSWORD_LENGTH = 6;

@Component({
    selector: "app-account-details-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent implements OnDestroy {
    currentUser: User;

    firstName = new FormControl("", Validators.required);
    lastName = new FormControl("", Validators.required);
    fieldsForm = new FormGroup({
        firstName: this.firstName,
        lastName: this.lastName,
    });

    currentPassword = new FormControl("", Validators.required);
    newPassword = new FormControl("", [Validators.required, Validators.minLength(MINIMUM_PASSWORD_LENGTH)]);
    confirmNewPassword = new FormControl("", matches(this.newPassword));
    passwordForm = new FormGroup(
        {
            currentPassword: this.currentPassword,
            newPassword: this.newPassword,
            confirmNewPassword: this.confirmNewPassword,
        },
    );

    private readonly _subscriptions = new Subscription();
    private readonly _dataIO: DataIO = null as any;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _message: Message,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;

        this._subscriptions.add(this.newPassword.valueChanges.subscribe(() => {
            this.confirmNewPassword.updateValueAndValidity();
        }));
    }

    ngOnDestroy(): void {
        this._subscriptions.unsubscribe();
    }

    editValuesAction(panel: PanelComponent): void {
        this.firstName.setValue(this.currentUser.firstName);
        this.lastName.setValue(this.currentUser.lastName);
        panel.editing = true;
    }

    editingFieldsCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async editingFieldsSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.fieldsForm.valid) {
            return;
        }
        panel.busy = true;
        this.fieldsForm.disable();
        try {
            const user = await this._dataIO.updateSelf({
                firstName: this.firstName.value,
                lastName: this.lastName.value,
            });
            this.currentUser = user;
            panel.editing = false;
            this._message.withInfo("Updated account profile.").showBriefly();
        } catch (e) {
            this._message.withError("Failed to update account profile.").showTillDismissed();
        } finally {
            this.fieldsForm.enable();
            panel.busy = false;
        }
    }

    changePasswordAction(panel: PanelComponent): void {
        this.passwordForm.reset();
        panel.editing = true;
    }

    changingPasswordCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async changingPasswordSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.passwordForm.valid) {
            return;
        }
        panel.busy = true;
        this.passwordForm.disable();
        try {
            const user = await this._dataIO.updateSelf({
                currentPassword: this.currentPassword.value,
                newPassword: this.newPassword.value,
            });
            this.currentUser = user;
            panel.editing = false;
            this._message.withInfo("Updated account password.").showBriefly();
        } catch (e) {
            this._message.withError("Failed to update account password.").showTillDismissed();
        } finally {
            this.passwordForm.enable();
            panel.busy = false;
        }
    }
}
