import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { AccountDetailsInitialDataGQL, UpdateMe, UpdateMeGQL } from "../../generated/graphql";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _accountDetailsInitialDataGQL: AccountDetailsInitialDataGQL,
        private readonly _resolverTools: ResolverTools,
        private readonly _updateMeGQL: UpdateMeGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        return this._accountDetailsInitialDataGQL
            .fetch({
            })
            .pipe(
                take(1),
                // tslint:disable-next-line
                mergeMap(result => {
                    return of(this._createDataIO(
                        {
                            currentUser: result.data.me,
                        },
                    ));
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"]): DataIO {
        return {
            initial,

            updateSelf: async ({ firstName, lastName, currentPassword, newPassword }) => {
                const result = await this._updateMeGQL
                    .mutate({
                        input: {
                            firstName,
                            lastName,
                            currentPassword,
                            newPassword,
                        },
                    })
                    .toPromise();
                const data = result.data;
                if (!data) {
                    throw new Error();
                }
                return data.updateMe;
            },
        };
    }
}
