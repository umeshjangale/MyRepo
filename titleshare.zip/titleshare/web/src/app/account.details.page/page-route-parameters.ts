// tslint:disable-next-line
export interface AccountDetailsParameters {
}
