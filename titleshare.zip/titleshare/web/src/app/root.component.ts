import { Component, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";

import { routerNavigating } from "./utils/router-navigating";

// tslint:disable:component-selector
@Component({
    selector: "body",
    templateUrl: "./root.component.html",
    styleUrls: ["./root.component.scss"],
})
export class RootComponent implements OnDestroy {
    busy: boolean = false;

    private readonly _subscriptions: Subscription = new Subscription();

    constructor(
        router: Router,
    ) {
        this._subscriptions.add(
            router.events.pipe(routerNavigating)
                .subscribe(v => this.busy = v),
        );
    }

    ngOnDestroy(): void {
        this._subscriptions.unsubscribe();
    }
}
