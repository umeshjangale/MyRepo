import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { AccountDetailsPageModule } from "./account.details.page/page.module";
import { AccountLoginPageModule } from "./account.login.page/page.module";
import { AccountResetPasswordPageModule } from "./account.reset-password.page/page.module";
import { ContentCollectionCreatePageModule } from "./content-collection.create.page/page.module";
import { ContentCollectionDetailsPageModule } from "./content-collection.details.page/page.module";
import { ContentDetailsPageModule } from "./content.details.page/page.module";
import { ErrorNotFoundPageModule } from "./error.not-found.page/page.module";
import { InformationMobileAppsPageModule } from "./information.mobile-apps.page/page.module";
import { OrganisationCreatePageModule } from "./organisation.create.page/page.module";
import { OrganisationDetailsPageModule } from "./organisation.details.page/page.module";
import { accountDetailsRoute, accountLoginRoute, accountResetPasswordRoute, contentCollectionCreateRoute, contentCollectionDetailsRoute, contentDetailsRoute, informationMobileAppsRoute, informationPrivacyRoute, informationTermsRoute, organisationCreateRoute, organisationDetailsRoute, userDashboardRoute, userDetailsRoute, userGroupCreateRoute, userGroupDetailsRoute, userInviteRoute } from "./routes";
import { UserGroupCreatePageModule } from "./user-group.create.page/page.module";
import { UserGroupDetailsPageModule } from "./user-group.details.page/page.module";
import { UserDashboardPageModule } from "./user.dashboard.page/page.module";
import { UserDetailsPageModule } from "./user.details.page/page.module";
import { UserInvitePageModule } from "./user.invite.page/page.module";

const routes: Routes = [
    {
        path: "",
        redirectTo: accountLoginRoute.routerConfigPath,
        pathMatch: "full",
    },
    {
        path: userDashboardRoute.routerConfigPath,
        loadChildren: () => UserDashboardPageModule,
    },
    {
        path: informationMobileAppsRoute.routerConfigPath,
        loadChildren: () => InformationMobileAppsPageModule,
    },
    {
        path: informationPrivacyRoute.routerConfigPath,
        loadChildren: "./information.privacy.page/page.module#InformationPrivacyPageModule",
    },
    {
        path: informationTermsRoute.routerConfigPath,
        loadChildren: "./information.terms.page/page.module#InformationTermsPageModule",
    },
    {
        path: organisationCreateRoute.routerConfigPath,
        loadChildren: () => OrganisationCreatePageModule,
    },
    {
        path: organisationDetailsRoute.routerConfigPath,
        loadChildren: () => OrganisationDetailsPageModule,
    },
    {
        path: accountDetailsRoute.routerConfigPath,
        loadChildren: () => AccountDetailsPageModule,
    },
    {
        path: accountLoginRoute.routerConfigPath,
        loadChildren: () => AccountLoginPageModule,
    },
    {
        path: accountResetPasswordRoute.routerConfigPath,
        loadChildren: () => AccountResetPasswordPageModule,
    },
    {
        path: contentCollectionCreateRoute.routerConfigPath,
        loadChildren: () => ContentCollectionCreatePageModule,
    },
    {
        path: contentCollectionDetailsRoute.routerConfigPath,
        loadChildren: () => ContentCollectionDetailsPageModule,
    },
    {
        path: contentDetailsRoute.routerConfigPath,
        loadChildren: () => ContentDetailsPageModule,
    },
    {
        path: userGroupCreateRoute.routerConfigPath,
        loadChildren: () => UserGroupCreatePageModule,
    },
    {
        path: userGroupDetailsRoute.routerConfigPath,
        loadChildren: () => UserGroupDetailsPageModule,
    },
    {
        path: userInviteRoute.routerConfigPath,
        loadChildren: () => UserInvitePageModule,
    },
    {
        path: userDetailsRoute.userRouterConfigPath,
        loadChildren: () => UserDetailsPageModule,
    },
    {
        path: userDetailsRoute.organisationUserRouterConfigPath,
        loadChildren: () => UserDetailsPageModule,
    },
    {
        path: "",
        loadChildren: () => ErrorNotFoundPageModule,
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { urlUpdateStrategy: "eager" })],
    exports: [RouterModule],
})
export class RootRoutingModule { }
