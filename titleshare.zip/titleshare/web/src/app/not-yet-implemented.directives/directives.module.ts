import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { MessageServiceModule } from "../message.service/module";

import { NotYetImplementedDirective } from "./not-yet-implemented.directive";

@NgModule({
    imports: [
        CommonModule,
        MessageServiceModule,
    ],
    declarations: [
        NotYetImplementedDirective,
    ],
    exports: [
        NotYetImplementedDirective,
    ],
})
export class NotYetImplementedDirectivesModule { }
