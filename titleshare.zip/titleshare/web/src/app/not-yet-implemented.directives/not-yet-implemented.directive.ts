import { Directive, ElementRef } from "@angular/core";

import { Message } from "../message.service/message.service";

@Directive({
    selector: "[appNotYetImplemented]",
})
export class NotYetImplementedDirective {
    constructor(
        elementRef: ElementRef<HTMLElement>,
        private readonly _message: Message,
    ) {
        const element = elementRef.nativeElement;
        element.classList.add("global-not-yet-implemented");
        element.addEventListener("click", () => {
            this._message.withInfo("Sorry, not yet implemented.").showBriefly();
        });
    }
}
