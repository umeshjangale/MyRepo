export interface RequestPasswordResponse {
    success: boolean;
}
