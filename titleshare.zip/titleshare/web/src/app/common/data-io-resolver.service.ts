import { Injectable } from "@angular/core";

import { RequestResetPasswordGQL } from "../../generated/graphql";
import { RequestPasswordResponse } from "../models/interfaces";

@Injectable()
export class DataIOCommonServiceResolver {
    constructor(private readonly _requestResetPasswordGQL: RequestResetPasswordGQL) { }

    async requestResetPassword(email: string): Promise<RequestPasswordResponse> {
        const result = await this._requestResetPasswordGQL.mutate({
            email,
        }).toPromise();

        const data = result.data;
        if (!data) {
            throw new Error();
        }

        return data.requestPasswordReset;
    }
}
