import { AbstractControl, ValidatorFn } from "@angular/forms";

/**
 * A validator that makes a control conditionally mandatory.
 *
 * Example:
 * ```
 *  checkbox = new FormControl("");
 *  reason = new FormControl("", requiredIf(() => this.checkbox.value === true));
 * // ...
 * constructor() {
 *     this._subscriptions.add(this.checkbox.valueChanges.subscribe(() => {
 *         this.reason.updateValueAndValidity();
 *     }));
 * }
 * ```
 * @param condition A function to determine if a control value is required.
 */
export function requiredIf(condition: () => boolean): ValidatorFn {
    return (control: AbstractControl) => {
        const required = condition();
        if (required && !control.value) {
            return { required: true };
        } else {
            return null;
        }
    };
}
