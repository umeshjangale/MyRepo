import { RoleType } from "../../generated/graphql";

export function labelForRoleType(roleType: RoleType): string {
    switch (roleType) {
        case RoleType.SysAdmin:
            return "System Admin";
        case RoleType.OrgAdmin:
            return "Organisation Admin";
        case RoleType.OrgContentUploader:
            return "Content Uploader";
        case RoleType.Consumer:
            return "Consumer";
    }
    throw new Error();
}

export function labelForRoleTypes(roleTypes: Set<RoleType>): string {
    const roleTypeOrdering = [RoleType.SysAdmin, RoleType.OrgAdmin, RoleType.OrgContentUploader, RoleType.Consumer];
    return roleTypeOrdering.filter(roleType => roleTypes.has(roleType)).map(labelForRoleType).join(", ");
}
