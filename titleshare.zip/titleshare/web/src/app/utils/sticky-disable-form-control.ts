import { FormControl } from "@angular/forms";

/**
 * The default FormControl "forgets" it's disable state
 * when the containing form group is enabled.
 * This subclass overcomes that limitation, offering a flag
 * for controlling whether or not the control's disable state
 * is sticky.
 */
export class StickyDisableFormControl extends FormControl {
    stickyDisable: boolean = false;
    enable(opts?: {
        onlySelf?: boolean;
        emitEvent?: boolean;
    }): void {
        if (!this.stickyDisable) {
            super.enable(opts);
        }
    }
}
