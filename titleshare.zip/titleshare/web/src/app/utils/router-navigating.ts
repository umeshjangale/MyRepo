import { Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart } from "@angular/router";
import { Observable } from "rxjs";
import { distinctUntilChanged, filter, map, skipWhile } from "rxjs/operators";

export function routerNavigating(source: Observable<Event>): Observable<boolean> {
    return source.pipe(
        map(e => {
            if (e instanceof NavigationStart) {
                return true;
            }
            if (e instanceof NavigationEnd || e instanceof NavigationCancel || e instanceof NavigationError) {
                return false;
            }
            return undefined;
        }),
        filter(notUndefined),
        distinctUntilChanged(),
        // skip the first false (if any), which occurs if we start observing mid-navigation
        skipWhile(v => !v),
    );
}

function notUndefined(v: boolean | undefined): v is boolean {
    return typeof v === "boolean";
}
