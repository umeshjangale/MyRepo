import { RoleType } from "../../generated/graphql";

interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}

export type OrganisationRoles = SysAdminOrganisationRoles | NonSysAdminOrganisationRoles;

export interface SysAdminOrganisationRoles {
    sysAdmin: true;
}

export interface NonSysAdminOrganisationRoles {
    sysAdmin: false;
    orgAdminRolesCount: number;
    consumerRolesCount: number;
    organisationIdToRoleTypes: Map<string, Set<RoleType>>;
}

export function extractOrganisationRoles(roles: ReadonlyArray<Readonly<Role>>): OrganisationRoles {
    let consumerRolesCount: number = 0;
    let orgAdminRolesCount: number = 0;
    const organisationIdToRoleTypes = new Map<string, Set<RoleType>>();
    for (const role of roles) {
        if (role.type === RoleType.SysAdmin) {
            return {
                sysAdmin: true,
            };
        }
        if (role.type === RoleType.OrgAdmin) {
            orgAdminRolesCount++;
        } else if (role.type === RoleType.OrgContentUploader) {
            // Intentionally do nothing
        } else if (role.type === RoleType.Consumer) {
            consumerRolesCount++;
        } else {
            throw new Error();
        }
        if (role.organisation) {
            let roleTypes = organisationIdToRoleTypes.get(role.organisation.id);
            if (roleTypes) {
                roleTypes.add(role.type);
            } else {
                roleTypes = new Set();
                roleTypes.add(role.type);
                organisationIdToRoleTypes.set(role.organisation.id, roleTypes);
            }
        } else {
            console.error("ignoring unexpected organisationless role");
        }
    }
    return {
        sysAdmin: false,
        consumerRolesCount,
        orgAdminRolesCount,
        organisationIdToRoleTypes,
    };
}

export function userRolesWithinOrganisation(roles: ReadonlyArray<Readonly<Role>>, organisationId: string | undefined | null): Set<RoleType> {
    const result = new Set<RoleType>();
    for (const role of roles) {
        if (role.type === RoleType.SysAdmin) {
            return new Set([RoleType.SysAdmin]);
        }
        if (role.organisation && role.organisation.id === organisationId) {
            result.add(role.type);
        }
    }
    return result;
}
