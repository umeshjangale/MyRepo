import { AbstractControl, ValidatorFn } from "@angular/forms";

/**
 * A validator that forces two controls to have the same value.
 *
 * Example:
 * ```
 * password = new FormControl("", [Validators.required, Validators.minLength(MINIMUM_PASSWORD_LENGTH)]);
 * confirmPassword = new FormControl("", matches(this.password));
 * // ...
 * constructor() {
 *     this._subscriptions.add(this.newPassword.valueChanges.subscribe(() => {
 *         this.confirmNewPassword.updateValueAndValidity();
 *     }));
 * }
 * ```
 * @param otherControl The control whose value must match.
 */
export function matches(otherControl: AbstractControl): ValidatorFn {
    return (control: AbstractControl) => {
        if (control.value === otherControl.value) {
            return null;
        } else {
            return { mismatch: true };
        }
    };
}
