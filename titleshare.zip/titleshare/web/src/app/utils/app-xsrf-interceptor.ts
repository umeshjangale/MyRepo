import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpXsrfTokenExtractor } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";

import { environment } from "../../environments/environment";

@Injectable()
export class AppXsrfInterceptor implements HttpInterceptor {

    private readonly headerName = "X-XSRF-TOKEN";

    constructor(
        private readonly tokenService: HttpXsrfTokenExtractor) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const lcUrl = req.url.toLowerCase();

        const isAbsoluteUrl = lcUrl.startsWith("http://") || lcUrl.startsWith("https://");
        const isInterceptableUrl = !isAbsoluteUrl || lcUrl.startsWith(environment.serverUri);

        if (req.method === "GET" || req.method === "HEAD" || !isInterceptableUrl) {
            return next.handle(req);
        }

        const token = this.tokenService.getToken();

        // Be careful not to overwrite an existing header of the same name.
        if (token !== null && !req.headers.has(this.headerName)) {
            // tslint:disable-next-line: no-parameter-reassignment
            req = req.clone({ headers: req.headers.set(this.headerName, token) });
        }

        return next.handle(req);
    }
}
