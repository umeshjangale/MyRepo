import { MonoTypeOperatorFunction, Observable } from "rxjs";

export function subscriptionInterceptor<T>(subscribe: () => void, unsubscribe: () => void): MonoTypeOperatorFunction<T> {
    return source => new Observable<T>(subscriber => {
        subscribe();
        subscriber.add(unsubscribe);
        return source.subscribe(subscriber);
    });
}
