import { Directive } from "@angular/core";

@Directive({
    selector: "[appPageContent]",
})
export class PageContentDirective {
}

@Directive({
    // tslint:disable-next-line:directive-selector
    selector: "app-standard-page-toolbar-additions",
})
export class PageToolbarAdditionsDirective {
}
