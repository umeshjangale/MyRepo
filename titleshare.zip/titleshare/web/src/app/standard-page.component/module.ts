import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatListModule, MatMenuModule, MatSelectModule, MatToolbarModule } from "@angular/material";
import { RouterModule } from "@angular/router";

import { IconsModule } from "../icons/icons.module";
import { LogoutUser } from "../services/logout-user.service";

import { PageComponent } from "./standard-page.component";
import { PageContentDirective, PageToolbarAdditionsDirective } from "./standard-page.directives";

@NgModule({
    imports: [
        CommonModule,
        IconsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatListModule,
        MatSelectModule,
        MatToolbarModule,
        ReactiveFormsModule,
        RouterModule,
    ],
    declarations: [
        PageComponent,
        PageContentDirective,
        PageToolbarAdditionsDirective,
    ],
    exports: [
        PageComponent,
        PageContentDirective,
        PageToolbarAdditionsDirective,
    ],
    providers: [
        LogoutUser,
    ],
})
export class StandardPageModule { }
