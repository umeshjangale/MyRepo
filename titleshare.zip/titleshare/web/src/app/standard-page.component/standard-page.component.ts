import { Component, Input, OnInit } from "@angular/core";
import { Router } from "@angular/router";

import { accountDetailsRoute, informationPrivacyRoute, informationTermsRoute, userDashboardRoute } from "../routes";
import { LogoutUser } from "../services/logout-user.service";

export interface User {
    id: string;
    email: string;
}

@Component({
    selector: "app-standard-page",
    templateUrl: "./standard-page.component.html",
    styleUrls: ["./standard-page.component.scss"],
})
export class PageComponent implements OnInit {
    dashboardLink = userDashboardRoute.commands({});
    privacyRouterLink = informationPrivacyRoute.commands({});
    termsRouterLink = informationTermsRoute.commands({});

    private _titleSet: boolean = false;
    private _userSet: boolean = false;
    private _user: User | null = null;

    constructor(
        private readonly _logoutUser: LogoutUser,
        private readonly _router: Router,
    ) {
    }

    @Input() set title(value: string) {
        this._titleSet = true;
        if (typeof (value as any) !== "string") {
            console.warn("WARNING: page.title incorrectly set");
            return;
        }
        if (value.length === 0) {
            console.warn("WARNING: page.title empty");
        }
        document.title = value || "";
    }

    get user(): User | null {
        return this._user;
    }

    @Input() set user(value: User | null) {
        this._userSet = true;
        if (typeof (value as any) !== "object") {
            console.warn("WARNING: page.user incorrectly set");
            return;
        }
        if (value !== null && (typeof (value.id as any) !== "string" || typeof (value.email as any) !== "string")) {
            console.warn(`WARNING: page.user malformed, found ${JSON.stringify(value)}`);
            return;
        }
        this._user = value;
    }

    ngOnInit(): void {
        if (!this._titleSet) {
            console.warn("WARNING: page.title not set");
        }
        if (!this._userSet) {
            console.warn("WARNING: page.user not set");
        }
    }

    gotoAccountAction(): void {
        this._router.navigate(accountDetailsRoute.commands({}))
            .catch(e => console.error(e));
    }

    async logoutUserAction(): Promise<void> {
        await this._logoutUser.logoutUser();
    }
}
