import { Observable } from "rxjs";

import { ContentAccessSource, RoleType } from "../../generated/graphql";

export interface DataIO {
    readonly initial: {
        readonly currentUser: UserWithRoles;
        readonly content: Content;
        readonly contentUsers: Page<ContentUser>;
        readonly userGroups: Page<UserGroup>;
        readonly contentCollections: Page<ContentCollection>;
        readonly contentUsersPerPage: number;
        readonly userGroupsPerPage: number;
        readonly contentCollectionsPerPage: number;
        readonly languages: Language[];
        readonly genres: Genre[];
    };
    contentUsersPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentUser>>;
    contentUserGroupsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    contentContentCollectionsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    userUserGroupsPageOne(parameters: { userId: string }): Promise<Page<UserUserGroup>>;
    userContentCollectionsPageOne(parameters: { userId: string }): Promise<Page<UserContentCollection>>;
    addUserToContent(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentUser>>;
    removeUserFromContent(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentUser>>;
    addUserGroupToContent(parameters: { userGroupId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    removeUserGroupFromContent(parameters: { userGroupId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    addContentCollectionToContent(parameters: { contentCollectionId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    removeContentCollectionFromContent(parameters: { contentCollectionId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    suggestedUsers(parameters: { value: string }): Observable<SuggestedUser[]>;
    suggestedUserGroups(parameters: { value: string }): Observable<SuggestedUserGroup[]>;
    suggestedContentCollections(parameters: { value: string }): Observable<SuggestedContentCollection[]>;
    updateContentMetadata(parameters: UpdatableContentMetadata): Promise<Content>;
}

export interface Language {
    readonly code: string;
    readonly name: string;
}

export interface Genre {
    readonly code: string;
    readonly name: string;
}

export interface Content {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
    readonly description: string;
    readonly author: string;
    readonly narrator: string;
    readonly publisher: string;
    readonly releaseDate: number | null;
    readonly createdDate: number;
    readonly totalDuration: number;
    readonly language: Language;
    readonly genre: Genre;
    readonly secondGenre: Genre | null;
    readonly coverImageUrl: string;
    readonly nonBillable: boolean;
    readonly nonBillableReason: string;
    readonly organisation: {
        readonly id: string;
        readonly name: string;
    };
    readonly usersReportUri: string;
}

export interface UpdatableContentMetadata {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
    readonly description: string;
    readonly author: string;
    readonly narrator: string;
    readonly publisher: string;
    readonly releaseDate: number | null;
    readonly languageCode: string;
    readonly genreCode: string;
    readonly secondGenreCode: string | null;
    readonly nonBillable: boolean | undefined;
    readonly nonBillableReason: string | undefined;
}

export interface ContentUser {
    readonly user: {
        readonly id: string;
        readonly email: string;
        readonly firstName: string;
        readonly lastName: string;
    };
    readonly sources: ReadonlyArray<{
        source: ContentAccessSource;
    }>;
}

export interface SuggestedUser {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}

export interface SuggestedUserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface User {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
}

export interface UserWithRoles {
    readonly id: string;
    readonly email: string;
    readonly firstName: string;
    readonly lastName: string;
    readonly roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}

export interface UserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly users: {
        readonly totalCount: number;
    };
}

export interface UserUserGroup {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface ContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly content: {
        readonly totalCount: number;
    };
}

export interface UserContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface SuggestedContentCollection {
    readonly id: string;
    readonly name: string;
    readonly description: string;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
