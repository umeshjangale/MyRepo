import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, map, mergeMap, take } from "rxjs/operators";

import { AddAssociationGQL, ContentDetailsContentContentCollectionsGQL, ContentDetailsContentUserGroupsGQL, ContentDetailsContentUsersGQL, ContentDetailsInitialDataGQL, ContentDetailsUserContentCollectionsGQL, ContentDetailsUserUserGroupsGQL, RemoveAssociationGQL, SuggestedContentCollectionsForContentGQL, SuggestedUserGroupsForAddingToContentGQL, SuggestedUsersForAddingToContentGQL, UpdateContentMetadataGQL } from "../../generated/graphql";
import { contentDetailsRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

const CONTENT_USERS_PER_PAGE = 5;
const CONTENT_USER_GROUPS_PER_PAGE = 5;
const CONTENT_CONTENT_COLLECTIONS_PER_PAGE = 5;

const USER_USER_GROUPS_PER_PAGE = 5;
const USER_CONTENT_COLLECTIONS_PER_PAGE = 5;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _resolverTools: ResolverTools,
        private readonly _contentDetailsContentUsersGQL: ContentDetailsContentUsersGQL,
        private readonly _contentDetailsContentUserGroupsGQL: ContentDetailsContentUserGroupsGQL,
        private readonly _contentDetailsContentContentCollectionsGQL: ContentDetailsContentContentCollectionsGQL,
        private readonly _contentDetailsUserUserGroupsGQL: ContentDetailsUserUserGroupsGQL,
        private readonly _contentDetailsUserContentCollectionsGQL: ContentDetailsUserContentCollectionsGQL,
        private readonly _contentDetailsInitialDataGQL: ContentDetailsInitialDataGQL,
        private readonly _addAssociationGQL: AddAssociationGQL,
        private readonly _removeAssociationGQL: RemoveAssociationGQL,
        private readonly _suggestedUsersForAddingToContentGQL: SuggestedUsersForAddingToContentGQL,
        private readonly _suggestedUserGroupsForAddingToContentGQL: SuggestedUserGroupsForAddingToContentGQL,
        private readonly _suggestedContentCollectionsForContentGQL: SuggestedContentCollectionsForContentGQL,
        private readonly _updateContentMetadataGQL: UpdateContentMetadataGQL,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        const { contentId } = contentDetailsRoute.parameters(route.paramMap);
        return this._contentDetailsInitialDataGQL
            .fetch({
                contentId,
                contentUsersPageSize: CONTENT_USERS_PER_PAGE,
                contentUserGroupsPageSize: CONTENT_USER_GROUPS_PER_PAGE,
                contentContentCollectionsPageSize: CONTENT_CONTENT_COLLECTIONS_PER_PAGE,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    if (result.data.node) {
                        return of(this._createDataIO(
                            {
                                currentUser: result.data.me,
                                content: {
                                    ...result.data.node,
                                    coverImageUrl: result.data.node.coverImageUris.length ? result.data.node.coverImageUris[0] : "",
                                },
                                contentUsers: {
                                    ...result.data.node.users,
                                    zeroBasedPageIndex: 0,
                                },
                                userGroups: {
                                    ...result.data.node.userGroups,
                                    zeroBasedPageIndex: 0,
                                },
                                contentCollections: {
                                    ...result.data.node.contentCollections,
                                    zeroBasedPageIndex: 0,
                                },
                                contentUsersPerPage: CONTENT_USERS_PER_PAGE,
                                userGroupsPerPage: CONTENT_USER_GROUPS_PER_PAGE,
                                contentCollectionsPerPage: CONTENT_CONTENT_COLLECTIONS_PER_PAGE,
                                languages: result.data.languages,
                                genres: result.data.genres,
                            },
                            contentId,
                        ));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"], contentId: string): DataIO {
        const contentUsersPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._contentDetailsContentUsersGQL
                .fetch(
                    {
                        contentId,
                        searchText,
                        pageSize: CONTENT_USERS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                throw new Error();
            }

            return {
                ...data.node.users,
                zeroBasedPageIndex,
            };
        };

        const contentUserGroupsPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._contentDetailsContentUserGroupsGQL
                .fetch(
                    {
                        contentId,
                        searchText,
                        pageSize: CONTENT_USER_GROUPS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                throw new Error();
            }

            return {
                ...data.node.userGroups,
                zeroBasedPageIndex,
            };

        };

        const contentContentCollectionsPage = async ({ zeroBasedPageIndex, searchText }: { zeroBasedPageIndex: number; searchText: string }) => {
            const result = await this._contentDetailsContentContentCollectionsGQL
                .fetch(
                    {
                        contentId,
                        searchText,
                        pageSize: CONTENT_CONTENT_COLLECTIONS_PER_PAGE,
                        oneBasedPageNumber: zeroBasedPageIndex + 1,
                    },
                    {
                        fetchPolicy: "network-only",
                    },
                )
                .toPromise();
            const data = result.data;
            if (!data.node) {
                throw new Error();
            }

            return {
                ...data.node.contentCollections,
                zeroBasedPageIndex,
            };
        };

        return {
            initial,

            contentUsersPage: async ({ zeroBasedPageIndex, searchText }) => contentUsersPage({ zeroBasedPageIndex, searchText }),
            contentUserGroupsPage: async ({ zeroBasedPageIndex, searchText }) => contentUserGroupsPage({ zeroBasedPageIndex, searchText }),
            contentContentCollectionsPage: async ({ zeroBasedPageIndex, searchText }) => contentContentCollectionsPage({ zeroBasedPageIndex, searchText }),

            userUserGroupsPageOne: async ({ userId }) => {
                const result = await this._contentDetailsUserUserGroupsGQL
                    .fetch(
                        {
                            userId,
                            contentId,
                            pageSize: USER_USER_GROUPS_PER_PAGE,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                return {
                    ...result.data.contentAccessReasons.userGroups,
                    zeroBasedPageIndex: 0,
                };
            },
            userContentCollectionsPageOne: async ({ userId }) => {
                const result = await this._contentDetailsUserContentCollectionsGQL
                    .fetch(
                        {
                            userId,
                            contentId,
                            pageSize: USER_CONTENT_COLLECTIONS_PER_PAGE,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                return {
                    ...result.data.contentAccessReasons.contentCollections,
                    zeroBasedPageIndex: 0,
                };
            },

            updateContentMetadata: async content => {
                const result = await this._updateContentMetadataGQL.mutate(content).toPromise();
                if (!result.data) {
                    throw new Error();
                }
                return {
                    ...result.data.updateContent,
                    coverImageUrl: result.data.updateContent.coverImageUris.length ? result.data.updateContent.coverImageUris[0] : "",
                };
            },

            addUserToContent: async ({ userId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch content users
                await this._addAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: userId,
                    })
                    .toPromise();
                return contentUsersPage({ zeroBasedPageIndex, searchText });
            },

            removeUserFromContent: async ({ userId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch content users
                await this._removeAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: userId,
                    })
                    .toPromise();
                return contentUsersPage({ zeroBasedPageIndex, searchText });
            },

            addUserGroupToContent: async ({ userGroupId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch user groups
                await this._addAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: userGroupId,
                    })
                    .toPromise();
                return contentUserGroupsPage({ zeroBasedPageIndex, searchText });
            },

            removeUserGroupFromContent: async ({ userGroupId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch user groups
                await this._removeAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: userGroupId,
                    })
                    .toPromise();
                return contentUserGroupsPage({ zeroBasedPageIndex, searchText });
            },

            addContentCollectionToContent: async ({ contentCollectionId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to add and a failure to fetch user groups
                await this._addAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: contentCollectionId,
                    })
                    .toPromise();
                return contentContentCollectionsPage({ zeroBasedPageIndex, searchText });
            },

            removeContentCollectionFromContent: async ({ contentCollectionId, zeroBasedPageIndex, searchText }) => {
                // TODO: consumer cannot differentiate between a failure to remove and a failure to fetch user groups
                await this._removeAssociationGQL
                    .mutate({
                        id: contentId,
                        associateId: contentCollectionId,
                    })
                    .toPromise();
                return contentContentCollectionsPage({ zeroBasedPageIndex, searchText });
            },

            suggestedUsers: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }

                const lowerValue = value.toLowerCase();
                return this._suggestedUsersForAddingToContentGQL
                    .fetch(
                        {
                            contentId: initial.content.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            suggestedUserGroups: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }
                const lowerValue = value.toLowerCase();
                return this._suggestedUserGroupsForAddingToContentGQL
                    .fetch(
                        {
                            contentId: initial.content.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },

            suggestedContentCollections: ({ value }) => {
                if (value.length === 0) {
                    return of([]);
                }
                const lowerValue = value.toLowerCase();
                return this._suggestedContentCollectionsForContentGQL
                    .fetch(
                        {
                            contentId: initial.content.id,
                            searchText: lowerValue,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .pipe(
                        map(result => result.data.suggestionsForAssociation.items),
                    );
            },
        };
    }
}
