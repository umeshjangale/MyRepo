export interface ContentDetailsParameters {
    contentId: string;
}
