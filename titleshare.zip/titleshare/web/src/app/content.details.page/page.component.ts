import { CdkTextareaAutosize } from "@angular/cdk/text-field";
import { Component, OnDestroy, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatPaginator, PageEvent } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";
import * as moment from "moment-timezone";
import { Subscription } from "rxjs";

import { ContentAccessSource, RoleType } from "../../generated/graphql";
import { ConfirmationDialogOpener } from "../confirmation.dialog/dialog-opener.service";
import { ItemSelectionByTextSearchDialogOpener } from "../item-selection-by-text-search.dialog/dialog-opener.service";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { contentCollectionDetailsRoute, userDetailsRoute, userGroupDetailsRoute } from "../routes";
import { SearchTextComponent, SearchTextEvent } from "../search-text.component/search-text.component";
import { requiredIf } from "../utils/required-if-validator";

import { Content, ContentCollection, ContentUser, DataIO, Page, SuggestedContentCollection, SuggestedUser, SuggestedUserGroup, User, UserGroup, UserUserGroup, UserWithRoles } from "./data-io";

@Component({
    selector: "app-content-details-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent implements OnDestroy {

    currentUser: UserWithRoles;
    content: Content;
    contentUserList: { page: Page<ContentUser>; pageSize: number; columns: string[] };
    userGroupList: { page: Page<UserGroup>; pageSize: number; columns: string[] };
    contentCollectionList: { page: Page<ContentCollection>; pageSize: number; columns: string[] };
    readonly languages: Array<{ code: string; name: string }>;
    readonly genres: Array<{ code: string; name: string }>;
    readonly permissions: {
        sysAdmin: boolean;
    };

    @ViewChild("usersFilter") usersFilter!: SearchTextComponent;
    @ViewChild("userGroupsFilter") userGroupsFilter!: SearchTextComponent;
    @ViewChild("contentCollectionsFilter") contentCollectionsFilter!: SearchTextComponent;

    @ViewChild(".code_contentUsersPaginator") contentUsersPaginator: MatPaginator | undefined;
    @ViewChild(".code_userGroupsPaginator") userGroupsPaginator: MatPaginator | undefined;
    @ViewChild(".code_contentCollectionsPaginator") contentCollectionsPaginator: MatPaginator | undefined;
    @ViewChild("autosize") autosize: CdkTextareaAutosize | undefined;
    currentMenuItemsForUser: Array<{ id: string; name: string }> = [];

    title = new FormControl("", Validators.required);
    subtitle = new FormControl("");
    description = new FormControl("");
    author = new FormControl("");
    narrator = new FormControl("");
    publisher = new FormControl("");
    releaseDate = new FormControl("");
    languageCode = new FormControl("", Validators.required);
    genreCode = new FormControl("", Validators.required);
    secondGenreCode = new FormControl("");
    billable = new FormControl("");
    nonBillableReason = new FormControl("", requiredIf(() => this.billable.value === false));
    fieldsForm = new FormGroup({
        title: this.title,
        subtitle: this.subtitle,
        description: this.description,
        author: this.author,
        narrator: this.narrator,
        publisher: this.publisher,
        releaseDate: this.releaseDate,
        languageCode: this.languageCode,
        genreCode: this.genreCode,
        secondGenreCode: this.secondGenreCode,
        billable: this.billable,
        nonBillableReason: this.nonBillableReason,
    });

    private readonly _subscriptions = new Subscription();
    private readonly _dataIO: DataIO = null as any;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _confirmationDialogOpener: ConfirmationDialogOpener,
        private readonly _itemSelectionByTextSearchDialogOpener: ItemSelectionByTextSearchDialogOpener,
        private readonly _message: Message,
        private readonly _router: Router,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.content = initial.content;
        this.contentUserList = {
            page: initial.contentUsers,
            pageSize: initial.contentUsersPerPage,
            columns: ["firstName", "lastName", "email", "actions"],
        };
        this.userGroupList = {
            page: initial.userGroups,
            pageSize: initial.userGroupsPerPage,
            columns: ["name", "description", "membersCount", "actions"],
        };
        this.contentCollectionList = {
            page: initial.contentCollections,
            pageSize: initial.contentCollectionsPerPage,
            columns: ["name", "description", "contentCount", "actions"],
        };
        this.languages = initial.languages;
        this.genres = initial.genres;

        this.permissions = {
            sysAdmin: this.currentUser.roles.some(x => x.type === RoleType.SysAdmin),
        };

        this._subscriptions.add(this.billable.valueChanges.subscribe(() => {
            this.nonBillableReason.updateValueAndValidity();
        }));
    }

    ngOnDestroy(): void {
        this._subscriptions.unsubscribe();
    }

    getReleaseDateDisplay() {
        if (!this.content.releaseDate) { return null; }
        return moment.utc(this.content.releaseDate).format("Do MMM YYYY");
    }

    getTimezoneDisplay() {
        return moment.tz(moment.tz.guess()).format("z");
    }

    getImportDateDisplay() {
        const utc = moment.utc(this.content.createdDate);
        return utc.tz(moment.tz.guess()).format("Do MMM YYYY LT");
    }

    getDurationDisplay() {
        if (!this.content.totalDuration) { return ""; }

        // totalDuration is in seconds.
        // tslint:disable-next-line: no-magic-numbers
        const h = Math.floor(this.content.totalDuration / 3600);
        // tslint:disable-next-line: no-magic-numbers
        const m = Math.floor(this.content.totalDuration % 3600 / 60);
        // const s = Math.floor(this.content.totalDuration % 3600 % 60);

        const hDisplay = `${h}hrs`;
        const mDisplay = `${m}mins`;
        return `${hDisplay} ${mDisplay}`;
    }

    hasDirectAccess(contentUser: ContentUser) {
        return contentUser.sources.some(x => x.source === ContentAccessSource.Direct);
    }

    hasGroupAccess(contentUser: ContentUser) {
        return contentUser.sources.some(x => x.source === ContentAccessSource.UserGroup);
    }

    hasContentCollectionAccess(contentUser: ContentUser) {
        return contentUser.sources.some(x => x.source === ContentAccessSource.ContentCollection);
    }

    async fetchUserGroupsForUserAction(contentUser: ContentUser): Promise<void> {
        return this._setMenuItemsForUser(contentUser, async () => this._dataIO.userUserGroupsPageOne({ userId: contentUser.user.id }));
    }

    async fetchContentCollectionsForUserAction(contentUser: ContentUser): Promise<void> {
        return this._setMenuItemsForUser(contentUser, async () => this._dataIO.userContentCollectionsPageOne({ userId: contentUser.user.id }));
    }

    editValuesAction(panel: PanelComponent): void {
        this.title.setValue(this.content.title);
        this.subtitle.setValue(this.content.subtitle);
        this.description.setValue(this.content.description);
        this.author.setValue(this.content.author);
        this.narrator.setValue(this.content.narrator);
        this.publisher.setValue(this.content.publisher);
        this.releaseDate.setValue(this.content.releaseDate ? moment.utc(this.content.releaseDate) : null);
        this.languageCode.setValue(this.content.language.code);
        this.genreCode.setValue(this.content.genre.code);
        this.secondGenreCode.setValue(this.content.secondGenre ? this.content.secondGenre.code : null);
        this.billable.setValue(!this.content.nonBillable);
        this.nonBillableReason.setValue(this.content.nonBillableReason);
        panel.editing = true;
    }

    editingFieldsCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async editingFieldsSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.fieldsForm.valid) {
            return;
        }
        panel.busy = true;
        this.fieldsForm.disable();
        try {
            // The date picker returns a moment instance in local time. For release date, convert the interpretation of this to UTC.
            const utcReleaseDate = moment.isMoment(this.releaseDate.value) ? moment.utc(this.releaseDate.value.format("YYYY-MM-DD")).valueOf() : null;

            const content = await this._dataIO.updateContentMetadata({
                id: this.content.id,
                title: this.title.value,
                subtitle: this.subtitle.value,
                description: this.description.value,
                author: this.author.value,
                narrator: this.narrator.value,
                publisher: this.publisher.value,
                releaseDate: utcReleaseDate,
                languageCode: this.languageCode.value,
                genreCode: this.genreCode.value,
                secondGenreCode: this.secondGenreCode.value || null,
                nonBillable: this.permissions.sysAdmin ? this.billable.value === false : undefined,
                nonBillableReason: this.permissions.sysAdmin ? this.nonBillableReason.value : undefined,
            });
            this.content = content;
            panel.editing = false;
            this._message.withInfo("Updated content metadata.").showBriefly();
        } catch (e) {
            this._message.withError("Failed to update content metadata.").showTillDismissed();
        } finally {
            this.fieldsForm.enable();
            panel.busy = false;
        }
    }

    async applyUsersFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentUserList.page = await this._dataIO.contentUsersPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentUsersPaginator) {
                    this.contentUsersPaginator.pageIndex = this.contentUserList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch users.").showBriefly();
            }
        });
    }

    async contentUsersPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentUserList.page = await this._dataIO.contentUsersPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.usersFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentUsersPaginator) {
                this.contentUsersPaginator.pageIndex = this.contentUserList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content users.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyUserGroupsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.userGroupList.page = await this._dataIO.contentUserGroupsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.userGroupsPaginator) {
                    this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch user groups.").showBriefly();
            }
        });
    }

    async userGroupsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.contentUserGroupsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.userGroupsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch user groups.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyContentCollectionsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentCollectionList.page = await this._dataIO.contentContentCollectionsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentCollectionsPaginator) {
                    this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content collections.").showBriefly();
            }
        });
    }

    async contentCollectionsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.contentContentCollectionsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentCollectionsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content collections.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    gotoUserAction(user: ContentUser): void {
        this._router.navigate(userDetailsRoute.commands({ userId: user.user.id, organisationId: this.content.organisation.id }))
            .catch(e => console.error(e));
    }

    gotoUserGroupAction(userGroup: UserGroup): void {
        this._router.navigate(userGroupDetailsRoute.commands({ userGroupId: userGroup.id }))
            .catch(e => console.error(e));
    }

    gotoUserGroupForUserAction(userGroup: { id: string }, contentUser: ContentUser): void {

        // See this._setMenuItemsForUser for special id values.
        switch (userGroup.id) {
            case "error":
                return;
            case "ellipsis":
                this._router.navigate(userDetailsRoute.commands({ userId: contentUser.user.id, organisationId: this.content.organisation.id }))
                    .catch(e => console.error(e));
                break;
            default:
                this._router.navigate(userGroupDetailsRoute.commands({ userGroupId: userGroup.id }))
                    .catch(e => console.error(e));
        }
    }

    gotoContentCollectionAction(contentCollection: ContentCollection): void {
        this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: contentCollection.id }))
            .catch(e => console.error(e));
    }

    gotoContentCollectionForUserAction(contentCollection: { id: string }, contentUser: ContentUser): void {

        // See this._setMenuItemsForUser for special id values.
        switch (contentCollection.id) {
            case "error":
                return;
            case "ellipsis":
                this._router.navigate(userDetailsRoute.commands({ userId: contentUser.user.id, organisationId: this.content.organisation.id }))
                    .catch(e => console.error(e));
                break;
            default:
                this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: contentCollection.id }))
                    .catch(e => console.error(e));
        }
    }

    async addUserAction(panel: PanelComponent): Promise<any> {
        const maybeUser = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedUser>({
            dialogTitle: "Grant User Access",
            searchTextPlaceholder: "Search by first or last name",
            filteredItems: text => this._dataIO.suggestedUsers({ value: text }),
            displayableItem: item => ({ primaryLabel: `${item.firstName} ${item.lastName}`, secondaryLabel: item.email }),
        });
        if (maybeUser) {
            return this._addUser(maybeUser, this.contentUsersPaginator ? this.contentUsersPaginator.pageIndex : 0, panel);
        }
    }

    async removeUserAction(contentUser: ContentUser, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove User Access",
            message: `Are you sure you want to remove user "${contentUser.user.firstName} ${contentUser.user.lastName}" from this content ? `,
            confirmButtonTitle: "Remove User",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUser(contentUser.user, this.contentUsersPaginator ? this.contentUsersPaginator.pageIndex : 0, panel);
        }
    }

    async addUserGroupAction(panel: PanelComponent): Promise<any> {
        const maybeUserGroup = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedUserGroup>({
            dialogTitle: "Grant User Group Access",
            searchTextPlaceholder: "Search by name",
            filteredItems: text => this._dataIO.suggestedUserGroups({ value: text }),
            displayableItem: item => ({ primaryLabel: item.name, secondaryLabel: item.description }),
        });
        if (maybeUserGroup) {
            return this._addUserGroup(maybeUserGroup, this.userGroupsPaginator ? this.userGroupsPaginator.pageIndex : 0, panel);
        }
    }

    async removeUserGroupAction(userGroup: UserGroup, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove User Group",
            message: `Are you sure you want to remove user group "${userGroup.name}" from this content ? `,
            confirmButtonTitle: "Remove User Group",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUserGroup(userGroup, this.userGroupsPaginator ? this.userGroupsPaginator.pageIndex : 0, panel);
        }
    }

    async addContentCollectionAction(panel: PanelComponent): Promise<any> {
        const maybeContentCollection = await this._itemSelectionByTextSearchDialogOpener.openDialog<SuggestedContentCollection>({
            dialogTitle: "Add to Content Collection",
            searchTextPlaceholder: "Search by name",
            filteredItems: text => this._dataIO.suggestedContentCollections({ value: text }),
            displayableItem: item => ({ primaryLabel: item.name, secondaryLabel: item.description }),
        });
        if (maybeContentCollection) {
            return this._addContentCollection(maybeContentCollection, this.contentCollectionsPaginator ? this.contentCollectionsPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentCollectionAction(contentCollection: ContentCollection, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove from Content Collection",
            message: `Are you sure you want to remove this content from content collection "${contentCollection.name}" ? `,
            confirmButtonTitle: "Remove from Content Collection",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContentCollection(contentCollection, this.contentCollectionsPaginator ? this.contentCollectionsPaginator.pageIndex : 0, panel);
        }
    }

    private async _addUser(user: SuggestedUser, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentUserList.page = await this._dataIO.addUserToContent({ userId: user.id, zeroBasedPageIndex, searchText: this.usersFilter.value });
            this._message.withInfo(`Added user "${user.firstName} ${user.lastName}" to content "${this.content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentUsersPaginator) {
                this.contentUsersPaginator.pageIndex = this.contentUserList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user "${user.firstName} ${user.lastName}" to content "${this.content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeUser(user: User, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentUserList.page = await this._dataIO.removeUserFromContent({ userId: user.id, zeroBasedPageIndex, searchText: this.usersFilter.value });
            this._message.withInfo(`Removed user "${user.firstName} ${user.lastName}" from content "${this.content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentUsersPaginator) {
                this.contentUsersPaginator.pageIndex = this.contentUserList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${user.firstName} ${user.lastName}" from content "${this.content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _refreshContentUsers() {
        try {
            this.contentUserList.page = await this._dataIO.contentUsersPage({ zeroBasedPageIndex: this.contentUserList.page.zeroBasedPageIndex, searchText: this.usersFilter.value });
        } catch (e) {
            this._message.withError("Failed to refresh list of users with access.").showBriefly();
        }
    }

    private async _addUserGroup(userGroup: SuggestedUserGroup, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.addUserGroupToContent({ userGroupId: userGroup.id, zeroBasedPageIndex, searchText: this.userGroupsFilter.value });
            this._message.withInfo(`Added user group "${userGroup.name}" to content "${this.content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add user group "${userGroup.name}" to content "${this.content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshContentUsers();
        }
    }

    private async _removeUserGroup(userGroup: UserGroup, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.removeUserGroupFromContent({ userGroupId: userGroup.id, zeroBasedPageIndex, searchText: this.userGroupsFilter.value });
            this._message.withInfo(`Removed user group "${userGroup.name}" from content "${this.content.title}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user group "${userGroup.name}" from content "${this.content.title}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshContentUsers();
        }
    }

    private async _addContentCollection(contentCollection: SuggestedContentCollection, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.addContentCollectionToContent({ contentCollectionId: contentCollection.id, zeroBasedPageIndex, searchText: this.contentCollectionsFilter.value });
            this._message.withInfo(`Added content "${this.content.title}" to content collection "${contentCollection.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to add content "${this.content.title}" to content collection "${contentCollection.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshContentUsers();
        }
    }

    private async _removeContentCollection(contentCollection: ContentCollection, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.removeContentCollectionFromContent({ contentCollectionId: contentCollection.id, zeroBasedPageIndex, searchText: this.contentCollectionsFilter.value });
            this._message.withInfo(`Removed content "${this.content.title}" from content collection "${contentCollection.name}".`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove content "${this.content.title}" from content collection "${contentCollection.name}".`).showTillDismissed();
        } finally {
            panel.busy = false;
            await this._refreshContentUsers();
        }
    }

    private async _setMenuItemsForUser(contentUser: ContentUser, dataFetcher: () => Promise<Page<{ id: string; name: string }>>) {
        this.currentMenuItemsForUser = [];

        try {
            const page = await dataFetcher();

            const displayCount = 4;
            if (page.totalCount <= displayCount) {
                this.currentMenuItemsForUser = page.items;
                return;
            }

            const items = page.items.slice(0, displayCount - 1);
            items.push({
                id: "ellipsis",
                name: `Plus ${page.totalCount - displayCount + 1} more...`,
            });

            this.currentMenuItemsForUser = items;

        } catch (e) {
            this._message.withError(`Failed to fetch data for user "${contentUser.user.firstName} ${contentUser.user.lastName}".`).showBriefly();
            this.currentMenuItemsForUser = [{
                id: "error",
                name: "Error...",
            }];
        }
    }
}
