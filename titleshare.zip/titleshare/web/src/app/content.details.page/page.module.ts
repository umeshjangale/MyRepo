import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MAT_DATE_FORMATS, MatButtonModule, MatCardModule, MatCheckboxModule, MatDatepickerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule, MatPaginatorModule, MatProgressSpinnerModule, MatSelectModule, MatTableModule } from "@angular/material";
import { MomentDateModule } from "@angular/material-moment-adapter";

import { ConfirmationDialogModule } from "../confirmation.dialog/dialog.module";
import { ItemSelectionByTextSearchDialogModule } from "../item-selection-by-text-search.dialog/dialog.module";
import { MessageServiceModule } from "../message.service/module";
import { NotYetImplementedDirectivesModule } from "../not-yet-implemented.directives/directives.module";
import { PanelModule } from "../panel.component/module";
import { ProtectedSrcDirectivesModule } from "../protected-src.directives/directives.module";
import { SearchTextModule } from "../search-text.component/search-text.module";
import { StandardPageModule } from "../standard-page.component/module";
import { TableDirectivesModule } from "../table.directives/directives.module";
import { UsabilityDirectivesModule } from "../usability.directives/directives.module";

import { PageRoutingModule } from "./page-routing.module";
import { PageComponent } from "./page.component";

const DATE_FORMAT = {
    parse: {
        dateInput: "Do MMM YYYY",
    },
    display: {
        dateInput: "Do MMM YYYY",
        monthYearLabel: "MMM YYYY",
        dateA11yLabel: "Do MMM YYYY",
        monthYearA11yLabel: "MMMM YYYY",
    },
};

@NgModule({
    imports: [
        CommonModule,
        ConfirmationDialogModule,
        ItemSelectionByTextSearchDialogModule,
        ProtectedSrcDirectivesModule,
        MatButtonModule,
        MatCardModule,
        MatDatepickerModule,
        MomentDateModule,
        MatFormFieldModule,
        MatCheckboxModule,
        MatIconModule,
        MatInputModule,
        MatSelectModule,
        MatMenuModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatTableModule,
        MessageServiceModule,
        NotYetImplementedDirectivesModule,
        PanelModule,
        StandardPageModule,
        TableDirectivesModule,
        PageRoutingModule,
        ReactiveFormsModule,
        UsabilityDirectivesModule,
        SearchTextModule,
    ],
    providers: [
        { provide: MAT_DATE_FORMATS, useValue: DATE_FORMAT },
    ],
    declarations: [
        PageComponent,
    ],
})
export class ContentDetailsPageModule { }
