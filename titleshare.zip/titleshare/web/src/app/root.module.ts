import { Location } from "@angular/common";
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule, HttpErrorResponse } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { MatFormFieldModule, MatListModule, MatProgressSpinnerModule, MatSelectModule, MatToolbarModule } from "@angular/material";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Router } from "@angular/router";
import { APOLLO_OPTIONS, ApolloModule } from "apollo-angular";
import { HttpLink, HttpLinkModule } from "apollo-angular-link-http";
import { InMemoryCache } from "apollo-cache-inmemory";
import { ApolloClientOptions } from "apollo-client";
import { ApolloLink } from "apollo-link";
import { onError } from "apollo-link-error";
import { GraphQLError } from "graphql";

import { environment } from "../environments/environment";

import { DataIOCommonServiceResolver } from "./common/data-io-resolver.service";
import { IconsModule } from "./icons/icons.module";
import { RootRoutingModule } from "./root-routing.module";
import { RootComponent } from "./root.component";
import { accountLoginRoute } from "./routes";
import { ResolverTools } from "./services/resolver-tools.service";
import { AppXsrfInterceptor } from "./utils/app-xsrf-interceptor";

@NgModule({
    declarations: [
        RootComponent,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        IconsModule,
        MatFormFieldModule,
        MatListModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        MatToolbarModule,
        RootRoutingModule,
        HttpClientModule,
        ApolloModule,
        HttpLinkModule,
    ],
    providers: [
        {
            provide: APOLLO_OPTIONS,
            useFactory(httpLink: HttpLink, router: Router, location: Location): ApolloClientOptions<any> {
                const unauthenticatedRedirectLink = onError(({ operation, graphQLErrors, networkError }) => {
                    if (
                        !operation.getContext().skipUnauthenticatedRedirect &&
                        (graphQLErrors && hasUnauthenticatedError(graphQLErrors)) ||
                        (networkError && isHttpErrorResponseWithGraphQLErrors(networkError) && hasUnauthenticatedError(networkError.error.errors))
                    ) {
                        router.navigate(accountLoginRoute.commands({ successUrl: location.path() ? location.path() : undefined }))
                            .catch(me => console.error(me));
                    }
                });
                return {
                    cache: new InMemoryCache(),
                    link: ApolloLink.from([
                        unauthenticatedRedirectLink,
                        httpLink.create({
                            uri: environment.graphqlUri,
                            // In deployed environments, the web and server use the same domain, so withCredentials is not required.
                            withCredentials: !environment.production,
                        }),
                    ]),
                    defaultOptions: {
                        query: {
                            // Globally disable client-side caching
                            fetchPolicy: "no-cache",
                        },
                    },
                };
            },
            deps: [HttpLink, Router, Location],
        },
        DataIOCommonServiceResolver,
        { provide: HTTP_INTERCEPTORS, useClass: AppXsrfInterceptor, multi: true },
        ResolverTools,
    ],
    bootstrap: [RootComponent],
})
export class RootModule { }

function isHttpErrorResponseWithGraphQLErrors(e: unknown): e is { error: { errors: GraphQLError[] } } {
    return e instanceof HttpErrorResponse && e.error && e.error.errors && Array.isArray(e.error.errors);
}

function hasUnauthenticatedError(errors: ReadonlyArray<GraphQLError>): boolean {
    return errors.some(ge => !!ge && !!ge.extensions && ge.extensions.code === "UNAUTHENTICATED");
}
