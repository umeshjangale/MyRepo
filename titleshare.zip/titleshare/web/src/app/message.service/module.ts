import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { MatSnackBarModule } from "@angular/material";

import { Message } from "./message.service";

@NgModule({
    imports: [
        CommonModule,
        MatSnackBarModule,
    ],
    providers: [
        Message,
    ],
})
export class MessageServiceModule { }
