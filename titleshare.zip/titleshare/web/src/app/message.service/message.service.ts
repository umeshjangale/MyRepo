import { Injectable } from "@angular/core";
import { MatSnackBar, MatSnackBarConfig } from "@angular/material";

class Showable {
    constructor(
        private readonly _matSnackbar: MatSnackBar,
        private readonly _text: string,
        private readonly _config: MatSnackBarConfig = {},
    ) {
    }

    showIndefinitely() {
        this._show();
    }

    showBriefly() {
        this._show(undefined, { duration: 5000 });
    }

    showTillDismissed(action: string = "Ok") {
        this._show(action);
    }

    private _show(action?: string, config: MatSnackBarConfig = {}) {
        const mergedConfig = {
            ...this._config,
            ...config,
        };
        this._matSnackbar.open(this._text, action, mergedConfig);
    }
}

@Injectable()
export class Message {
    constructor(
        private readonly _matSnackbar: MatSnackBar,
    ) {
    }

    withError(text: string): Showable {
        return new Showable(this._matSnackbar, text, { panelClass: "snack-bar-error" });
    }

    withInfo(text: string): Showable {
        return new Showable(this._matSnackbar, text);
    }
}
