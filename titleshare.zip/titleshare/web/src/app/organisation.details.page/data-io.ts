import { RoleType } from "../../generated/graphql";

export interface DataIO {
    initial: {
        currentUser: User;
        organisation: Organisation;
        contentItems: Page<Content>;
        users: Page<User>;
        userGroups: Page<UserGroup>;
        contentCollections: Page<ContentCollection>;
        contentItemsPerPage: number;
        usersPerPage: number;
        userGroupsPerPage: number;
        contentCollectionsPerPage: number;
    };
    contentItemsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    usersPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    userGroupsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    contentCollectionsPage(parameters: { zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
    updateOrganisation(parameters: OrganisationUpdate): Promise<Organisation>;
    removeUser(parameters: { userId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<User>>;
    removeContent(parameters: { contentId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<Content>>;
    removeUserGroup(parameters: { userGroupId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<UserGroup>>;
    removeContentCollection(parameters: { contentCollectionId: string; zeroBasedPageIndex: number; searchText: string }): Promise<Page<ContentCollection>>;
}

export interface Content {
    readonly id: string;
    readonly title: string;
    readonly subtitle: string;
}

export interface UserGroup {
    id: string;
    name: string;
    description: string;
    users: {
        totalCount: number;
    };
}

export interface ContentCollection {
    id: string;
    name: string;
    description: string;
    content: {
        totalCount: number;
    };
}

export interface Organisation {
    id: string;
    name: string;
    importStorageBucket: string | null;
    importNarrationRegex: string;
    importSoundtrackRegex: string;
    importCoverImageRegex: string;
    importSftpUsername: string | null;
    importSftpPassword: string | null;
    usersReportUri: string;
    contentReportUri: string;
}

export interface OrganisationUpdate {
    id: string;
    name: string;
    importStorageBucket: string | undefined;
    importNarrationRegex: string;
    importSoundtrackRegex: string;
    importCoverImageRegex: string;
    importSftpUsername: string | undefined;
    importSftpPassword: string | undefined;
}

export interface User {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: Role[];
}

export interface Role {
    type: RoleType;
    organisation?: { id: string } | null;
}

export interface Page<T> {
    readonly items: T[];
    readonly totalCount: number;
    readonly zeroBasedPageIndex: number;
}
