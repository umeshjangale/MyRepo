export interface OrganisationDetailsParameters {
    organisationId: string;
}
