// angular imports
import { Component, ViewChild } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatPaginator, PageEvent } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";

import { RoleType } from "../../generated/graphql";
import { DataIOCommonServiceResolver } from "../common/data-io-resolver.service";
import { ConfirmationDialogOpener } from "../confirmation.dialog/dialog-opener.service";
import { Message } from "../message.service/message.service";
import { PanelComponent } from "../panel.component/panel.component";
import { contentCollectionCreateRoute, contentCollectionDetailsRoute, contentDetailsRoute, userDetailsRoute, userGroupCreateRoute, userGroupDetailsRoute, userInviteRoute } from "../routes";
import { SearchTextComponent, SearchTextEvent } from "../search-text.component/search-text.component";
import { userRolesWithinOrganisation } from "../utils/user-roles";
import { ViewMetadataDialogOpener } from "../view-metadata.dialog/dialog-opener.service";

import { Content, ContentCollection, DataIO, Organisation, Page, User, UserGroup } from "./data-io";

@Component({
    selector: "app-organisation-details-page",
    templateUrl: "./page.component.html",
    styleUrls: ["./page.component.scss"],
})
export class PageComponent {
    currentUser: User;
    organisation: Organisation;
    contentList: { page: Page<Content>; pageSize: number; columns: string[] };
    userList: { page: Page<User>; pageSize: number; columns: string[] };
    userGroupList: { page: Page<UserGroup>; pageSize: number; columns: string[] };
    contentCollectionList: { page: Page<ContentCollection>; pageSize: number; columns: string[] };
    permissions: {
        editOrganisation: boolean;
        viewSftpCredentials: boolean;
    };

    @ViewChild("usersFilter") usersFilter!: SearchTextComponent;
    @ViewChild("contentFilter") contentFilter!: SearchTextComponent;
    @ViewChild("userGroupsFilter") userGroupsFilter!: SearchTextComponent;
    @ViewChild("contentCollectionsFilter") contentCollectionsFilter!: SearchTextComponent;

    @ViewChild(".code_contentItemsPaginator") contentItemsPaginator: MatPaginator | undefined;
    @ViewChild(".code_usersPaginator") usersPaginator: MatPaginator | undefined;
    @ViewChild(".code_userGroupsPaginator") userGroupsPaginator: MatPaginator | undefined;
    @ViewChild(".code_contentCollectionsPaginator") contentCollectionsPaginator: MatPaginator | undefined;

    name = new FormControl("");
    importStorageBucket = new FormControl("");
    importSftpUsername = new FormControl("");
    importSftpPassword = new FormControl("");
    importNarrationRegex = new FormControl("", Validators.required);
    importSoundtrackRegex = new FormControl("", Validators.required);
    importCoverImageRegex = new FormControl("", Validators.required);
    fieldsForm = new FormGroup({
        name: this.name,
        importStorageBucket: this.importStorageBucket,
        importSftpUsername: this.importSftpUsername,
        importSftpPassword: this.importSftpPassword,
        importNarrationRegex: this.importNarrationRegex,
        importSoundtrackRegex: this.importSoundtrackRegex,
        importCoverImageRegex: this.importCoverImageRegex,
    });

    private readonly _dataIO: DataIO;

    constructor(
        activatedRoute: ActivatedRoute,
        private readonly _confirmationDialogOpener: ConfirmationDialogOpener,
        private readonly _message: Message,
        private readonly _router: Router,
        private readonly _viewMetadataDialogOpener: ViewMetadataDialogOpener,
        private readonly _dataIOCommonServiceResolver: DataIOCommonServiceResolver,
    ) {
        this._dataIO = activatedRoute.snapshot.data.dataIO as DataIO;
        const initial = this._dataIO.initial;
        this.currentUser = initial.currentUser;
        this.organisation = initial.organisation;
        const userRoles = userRolesWithinOrganisation(this.currentUser.roles, this.organisation.id);
        this.contentList = {
            page: initial.contentItems,
            pageSize: initial.contentItemsPerPage,
            columns: ["title", "subtitle", "author", "actions"],
        };
        this.userList = {
            page: initial.users,
            pageSize: initial.usersPerPage,
            columns: ["firstName", "lastName", "email", "roles", "actions"],
        };
        this.userGroupList = {
            page: initial.userGroups,
            pageSize: initial.userGroupsPerPage,
            columns: ["name", "description", "membersCount", "actions"],
        };
        this.contentCollectionList = {
            page: initial.contentCollections,
            pageSize: initial.contentCollectionsPerPage,
            columns: ["name", "description", "contentCount", "actions"],
        };

        this.permissions = {
            editOrganisation: userRoles.has(RoleType.SysAdmin),
            viewSftpCredentials: userRoles.has(RoleType.SysAdmin) || userRoles.has(RoleType.OrgContentUploader),
        };
    }

    async showSftpCredentials(panel: PanelComponent): Promise<void> {
        await this._viewMetadataDialogOpener.openDialog({
            title: "SFTP Credentials",
            items: [
                {
                    key: "Server",
                    value: "sftp.title-share.net",
                },
                {
                    key: "Username",
                    value: this.organisation.importSftpUsername || "NOT YET AVAILABLE",
                },
                {
                    key: "Password",
                    value: this.organisation.importSftpPassword || "NOT YET AVAILABLE",
                },
            ],
        });
    }

    editValuesAction(panel: PanelComponent): void {
        this.name.setValue(this.organisation.name);
        this.importStorageBucket.setValue(this.organisation.importStorageBucket);
        this.importSftpUsername.setValue(this.organisation.importSftpUsername);
        this.importSftpPassword.setValue(this.organisation.importSftpPassword);
        this.importNarrationRegex.setValue(this.organisation.importNarrationRegex);
        this.importSoundtrackRegex.setValue(this.organisation.importSoundtrackRegex);
        this.importCoverImageRegex.setValue(this.organisation.importCoverImageRegex);
        panel.editing = true;
    }

    editingFieldsCancelAction(panel: PanelComponent): void {
        panel.editing = false;
    }

    async editingFieldsSaveAction(panel: PanelComponent): Promise<void> {
        if (!this.fieldsForm.valid) {
            return;
        }
        panel.busy = true;
        this.fieldsForm.disable();
        try {
            const organisation = await this._dataIO.updateOrganisation({
                id: this.organisation.id,
                name: this.name.value,
                importStorageBucket: this.importStorageBucket.value,
                importSftpUsername: this.importSftpUsername.value,
                importSftpPassword: this.importSftpPassword.value,
                importNarrationRegex: this.importNarrationRegex.value,
                importSoundtrackRegex: this.importSoundtrackRegex.value,
                importCoverImageRegex: this.importCoverImageRegex.value,
            });
            this.organisation = organisation;
            panel.editing = false;
            this._message.withInfo("Updated organisation metadata.").showBriefly();
        } catch (e) {
            this._message.withError("Failed to update organisation metadata.").showTillDismissed();
        } finally {
            this.fieldsForm.enable();
            panel.busy = false;
        }
    }

    async applyContentFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentList.page = await this._dataIO.contentItemsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentItemsPaginator) {
                    this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content.").showBriefly();
            }
        });
    }

    async contentItemsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentList.page = await this._dataIO.contentItemsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentItemsPaginator) {
                this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content items.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyUsersFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.userList.page = await this._dataIO.usersPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.usersPaginator) {
                    this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch users.").showBriefly();
            }
        });
    }

    async usersPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userList.page = await this._dataIO.usersPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.usersFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.usersPaginator) {
                this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch users.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyUserGroupsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.userGroupList.page = await this._dataIO.userGroupsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.userGroupsPaginator) {
                    this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch user groups.").showBriefly();
            }
        });
    }

    async userGroupsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.userGroupsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.userGroupsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch user groups.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    async applyContentCollectionsFilter(event: SearchTextEvent): Promise<void> {
        await event.withBusy(async () => {
            try {
                // Always request the first page.
                this.contentCollectionList.page = await this._dataIO.contentCollectionsPage({ zeroBasedPageIndex: 0, searchText: event.searchText });
                if (this.contentCollectionsPaginator) {
                    this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
                }
            } catch (e) {
                this._message.withError("Failed to fetch content collections.").showBriefly();
            }
        });
    }

    async contentCollectionsPageChangeAction(pageEvent: PageEvent, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.contentCollectionsPage({ zeroBasedPageIndex: pageEvent.pageIndex, searchText: this.contentCollectionsFilter.value });
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError("Failed to fetch content collections.").showBriefly();
        } finally {
            panel.busy = false;
        }
    }

    userIsOrgAdmin(user: User): boolean {
        return user.roles.some(role => role.type === RoleType.OrgAdmin && !!(role.organisation && role.organisation.id === this.organisation.id));
    }

    userIsOrgContentUploader(user: User): boolean {
        return user.roles.some(role => role.type === RoleType.OrgContentUploader && !!(role.organisation && role.organisation.id === this.organisation.id));
    }

    async inviteUserAction(): Promise<any> {
        this._router.navigate(userInviteRoute.commands({
            organisationId: this.organisation.id,
            completionTitle: "Organisation Details",
            completionUrl: this._router.url,
        }))
            .catch(e => console.error(e));
    }

    async removeUserAction(user: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Remove User from Organisation",
            message: `Are you sure you want to remove user "${user.firstName} ${user.lastName}" from this organisation ? `,
            confirmButtonTitle: "Remove User",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUser(user, this.usersPaginator ? this.usersPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentAction(content: Content, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Delete Content",
            message: `Are you sure you want to permanently delete content "${content.title}" ?`,
            confirmButtonTitle: "Permanently Delete Content",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContent(content, this.contentItemsPaginator ? this.contentItemsPaginator.pageIndex : 0, panel);
        }
    }

    async removeUserGroupAction(userGroup: UserGroup, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Delete User Group",
            message: `Are you sure you want to delete user group "${userGroup.name}" ?`,
            confirmButtonTitle: "Delete User Group",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeUserGroup(userGroup, this.userGroupsPaginator ? this.userGroupsPaginator.pageIndex : 0, panel);
        }
    }

    async removeContentCollectionAction(contentCollection: ContentCollection, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Delete Content Collection",
            message: `Are you sure you want to delete content collection "${contentCollection.name}" ?`,
            confirmButtonTitle: "Delete Content Collection",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._removeContentCollection(contentCollection, this.contentCollectionsPaginator ? this.contentCollectionsPaginator.pageIndex : 0, panel);
        }
    }

    async createUserGroupAction(): Promise<any> {
        this._router.navigate(userGroupCreateRoute.commands({ organisationId: this.organisation.id }))
            .catch(e => console.error(e));
    }

    async createContentCollectionAction(): Promise<any> {
        this._router.navigate(contentCollectionCreateRoute.commands({ organisationId: this.organisation.id }))
            .catch(e => console.error(e));
    }

    async requestResetPassword(sysAdmin: User, panel: PanelComponent): Promise<any> {
        const maybeRemove = await this._confirmationDialogOpener.openDialog({
            title: "Reset Organisation User Password",
            message: `Are you sure you want to reset password for user "${sysAdmin.firstName} ${sysAdmin.lastName}"?`,
            confirmButtonTitle: "Reset Password",
            rejectButtonTitle: "Cancel",
        });
        if (maybeRemove) {
            return this._requestResetPassword(sysAdmin, panel);
        }
    }

    gotoContentAction(content: Content): void {
        this._router.navigate(contentDetailsRoute.commands({ contentId: content.id }))
            .catch(e => console.error(e));
    }

    gotoUserAction(user: User): void {
        this._router.navigate(userDetailsRoute.commands({ userId: user.id, organisationId: this.organisation.id }))
            .catch(e => console.error(e));
    }

    gotoUserGroupAction(userGroup: UserGroup): void {
        this._router.navigate(userGroupDetailsRoute.commands({ userGroupId: userGroup.id }))
            .catch(e => console.error(e));
    }

    gotoContentCollectionAction(contentCollection: ContentCollection): void {
        this._router.navigate(contentCollectionDetailsRoute.commands({ contentCollectionId: contentCollection.id }))
            .catch(e => console.error(e));
    }

    private async _removeUser(user: User, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userList.page = await this._dataIO.removeUser({ userId: user.id, zeroBasedPageIndex, searchText: this.usersFilter.value });
            this._message.withInfo(`Removed user "${user.firstName} ${user.lastName}" from the organisation.`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.usersPaginator) {
                this.usersPaginator.pageIndex = this.userList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to remove user "${user.firstName} ${user.lastName}" from the organisation.`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeContent(content: Content, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentList.page = await this._dataIO.removeContent({ contentId: content.id, zeroBasedPageIndex, searchText: this.contentFilter.value });
            this._message.withInfo(`Content "${content.title} has been deleted.`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentItemsPaginator) {
                this.contentItemsPaginator.pageIndex = this.contentList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to delete content "${content.title}.`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeUserGroup(userGroup: UserGroup, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.userGroupList.page = await this._dataIO.removeUserGroup({ userGroupId: userGroup.id, zeroBasedPageIndex, searchText: this.userGroupsFilter.value });
            this._message.withInfo(`User group "${userGroup.name} has been deleted.`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.userGroupsPaginator) {
                this.userGroupsPaginator.pageIndex = this.userGroupList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to delete user group "${userGroup.name}.`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _removeContentCollection(contentCollection: ContentCollection, zeroBasedPageIndex: number, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        try {
            this.contentCollectionList.page = await this._dataIO.removeContentCollection({ contentCollectionId: contentCollection.id, zeroBasedPageIndex, searchText: this.contentCollectionsFilter.value });
            this._message.withInfo(`Content collection "${contentCollection.name} has been deleted.`).showBriefly();
        } catch (e) {
            // Restore the paginator to the pre-load state (items/pageindex combo)
            if (this.contentCollectionsPaginator) {
                this.contentCollectionsPaginator.pageIndex = this.contentCollectionList.page.zeroBasedPageIndex;
            }
            this._message.withError(`Failed to delete content collection "${contentCollection.name}.`).showTillDismissed();
        } finally {
            panel.busy = false;
        }
    }

    private async _requestResetPassword(sysAdmin: User, panel: PanelComponent): Promise<void> {
        panel.busy = true;
        this._dataIOCommonServiceResolver.requestResetPassword(sysAdmin.email)
            .then(_ => this._message.withInfo(`Reset password request sent for user "${sysAdmin.firstName} ${sysAdmin.lastName}"`).showBriefly())
            .catch(_ => this._message.withError(`Failed to send request to reset password for "${sysAdmin.firstName} ${sysAdmin.lastName}".`).showTillDismissed());
        panel.busy = false;
    }
}
