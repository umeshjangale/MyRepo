import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable, of } from "rxjs";
import { catchError, mergeMap, take } from "rxjs/operators";

import { OrganisationDetailsContentCollectionsGQL, OrganisationDetailsContentGQL, OrganisationDetailsInitialDataGQL, OrganisationDetailsUserGroupsGQL, OrganisationDetailsUsersGQL, RemoveContentCollectionGQL, RemoveContentGQL, RemoveUserFromOrganisationGQL, RemoveUserGroupGQL, UpdateOrganisationGQL } from "../../generated/graphql";
import { organisationDetailsRoute } from "../routes";
import { ResolverTools } from "../services/resolver-tools.service";

import { DataIO } from "./data-io";

const CONTENT_ITEMS_PER_PAGE = 15;
const USERS_PER_PAGE = 15;
const USER_GROUPS_PER_PAGE = 5;
const CONTENT_COLLECTIONS_PER_PAGE = 5;

@Injectable()
export class DataIOResolver implements Resolve<DataIO> {
    constructor(
        private readonly _organisationDetailsContentCollectionsGQL: OrganisationDetailsContentCollectionsGQL,
        private readonly _organisationDetailsInitialDataGQL: OrganisationDetailsInitialDataGQL,
        private readonly _organisationDetailsContentGQL: OrganisationDetailsContentGQL,
        private readonly _organisationDetailsUsersGQL: OrganisationDetailsUsersGQL,
        private readonly _organisationDetailsUserGroupsGQL: OrganisationDetailsUserGroupsGQL,
        private readonly _updateOrganisationGQL: UpdateOrganisationGQL,
        private readonly _removeUserGQL: RemoveUserFromOrganisationGQL,
        private readonly _removeContentGQL: RemoveContentGQL,
        private readonly _removeUserGroupGQL: RemoveUserGroupGQL,
        private readonly _removeContentCollectionGQL: RemoveContentCollectionGQL,
        private readonly _resolverTools: ResolverTools,
    ) {
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<DataIO> {
        const { organisationId } = organisationDetailsRoute.parameters(route.paramMap);
        return this._organisationDetailsInitialDataGQL
            .fetch({
                organisationId,
                contentPageSize: CONTENT_ITEMS_PER_PAGE,
                usersPageSize: USERS_PER_PAGE,
                userGroupsPageSize: USER_GROUPS_PER_PAGE,
                contentCollectionsPageSize: CONTENT_COLLECTIONS_PER_PAGE,
            })
            .pipe(
                take(1),
                mergeMap(result => {
                    const data = result.data;
                    if (data.node) {
                        return of(this._createDataIO(
                            {
                                currentUser: data.me,
                                organisation: data.node,
                                contentItems: {
                                    ...data.node.content,
                                    zeroBasedPageIndex: 0,
                                },
                                users: {
                                    ...data.node.users,
                                    zeroBasedPageIndex: 0,
                                },
                                userGroups: {
                                    ...data.node.userGroups,
                                    zeroBasedPageIndex: 0,
                                },
                                contentCollections: {
                                    ...data.node.contentCollections,
                                    zeroBasedPageIndex: 0,
                                },
                                contentItemsPerPage: CONTENT_ITEMS_PER_PAGE,
                                usersPerPage: USERS_PER_PAGE,
                                userGroupsPerPage: USER_GROUPS_PER_PAGE,
                                contentCollectionsPerPage: CONTENT_COLLECTIONS_PER_PAGE,
                            },
                            organisationId,
                        ));
                    } else {
                        return this._resolverTools.showErrorNotFound();
                    }
                }),
                catchError(() => this._resolverTools.showErrorNotFound()),
            );
    }

    private _createDataIO(initial: DataIO["initial"], organisationId: string): DataIO {
        return {
            initial,

            contentItemsPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._organisationDetailsContentGQL
                    .fetch(
                        {
                            searchText,
                            organisationId,
                            pageSize: CONTENT_ITEMS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const data = result.data;
                if (!data.node) {
                    return { items: [], totalCount: 0, zeroBasedPageIndex };
                }

                return {
                    ...data.node.content,
                    zeroBasedPageIndex,
                };
            },

            usersPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._organisationDetailsUsersGQL
                    .fetch(
                        {
                            searchText,
                            organisationId,
                            pageSize: USERS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const data = result.data;
                if (!data.node) {
                    return { items: [], totalCount: 0, zeroBasedPageIndex };
                }

                return {
                    ...data.node.users,
                    zeroBasedPageIndex,
                };
            },

            userGroupsPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._organisationDetailsUserGroupsGQL
                    .fetch(
                        {
                            organisationId,
                            searchText,
                            pageSize: USER_GROUPS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const data = result.data;
                if (!data.node) {
                    return { items: [], totalCount: 0, zeroBasedPageIndex };
                }

                return {
                    ...data.node.userGroups,
                    zeroBasedPageIndex,
                };
            },

            contentCollectionsPage: async ({ zeroBasedPageIndex, searchText }) => {
                const result = await this._organisationDetailsContentCollectionsGQL
                    .fetch(
                        {
                            organisationId,
                            searchText,
                            pageSize: CONTENT_COLLECTIONS_PER_PAGE,
                            oneBasedPageNumber: zeroBasedPageIndex + 1,
                        },
                        {
                            fetchPolicy: "network-only",
                        },
                    )
                    .toPromise();
                const data = result.data;
                if (!data.node) {
                    return { items: [], totalCount: 0, zeroBasedPageIndex };
                }

                return {
                    ...data.node.contentCollections,
                    zeroBasedPageIndex,
                };
            },

            updateOrganisation: async organisation => {
                const result = await this._updateOrganisationGQL.mutate(organisation).toPromise();
                if (!result.data) {
                    throw new Error();
                }
                return result.data.updateOrganisation;
            },

            removeUser: async ({ userId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeUserGQL.mutate({
                    userId,
                    organisationId,
                    searchText,
                    pageSize: USERS_PER_PAGE,
                    oneBasedPageNumber: zeroBasedPageIndex + 1,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.removeUserFromOrganisation.users,
                    zeroBasedPageIndex,
                };
            },

            removeContent: async ({ contentId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeContentGQL.mutate({
                    contentId,
                    searchText,
                    pageSize: CONTENT_ITEMS_PER_PAGE,
                    oneBasedPageNumber: zeroBasedPageIndex + 1,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.removeContent.content,
                    zeroBasedPageIndex,
                };
            },

            removeUserGroup: async ({ userGroupId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeUserGroupGQL.mutate({
                    userGroupId,
                    searchText,
                    pageSize: USER_GROUPS_PER_PAGE,
                    oneBasedPageNumber: zeroBasedPageIndex + 1,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.removeUserGroup.userGroups,
                    zeroBasedPageIndex,
                };
            },

            removeContentCollection: async ({ contentCollectionId, zeroBasedPageIndex, searchText }) => {
                const result = await this._removeContentCollectionGQL.mutate({
                    contentCollectionId,
                    searchText,
                    pageSize: CONTENT_COLLECTIONS_PER_PAGE,
                    oneBasedPageNumber: zeroBasedPageIndex + 1,
                }).toPromise();

                const data = result.data;
                if (!data) {
                    throw new Error();
                }

                return {
                    ...data.removeContentCollection.contentCollections,
                    zeroBasedPageIndex,
                };
            },
        };
    }
}
