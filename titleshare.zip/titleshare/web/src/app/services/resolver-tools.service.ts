import { Location } from "@angular/common";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { EMPTY, Observable } from "rxjs";

@Injectable()
export class ResolverTools {
    constructor(
        private readonly _location: Location,
        private readonly _router: Router,
    ) {
    }

    showErrorNotFound(): Observable<never> {
        this._navigateToErrorNotFound()
            .catch(e => console.error(e));
        return EMPTY;
    }

    private async _navigateToErrorNotFound(): Promise<void> {
        // See https://stackoverflow.com/questions/42055517/angular-displaying-target-url-when-resolve-fails
        const path = this._location.path();
        await this._router.navigate(["error/not-found"], { skipLocationChange: true });
        this._location.replaceState(path);
    }
}
