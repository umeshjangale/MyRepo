import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Apollo } from "apollo-angular";

import { LogoutUserGQL } from "../../generated/graphql";
import { accountLoginRoute } from "../routes";

@Injectable()
export class LogoutUser {
    constructor(
        private readonly _apollo: Apollo,
        private readonly _logoutUserGQL: LogoutUserGQL,
        private readonly _router: Router,
    ) {
    }

    async logoutUser(): Promise<void> {
        try {
            await this._logoutUserGQL
                .mutate()
                .toPromise();
        } catch (e) {
            console.error("failed to clear remote token", e);
        }
        localStorage.removeItem("token");
        await this._apollo.getClient().clearStore();
        await this._router.navigate(accountLoginRoute.commands({}));
    }
}
