import { OrganisationDetailsParameters } from "../organisation.details.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const organisationSegment = "organisation";
const organisationIdParameter = "organisationId";
export const routerConfigPath = `${organisationSegment}/:${organisationIdParameter}`;
export const { commands, parameters, url } = createRoute<OrganisationDetailsParameters>(() => ({
    commands({ organisationId }) {
        return [`/${organisationSegment}`, organisationId];
    },
    parameters(values) {
        return {
            organisationId: values.required(organisationIdParameter),
        };
    },
}));
