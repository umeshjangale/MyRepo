import { createRoute } from "../routes-utils";
import { UserGroupDetailsParameters } from "../user-group.details.page/page-route-parameters";

const userGroupSegment = "user-group";
const userGroupIdParameter = "userGroupId";
export const routerConfigPath = `${userGroupSegment}/:${userGroupIdParameter}`;
export const { commands, parameters, url } = createRoute<UserGroupDetailsParameters>(() => ({
    commands({ userGroupId }) {
        return [`/${userGroupSegment}`, userGroupId];
    },
    parameters(values) {
        return {
            userGroupId: values.required(userGroupIdParameter),
        };
    },
}));
