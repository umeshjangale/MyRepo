import { OrganisationCreateParameters } from "../organisation.create.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const newOrganisationSegment = "new-organisation";
export const routerConfigPath = `${newOrganisationSegment}`;
export const { commands, parameters, url } = createRoute<OrganisationCreateParameters>(() => ({
    commands({ }) {
        return [`/${newOrganisationSegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
