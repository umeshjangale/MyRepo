import { createRoute } from "../routes-utils";
import { UserInviteParameters } from "../user.invite.page/page-route-parameters";

const inviteUserSegment = "invite-user";
export const routerConfigPath = `${inviteUserSegment}`;
export const { commands, parameters, url } = createRoute<UserInviteParameters>(() => ({
    commands({ organisationId, roleType, completionTitle, completionUrl }) {
        return [`/${inviteUserSegment}`, { organisationId, roleType, completionTitle, completionUrl }];
    },
    parameters(values) {
        return {
            organisationId: values.optional("organisationId"),
            roleType: values.optional("roleType"),
            completionTitle: values.optional("completionTitle"),
            completionUrl: values.optional("completionUrl"),
        };
    },
}));
