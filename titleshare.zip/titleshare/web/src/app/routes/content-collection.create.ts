import { ContentCollectionCreateParameters } from "../content-collection.create.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const newContentCollectionSegment = "new-content-collection";
export const routerConfigPath = `${newContentCollectionSegment}`;
export const { commands, parameters, url } = createRoute<ContentCollectionCreateParameters>(() => ({
    commands({ organisationId }) {
        return [`/${newContentCollectionSegment}`, { organisationId }];
    },
    parameters(values) {
        return {
            organisationId: values.optional("organisationId"),
        };
    },
}));
