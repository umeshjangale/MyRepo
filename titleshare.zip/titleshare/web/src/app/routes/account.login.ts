import { AccountLoginParameters } from "../account.login.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const loginSegment = "login";
export const routerConfigPath = `${loginSegment}`;
export const { commands, parameters, url } = createRoute<AccountLoginParameters>(() => ({
    commands({ successUrl }) {
        return [`/${loginSegment}`, { successUrl }];
    },
    parameters(values) {
        return {
            successUrl: values.optional("successUrl"),
        };
    },
}));
