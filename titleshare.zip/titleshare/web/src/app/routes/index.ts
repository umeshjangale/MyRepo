// tslint:disable ordered-imports

import * as accountDetailsRoute from "./account.details";
export { accountDetailsRoute };

import * as accountLoginRoute from "./account.login";
export { accountLoginRoute };

// This route is the target for the link within server generated user reset password emails
import * as accountResetPasswordRoute from "./account.reset-password";
export { accountResetPasswordRoute };

import * as contentCollectionCreateRoute from "./content-collection.create";
export { contentCollectionCreateRoute };

import * as contentCollectionDetailsRoute from "./content-collection.details";
export { contentCollectionDetailsRoute };

import * as contentDetailsRoute from "./content.details";
export { contentDetailsRoute };

import * as informationMobileAppsRoute from "./information.mobile-apps";
export { informationMobileAppsRoute };

import * as informationPrivacyRoute from "./information.privacy";
export { informationPrivacyRoute };

import * as informationTermsRoute from "./information.terms";
export { informationTermsRoute };

import * as organisationCreateRoute from "./organisation.create";
export { organisationCreateRoute };

import * as organisationDetailsRoute from "./organisation.details";
export { organisationDetailsRoute };

import * as userGroupCreateRoute from "./user-group.create";
export { userGroupCreateRoute };

import * as userGroupDetailsRoute from "./user-group.details";
export { userGroupDetailsRoute };

import * as userDashboardRoute from "./user.dashboard";
export { userDashboardRoute };

import * as userInviteRoute from "./user.invite";
export { userInviteRoute };

import * as userDetailsRoute from "./user.details";
export { userDetailsRoute };
