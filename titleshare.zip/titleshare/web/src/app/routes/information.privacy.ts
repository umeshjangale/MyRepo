import { createRoute } from "../routes-utils";

const privacySegment = "privacy";
export const routerConfigPath = `${privacySegment}`;
export const { commands, parameters, url } = createRoute<{}>(() => ({
    commands({ }) {
        return [`/${privacySegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
