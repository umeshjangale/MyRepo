import { createRoute } from "../routes-utils";
import { UserDetailsParameters } from "../user.details.page/page-route-parameters";

const organisationSegment = "organisation";
const organisationIdParameter = "organisationId";
const userSegment = "user";
const userIdParameter = "userId";
export const userRouterConfigPath = `${userSegment}/:${userIdParameter}`;
export const organisationUserRouterConfigPath = `${organisationSegment}/:${organisationIdParameter}/${userSegment}/:${userIdParameter}`;
export const { commands, parameters, url } = createRoute<UserDetailsParameters>(() => ({
    commands({ userId, organisationId }) {
        if (organisationId) {
            return [`/${organisationSegment}`, organisationId, `${userSegment}`, userId];
        }

        return [`/${userSegment}`, userId];
    },
    parameters(values) {
        return {
            organisationId: values.optional(organisationIdParameter),
            userId: values.required(userIdParameter),
        };
    },
}));
