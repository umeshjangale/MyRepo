import { createRoute } from "../routes-utils";

const termsSegment = "terms";
export const routerConfigPath = `${termsSegment}`;
export const { commands, parameters, url } = createRoute<{}>(() => ({
    commands({ }) {
        return [`/${termsSegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
