import { ContentCollectionDetailsParameters } from "../content-collection.details.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const contentCollectionSegment = "content-collection";
const contentCollectionIdParameter = "contentCollectionId";

export const routerConfigPath = `${contentCollectionSegment}/:${contentCollectionIdParameter}`;
export const { commands, parameters, url } = createRoute<ContentCollectionDetailsParameters>(() => ({
    commands({ contentCollectionId }) {
        return [`/${contentCollectionSegment}`, contentCollectionId];
    },
    parameters(values) {
        return {
            contentCollectionId: values.required(contentCollectionIdParameter),
        };
    },
}));
