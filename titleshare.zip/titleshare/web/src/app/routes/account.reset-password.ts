import { ParamMap } from "@angular/router";

import { AccountResetPasswordParameters } from "../account.reset-password.page/page-route-parameters";
import { ParameterValues } from "../routes-utils";

// This route is the target for the link within server generated user reset password emails
const resetPasswordSegment = "reset-password";
export const routerConfigPath = `${resetPasswordSegment}`;
export const { parameters } = (() => ({
    parameters(paramMap: ParamMap, queryParamMap: ParamMap): AccountResetPasswordParameters {
        const queryValues = new ParameterValues<AccountResetPasswordParameters>(queryParamMap);
        return {
            email: queryValues.required("email"),
            token: queryValues.required("token"),
        };
    },
}))();
