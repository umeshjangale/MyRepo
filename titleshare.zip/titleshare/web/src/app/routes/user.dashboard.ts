import { createRoute } from "../routes-utils";

const dashboardSegment = "dashboard";
export const routerConfigPath = `${dashboardSegment}`;
export const { commands, parameters, url } = createRoute<{}>(() => ({
    commands({ }) {
        return [`/${dashboardSegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
