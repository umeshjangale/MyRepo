import { createRoute } from "../routes-utils";
import { UserGroupCreateParameters } from "../user-group.create.page/page-route-parameters";

const newUserGroupSegment = "new-user-group";
export const routerConfigPath = `${newUserGroupSegment}`;
export const { commands, parameters, url } = createRoute<UserGroupCreateParameters>(() => ({
    commands({ organisationId }) {
        return [`/${newUserGroupSegment}`, { organisationId }];
    },
    parameters(values) {
        return {
            organisationId: values.optional("organisationId"),
        };
    },
}));
