import { ContentDetailsParameters } from "../content.details.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const contentSegment = "content";
const contentIdParameter = "contentId";
export const routerConfigPath = `${contentSegment}/:${contentIdParameter}`;
export const { commands, parameters, url } = createRoute<ContentDetailsParameters>(() => ({
    commands({ contentId }) {
        return [`/${contentSegment}`, contentId];
    },
    parameters(values) {
        return {
            contentId: values.required(contentIdParameter),
        };
    },
}));
