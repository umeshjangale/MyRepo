import { createRoute } from "../routes-utils";

const mobileAppsSegment = "mobile-apps";
export const routerConfigPath = `${mobileAppsSegment}`;
export const { commands, parameters, url } = createRoute<{}>(() => ({
    commands({ }) {
        return [`/${mobileAppsSegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
