import { AccountDetailsParameters } from "../account.details.page/page-route-parameters";
import { createRoute } from "../routes-utils";

const accountSegment = "account";
export const routerConfigPath = `${accountSegment}`;
export const { commands, parameters, url } = createRoute<AccountDetailsParameters>(() => ({
    commands({ }) {
        return [`/${accountSegment}`];
    },
    parameters(values) {
        return {
        };
    },
}));
