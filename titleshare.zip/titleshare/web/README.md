# Web

The user-facing web project for the titleShare family of projects.

## Setup

Dependencies:
- node >= 10
- yarn

Run `yarn install` from within the root of this project. Then use the following instructions for running or building.

## Development server

Run `yarn ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Build

Run `yarn ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Lint

Run `yarn ng lint` to lint the project.

## Further help

To get more help on the Angular CLI use `yarn ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
