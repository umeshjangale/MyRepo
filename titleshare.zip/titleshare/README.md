# titleShare
The titleShare [web](./web) and [server](./server) projects.

## CI 

Circle CI is configured to deploy both the web and server apps to an AWS elastic beanstalk environment.

Merge to `release-demo` to deploy to https://demo.title-share.net

Merge to `release-prod` to deploy to https://portal.title-share.net
