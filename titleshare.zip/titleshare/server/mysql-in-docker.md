To aid in cross-platform development, and to ensure the local database matches as closely as possible to the production database (in terms of mysql server version), docker can be used to run the mysql server.

See https://hub.docker.com/r/mysql/mysql-server/ for more info.

```
docker run --name=mysql_5_6 -d -e MYSQL_ROOT_HOST=% -p 3306:3306 mysql/mysql-server:5.6
# Dump the password to the console (you must copy it to clipboard).
docker logs mysql_5_6 2>&1 | grep GENERATED
# Paste the password when prompted below
docker exec -it mysql_5_6 mysqladmin -uroot -p password
# I changed it to "password", secure, eh?

# Create the db
docker exec -it mysql_5_6 mysqladmin -uroot -p create titleshare-dev
# Create the user
docker exec -it mysql_5_6 mysql -uroot -p
CREATE USER 'localdev' IDENTIFIED BY 'localdev';
GRANT ALL ON `titleshare-dev`.* TO 'localdev';
```

To start/stop the container:
```
# Takes up to 30 seconds to start, can check state with docker ps
docker container start mysql_5_6
docker container stop mysql_5_6
```

To drop/create the database:
```
docker exec -it mysql_5_6 mysqladmin -uroot -p drop titleshare-dev
docker exec -it mysql_5_6 mysqladmin -uroot -p create titleshare-dev
```