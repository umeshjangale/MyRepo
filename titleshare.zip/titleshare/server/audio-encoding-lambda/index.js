process.env["PATH"] = process.env["PATH"] + ":" + process.env["LAMBDA_TASK_ROOT"];
const AWS = require("aws-sdk");
const { execFile } = require("child_process");
const helper = require("./helper");
const util = require("util");

function getSoxFormatOptions(format) {
    switch (format) {
        case "mp3-high":
            return ["-c 1", "-C 128"];
        case "mp3-low":
        default:
            return ["-c 1", "-C 64"];
    }
}

exports.handler = async (event) => {

    for (const record of event.Records) {
        const messageId = record.messageId;
        const body = JSON.parse(record.body);
        console.log(`Processing message Id: '${messageId}' ${JSON.stringify(body)}`);

        const sourceBucket = body.sourceBucket;
        const sourceStoragePath = body.sourceStoragePath;
        const destinationBucket = body.destinationBucket;
        const destinationStoragePath = body.destinationStoragePath;
        const destinationContentType = body.destinationContentType;
        const destinationMetadata = body.destinationMetadata;
        const completionQueueUrl = body.completionQueueUrl;
        const completionQueue = body.completionQueue;
        const formatOptions = getSoxFormatOptions(body.format);

        if (!sourceBucket) throw new Error(`Invalid sourceBucket '${sourceBucket}'`);
        if (!sourceStoragePath) throw new Error(`Invalid sourceStoragePath '${sourceStoragePath}'`);
        if (!destinationBucket) throw new Error(`Invalid destinationBucket '${destinationBucket}'`);
        if (!destinationStoragePath) throw new Error(`Invalid destinationStoragePath '${destinationStoragePath}'`);
        if (!destinationContentType) throw new Error(`Invalid destinationContentType '${destinationContentType}'`);
        if (!destinationMetadata) throw new Error(`Invalid destinationMetadata '${destinationMetadata}'`);
        if (!completionQueueUrl) throw new Error(`Invalid completionQueueUrl '${completionQueueUrl}'`);
        if (!completionQueue) throw new Error(`Invalid completionQueue '${completionQueue}'`);
        if (!body.format) throw new Error(`Invalid format '${body.format}'`);

        console.log(`Progress message 1 Id: '${messageId}'`);

        const inputFilename = "/tmp/" + helper.getFilename(sourceStoragePath);
        const outputFilename = "/tmp/output." + helper.getFileExtensionWithoutDot(destinationStoragePath);
        await helper.downloadToFile(sourceBucket, sourceStoragePath, inputFilename);

        const sox = "sox";

        const args = [inputFilename];
        if (formatOptions && formatOptions.length) {
            args.push(...formatOptions);
        }

        args.push(outputFilename);

        console.log(`Progress message 2... Id: '${messageId}' sox args: ${JSON.stringify(args)}`);
        const { stderr } = await util.promisify(execFile)(sox, args);
        console.log(`Progress message 3 Id: '${messageId}'`);

        helper.deleteFile(inputFilename);

        if (stderr) {
            console.error(`message Id ${messageId} failed to convert audio file '${sourceBucket}/${sourceStoragePath}'. ${stderr}`);
            throw new Error(stderr);
        }

        const fileBytes = await helper.getFileBytes(outputFilename);
        console.log(`Progress message 4 Id: '${messageId}' file bytes: ${fileBytes}`);
        const duration = await helper.getDurationFromHeader(outputFilename);
        console.log(`Progress message 5 Id: '${messageId}' duration: ${duration}`);

        await helper.uploadFile(destinationBucket, destinationStoragePath, outputFilename, destinationContentType, destinationMetadata);

        helper.deleteFile(outputFilename);

        const sqs = new AWS.SQS();

        const result = await sqs.sendMessage({
            QueueUrl: completionQueueUrl,
            MessageBody: JSON.stringify({
                fileBytes,
                duration,
                ...body,
                queue: completionQueue
            }),
        }).promise();

        console.log(`Message queued for file '${destinationStoragePath}' msgId:${result.MessageId}`);
        console.log(`Processing complete Id: '${messageId}'`);
    }

    return "Sox lambda function compeleted";
};


