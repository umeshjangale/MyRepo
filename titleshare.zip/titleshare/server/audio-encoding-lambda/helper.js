const AWS = require("aws-sdk");
const fs = require("fs");
const path = require("path");
const util = require("util");
const { execFile } = require("child_process");

exports.downloadToFile = async function downloadToFile(bucket, key, filename) {

    return new Promise((res, rej) => {
        const s3 = new AWS.S3();

        const fileStream = fs.createWriteStream(filename);
        const objStream = s3.getObject({ Bucket: bucket, Key: key }).createReadStream();
        objStream.pipe(fileStream);

        objStream.on("end", () => {
            res();
        }).on("error", err => {
            rej(err);
        });
    });
};

exports.uploadFile = async function uploadFile(bucket, key, filename, contentType, metadata) {
    const s3 = new AWS.S3();
    await s3.putObject({
        Bucket: bucket,
        Key: key,
        Body: fs.createReadStream(filename),
        ContentType: contentType,
        Metadata: metadata,
    }).promise();
};

exports.getFilename = function getFilename(value) {
    if (!value || value.endsWith("/")) return "";

    return path.basename(value);
};

exports.changeExtension = function changeExtension(filename, newExtensionWithoutDot) {
    const ext = path.extname(filename);

    let result = filename;
    if (ext) {
        result = result.substr(0, filename.length - ext.length);
    }

    if (newExtensionWithoutDot) {
        result += `.${newExtensionWithoutDot}`;
    }

    return result;
};

exports.getFileExtensionWithoutDot = function getFileExtensionWithoutDot(value) {
    let ext = path.extname(value);

    if (ext.startsWith(".")) {
        ext = ext.substring(1);
    }

    return ext;
};

exports.getFileBytes = async function getFileBytes(filePath) {
    return new Promise((res, rej) => {

        fs.stat(filePath, (err, stats) => {
            if (err) {
                rej(err);
                return;
            }
            res(stats.size);
        });
    });
};

exports.deleteFile = function deleteFile(filePath) {
    fs.unlink(filePath, err => {
        if (err) {
            console.log(`ERR: Failed to delete file '${filePath}'. ${err}`);
        }
    });
};

exports.getDurationFromHeader = async function getDurationFromHeader(filePath) {
    let { stdout, stderr } = await util.promisify(execFile)("sox", ["--i", "-D", filePath]);

    let durationString = stdout.trim();
    if (!durationString) throw new Error(`Failed to fetch duration from audio file header. Sox error: '${stderr}'`);
    if (isNaN(durationString)) {
        throw new Error(`Failed to fetch duration from audio file header. Sox output: '${durationString}' '${stderr}'`);
    } else {
        return Number(durationString);
    }
}
