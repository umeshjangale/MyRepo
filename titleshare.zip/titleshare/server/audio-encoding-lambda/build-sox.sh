# To be run on the same OS used by the AWS lambda execution environment. 
# Currently Amazon Linux amzn-ami-hvm-2017.03.1.20170812-x86_64-gp2  (docker image amazonlinux:2017.03.1.20170812)

yum -y install gcc-c++ tar gzip make xz findutils

curl -L -o libmad-0.15.1b.tar.gz https://downloads.sourceforge.net/project/mad/libmad/0.15.1b/libmad-0.15.1b.tar.gz
      tar -xvf libmad-0.15.1b.tar.gz
      rm libmad-0.15.1b.tar.gz
      cd libmad-0.15.1b
      sed -i '/-fforce-mem/d' configure
      ./configure --prefix=/usr --disable-shared --enable-static
      make -s
      make install
cd ..

curl -L -o lame-3.100.tar.gz https://downloads.sourceforge.net/project/lame/lame/3.100/lame-3.100.tar.gz
      tar -xvf lame-3.100.tar.gz
      rm lame-3.100.tar.gz
      cd lame-3.100
      ./configure --disable-shared --enable-static 
      make -s
      make install
cd ..

curl -L -o libogg-1.3.3.tar.gz https://ftp.osuosl.org/pub/xiph/releases/ogg/libogg-1.3.3.tar.gz
      tar -xvf libogg-1.3.3.tar.gz
      rm libogg-1.3.3.tar.gz
      cd libogg-1.3.3
      ./configure --disable-shared --enable-static 
      make -s
      make install
cd ..

curl -L -o libvorbis-1.3.5.tar.xz https://downloads.xiph.org/releases/vorbis/libvorbis-1.3.5.tar.xz
      tar -xvf libvorbis-1.3.5.tar.xz
      rm libvorbis-1.3.5.tar.xz
      cd libvorbis-1.3.5
      ./configure --disable-shared --enable-static 
      make -s
      make install
cd ..

curl -L -o flac-1.3.2.tar.xz https://versaweb.dl.sourceforge.net/project/flac/flac-src/flac-1.3.2.tar.xz
      tar -xvf flac-1.3.2.tar.xz
      rm flac-1.3.2.tar.xz
      cd flac-1.3.2
      ./configure --disable-shared --enable-static 
      make -s
      make install
cd ..

mkdir sox
    cd sox
    curl -L -o sox-14.4.2.tar.gz https://downloads.sourceforge.net/project/sox/sox/14.4.2/sox-14.4.2.tar.gz
    tar xvfz sox-14.4.2.tar.gz
    cd sox-14.4.2
    ./configure --disable-shared --enable-static
    make -s
    make install
