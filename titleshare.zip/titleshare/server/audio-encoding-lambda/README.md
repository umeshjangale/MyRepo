# Audio encoding function for AWS lambda

No CI is setup for this AWS lambda function.

The static sox executable is not kept in source control due to its size. If needed, it can be extracted from the lambda deployment package which can be downloaded from the AWS console, or it can be built from source.

## To build a static sox executable

Start a docker container using the the amazon linux version used in the lambda environment

 `docker run -it --name static-sox amazonlinux:2.0.20190823.1 bash`

 Copy the build script to the container

 `docker cp ./build-sox.sh static-sox:/`

 Run the build script in the container

 `./build-sox.sh`

 Copy the sox exe from the container to your local machine

 `docker cp static-sox:/usr/local/bin/sox .`

 ## To Deploy

Ensure the sox executable is in the root of the zip file

Run `zip -r sox-lambda.zip .` from the current directory then upload the zip file to AWS lambda.




