import { pascalCase } from 'change-case';
import { Field } from 'graphql-codegen-core';

const primitives = {
  "String": "string",
  "Int": "number",
  "Float": "number",
  "Boolean": "boolean",
  "ID": "string",
};

export function getResultType(type: Field, options: Handlebars.HelperOptions, skipPascalCase = false) {
  const config = options.data.root.config || {};
  const realType = getRealType(type, config.interfacePrefix, options, skipPascalCase);

  const useImmutable = !!config.immutableTypes;

  if (type.isArray) {
    let result = realType;

    const dimension = type.dimensionOfArray + 1;

    if (type.isNullableArray && !config.noNamespaces) {
      result = useImmutable ? [realType, 'null'].join(' | ') : `(${[realType, 'null'].join(' | ')})`;
    }

    if (useImmutable) {
      result = `${new Array(dimension).join('ReadonlyArray<')}${result}${new Array(dimension).join('>')}`;
    } else {
      result = `${result}${new Array(dimension).join('[]')}`;
    }

    if (!type.isRequired) {
      result = [result, 'null'].join(' | ');
    }

    return result;
  } else {
    if (type.isRequired) {
      return realType;
    } else {
      return [realType, 'null'].join(' | ');
    }
  }
}

function getRealType(type: Field, interfacePrefix: string, options: Handlebars.HelperOptions, skipPascalCase = false): string {
  const baseType = type.type;
  const underscorePrefix = type.type.match(/^[\_]+/) || '';

  if (primitives[baseType]) return primitives[baseType];

  const prefix = type.isScalar ? '' : interfacePrefix || '';
  const typeName = skipPascalCase ? baseType : pascalCase(baseType);
  return `${prefix}${underscorePrefix}${typeName}`;
}
