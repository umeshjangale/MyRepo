import { pascalCase } from 'change-case';

function getFieldResolverName(name: string) {
  return `${pascalCase(name)}Resolver`;
}

export = getFieldResolverName;
