
import { Field, Type, GraphQLSchema } from "graphql-codegen-core";
import { GraphQLInterfaceType } from "graphql";

function requiresTypename(type: Type, options: Handlebars.HelperOptions) {

    const schema: GraphQLSchema = options.data.root.rawSchema;

    const baseType = schema.getType(type.name);
    if (baseType instanceof GraphQLInterfaceType) {
        return true;
    }

    return false;
}

export = requiresTypename;
