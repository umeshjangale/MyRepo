function getScalarType(type: string, options: Handlebars.HelperOptions) {

  // HACK: Since options.data.root.config.scalars doesn't seem to work.
  // const config = options.data.root.config || {
  const config = {
    scalars: {
      Date: "Date",
      Long: "number",
    },
  };

  if (config.scalars && type in config.scalars) {
    return config.scalars[type];
  } else {
    return 'any';
  }
}

export = getScalarType;
