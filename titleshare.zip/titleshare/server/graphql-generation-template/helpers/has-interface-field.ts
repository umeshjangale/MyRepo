
import { Field, Type, GraphQLSchema } from "graphql-codegen-core";
import { GraphQLObjectType } from "graphql";

function hasInterfaceField(type: Type, field: Field, options: Handlebars.HelperOptions) {

    const schema: GraphQLSchema = options.data.root.rawSchema;

    const baseType = schema.getType(type.name) as GraphQLObjectType;
    if (!baseType) return false;

    if (baseType.getInterfaces) {
        const interfaces = baseType.getInterfaces();
        for (const inter of interfaces) {

            const fieldMap = inter.getFields();
            for (const fKey of Object.keys(fieldMap)) {
                if (fieldMap[fKey].name === field.name) {
                    return true;
                }
            }
        }
    }
    return false;
}

export = hasInterfaceField;
