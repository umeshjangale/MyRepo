function isRootType(name: string) {
    const v = name.toLowerCase();
    return v === "query" || v === "mutation" || v === "Subscription";
}

export = isRootType;
