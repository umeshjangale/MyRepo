## How to make a local database match the production database
aka How to run all migrations against an empty local database

There be landmines in the process for database migrations. This is because some migrations depend upon the shape of the typescript entities at the point in time of the migration being created. New migrations should be written to avoid any dependency on the typescript entities.

The following script should allow one to setup a new database and then migrate it to match the schema present within the production database.

(the following steps assume that the config is setup so that `database.autoSyncSchema = false`, and that the command is being run from the `server` directory)
```
git checkout 2019-05-27 && rm -rf dist/ && yarn install && yarn build && yarn orm migration:run
git checkout c0afcfbaafecbf9ab4598f6450d330b3185ddeb5 && rm -rf dist/ && yarn install && yarn build && yarn orm migration:run
git checkout release-prod && rm -rf dist/ && yarn install && yarn build && yarn orm migration:run
```
