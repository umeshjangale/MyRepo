import gql from "graphql-tag";
import "jasmine";
import { getManager } from "typeorm";

import { encryptId } from "../../../src/security/data-protection";
import * as db from "../../../src/storage/db-entities";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql create user group API", () => {

    it("inserts user group into database", async () => {

        const org = data.organisations.carperHollins;
        const orgId = encryptId(NodeType.Organisation, org.id);
        const groupName = "test user group xxx1";
        const desc = "group description";
        const query = gql`mutation {
            createUserGroup(input: { name: "${groupName}", description: "${desc}", organisationId: "${orgId}" }) { id name description }
          }`;

        const manager = getManager();
        const user = data.users.julie;

        // Ensure it doesn't exists to begin with.
        let group = await manager.findOne(db.UserGroup, { name: groupName });
        expect(group).toBeUndefined();

        // Act
        const result = await request(query, getContext(user));

        expect(result.errors).toBeUndefined();

        // Ensure it now exists in the db.
        group = await manager.findOne(db.UserGroup, { name: groupName });
        expect(group).not.toBeUndefined();
        if (!group) return;

        expect(result.data).toEqual({ createUserGroup: { id: encryptId(NodeType.UserGroup, group.id), name: groupName, description: desc } });

        // Clean up
        await manager.remove(group);
    }, 200000);
});
