import gql from "graphql-tag";
import "jasmine";
import { getManager } from "typeorm";

import * as DataProtection from "../../../src/security/data-protection";
import * as db from "../../../src/storage/db-entities";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql update me API", () => {

    it("updates firstName and password", async () => {
        let userId: number | undefined;

        try {
            const currentPassword = "abc123";
            const newPassword = "def456";
            const newFirstName = "!new name!";
            const mgr = getManager();
            const user = await mgr.save(mgr.create(db.User, {
                firstName: "firstname!",
                lastName: "lastName!",
                password: await DataProtection.hashPassword(currentPassword),
            }));

            userId = user.id;
            const query = gql`mutation {
                updateMe(input: { currentPassword: "${currentPassword}" newPassword: "${newPassword}" firstName: "${newFirstName}" }) { id firstName lastName }
            }`;

            const result = await request(query, getContext(user));
            expect(result.errors).toBeUndefined();

            const updatedUser = await mgr.findOne(db.User, userId);

            expect(updatedUser).not.toBeUndefined();
            if (!updatedUser) return;
            expect(await DataProtection.comparePassword(newPassword, updatedUser.password)).toBeTruthy();
            expect(updatedUser.firstName).toEqual(newFirstName);
            expect(updatedUser.lastName).toEqual(user.lastName);

            expect(result.data).toEqual({ updateMe: { id: DataProtection.encryptId(NodeType.User, userId), firstName: newFirstName, lastName: user.lastName } });

        } finally {
            if (userId) {
                await getManager().createQueryBuilder().delete().from(db.User).where("id = :id", { id: userId }).execute();
            }
        }
    });
});
