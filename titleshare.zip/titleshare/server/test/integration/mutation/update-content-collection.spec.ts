
import gql from "graphql-tag";
import "jasmine";
import { getManager } from "typeorm";

import { encryptId } from "../../../src/security/data-protection";
import * as db from "../../../src/storage/db-entities";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql update content collection API", () => {

    it("updates name only", async () => {
        let ccid: number | undefined;

        try {
            const cc = await getManager().save(db.ContentCollection, {
                id: 0,
                name: "initial name",
                description: "initial description",
                organisation: data.organisations.carperHollins,
                signUpCodeEnabled: false,
            });
            ccid = cc.id;

            const query = gql`mutation {
                updateContentCollection(input: { id: "${encryptId(NodeType.ContentCollection, ccid)}" name: "updated name" }) { name description }
            }`;

            const result = await request(query, getContext(data.users.julie));
            expect(result.errors).toBeUndefined();

            const updatedCc = await getManager().findOne(db.ContentCollection, ccid);

            expect(updatedCc).not.toBeUndefined();
            if (!updatedCc) return;
            expect(updatedCc.name).toEqual("updated name");
            expect(updatedCc.description).toEqual("initial description");

            expect(result.data).toEqual({ updateContentCollection: { name: "updated name", description: "initial description" } });

        } finally {
            if (ccid) {
                await getManager().createQueryBuilder().delete().from(db.ContentCollection).where("id = :id", { id: ccid }).execute();
            }
        }
    });

    it("updates description only", async () => {
        let ccid: number | undefined;

        try {
            const cc = await getManager().save(db.ContentCollection, {
                id: 0,
                name: "initial name",
                description: "initial description",
                organisation: data.organisations.carperHollins,
                signUpCodeEnabled: false,
            });
            ccid = cc.id;

            const query = gql`mutation {
                updateContentCollection(input: { id: "${encryptId(NodeType.ContentCollection, ccid)}" description: "updated description" }) { name description }
            }`;

            const result = await request(query, getContext(data.users.julie));
            expect(result.errors).toBeUndefined();

            const updatedCc = await getManager().findOne(db.ContentCollection, ccid);

            expect(updatedCc).not.toBeUndefined();
            if (!updatedCc) return;
            expect(updatedCc.name).toEqual("initial name");
            expect(updatedCc.description).toEqual("updated description");

            expect(result.data).toEqual({ updateContentCollection: { name: "initial name", description: "updated description" } });

        } finally {
            if (ccid) {
                await getManager().createQueryBuilder().delete().from(db.ContentCollection).where("id = :id", { id: ccid }).execute();
            }
        }
    });

    it("cannot use invalid characters in sign up code ", async () => {
        let ccid: number | undefined;

        try {
            const cc = await getManager().save(db.ContentCollection, {
                id: 0,
                name: "ignored",
                description: "ignored",
                organisation: data.organisations.carperHollins,
                signUpCodeEnabled: false,
            });
            ccid = cc.id;

            const invalidCharacters = ["0", "o", "i", "l", "1", "9", "g"];

            for (const character of invalidCharacters) {
                const code = `test-code-${character}`;

                const query = gql`mutation {
                    updateContentCollection(input: { id: "${encryptId(NodeType.ContentCollection, ccid)}" signUpCode: "${code}" }) { name description }
                }`;

                const result = await request(query, getContext(data.users.julie));
                expect(result.errors).not.toBeUndefined();
                if (!result.errors) return;
                expect(result.errors.length).toEqual(1);
                expect(result.errors[0].extensions).not.toBeUndefined();
                if (!result.errors[0].extensions) return;
                expect(result.errors[0].extensions.code).toEqual("BAD_USER_INPUT");
            }

        } finally {
            if (ccid) {
                await getManager().createQueryBuilder().delete().from(db.ContentCollection).where("id = :id", { id: ccid }).execute();
            }
        }
    });

    it("updates sign up code", async () => {
        let ccid: number | undefined;

        try {
            const cc = await getManager().save(db.ContentCollection, {
                id: 0,
                name: "initial name",
                description: "initial description",
                organisation: data.organisations.carperHollins,
                signUpCodeEnabled: false,
            });
            ccid = cc.id;

            const code = "ABCDEF2";
            const query = gql`mutation {
                updateContentCollection(input: { id: "${encryptId(NodeType.ContentCollection, ccid)}" signUpCode: "${code}" signUpCodeEnabled: true }) { signUpCode signUpCodeEnabled }
            }`;

            const result = await request(query, getContext(data.users.julie));
            expect(result.errors).toBeUndefined();

            const updatedCc = await getManager().findOne(db.ContentCollection, ccid);

            expect(updatedCc).not.toBeUndefined();
            if (!updatedCc) return;
            expect(updatedCc.name).toEqual("initial name");
            expect(updatedCc.description).toEqual("initial description");
            expect(updatedCc.signUpCode).toEqual(code);
            expect(updatedCc.signUpCodeEnabled).toEqual(true);

            expect(result.data).toEqual({ updateContentCollection: { signUpCode: code, signUpCodeEnabled: true } });

        } finally {
            if (ccid) {
                await getManager().createQueryBuilder().delete().from(db.ContentCollection).where("id = :id", { id: ccid }).execute();
            }
        }
    });
});
