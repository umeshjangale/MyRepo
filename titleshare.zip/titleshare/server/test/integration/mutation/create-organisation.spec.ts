import gql from "graphql-tag";
import "jasmine";
import { getManager } from "typeorm";

import { encryptId } from "../../../src/security/data-protection";
import * as db from "../../../src/storage/db-entities";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql create organisation API", () => {

    it("inserts organisation into database", async () => {

        const orgName = "test org temp";
        const query = gql`mutation {
            createOrganisation(input: { name: "${orgName}" }) { id name }
          }`;

        const manager = getManager();
        const user = data.users.sysAdmin;

        // Ensure it doesn't exists to begin with.
        let org = await manager.findOne(db.Organisation, { name: orgName });
        expect(org).toBeUndefined();

        // Act
        const result = await request(query, getContext(user));

        expect(result.errors).toBeUndefined();

        // Ensure it now exists in the db.
        org = await manager.findOne(db.Organisation, { name: orgName });
        expect(org).not.toBeUndefined();
        if (!org) return;

        expect(result.data).toEqual({ createOrganisation: { id: encryptId(NodeType.Organisation, org.id), name: orgName } });

        // Clean up
        await manager.remove(org);
    });
});
