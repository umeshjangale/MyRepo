import gql from "graphql-tag";
import "jasmine";

import { encryptId } from "../../../src/security/data-protection";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql Content Node API", () => {

    it("fetches content with date", async () => {

        const book = data.content.hashMeat.theBookOfBooks;

        expect(book.releaseDate).not.toBeNull();
        if (!book.releaseDate) return;

        const bookId = encryptId(NodeType.Content, book.id);
        const query = gql`query {
            node(id: "${bookId}") { id ...on Content { title, releaseDate } }
          }`;

        const user = data.users.sysAdmin;

        const result = await request(query, getContext(user));

        // Dates and times sent to the client are in milliseconds since 1970/01/01:
        const expectedTime = book.releaseDate.getTime();

        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({ node: { id: bookId, title: book.title, releaseDate: expectedTime } });
    });
});
