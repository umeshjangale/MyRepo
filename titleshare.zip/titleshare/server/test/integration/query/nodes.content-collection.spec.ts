import gql from "graphql-tag";
import "jasmine";

import { encryptId } from "../../../src/security/data-protection";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql Content Collection Nodes API", () => {

    it("fetches all content collections in order", async () => {

        const collectionList1 = [data.contentCollections.hashMeat.worstSellers, data.contentCollections.hashMeat.bestSellers];
        const collectionList2 = [data.contentCollections.hashMeat.bestSellers, data.contentCollections.hashMeat.worstSellers];

        for (const collections of [collectionList1, collectionList2]) {

            const ids = collections.map(cc => encryptId(NodeType.ContentCollection, cc.id));
            const idsString = ids.map(id => `"${id}"`).join();
            const query = gql`query {
                nodes(ids: [${idsString}]) { id ...on ContentCollection { name, description } }
            }`;

            const result = await request(query, getContext(data.users.alex));

            expect(result.errors).toBeUndefined();

            const expectedNodes = collections.map((cc, i) => ({ id: ids[i], name: cc.name, description: cc.description }));
            expect(result.data).toEqual({ nodes: expectedNodes });
        }
    });
});
