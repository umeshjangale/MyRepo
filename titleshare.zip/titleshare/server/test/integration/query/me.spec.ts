import gql from "graphql-tag";
import "jasmine";
import { getManager } from "typeorm";

import { toRoleType } from "../../../src/graphql/mapping";
import { decryptEmail, encryptEmail, encryptId } from "../../../src/security/data-protection";
import * as db from "../../../src/storage/db-entities";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql me API", () => {

    it("fetches basic user fields", async () => {

        const query = gql`query {
            me { email firstName }
          }`;

        const user = new db.User();
        const email = "test@example.com";
        user.email = encryptEmail(email);
        user.firstName = "name test first";

        const result = await request(query, getContext(user));

        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({ me: { firstName: user.firstName, email } });
    });

    it("fetches user roles and organisations", async () => {

        const query = gql`query {
            me { email firstName, roles { type organisation { id name } } }
          }`;

        const user = data.users.alex;

        const result = await request(query, getContext(user));

        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({
            me: {
                firstName: user.firstName,
                email: decryptEmail(user.email),
                roles: !user.userRoles ? null : user.userRoles.map(r => ({
                    type: toRoleType(r.type),
                    organisation: !r.organisation ? null : { id: encryptId(NodeType.Organisation, r.organisation.id), name: r.organisation.name },
                })),
            },
        });
    });
});
