import gql from "graphql-tag";
import "jasmine";

import { encryptId } from "../../../src/security/data-protection";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql Content Collection Node API", () => {

    it("fetches content collection", async () => {

        const cc = data.contentCollections.hashMeat.bestSellers;

        const ccId = encryptId(NodeType.ContentCollection, cc.id);
        const query = gql`query {
            node(id: "${ccId}") { id ...on ContentCollection { id, name, description } }
          }`;

        const result = await request(query, getContext(data.users.alex));

        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({ node: { id: ccId, name: cc.name, description: cc.description } });
    });
});
