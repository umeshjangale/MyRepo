import gql from "graphql-tag";
import "jasmine";

import { StorageContext } from "../../../src/graphql/context";
import { encryptId } from "../../../src/security/data-protection";
import { NodeType } from "../../../src/types/node-id";
import { data } from "../../test-data";
import { getContext, request } from "../../utils";

describe("Graphql User Group Node API", () => {

    it("fetches user group", async () => {

        const group = data.userGroups.hashMeat.group1;

        const groupId = encryptId(NodeType.UserGroup, group.id);
        const query = gql`query {
            node(id: "${groupId}") { id ...on UserGroup { name } }
          }`;

        const user = data.users.sysAdmin;

        const result = await request(query, getContext(user));

        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({ node: { id: groupId, name: group.name } });
    });

    it("doesn't fetch user group when not authorized", async () => {

        const group = data.userGroups.hashMeat.group1;

        const groupId = encryptId(NodeType.UserGroup, group.id);
        const query = gql`query {
            node(id: "${groupId}") { id ...on UserGroup { name } }
          }`;

        const user = data.users.julie;

        const result = await request(query, getContext(user));

        expect(result.data).toEqual({ node: null });
    });

    it("fetches organisation on user group", async () => {

        const group = data.userGroups.hashMeat.group1;

        expect(group.organisation).not.toBeNull();
        if (!group.organisation) return;

        const groupId = encryptId(NodeType.UserGroup, group.id);
        const query = gql`query {
            node(id: "${groupId}") { id ...on UserGroup { name, organisation { id, name } } }
          }`;

        const user = data.users.sysAdmin;

        const result = await request(query, getContext(user));

        const orgId = encryptId(NodeType.Organisation, group.organisation.id);
        expect(result.errors).toBeUndefined();
        expect(result.data).toEqual({ node: { id: groupId, name: group.name, organisation: { name: group.organisation.name, id: orgId } } });
    });
});
