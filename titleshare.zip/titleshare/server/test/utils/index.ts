import { ASTNode, graphql, print as gqlToString } from "graphql";

import { getGqlSchema } from "../../src/graphql/config";
import { Context, StorageContext } from "../../src/graphql/context";
import { serviceContainer } from "../../src/runtime/inversify.config";
import { SYMBOLS } from "../../src/runtime/symbols";
import * as db from "../../src/storage/db-entities";

const gqlSchema = getGqlSchema();

export const request = async (query: string | ASTNode, context?: Context, variables?: { [key: string]: any }) =>
    graphql(gqlSchema, typeof query === "string" ? query : gqlToString(query), undefined, context || {}, variables);

export function getContext(user?: db.User): Context {

    return {
        user: user || null,
        storage: serviceContainer.get<StorageContext>(SYMBOLS.StorageContext),
        ipAddress: "test runner",
        userAgent: "test runner",
        hasAuthenticationSignature: false,
        setAuthCookie: () => { return; },
    };
}
