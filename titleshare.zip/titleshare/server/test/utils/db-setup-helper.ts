import "jasmine";
import { getManager } from "typeorm";

import config from "../../src/config";
import { createLogger } from "../../src/logger";
import { AudioFile, AudioSection, Content, ContentCollection, Genre, Language, Organisation, User, UserGroup, UserRole } from "../../src/storage/db-entities";
import { UserContentPlayback } from "../../src/storage/db-entities/user-content-playback";
import { configureDatabase } from "../../src/storage/helpers/db-helper";
import { createTestData } from "../test-data";

const log = createLogger("db-helper");

beforeAll(done => {

    // Ensure the node environment is set to the "test" configuration.
    if (config.nodeEnv !== "test") throw new Error(`tests must be run with NODE_ENV set to 'test'. Found '${config.nodeEnv}'`);

    const setupDb = async () => {
        log.i("Insert test data into DB...");

        await configureDatabase();

        await createTestData();

        log.i("Insert test data into DB...done");
    };

    setupDb()
        .catch(err => log.e("Error setting up test DB", err))
        .then(done)
        .catch(err => log.e("", err));

},        20000);

afterAll(done => {

    const cleanupDb = async () => {

        log.i("Deleting test data from DB...");
        await getManager().transaction(async trans => {

            await trans.query("SET FOREIGN_KEY_CHECKS = 0;");

            // Drop relationship tables first. Any better way to do this?
            await trans.query("TRUNCATE TABLE user_role_member;");
            await trans.query("TRUNCATE TABLE user_group_member;");
            await trans.clear(UserContentPlayback);
            await trans.clear(UserRole);
            await trans.clear(Organisation);
            await trans.clear(User);
            await trans.clear(UserGroup);
            await trans.clear(Language);
            await trans.clear(Genre);
            await trans.clear(Content);
            await trans.clear(ContentCollection);
            await trans.clear(AudioSection);
            await trans.clear(AudioFile);

            await trans.query("SET FOREIGN_KEY_CHECKS = 1;");
        });

        log.i("Deleting test data from DB...done");
    };

    cleanupDb()
        .catch(err => log.e("Error cleaning up test DB", err))
        .then(done)
        .catch(err => log.e("", err));
});
