import { getManager } from "typeorm";

import { createLogger } from "../../src/logger";
import { encryptEmail } from "../../src/security/data-protection";
import { Content, ContentCollection, Genre, Language, Organisation, User, UserContent, UserGroup, UserRole } from "../../src/storage/db-entities";
import { AccessSource, ContentStatus, ContentType, RoleType } from "../../src/storage/db-entities/enums";
import { UserContentAccess } from "../../src/storage/db-entities/user-content-access";
import { UserContentPlayback } from "../../src/storage/db-entities/user-content-playback";

const log = createLogger("Test Data");

const _createTestData = async () => {

    const mgr = getManager();

    const organisations = {
        hashMeat: await mgr.save(mgr.create(Organisation, { name: "Hashmeat", importStorageBucket: "non-existent-1" })),
        carperHollins: await mgr.save(mgr.create(Organisation, { name: "Carper Hollins", importStorageBucket: "non-existent-2" })),
    };

    const userRoles = {
        sysAdmin: await mgr.save(mgr.create(UserRole, { name: "System Admin", type: RoleType.SystemAdmin })),
        hashMeat: {
            orgAdmin: await mgr.save(mgr.create(UserRole, { name: "Organisation Admin", type: RoleType.OrganisationAdmin, organisation: organisations.hashMeat })),
        },
        carperHollins: {
            orgAdmin: await mgr.save(mgr.create(UserRole, { name: "Organisation Admin", type: RoleType.OrganisationAdmin, organisation: organisations.carperHollins })),
        },
    };

    const userGroups = {
        hashMeat: {
            group1: await mgr.save(mgr.create(UserGroup, { name: "Group 1", organisation: organisations.hashMeat })),
        },
    };

    const languages = {
        en: await mgr.save(mgr.create(Language, { code: "en", name: "English" })),
    };

    const genres = {
        action: await mgr.save(mgr.create(Genre, { code: "action", name: "Action!" })),
        romantic: await mgr.save(mgr.create(Genre, { code: "romantic", name: "Romantic" })),
    };

    const content = {
        hashMeat: {
            theBookOfBooks: await mgr.save(mgr.create(Content, {
                title: "The Book of Books",
                type: ContentType.Audiobook,
                subtitle: "Series 1",
                description: "A great book by published by Hash Meat.",
                hasSoundtrack: false,
                author: "Meredith",
                narrator: "Sammy",
                publisher: "Hash Meat",
                language: languages.en,
                genre: genres.action,
                secondGenre: genres.romantic,
                releaseDate: new Date(1990, 1, 1, 16, 30),
                organisation: organisations.hashMeat,
                totalDuration: 15 * 60,
                status: ContentStatus.Available,
            })),
        },
    };

    const contentCollections = {
        hashMeat: {
            bestSellers: await mgr.save(mgr.create(ContentCollection, {
                name: "Best Sellers",
                description: "Hash Meats best sellers collection",
                organisation: organisations.hashMeat,
            })),
            worstSellers: await mgr.save(mgr.create(ContentCollection, {
                name: "Worst Sellers",
                description: "Hash Meats worst sellers collection",
                organisation: organisations.hashMeat,
            })),
        },
        carperHollins: {
            bestSellers: await mgr.save(mgr.create(ContentCollection, {
                name: "Best Sellers",
                description: "Carper Hollins best sellers collection",
                organisation: organisations.carperHollins,
            })),
        },
    };

    const users = {
        sysAdmin: await mgr.save(mgr.create(User, {

            email: encryptEmail("bob@title-share.net"),
            firstName: "bob",
            lastName: "admin",
            inviteAcceptedDateUtc: new Date(),
            userRoles: [userRoles.sysAdmin],
        })),
        alex: await mgr.save(mgr.create(User, {

            email: encryptEmail("alex@title-share.net"),
            firstName: "alex",
            lastName: "org admin",
            inviteAcceptedDateUtc: new Date(),
            userRoles: [userRoles.hashMeat.orgAdmin],
            lastLoginDateUtc: new Date("2017-01-01T09:00:00.000Z"),
        })),
        julie: await mgr.save(mgr.create(User, {

            email: encryptEmail("julie@title-share.net"),
            firstName: "julie",
            lastName: "org admin",
            inviteAcceptedDateUtc: new Date(),
            userRoles: [userRoles.carperHollins.orgAdmin],
        })),
    };

    await mgr.save(mgr.create(UserContentPlayback, {
        content: content.hashMeat.theBookOfBooks,
        user: users.alex,
        audioSectionsHash: "v1",
        audioSectionIndex: 0,
        startTime: 2,
        endTime: 100,
    }));

    await mgr.save(mgr.create(UserContentAccess, {
        content: content.hashMeat.theBookOfBooks,
        user: users.alex,
        source: AccessSource.Direct,
    }));

    await mgr.save(mgr.create(UserContent, {
        content: content.hashMeat.theBookOfBooks,
        user: users.alex,
        bookmarkedAudioSectionIndex: 1,
        bookmarkedAudioSectionTime: 10,
    }));

    return {
        organisations,
        userRoles,
        users,
        userGroups,
        content,
        contentCollections,
    };
};

type ThenType<T> = T extends Promise<infer U> ? U : T;
export let data: ThenType<ReturnType<typeof _createTestData>>;

export const createTestData = async () => {
    data = await _createTestData();
    return data;
};
