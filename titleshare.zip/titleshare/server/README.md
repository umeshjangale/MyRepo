# Server

The server app for titleShare

## Setup

Dependencies:
- node >= 10
- yarn
- mysql
- sox
- aws

Run `yarn install` from within the `server` directory of this project. Then use the following instructions for running or building.

If the install runs into issues with `bcrypt` you may need to install its dependencies. Following instructions [here](https://github.com/kelektiv/node.bcrypt.js/wiki/Installation-Instructions)

Windows: Open powershell with administrator privileges and run this command, then proceed with bcrypt installation
```
npm install --global --production windows-build-tools
```

### Setup mysql

- Add local database called `titleshare-dev`
- Add a user called `localdev` with password `localdev`
- Add DBA permissions to the localdev user

#### Note:

I encountered issue with the mysql driver: "Client does not support authentication protocol requested by server; consider upgrading MySQL client".

Resolved by [following instructions on github issue](https://github.com/mysqljs/mysql/issues/1507).
```
mysql -uroot -p
ALTER USER 'localdev'@'localhost' IDENTIFIED WITH mysql_native_password BY 'localdev';
FLUSH PRIVILEGES;
exit
```

### Environment variables
- `NODE_ENV` will set the app configuration to use. e.g. `NODE_ENV=production`. The default is `development`

See [src/config/custom-environment-variables.json](./src/config/custom-environment-variables.json) for other environment variables expected by the app.

### SoX audio

Download and install [sox](http://sox.sourceforge.net/) with libmad and libmp3lame libraries (for mp3 support).

The server app expects to find `sox` in your path. Alternatively you can set `sox.soxPath` in `./src/config/local.json` to point to the executable.

### AWS

The server uses AWS services like S3 and Simple Queue Service. For local development you can use these services within the free tier.

Using your own account, setup a new IAM user, [get the credentials](https://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/getting-your-credentials.html) and put them in a [shared credentials file](https://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/loading-node-credentials-shared.html)

#### S3
Create a bucket called `titleshare-local` and `titleshare-local-staging` in your own AWS account.

Audiobook imports are triggered via [S3 notifications](https://docs.aws.amazon.com/AmazonS3/latest/dev/NotificationHowTo.html) which publish events to SQS. The titleShare server will listen for messages on a queue named `import-file-event`. Each organisation must be configured with its own import bucket.

#### Simple queue service (SQS)

Using your own AWS account is recommended for SQS, but emulation can also be done using `docker run -p 9324:9324 softwaremill/elasticmq`.

If going the emulation route, you'll need to use a local config entry something like:
```json
{
  "sqs": {
    "region": "dummy",
    "endpoint": "http://localhost:9324",
    "deadLetterQueueUrl": null,
    "monoQueueUrl": null
  }
}
```
and you'll also need to invoke the dev and dev-worker scripts with something like:
```
AWS_ACCESS_KEY_ID=abcd AWS_SECRET_ACCESS_KEY=efgh yarn dev
AWS_ACCESS_KEY_ID=abcd AWS_SECRET_ACCESS_KEY=efgh yarn dev-worker
```

## Build

Run `yarn build`

## Run database migrations locally

Run (after build) `yarn orm migration:run`

To create a migration:

1. Update database entities in `db-entities`
2. Run `yarn orm migration:generate --name someFeatureName`
3. observe new file in `src/migrations`
4. Build the project `yarn build` (migrations run using .js files, not .ts)
5. Run the migration `yarn orm migration:run`

## Test

Setup a new database/schema for testing

- Add local database called `titleshare-test`
- Add a user called `localtest` with password `localtest`
- Add DBA permissions to the localtest user

Run `yarn test`

## Development server

### Graphql API
Run `yarn dev` and navigate to `http://localhost:3000/graphql` to explore the API

### Worker app
Run `yarn dev-worker` (to run background jobs like sending emails)

#### Debug

There is also config setup in `.vscode/launch.json` for debugging with vs-code.

## Linting

Run `yarn lint` to find linting issues and `yarn lint --fix` to attempt to automatically fix them.

## Create the first user

For one time creation of the first user (sys-admin) in the system, add a bootstrap entry to your local configuration file.

## Helpful VS Code plugins
 - [TSLint](https://marketplace.visualstudio.com/items?itemName=eg2.tslint)
 - [GraphQL for VSCode](https://marketplace.visualstudio.com/items?itemName=kumar-harsh.graphql-for-vscode)
 - [Code Spell Checker](https://marketplace.visualstudio.com/items?itemName=streetsidesoftware.code-spell-checker)