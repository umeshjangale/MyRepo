declare module "http" {
    export interface IncomingMessage {
        hasAuthenticationSignature?: boolean
    }
}