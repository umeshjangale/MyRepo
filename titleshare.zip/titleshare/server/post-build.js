var ncp = require('ncp').ncp;
var fs = require("fs");
var path = require("path");

function copyFiles(srcDir, destDir, filterRegex) {
    fs.readdir(srcDir, (err, files) => {

        if (err) {
            console.log(err);
            return;
        }

        if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true, });
        }

        for (let file of files) {
            if (!filterRegex || filterRegex.test(file)) {
                fs.copyFileSync(path.join(srcDir, file), path.join(destDir, file))
            }

        }
    });
}

console.log('Running post build script...');
copyFiles(__dirname + '/src/config/', __dirname + '/dist/src/config/', /^.*\.json$/);
copyFiles(__dirname + '/src/_static/', __dirname + '/dist/src/_static/');
