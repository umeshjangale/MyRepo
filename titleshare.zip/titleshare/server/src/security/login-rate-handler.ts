import config from "../config";
import { createLogger, Logger } from "../logger";

class LoginStatus {

    successes: number = 0;
    failures: number = 0;
    consecutiveFailures: number = 0;
    readonly createdAt: Date = new Date();
    updatedAt: Date = new Date();
    get totalLogins() { return this.successes + this.failures; }

    get loginsPerMinute(): number {
        if (this.totalLogins === 0) return 0;

        const minutes = (Date.now() - this.createdAt.getTime()) / 1000 / 60;
        return this.totalLogins / minutes;
    }

    get failureRatio(): number {
        if (this.totalLogins === 0) return 0;
        return this.failures / this.totalLogins;
    }
}

interface LoginRateHandlerOptions {
    consecutiveLoginFailureLimit: number;
    maxLoginsPerMinute: number;
    maxFailureRatio: number;
    freeAttempts: number;
    cacheRetentionMinutes: number;
}

class LoginRateHandler {

    // Cache is in memory, so rate limits will be calculated per machine.
    readonly cache: { [key: string]: LoginStatus };
    readonly options: LoginRateHandlerOptions;
    readonly cachePruneInterval = 30 * 60 * 1000; // 30 mins
    readonly log: Logger;

    constructor(options: LoginRateHandlerOptions) {
        this.cache = {};
        this.options = options;
        this.log = createLogger("LoginRateHandler");

        setInterval(() => this._pruneCache(), this.cachePruneInterval);
    }

    hasReachedLimit(key: string): boolean {
        const status = this._getOrCreateStatus(key);

        const hasHitLimit = () => {
            if (status.consecutiveFailures >= this.options.consecutiveLoginFailureLimit) return true;
            if (status.totalLogins > this.options.freeAttempts && status.failureRatio >= this.options.maxFailureRatio) return true;
            if (status.totalLogins > this.options.freeAttempts && status.loginsPerMinute >= this.options.maxLoginsPerMinute) return true;
            return false;
        };

        if (hasHitLimit()) {
            this.log.w(`Login rate limit reached for ${key}`, status);
            return true;
        }

        return false;
    }

    success(key: string): void {
        const status = this._getOrCreateStatus(key);
        status.successes++;
        status.consecutiveFailures = 0;
        status.updatedAt = new Date();
    }

    failure(key: string): void {
        const status = this._getOrCreateStatus(key);

        status.failures++;
        status.consecutiveFailures++;
        status.updatedAt = new Date();
    }

    private _pruneCache() {

        const removalTime = Date.now() - (this.options.cacheRetentionMinutes * 60 * 1000);

        let removedCount = 0;
        const keys = Object.keys(this.cache);

        for (const key of keys) {
            const status = this.cache[key];
            if (status.updatedAt.getTime() <= removalTime) {

                // tslint:disable-next-line: no-dynamic-delete
                delete this.cache[key];
                removedCount++;
            }
        }

        if (removedCount > 0) {
            this.log.i(`Pruned cache. Old Size: ${keys.length}. New Size: ${keys.length - removedCount} (removed ${removedCount})`);
        }
    }

    private _getOrCreateStatus(key: string): LoginStatus {
        if (key in this.cache) {
            return this.cache[key];
        }

        const status = new LoginStatus();
        this.cache[key] = status;
        return status;
    }
}

export const loginRateHandler = new LoginRateHandler({
    consecutiveLoginFailureLimit: config.runtime.loginRate.consecutiveLoginFailureLimit,
    maxLoginsPerMinute: config.runtime.loginRate.maxLoginsPerMinute,
    maxFailureRatio: config.runtime.loginRate.maxFailureRatio,
    freeAttempts: config.runtime.loginRate.freeAttempts,
    cacheRetentionMinutes: config.runtime.loginRate.cacheRetentionMinutes,
});
