import bcrypt from "bcrypt";
import crypto, { HexBase64BinaryEncoding } from "crypto";

import config from "../config";
import { createLogger } from "../logger";
import { NodeId, NodeType } from "../types/node-id";

const _saltRounds = 12;

export const jwtSecret = crypto.pbkdf2Sync(config.security.jwtKeyPassword, config.security.jwtSalt, 100009, 64, "sha512");

const _key1 = crypto.pbkdf2Sync(config.security.keyPassword1, config.security.salt1, 10009, 16, "sha512");
const _key2 = crypto.pbkdf2Sync(config.security.keyPassword2, config.security.salt2, 10017, 16, "sha512");
const _key3 = crypto.pbkdf2Sync(config.security.keyPassword3, config.security.salt3, 10017, 16, "sha512");

const _iv1 = Buffer.from(config.security.iv1);
const _iv2 = Buffer.from(config.security.iv2);
const _iv3 = Buffer.from(config.security.iv3);

const log = createLogger("data-protection");

const plusesRegExp = /\+/g;
const forwardSlashesRegExp = /\//g;
const equalsRegExp = /=/g;
const minusRegExp = /-/g;
const underscoreRegExp = /_/g;
const periodRegExp = /\./g;

export async function hashPassword(password: string): Promise<string> {
    const salt = await bcrypt.genSalt(_saltRounds);
    return bcrypt.hash(password, salt);
}

export async function comparePassword(password: string, passwordHash: string): Promise<boolean> {
    return bcrypt.compare(password, passwordHash);
}

function encryptCore(payload: string, key: Buffer, iv: Buffer): Buffer {
    const cipher = crypto.createCipheriv("aes-128-cbc", key, iv);
    let encrypted = cipher.update(payload, "utf8");
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    return encrypted;
}

function decryptCore(value: Buffer | string, key: Buffer, iv: Buffer, valueEncoding: HexBase64BinaryEncoding = "base64"): Buffer {
    const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);

    let decrypted: Buffer;

    decrypted = typeof value === "string"
        ? decipher.update(value, valueEncoding)
        : decipher.update(value);

    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted;
}

export function encryptEmail(email: string): string {
    const encrypted = encryptCore(email.toLowerCase(), _key1, _iv1);
    return encrypted.toString("base64");
}

export function decryptEmail(encryptedEmail: string): string {
    const decrypted = decryptCore(encryptedEmail, _key1, _iv1);
    return decrypted.toString("utf8");
}

export function encryptImportSftpPassword(password: string): string {
    const encrypted = encryptCore(password, _key1, _iv1);
    return encrypted.toString("base64");
}

export function decryptImportSftpPassword(encryptedPassword: string): string {
    const decrypted = decryptCore(encryptedPassword, _key1, _iv1);
    return decrypted.toString("utf8");
}

export function encryptId(type: NodeType, id: number) {
    const idFormat = `${type}:${id}`;

    const encrypted = encryptCore(idFormat, _key2, _iv2);
    return bufferToUrlBase64(encrypted);
}

export function decryptNodeId(id: string): NodeId | null {
    try {
        if (!id) return null;
        const decrypted = decryptCore(urlBase64ToBuffer(id), _key2, _iv2);

        const idFormat = decrypted.toString("utf8");
        const parts = idFormat.split(":");
        if (parts.length !== 2) return null;

        const type = parts[0] as NodeType;
        const parsedId = parseInt(parts[1], 10);

        return { id: parsedId, type };
    } catch (err) {
        log.e(`An error occurred decrypting id '${id}'`, err);
        return null;
    }
}

export function decryptId(id: string, expectedType: NodeType): number | null {
    const nodeId = decryptNodeId(id);
    if (!nodeId) return null;
    if (expectedType !== nodeId.type) return null;

    return nodeId.id;
}

/** Converts a buffer to a base64 string suitable for use in URLs (no percent encoding needed) */
export function bufferToUrlBase64(b: Buffer): string {
    return b.toString("base64")
        .replace(plusesRegExp, "-")
        .replace(forwardSlashesRegExp, "_")
        .replace(equalsRegExp, ".");
}

/** Converts a base64 string suitable for use in URLs (no percent encoding needed) to a buffer */
export function urlBase64ToBuffer(s: string): Buffer {
    const standardBase64 = s.replace(minusRegExp, "+")
        .replace(underscoreRegExp, "/")
        .replace(periodRegExp, "=");

    return Buffer.from(standardBase64, "base64");
}

export function createPasswordResetToken(userId: number, passwordResetNonce: string): string {
    const payload = {
        userId,
        timestamp: Date.now(),
        nonce: passwordResetNonce,
    };

    const encrypted = encryptCore(JSON.stringify(payload), _key3, _iv3);
    return bufferToUrlBase64(encrypted);
}

export function validatePasswordResetToken(token: string, userId: number, passwordResetNonce: string): boolean {

    try {
        const decrypted = decryptCore(urlBase64ToBuffer(token), _key3, _iv3);

        const payload = JSON.parse(decrypted.toString("utf8"));

        if (payload.userId !== userId) return false;
        if (payload.nonce !== passwordResetNonce) return false;
        if (!payload.timestamp) return false;

        // Set validation date to 3 months ago, so they don't remain valid forever.
        const validationDate = new Date();
        validationDate.setMonth(validationDate.getMonth() - 3);

        const timestamp = new Date(payload.timestamp);
        if (timestamp < validationDate) return false;

    } catch (err) {
        log.e("Error validating password reset token", err);
        return false;
    }

    return true;
}

export function md5Hash(value: string): string {
    if (!value) return "";
    return crypto.createHash("md5").update(value).digest("hex");
}
