import "jasmine";

import { NodeType } from "../types/node-id";

import * as DataProtection from "./data-protection";

describe("DataProtection", () => {

    describe("email encryption", () => {
        it("encrypts and decrypts", () => {
            const email = "test@example.com";

            const encryptedEmail = DataProtection.encryptEmail(email);

            expect(encryptedEmail).not.toBeNull();
            expect(encryptedEmail.length).toBeGreaterThan(email.length);

            const decryptedEmail = DataProtection.decryptEmail(encryptedEmail);

            expect(decryptedEmail).toEqual(email);
        });
    });

    describe("id encryption", () => {
        it("encrypts and decrypts", () => {
            const id = 123;

            const encrypted = DataProtection.encryptId(NodeType.User, id);

            expect(encrypted).not.toBeNull();
            expect(encrypted.length).toBeGreaterThan(20);

            const decrypted = DataProtection.decryptId(encrypted, NodeType.User);

            expect(decrypted).toEqual(id);
        });
    });

    describe("password reset functions", () => {
        it("create and validate", () => {
            const id = 123;
            const nonce = "abc";

            const token = DataProtection.createPasswordResetToken(id, nonce);

            expect(token).not.toBeNull();
            expect(token.length).toBeGreaterThan(20);

            const isValid = DataProtection.validatePasswordResetToken(token, id, nonce);

            expect(isValid).toBeTruthy();
        });

        it("create and invalidate", () => {
            const id = 123;
            const nonce = "abc";

            const token = DataProtection.createPasswordResetToken(id, nonce);

            expect(token).not.toBeNull();
            expect(token.length).toBeGreaterThan(20);

            const isValid = DataProtection.validatePasswordResetToken(token, 456, nonce);

            expect(isValid).toBeFalsy();
        });
    });

    describe("url base64 helpers", () => {
        it("can round trip", () => {
            const singleByteBuffer = Buffer.alloc(1);
            for (let i = 0; i < 256; i++) {
                singleByteBuffer[0] = i;
                const encoded = DataProtection.bufferToUrlBase64(singleByteBuffer);
                const decoded = DataProtection.urlBase64ToBuffer(encoded);
                expect(decoded.equals(singleByteBuffer)).toBe(true);
            }
        });
    });

    describe("md5 hashing", () => {
        it("does not throw error", () => {
            const result = DataProtection.md5Hash("some value");
            expect(result).toBeTruthy();
        });
    });
});
