//
// Config for the server
// All configuration should be accessed through here.
//

// Set the environment variable needed for the config package.
process.env.NODE_CONFIG_DIR = __dirname;

// tslint:disable-next-line:import-blacklist
import config from "config";

export default {
    nodeEnv: config.util.getEnv("NODE_ENV") as string,
    isDevelopment: config.util.getEnv("NODE_ENV") === "development",
    isProduction: config.util.getEnv("NODE_ENV") === "production",
    bootstrap: {
        firstUserEmail: config.has("bootstrap.firstUserEmail") ? config.get("bootstrap.firstUserEmail") as string : undefined,
        firstUserPassword: config.has("bootstrap.firstUserPassword") ? config.get("bootstrap.firstUserPassword") as string : undefined,
    },
    app: {
        endpoint: config.get("app.endpoint") as string,
        port: config.get("app.port") as number,
        useBasicAuth: config.get("app.useBasicAuth") as boolean,
        basicAuthUsername: config.get("app.basicAuthUsername") as string,
        basicAuthPassword: config.get("app.basicAuthPassword") as string,
        useLambdaForAudioEncoding: config.get("app.useLambdaForAudioEncoding") as boolean,
        corsAllowedOrigins: config.get("app.corsAllowedOrigins") as string[],
    },
    cookie: {
        name: config.get("cookie.name") as string,
        domain: config.get("cookie.domain") as string,
        validitySeconds: config.get("cookie.validitySeconds") as number,
        csrfName: config.get("cookie.csrfName") as string,
    },
    graphql: {
        allowGraphqlIntrospection: config.get("graphql.allowGraphqlIntrospection") as boolean,
        maxQueryDepth: config.get("graphql.maxQueryDepth") as number,
        hideErrorDetailsFromHttpResponse: config.get("graphql.hideErrorDetailsFromHttpResponse") as boolean,
    },
    runtime: {
        minimumIosAppVersion: config.get("runtime.minimumIosAppVersion") as string,
        minimumAndroidAppVersion: config.get("runtime.minimumAndroidAppVersion") as string,
        tempDirectory: config.get("runtime.tempDirectory") as string,
        rateLimitMaxRequests: config.get("runtime.rateLimitMaxRequests") as number,
        rateLimitTimeWindowSeconds: config.get("runtime.rateLimitTimeWindowSeconds") as number,
        loginRate: {
            consecutiveLoginFailureLimit: config.get("runtime.loginRate.consecutiveLoginFailureLimit") as number,
            maxLoginsPerMinute: config.get("runtime.loginRate.maxLoginsPerMinute") as number,
            maxFailureRatio: config.get("runtime.loginRate.maxFailureRatio") as number,
            freeAttempts: config.get("runtime.loginRate.freeAttempts") as number,
            cacheRetentionMinutes: config.get("runtime.loginRate.cacheRetentionMinutes") as number,
        },
    },
    sqs: {
        region: config.get("sqs.region") as string,
        endpoint: config.has("sqs.endpoint") ? config.get("sqs.endpoint") as string : undefined,
        deadLetterQueueUrl: config.has("sqs.deadLetterQueueUrl") ? config.get("sqs.deadLetterQueueUrl") as string : undefined,
        monoQueueUrl: config.has("sqs.monoQueueUrl") ? config.get("sqs.monoQueueUrl") as string : undefined,
    },
    s3: {
        region: config.get("s3.region") as string,
        bucket: config.get("s3.bucket") as string,
        stagingBucket: config.get("s3.stagingBucket") as string,
    },
    cloudFront: {
        enabled: config.get("cloudFront.enabled") as boolean,
        endpoint: config.get("cloudFront.endpoint") as string,
        dynamicImageEndpoint: config.get("cloudFront.dynamicImageEndpoint") as string,
        keypairId: config.get("cloudFront.keypairId") as string,
        privateKeyBase64String: config.get("cloudFront.privateKeyBase64String") as string,
        privateKeyPath: config.get("cloudFront.privateKeyPath") as string,
        urlExpirySeconds: config.get("cloudFront.urlExpirySeconds") as number,
        dynamicImageAuthorization: config.get("cloudFront.dynamicImageAuthorization") as string,
        dynamicImageCacheControlHeader: config.get("cloudFront.dynamicImageCacheControlHeader") as string,
        dynamicImageAllowedSizes: config.get("cloudFront.dynamicImageAllowedSizes") as Array<{ h: number; w: number }>,
    },
    security: {
        jwtKeyPassword: config.get("security.jwtKeyPassword") as string,
        jwtSalt: config.get("security.jwtSalt") as string,
        keyPassword1: config.get("security.keyPassword1") as string,
        salt1: config.get("security.salt1") as string,
        iv1: config.get("security.iv1"),
        keyPassword2: config.get("security.keyPassword2") as string,
        salt2: config.get("security.salt2") as string,
        iv2: config.get("security.iv2"),
        keyPassword3: config.get("security.keyPassword3") as string,
        salt3: config.get("security.salt3") as string,
        iv3: config.get("security.iv3"),
    },
    database: {
        host: config.get("database.host") as string,
        port: config.get("database.port") as number,
        username: config.get("database.username") as string,
        password: config.get("database.password") as string,
        dbName: config.get("database.dbName") as string,
        autoSyncSchema: config.get("database.autoSyncSchema") as boolean && config.util.getEnv("NODE_ENV") !== "production",
        logging: config.get("database.logging") as boolean,
        connectTimeout: config.get("database.connectTimeout") as number,
    },
    email: {
        bccAddress: config.has("email.bccAddress") ? config.get("email.bccAddress") as string : undefined,
        fromAddress: config.get("email.fromAddress") as string,
        sendGridApiKey: config.get("email.sendGridApiKey") as string,
        template: {
            userInviteId: config.get("email.template.userInviteId") as string,
            sysAdminInviteId: config.get("email.template.sysAdminInviteId") as string,
            newContentId: config.get("email.template.newContentId") as string,
            importFailed: config.get("email.template.importFailed") as string,
            importSucceeded: config.get("email.template.importSucceeded") as string,
            passwordResetId: config.get("email.template.passwordResetId") as string,
            setFirstPasswordId: config.get("email.template.setFirstPasswordId") as string,
        },
        unsubscribeGroups: {
            newContentId: config.get("email.unsubscribeGroups.newContentId") as number,
            invitationsId: config.get("email.unsubscribeGroups.invitationsId") as number,
            adminId: config.get("email.unsubscribeGroups.adminId") as number,
        },
        imageSize: {
            h: config.get("email.imageSize.h") as number,
            w: config.get("email.imageSize.w") as number,
        },
    },
    notifications: {
        inviteUserDelayMinutes: config.get("notifications.inviteUserDelayMinutes") as number,
        setFirstPasswordDelayMinutes: config.get("notifications.setFirstPasswordDelayMinutes") as number,
        newContentDelayMinutes: config.get("notifications.newContentDelayMinutes") as number,
    },
    externalLinks: {
        resetPasswordUrlFormat: config.get("externalLinks.resetPasswordUrlFormat") as string,
    },
    import: {
        notificationEmailAddresses: config.get("import.notificationEmailAddresses") as string[],
        transferTimeoutSeconds: config.get("import.transferTimeoutSeconds") as number,
        archivePrefix: config.get("import.archivePrefix") as string,
        defaultNarrationFileRegex: config.get("import.defaultNarrationFileRegex") as string,
        defaultSoundtrackFileRegex: config.get("import.defaultSoundtrackFileRegex") as string,
        defaultCoverImageFileRegex: config.get("import.defaultCoverImageFileRegex") as string,
        maxImportFileSize: (config.get("import.maxImportFileSizeMb") as number) * 1024 * 1024,
        maxImportFileDurationMinutes: config.get("import.maxImportFileDurationMinutes"),
        largeFileThresholdSize: (config.get("import.largeFileThresholdSizeMb") as number) * 1024 * 1024,
    },
    sox: {
        soxPath: config.has("sox.soxPath") ? config.get("sox.soxPath") as string : undefined,
        mp3LowQualityNarrationFormatOptions: config.get("sox.mp3LowQualityNarrationFormatOptions") as string[],
        mp3HighQualityNarrationFormatOptions: config.get("sox.mp3HighQualityNarrationFormatOptions") as string[],
        mp3LowQualitySoundtrackFormatOptions: config.get("sox.mp3LowQualitySoundtrackFormatOptions") as string[],
        mp3HighQualitySoundtrackFormatOptions: config.get("sox.mp3HighQualitySoundtrackFormatOptions") as string[],
    },
};
