import crypto from "crypto";
import fs from "fs";

import { createLogger } from "../logger";
import { getFileExtensionWithoutDot } from "../utils";

const log = createLogger("TempFileHelper");

export class TempFileHelper {

    private readonly _files: string[] = [];
    constructor(private readonly _tempDirectory: string) {
    }

    /** Creates a globally unique full path for the filename */
    getFullPath(filename: string) {

        const extension = getFileExtensionWithoutDot(filename);

        // Avoid using weird characters.
        // WARN: File names are passed as cmd line arguments, therefore must not contain shell metacharacters or they may be used to trigger arbitrary command execution.
        const cleanFilename = filename.replace(/[^a-zA-Z0-9]/g, "_");

        const slash = this._tempDirectory.endsWith("/") ? "" : "/";
        let uniqueName = `${this._tempDirectory}${slash}${cleanFilename}_${crypto.randomBytes(16).toString("hex")}`;

        if (extension) {
            uniqueName += `.${extension}`;
        }

        this._files.push(uniqueName);
        return uniqueName;
    }

    /** deletes all files created by this instance. */
    cleanup() {

        for (const file of this._files) {
            fs.unlink(file, err => {
                if (err) {
                    log.e(`Error deleting file ${file}`, err);
                }
            });
        }

    }
}
