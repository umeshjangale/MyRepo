
const SYMBOLS = {
    UserStorage: Symbol.for("UserStorage"),
    UserGroupStorage: Symbol.for("UserGroupStorage"),
    ContentStorage: Symbol.for("ContentStorage"),
    ContentCollectionStorage: Symbol.for("ContentCollectionStorage"),
    ReferenceDataStorage: Symbol.for("ReferenceDataStorage"),
    OrganisationStorage: Symbol.for("OrganisationStorage"),
    NotificationStorage: Symbol.for("NotificationStorage"),
    ReportStorage: Symbol.for("ReportStorage"),
    MessageHandler: Symbol.for("MessageHandler"),
    QueueService: Symbol.for("QueueService"),
    StorageContext: Symbol.for("StorageContext"),
    ImageService: Symbol.for("ImageService"),
    AudioStorage: Symbol.for("AudioStorage"),
    EmailService: Symbol.for("EmailService"),
    ImportStorage: Symbol.for("ImportStorage"),
    AudioService: Symbol.for("AudioService"),
};

const FACTORY_SYMBOLS = {
    UserStorage: "Factory<UserStorage>",
    UserGroupStorage: "Factory<UserGroupStorage>",
    ContentStorage: "Factory<ContentStorage>",
    ContentCollectionStorage: "Factory<ContentCollectionStorage>",
    ReferenceDataStorage: "Factory<ReferenceDataStorage>",
    OrganisationStorage: "Factory<OrganisationStorage>",
    NotificationStorage: "Factory<NotificationStorage>",
    ReportStorage: "Factory<ReportStorage>",
    QueueService: "Factory<QueueService>",
    ImageService: "Factory<ImageService>",
    AudioStorage: "Factory<AudioStorage>",
};

export { SYMBOLS, FACTORY_SYMBOLS };
