
import "jasmine";
import path from "path";

import { getFilenameWithoutExtension } from "../utils";

import { TempFileHelper } from "./temp-file-helper";

describe("Temp File Helper", () => {

    describe("getFullPath", () => {
        it("Sanitizes filename input ", async () => {
            const tmpFileHelper = new TempFileHelper("");

            const someInvalidCharacters = [">", "<", "$", "*", "[", "]", "|", ";", "&", "(", ")", "#", "\"", "'", "`", "."];

            someInvalidCharacters.forEach(c => {
                const p1 = tmpFileHelper.getFullPath(c);
                expect(p1).not.toContain(c);

                const p2 = tmpFileHelper.getFullPath(c + c);
                expect(p2).not.toContain(c);
            });
        });

        it("Retains file extension from input ", async () => {
            const tmpFileHelper = new TempFileHelper("./abc");
            const filename = "audio.mp3";

            const actual = tmpFileHelper.getFullPath(filename);
            const extension = path.extname(actual);

            expect(extension).toEqual(".mp3");
        });

        it("Supports temp dir with or without trailing slash", async () => {

            const tempDirectories = ["./", ".", "abc/", "abc"];

            tempDirectories.forEach(tempDir => {
                const tmpFileHelper = new TempFileHelper(tempDir);
                const actual1 = tmpFileHelper.getFullPath("file.txt");
                expect(actual1).not.toContain("//");
            });
        });
    });
});
