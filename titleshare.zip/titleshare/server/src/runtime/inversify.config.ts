import { Container, interfaces } from "inversify";
import "reflect-metadata";

import { AudioService } from "../audio/audio-service";
import { EmailService } from "../email/email-service";
import { StorageContext } from "../graphql/context";
import { ImageService } from "../images/image-service";
import { MessageHandler } from "../queues/message-handler";
import { QueueService } from "../queues/queue-service";
import { AudioStorage } from "../storage/audio-storage";
import { ContentCollectionStorage } from "../storage/content-collection-storage";
import { ContentStorage } from "../storage/content-storage";
import { ImportStorage } from "../storage/import-storage";
import { NotificationStorage } from "../storage/notification-storage";
import { OrganisationStorage } from "../storage/organisation-storage";
import { ReferenceDataStorage } from "../storage/reference-data-storage";
import { ReportStorage } from "../storage/report-storage";
import { UserGroupStorage } from "../storage/user-group-storage";
import { UserStorage } from "../storage/user-storage";

import { FACTORY_SYMBOLS, SYMBOLS } from "./symbols";

/**
 * The DI container config.
 * serviceContainer should only be imported at the application root. Use constructor dependency injection in all other cases.
 */

const serviceContainer = new Container();
serviceContainer.bind<UserStorage>(SYMBOLS.UserStorage).to(UserStorage);
serviceContainer.bind<UserGroupStorage>(SYMBOLS.UserGroupStorage).to(UserGroupStorage);
serviceContainer.bind<ContentStorage>(SYMBOLS.ContentStorage).to(ContentStorage);
serviceContainer.bind<ContentCollectionStorage>(SYMBOLS.ContentCollectionStorage).to(ContentCollectionStorage);
serviceContainer.bind<ReferenceDataStorage>(SYMBOLS.ReferenceDataStorage).to(ReferenceDataStorage);
serviceContainer.bind<OrganisationStorage>(SYMBOLS.OrganisationStorage).to(OrganisationStorage);
serviceContainer.bind<NotificationStorage>(SYMBOLS.NotificationStorage).to(NotificationStorage);
serviceContainer.bind<ReportStorage>(SYMBOLS.ReportStorage).to(ReportStorage);
serviceContainer.bind<MessageHandler>(SYMBOLS.MessageHandler).to(MessageHandler);
serviceContainer.bind<QueueService>(SYMBOLS.QueueService).to(QueueService);
serviceContainer.bind<StorageContext>(SYMBOLS.StorageContext).to(StorageContext);
serviceContainer.bind<ImageService>(SYMBOLS.ImageService).to(ImageService);
serviceContainer.bind<AudioStorage>(SYMBOLS.AudioStorage).to(AudioStorage);
serviceContainer.bind<EmailService>(SYMBOLS.EmailService).to(EmailService);
serviceContainer.bind<ImportStorage>(SYMBOLS.ImportStorage).to(ImportStorage);
serviceContainer.bind<AudioService>(SYMBOLS.AudioService).to(AudioService);

serviceContainer.bind<interfaces.Factory<UserStorage>>(FACTORY_SYMBOLS.UserStorage).toFactory<UserStorage>((context: interfaces.Context) =>
    () => context.container.get<UserStorage>(SYMBOLS.UserStorage));

serviceContainer.bind<interfaces.Factory<UserGroupStorage>>(FACTORY_SYMBOLS.UserGroupStorage).toFactory<UserGroupStorage>((context: interfaces.Context) =>
    () => context.container.get<UserGroupStorage>(SYMBOLS.UserGroupStorage));

serviceContainer.bind<interfaces.Factory<ContentStorage>>(FACTORY_SYMBOLS.ContentStorage).toFactory<ContentStorage>((context: interfaces.Context) =>
    () => context.container.get<ContentStorage>(SYMBOLS.ContentStorage));

serviceContainer.bind<interfaces.Factory<ContentCollectionStorage>>(FACTORY_SYMBOLS.ContentCollectionStorage).toFactory<ContentCollectionStorage>((context: interfaces.Context) =>
    () => context.container.get<ContentCollectionStorage>(SYMBOLS.ContentCollectionStorage));

serviceContainer.bind<interfaces.Factory<ReferenceDataStorage>>(FACTORY_SYMBOLS.ReferenceDataStorage).toFactory<ReferenceDataStorage>((context: interfaces.Context) =>
    () => context.container.get<ReferenceDataStorage>(SYMBOLS.ReferenceDataStorage));

serviceContainer.bind<interfaces.Factory<OrganisationStorage>>(FACTORY_SYMBOLS.OrganisationStorage).toFactory<OrganisationStorage>((context: interfaces.Context) =>
    () => context.container.get<OrganisationStorage>(SYMBOLS.OrganisationStorage));

serviceContainer.bind<interfaces.Factory<NotificationStorage>>(FACTORY_SYMBOLS.NotificationStorage).toFactory<NotificationStorage>((context: interfaces.Context) =>
    () => context.container.get<NotificationStorage>(SYMBOLS.NotificationStorage));

serviceContainer.bind<interfaces.Factory<ReportStorage>>(FACTORY_SYMBOLS.ReportStorage).toFactory<ReportStorage>((context: interfaces.Context) =>
    () => context.container.get<ReportStorage>(SYMBOLS.ReportStorage));

serviceContainer.bind<interfaces.Factory<QueueService>>(FACTORY_SYMBOLS.QueueService).toFactory<QueueService>((context: interfaces.Context) =>
    () => context.container.get<QueueService>(SYMBOLS.QueueService));

serviceContainer.bind<interfaces.Factory<ImageService>>(FACTORY_SYMBOLS.ImageService).toFactory<ImageService>((context: interfaces.Context) =>
    () => context.container.get<ImageService>(SYMBOLS.ImageService));

serviceContainer.bind<interfaces.Factory<AudioStorage>>(FACTORY_SYMBOLS.AudioStorage).toFactory<AudioStorage>((context: interfaces.Context) =>
    () => context.container.get<AudioStorage>(SYMBOLS.AudioStorage));

export { serviceContainer };
