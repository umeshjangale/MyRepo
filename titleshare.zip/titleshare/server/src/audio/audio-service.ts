import { execFile } from "child_process";
import { injectable } from "inversify";
import util from "util";

import config from "../config";
import { createLogger } from "../logger";
import { OperationResult } from "../types/operation-result";
import { assertNever } from "../utils";

import { AudioFormat, AudioProfile } from "./audio-format";

const log = createLogger("AudioService");

/** An audio service implementation using sox */
@injectable()
export class AudioService {

    supportedFormats(): AudioFormat[] {

        return [
            AudioFormat.mp3HighQuality(),
        ];
    }

    async convert(inputFilename: string, outputFilename: string, format: AudioFormat, profile: AudioProfile): Promise<void> {

        const sox = this.getSoxPath();

        const formatOptions = this.getFormatOptions(format, profile);

        const args: string[] = [inputFilename];
        if (formatOptions && formatOptions.length) {
            args.push(...formatOptions);
        }

        args.push(outputFilename);

        const { stderr } = await util.promisify(execFile)(sox, args);

        if (stderr) {
            throw new Error(stderr);
        }
    }

    async getInfo(inputFilename: string): Promise<OperationResult<string>> {

        const sox = this.getSoxPath();

        const { stdout, stderr } = await util.promisify(execFile)(sox, ["--i", inputFilename]);

        if (stderr) {
            return OperationResult.error(stderr);
        }

        return OperationResult.as(stdout);
    }

    /** Retrieves the audio files duration in seconds by reading the header of the file only (possibly inaccurate) */
    async getDurationFromHeader(inputFilename: string): Promise<number> {

        const sox = this.getSoxPath();

        const { stdout, stderr } = await util.promisify(execFile)(sox, ["--i", "-D", inputFilename]);

        const durationString = stdout.trim();
        if (!durationString) throw new Error(`Failed to fetch duration from audio file header. Sox error: '${stderr}'`);
        if (isNaN(durationString as any)) {
            throw new Error(`Failed to fetch duration from audio file header. Sox output: '${durationString}' '${stderr}'`);
        } else {
            return Number(durationString);
        }
    }

    /** Retrieves the audio files duration in seconds by reading the entire audio file (most accurate) */
    async getDurationFromAudioData(inputFilename: string): Promise<number> {

        const sox = this.getSoxPath();

        // Sox sends its output to stderr
        const { stderr } = await util.promisify(execFile)(sox, [inputFilename, "-n", "stat"]);

        const durationPrefix = "Length (seconds):";
        let duration: number | undefined;
        for (const line of stderr.split("\n")) {
            if (line.startsWith(durationPrefix)) {
                const durationString = line.replace(durationPrefix, "").trim();
                if (isNaN(durationString as any)) {
                    log.i(`Unexpected non number from sox duration '${durationString}'`);
                } else {
                    duration = Number(durationString);
                    break;
                }
            }
        }

        if (!duration) {
            throw new Error(`Failed to fetch duration from audio file. Sox output: '${stderr}'`);
        }

        return duration;
    }

    private getSoxPath() {
        return config.sox.soxPath ? config.sox.soxPath : "sox";
    }

    private getFormatOptions(format: AudioFormat, profile: AudioProfile) {
        let formatOptions: string[] = [];

        switch (profile) {
            case "narration":
                switch (format.suffixAndExtension) {
                    case "low.mp3":
                        formatOptions = config.sox.mp3LowQualityNarrationFormatOptions;
                        break;
                    case "high.mp3":
                        formatOptions = config.sox.mp3HighQualityNarrationFormatOptions;
                        break;
                    default:
                        assertNever(format);
                }
                break;
            case "soundtrack":
                switch (format.suffixAndExtension) {
                    case "low.mp3":
                        formatOptions = config.sox.mp3LowQualitySoundtrackFormatOptions;
                        break;
                    case "high.mp3":
                        formatOptions = config.sox.mp3HighQualitySoundtrackFormatOptions;
                        break;
                    default:
                        assertNever(format);
                }
                break;
            default:
                return assertNever(profile);
        }

        return formatOptions;
    }
}
