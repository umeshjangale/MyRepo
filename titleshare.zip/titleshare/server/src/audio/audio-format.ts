import * as db from "../storage/db-entities";
import { assertNever } from "../utils";

export type AudioFormat = Mp3LowQualityFormat | Mp3HighQualityFormat;

export type AudioProfile = "narration" | "soundtrack";

interface Mp3LowQualityFormat {
    encoding: "mp3";
    suffixAndExtension: "low.mp3";
    mimeType: "audio/mp3";
}

interface Mp3HighQualityFormat {
    encoding: "mp3";
    suffixAndExtension: "high.mp3";
    mimeType: "audio/mp3";
}

// tslint:disable-next-line:variable-name
export const AudioFormat = {
    mp3LowQuality: (): Mp3LowQualityFormat => ({
        suffixAndExtension: "low.mp3",
        encoding: "mp3",
        mimeType: "audio/mp3",
    }),
    mp3HighQuality: (): Mp3HighQualityFormat => ({
        suffixAndExtension: "high.mp3",
        encoding: "mp3",
        mimeType: "audio/mp3",
    }),
};

export function toDbAudioFormat(format: AudioFormat) {
    switch (format.suffixAndExtension) {
        case "low.mp3":
            return db.AudioFormat.Mp3Low;
        case "high.mp3":
            return db.AudioFormat.Mp3High;
            break;
        default:
            return assertNever(format);
    }
}

export function fromDbAudioFormat(format: db.AudioFormat): AudioFormat | undefined {
    switch (format) {
        case db.AudioFormat.Mp3High:
            return AudioFormat.mp3HighQuality();
        case db.AudioFormat.Mp3Low:
            return AudioFormat.mp3LowQuality();
        case db.AudioFormat.Original:
            return undefined;
        default:
            assertNever(format);
    }
}
