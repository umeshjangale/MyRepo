
import "jasmine";

import config from "../config";
import { TempFileHelper } from "../runtime/temp-file-helper";

import { AudioFormat } from "./audio-format";
import { AudioService } from "./audio-service";

describe("Sox Audio Service", () => {

    const audioSvc = new AudioService();
    const tmpFileHelper = new TempFileHelper(config.runtime.tempDirectory);

    describe("convert", () => {
        it("Converts wav to mp3", async () => {

            const input = `${__dirname}/test/click_01.wav`;
            const output = tmpFileHelper.getFullPath("wav_to_mp3_test.mp3");
            await audioSvc.convert(input, output, AudioFormat.mp3HighQuality(), "narration");

            const infoResult = await audioSvc.getInfo(output);
            if (infoResult.hasError) {
                fail(infoResult.error);
            } else {
                expect(infoResult.obj).not.toContain("FAIL");
            }
        });
    });

    describe("getDurationFromAudioData", () => {
        it("Gets duration for test file click", async () => {

            const input = `${__dirname}/test/click_01.wav`;
            const expected = 0.013016;
            const actual = await audioSvc.getDurationFromAudioData(input);

            expect(actual).toEqual(expected);
        });
    });

    describe("getDurationFromHeader", () => {
        it("Gets duration for test file click", async () => {

            const input = `${__dirname}/test/click_01.wav`;
            const expected = 0.013016;
            const actual = await audioSvc.getDurationFromHeader(input);

            expect(actual).toEqual(expected);
        });
    });

    afterAll(() => {
        tmpFileHelper.cleanup();
    });
});
