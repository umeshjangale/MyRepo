//
// Logging for the titleshare server.
// All logging should be done through this file.
// The levels are ordered as follows: e(rror), w(arn), i(nfo), d(ebug)
//

export interface Logger {
    // error
    e(message: string, error?: any): void;
    // warn
    w(message: string, error?: any): void;
    // info
    i(message: string): void;
    // debug
    d(message: string): void;
}

class DefaultLogger implements Logger {

    constructor(private readonly context: string) {

    }

    getTime(): string {
        const now = new Date(Date.now());
        return now.toISOString();
    }

    log(logLevel: string, message: string, error?: any) {
        let msg = `${this.getTime()}|[${logLevel}]|${this.context}|${message}`;
        if (error) msg += `| ${error} | ${JSON.stringify(error)}`;

        console.log(msg);
    }

    e(message: string, error?: any): void {
        this.log("ERR", message, error);
    }

    w(message: string, error?: any): void {
        this.log("WARN", message, error);
    }

    i(message: string): void {
        this.log("INFO", message);
    }

    d(message: string): void {
        this.log("DEBUG", message);
    }

}

export function createLogger(context: string): Logger {
    return new DefaultLogger(context);
}
