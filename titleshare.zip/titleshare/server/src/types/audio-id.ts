
export interface AudioId {
    sectionId: number;
    type: "narration" | "soundtrack";
}
