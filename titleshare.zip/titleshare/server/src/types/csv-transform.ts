import { Transform, TransformCallback, TransformOptions } from "stream";

import { ObjectReadable } from "./object-readable";

export class CsvTransform<T> extends Transform {

    private readonly newLine = "\n";
    private readonly outputEncoding = "utf8";
    private readonly qualifier = "\"";

    private hasWrittenHeader = false;

    constructor(readonly rowSelection: (row: T) => any[], readonly columnHeaders?: string[] | undefined, options?: TransformOptions) {
        super(options);
    }

    _transform(data: T, encoding: string, callback: TransformCallback): void {

        try {
            if (encoding === "buffer") {
                callback(new Error("Unsupported stream type. CsvTransform only supports streams in 'object mode'"));
                return;
            }

            if (this.columnHeaders && !this.hasWrittenHeader) {
                this.push(this._formatLine(this.columnHeaders), this.outputEncoding);
                this.hasWrittenHeader = true;
            }

            const row = this.rowSelection(data);
            this.push(this._formatLine(row), this.outputEncoding);
            callback();
        } catch (error) {
            callback(error);
        }
    }

    private _formatLine(row: any[]): string {
        const comma = ",";
        const separator = `${this.qualifier}${comma}${this.qualifier}`;
        const line = `${this.qualifier}${row.join(separator)}${this.qualifier}${this.newLine}`;
        return line;
    }
}

type StreamObjType<T> = T extends ObjectReadable<infer U> ? U : never;

export function csvTransform<T extends ObjectReadable<any>>(columnHeaders: string[], rowSelection: (row: StreamObjType<T>) => any[]) {
    const options: TransformOptions = {
        readableObjectMode: true,
        writableObjectMode: true,
    };

    return new CsvTransform(rowSelection, columnHeaders, options);
}
