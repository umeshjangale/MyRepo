export interface Paginated<T> {
    items: T[];
    totalCount: number;
}

export const EMPTY_PAGINATED: Readonly<Paginated<any>> = Object.freeze({
    items: [],
    totalCount: 0,
});
