import { Readable } from "stream";

/** An interface used simply to describe the type of the object being read from a stream (in object mode) */
// tslint:disable-next-line: no-empty-interface
export interface ObjectReadable<T> extends Readable {

}
