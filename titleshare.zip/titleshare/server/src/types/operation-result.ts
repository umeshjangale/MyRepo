
export type OperationResult<T, E extends string = string> = OperationResultOkay<T> | OperationResultError<E>;

interface OperationResultOkay<T> {
    hasError: false;
    obj: T;
}

interface OperationResultError<E extends string> {
    hasError: true;
    error: E;
}

// tslint:disable-next-line:variable-name
export const OperationResult = {
    error<E extends string>(error: E): OperationResultError<E> {
        return {
            hasError: true,
            error,
        };
    },
    invalidPermissions(): OperationResultError<"invalid-permissions"> {
        return {
            hasError: true,
            error: "invalid-permissions",
        };
    },
    as<T>(obj: T): OperationResultOkay<T> {
        return {
            hasError: false,
            obj,
        };
    },
    okay(): OperationResultOkay<void> {
        return {
            hasError: false,
            obj: undefined,
        };
    },
};
