export enum NodeType {
    User = "user",
    Organisation = "org",
    Content = "content",
    UserGroup = "user-group",
    ContentCollection = "content-collection",
    AudioSection = "audio-section",
}

export interface NodeId {
    id: number;
    type: NodeType;
}
