import { Request } from "express";

export interface JwtUser {
    sessionToken: string;
    id: string;
    csrfToken: string | null;
}

export interface UserRequest extends Request {
    user?: JwtUser;
}
