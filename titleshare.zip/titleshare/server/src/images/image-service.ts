import { injectable } from "inversify";
import sharp from "sharp";

@injectable()
export class ImageService {

    async resizeImageAsPng(inputBuffer: Buffer, newHeight: number, newWidth: number): Promise<Buffer> {
        return sharp(inputBuffer)
            .resize({ height: newHeight, width: newWidth, fit: "inside" })
            .toFormat("png")
            .toBuffer();
    }

    async resizeImage(inputBuffer: Buffer, newHeight: number, newWidth: number): Promise<Buffer> {
        return sharp(inputBuffer)
            .resize({ height: newHeight, width: newWidth, fit: "inside" })
            .toBuffer();
    }
}
