
import crypto from "crypto";
import * as http from "http";

import { createLogger } from "../logger";
import { getSignatureHeader, getSingleHeaderValue } from "../utils/http-header-utils";

const key = Buffer.from([0xB0, 0xFB, 0x1D, 0x3A, 0x3E, 0x87, 0xD6, 0xCB, 0x12, 0x26, 0x11, 0xC2, 0x29, 0x75, 0x72, 0xC6, 0x06, 0xAC, 0x0E, 0x9A, 0x3A, 0xB2, 0x3D, 0x89, 0x3F, 0x65, 0x09, 0xC1, 0xA7, 0xFA, 0x43, 0xC9, 0x59, 0x3B, 0xFE, 0xD1, 0xB2, 0x1E, 0x22, 0xAF, 0xB3, 0x0B]);

export function signatureValidation(req: http.IncomingMessage, res: http.ServerResponse, buffer: Buffer): void {

    if (!req.method || !req.url) {
        return;
    }

    const signatureHeader = getSignatureHeader(req.headers);
    if (!signatureHeader) {
        req.hasAuthenticationSignature = false;
        return;
    }

    // If a signature is provided, it MUST be valid for the request to continue.
    const parts = signatureHeader.split(" ");
    if (parts.length === 3) {
        const [version, timestamp, signature] = parts;

        if (version === "v1") {
            const signedHeaders = ["User-Agent", "Authorization"];

            let fields = `${timestamp}${req.method.toUpperCase()}${req.url}`;

            for (const header of signedHeaders) {
                const headerValue = getSingleHeaderValue(req.headers, [header, header.toLocaleLowerCase()]);
                if (headerValue) {
                    fields += headerValue;
                }
            }

            const fieldsData = Buffer.from(fields, "utf8");

            const data = Buffer.concat(
                [
                    fieldsData,
                    buffer,
                ],
                fieldsData.length + buffer.length);

            const serverSignature = crypto.createHmac("sha256", key)
                .update(data)
                .digest("base64");

            if (signature === serverSignature) {
                req.hasAuthenticationSignature = true;
                return;
            }
        }
    }

    createLogger("signatureValidation").e(`Invalid Request Signature '${signatureHeader}'`);
    throw new Error("Invalid Request Signature");
}
