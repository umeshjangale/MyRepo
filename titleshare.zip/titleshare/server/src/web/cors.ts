import { CorsOptions } from "apollo-server-express";

import config from "../config";

export const corsOptions: CorsOptions = {
    // In deployed environments, the web and server use the same domain, so the "Access-Control-Allow-Credentials" header is not required.
    credentials: config.isDevelopment ? true : false,
    origin: (origin: string | undefined, callback) => {
        if (origin === config.app.endpoint) {
            callback(null, true);
            return;
        }

        if (typeof origin === "undefined" || config.app.corsAllowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error(`Origin '${origin}' not allowed by CORS`));
        }
    },
};
