
import { Request, Response } from "express";

import { AudioProfile } from "../../audio/audio-format";
import * as Mapper from "../../graphql/mapping";
import { AudioFormat } from "../../graphql/type-defs/types";
import { createLogger } from "../../logger";
import { serviceContainer } from "../../runtime/inversify.config";
import { SYMBOLS } from "../../runtime/symbols";
import * as DataProtection from "../../security/data-protection";
import { AudioStorage } from "../../storage/audio-storage";
import { UserRequest } from "../../types/jwt-user";
import { getCurrentUser } from "../auth";

import { NodeType } from "./../../types/node-id";

/** Authenticates the current users permission to access an audio file and responds with a redirect to the signed URL  */
export async function redirectToAudio(req: UserRequest, res: Response) {

    const getUserOperation = await getCurrentUser(req, res);
    if (getUserOperation.hasError) {
        return res.status(401).send("Unauthorised");
    }

    const user = getUserOperation.obj;

    const contentId = DataProtection.decryptId(req.params.contentId, NodeType.Content);
    const sectionId = DataProtection.decryptId(req.params.sectionId, NodeType.AudioSection);
    const type: AudioProfile = req.params.type;
    const format: AudioFormat = req.params.format;
    const versionId = req.params.version; // Used only for cache busting

    if (type !== "narration" && type !== "soundtrack") {
        return res.status(400).send("Bad type request parameter");
    }

    if (!Object.values(AudioFormat).includes(format)) {
        return res.status(400).send("Bad format request parameter");
    }

    if (!contentId || !sectionId) {
        return res.status(400).send("Bad id request parameters");
    }

    const uri = await serviceContainer.get<AudioStorage>(SYMBOLS.AudioStorage).getSignedAudioUri(user, contentId, sectionId, type, Mapper.toDbAudioFormat(format));
    if (!uri) {
        return res.status(403).send("Forbidden");
    }

    res.redirect(302, uri);
}
