import { Request, Response } from "express";

import config from "../../config";
import { ImageService } from "../../images/image-service";
import { createLogger } from "../../logger";
import { serviceContainer } from "../../runtime/inversify.config";
import { SYMBOLS } from "../../runtime/symbols";
import * as DataProtection from "../../security/data-protection";
import { ContentStorage } from "../../storage/content-storage";
import { getS3, signImageUri } from "../../storage/helpers/blob-helper";
import { UserRequest } from "../../types/jwt-user";
import { getCurrentUser } from "../auth";

import { NodeType } from "./../../types/node-id";

/** Dynamically resize the image path in the URL to the given height and width. In production, a CDN should be used in front of this endpoint. */
export async function getDynamicImage(req: Request, res: Response) {

    if (isNaN(req.query.h) || isNaN(req.query.w)) {
        return res.status(400).send(`Height and width must be numbers ${req.query.h}x${req.query.w}`);
    }

    if (config.cloudFront.enabled) {
        if ((req.header("Authorization") || "") !== config.cloudFront.dynamicImageAuthorization) {
            return res.status(401).send("Unauthorised");
        }
    }

    const newHeight = Number(req.query.h);
    const newWidth = Number(req.query.w);

    if (!config.cloudFront.dynamicImageAllowedSizes.some(({ h, w }) => h === newHeight && w === newWidth)) {
        return res.status(400).send(`Image size ${newHeight}x${newWidth} must be allowed on the server.`);
    }

    // strip the method name from the full path to give us the object ID
    const s3ObjectId = req.path.substring("/dynamic-image/".length);

    const s3 = getS3();

    const params = { Bucket: config.s3.bucket, Key: s3ObjectId };

    s3.getObject(params, async (err, data) => {
        if (err) {
            createLogger("getDynamicImage").e(`s3.getObject returned an error while requesting '${s3ObjectId}' from bucket '${config.s3.bucket}'`, err);
            res.status(400).send("Bad request parameters");
        } else {
            const imageService = serviceContainer.get<ImageService>(SYMBOLS.ImageService);
            const newImage = await imageService.resizeImageAsPng(data.Body as Buffer, newHeight, newWidth);

            res.type(data.ContentType || "image/jpg");
            res.header("Cache-Control", config.cloudFront.dynamicImageCacheControlHeader);
            res.send(newImage);
        }
    });
}

export async function redirectToCoverImage(req: UserRequest, res: Response) {

    const getUserOperation = await getCurrentUser(req, res);
    if (getUserOperation.hasError) {
        return res.status(401).send("Unauthorised");
    }

    if (isNaN(req.params.h) || isNaN(req.params.w)) {
        return res.status(400).send("Height and width must be numbers");
    }

    const user = getUserOperation.obj;
    const contentId = DataProtection.decryptId(req.params.contentId, NodeType.Content);
    const height = Number(req.params.h);
    const width = Number(req.params.w);
    const versionId = req.params.version; // Used only for cache busting

    if (!contentId) {
        return res.status(400).send("Bad id request parameter");
    }

    const content = await serviceContainer.get<ContentStorage>(SYMBOLS.ContentStorage).getContent(user, contentId);
    if (!content || !content.coverImageStoragePath) {
        return res.status(404).send("Not found");
    }

    const uri = await signImageUri(content.coverImageStoragePath, height, width);
    res.redirect(302, uri);
}
