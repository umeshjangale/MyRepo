import { NextFunction, Request, Response } from "express";
import { pipeline } from "stream";

import { createLogger } from "../../logger";
import { serviceContainer } from "../../runtime/inversify.config";
import { SYMBOLS } from "../../runtime/symbols";
import * as DataProtection from "../../security/data-protection";
import { ContentStorage } from "../../storage/content-storage";
import { OrganisationStorage } from "../../storage/organisation-storage";
import { ReportStorage } from "../../storage/report-storage";
import { UserStorage } from "../../storage/user-storage";
import { csvTransform, CsvTransform } from "../../types/csv-transform";
import { UserRequest } from "../../types/jwt-user";
import { NodeType } from "../../types/node-id";
import { getDateDisplay, secondsToHms } from "../../utils";
import { getCurrentUser } from "../auth";

export async function downloadContentBillingReport(req: UserRequest, res: Response, next: NextFunction) {
    try {
        const getUserOperation = await getCurrentUser(req, res);
        if (getUserOperation.hasError) {
            return res.status(401).send("Unauthorised");
        }

        const currentUser = getUserOperation.obj;

        const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
        const result = await reports.getContentBillingReport(currentUser);
        if (result.hasError) {
            return res.status(403).send(result.error);
        }

        res.attachment("billing_titleshare.csv");

        const csv = csvTransform<typeof result.obj>(
            ["Organisation", "Import Date (UTC)", "Title", "Subtitle", "Author", "Billable", "Non-Billable Reason", "Deleted", "Deleted Date (UTC)"],
            row => [
                row.organisationName,
                row.createdDateUtc.toISOString(),
                row.title,
                row.subtitle,
                row.author,
                row.nonBillable ? "No" : "Yes",
                row.nonBillableReason,
                row.deletedDateUtc ? "Yes" : "No",
                row.deletedDateUtc ? row.deletedDateUtc.toISOString() : "",
            ]);

        pipeline(result.obj, csv, res, error => {
            if (error) {
                createLogger("downloadContentBillingReport").e("Error downloading report.", error);
                next(error);
            }
        });

    } catch (e) {
        createLogger("downloadContentBillingReport").e(e);
        return res.sendStatus(500);
    }
}

export async function downloadUsersReportForOrganisation(req: UserRequest, res: Response, next: NextFunction) {
    try {
        const getUserOperation = await getCurrentUser(req, res);
        if (getUserOperation.hasError) {
            return res.status(401).send("Unauthorised");
        }

        const currentUser = getUserOperation.obj;

        const organisationId = DataProtection.decryptId(req.params.organisationId, NodeType.Organisation);
        if (!organisationId) {
            return res.status(400).send(`Invalid organisationId '${req.params.organisationId}'`);
        }

        const organisation = await serviceContainer.get<OrganisationStorage>(SYMBOLS.OrganisationStorage).getOrganisationForAdmin(currentUser, organisationId);
        if (!organisation) {
            return res.status(400).send(`Invalid organisation '${organisationId}'`);
        }

        const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
        const result = await reports.getOrganisationUsers(currentUser, organisationId);
        if (result.hasError) {
            return res.status(403).send(result.error);
        }

        const filename = `users_${sanitizeForFileName(organisation.name)}.csv`;
        res.attachment(filename);

        const csv = csvTransform<typeof result.obj>(
            ["First Name", "Last Name", "Email", "Has Accepted Invite?", "Has Logged In?", "Last Logged In (UTC)"],
            row => [
                row.firstName,
                row.lastName,
                DataProtection.decryptEmail(row.encryptedEmail),
                row.inviteAcceptedDateUtc ? "Yes" : "No",
                row.loginCount > 0 ? "Yes" : "No",
                row.lastLoginDateUtc ? row.lastLoginDateUtc.toISOString() : "",
            ]);

        pipeline(result.obj, csv, res, error => {
            if (error) {
                createLogger("downloadUserReportForOrganisation").e("Error downloading report.", error);
                next(error);
            }
        });

    } catch (e) {
        createLogger("downloadUserReportForOrganisation").e(e);
        return res.sendStatus(500);
    }
}

export async function downloadContentReportForOrganisation(req: UserRequest, res: Response, next: NextFunction) {
    try {
        const getUserOperation = await getCurrentUser(req, res);
        if (getUserOperation.hasError) {
            return res.status(401).send("Unauthorised");
        }

        const currentUser = getUserOperation.obj;

        const organisationId = DataProtection.decryptId(req.params.organisationId, NodeType.Organisation);
        if (!organisationId) {
            return res.status(400).send(`Invalid organisationId '${req.params.organisationId}'`);
        }

        const organisation = await serviceContainer.get<OrganisationStorage>(SYMBOLS.OrganisationStorage).getOrganisationForAdmin(currentUser, organisationId);
        if (!organisation) {
            return res.status(400).send(`Invalid organisation '${organisationId}'`);
        }

        const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
        const result = await reports.getOrganisationContent(currentUser, organisationId);
        if (result.hasError) {
            return res.status(403).send(result.error);
        }

        const filename = `content_${sanitizeForFileName(organisation.name)}.csv`;
        res.attachment(filename);

        const csv = csvTransform<typeof result.obj>(
            ["Import Date (UTC)", "Title", "Subtitle", "Author", "Narrator", "Publisher", "Release Date (yyyy-mm-dd)"],
            row => [
                row.createdDateUtc.toISOString(),
                row.title,
                row.subtitle,
                row.author,
                row.narrator,
                row.publisher,
                row.releaseDate ? getDateDisplay(row.releaseDate) : "",
            ]);

        pipeline(result.obj, csv, res, error => {
            if (error) {
                createLogger("downloadContentReportForOrganisation").e("Error downloading report.", error);
                next(error);
            }
        });

    } catch (e) {
        createLogger("downloadContentReportForOrganisation").e(e);
        return res.sendStatus(500);
    }
}

export async function downloadContentReportForUser(req: UserRequest, res: Response, next: NextFunction) {
    try {
        const getUserOperation = await getCurrentUser(req, res);
        if (getUserOperation.hasError) {
            return res.status(401).send("Unauthorised");
        }

        const currentUser = getUserOperation.obj;

        const userId = DataProtection.decryptId(req.params.userId, NodeType.User);
        if (!userId) {
            return res.status(400).send(`Invalid userId '${req.params.userId}'`);
        }

        const user = await serviceContainer.get<UserStorage>(SYMBOLS.UserStorage).getUserForAdmin(currentUser, userId);
        if (!user) {
            return res.status(400).send(`Invalid user '${userId}'`);
        }

        // Organisation id is optional.
        const organisationId = DataProtection.decryptId(req.query.organisationId, NodeType.Organisation);

        const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
        const result = await reports.getContentPlaybackForUser(currentUser, userId, organisationId);
        if (result.hasError) {
            return res.status(403).send(result.error);
        }

        const filename = `user_usage_${sanitizeForFileName(user.firstName)}_${sanitizeForFileName(user.lastName)}.csv`;
        res.attachment(filename);

        const csv = csvTransform<typeof result.obj>(
            [
                "First Name",
                "Last Name",
                "Email",
                "Title",
                "Subtitle",
                "Author",
                "Organisation",
                "Playback Time (hh:mm:ss)",
                "Total Book Time (hh:mm:ss)",
                "Playback Percentage",
                "Bookmarked File Number",
                "Bookmarked File Time (hh:mm:ss)",
            ],
            row => [
                row.firstName,
                row.lastName,
                DataProtection.decryptEmail(row.encryptedEmail),
                row.title,
                row.subtitle,
                row.author,
                row.organisationName,
                secondsToHms(row.playbackTime),
                secondsToHms(row.totalDuration),
                row.playbackTime ? `${Math.round(row.playbackTime / row.totalDuration * 100)}%` : "0%",
                row.bookmarkedAudioSectionIndex !== null ? row.bookmarkedAudioSectionIndex + 1 : "",
                row.bookmarkedAudioSectionTime ? secondsToHms(row.bookmarkedAudioSectionTime) : "",
            ]);

        pipeline(result.obj, csv, res, error => {
            if (error) {
                createLogger("downloadContentReportForUser").e("Error downloading report.", error);
                next(error);
            }
        });

    } catch (e) {
        createLogger("downloadContentReportForUser").e(e);
        return res.sendStatus(500);
    }
}

export async function downloadUsersReportForContent(req: UserRequest, res: Response, next: NextFunction) {
    try {
        const getUserOperation = await getCurrentUser(req, res);
        if (getUserOperation.hasError) {
            return res.status(401).send("Unauthorised");
        }

        const currentUser = getUserOperation.obj;

        const contentId = DataProtection.decryptId(req.params.contentId, NodeType.Content);
        if (!contentId) {
            return res.status(400).send(`Invalid contentId '${req.params.contentId}'`);
        }

        const content = await serviceContainer.get<ContentStorage>(SYMBOLS.ContentStorage).getContent(currentUser, contentId);
        if (!content) {
            return res.status(400).send(`Invalid content '${contentId}'`);
        }

        const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
        const result = await reports.getUsersPlaybackForContent(currentUser, contentId);
        if (result.hasError) {
            return res.status(403).send(result.error);
        }

        const filename = `content_usage_${sanitizeForFileName(content.title)}.csv`;
        res.attachment(filename);

        const csv = csvTransform<typeof result.obj>(
            [
                "First Name",
                "Last Name",
                "Email",
                "Title",
                "Subtitle",
                "Author",
                "Playback Time (hh:mm:ss)",
                "Total Book Time (hh:mm:ss)",
                "Playback Percentage",
                "Bookmarked File Number",
                "Bookmarked File Time (hh:mm:ss)",
            ],
            row => [
                row.firstName,
                row.lastName,
                DataProtection.decryptEmail(row.encryptedEmail),
                row.title,
                row.subtitle,
                row.author,
                secondsToHms(row.playbackTime),
                secondsToHms(row.totalDuration),
                row.playbackTime ? `${Math.round(row.playbackTime / row.totalDuration * 100)}%` : "0%",
                row.bookmarkedAudioSectionIndex !== null ? row.bookmarkedAudioSectionIndex + 1 : "",
                row.bookmarkedAudioSectionTime ? secondsToHms(row.bookmarkedAudioSectionTime) : "",
            ]);

        pipeline(result.obj, csv, res, error => {
            if (error) {
                createLogger("downloadUsersReportForContent").e("Error downloading report.", error);
                next(error);
            }
        });

    } catch (e) {
        createLogger("downloadUsersReportForContent").e(e);
        return res.sendStatus(500);
    }
}

function sanitizeForFileName(value: string): string {
    return value.replace(/ /g, "_").toLowerCase();
}
