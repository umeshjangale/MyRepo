import { NextFunction, Request, Response } from "express";
import { Options as JwtOptions } from "express-jwt";

import config from "../config";
import { createLogger } from "../logger";
import { serviceContainer } from "../runtime/inversify.config";
import { SYMBOLS } from "../runtime/symbols";
import * as DataProtection from "../security/data-protection";
import { User } from "../storage/db-entities";
import { UserStorage } from "../storage/user-storage";
import { UserRequest } from "../types/jwt-user";
import { NodeType } from "../types/node-id";
import { OperationResult } from "../types/operation-result";
import { getUserAgent } from "../utils/user-agent-utils";

export async function getCurrentUser(req: UserRequest, res: Response): Promise<OperationResult<User, "not-authenticated" | "session-expired">> {

    if (!req.user) {
        return OperationResult.error("not-authenticated");
    }

    const userStorage = serviceContainer.get<UserStorage>(SYMBOLS.UserStorage);
    const userId = DataProtection.decryptId(req.user.id, NodeType.User);

    const user = userId ? await userStorage.getUser(userId, true) : null;

    // Ensure the user's session is valid
    if (!user || !user.sessionToken || user.sessionToken !== req.user.sessionToken) {
        removeAuthCookie(res);
        return OperationResult.error("session-expired");
    }

    const userAgent = getUserAgent(req.headers);
    const ip = req.ip ? req.ip : "";

    userStorage.logUserAgent(user, ip, userAgent).catch(err => {
        createLogger("getCurrentUser").e(`Error logging user agent for ip address ${ip}`, err);
    });

    return OperationResult.as(user);
}

export function setAuthCookie(res: Response, value: string, csrfToken: string, validitySeconds?: number): void {

    // The CSRF token cookie value must be read by the client and sent back in the "X-XSRF-TOKEN" header for each request.
    res.cookie(config.cookie.csrfName, csrfToken, {
        httpOnly: false,
        domain: config.cookie.domain,
        maxAge: (validitySeconds || config.cookie.validitySeconds) * 1000,
        secure: config.isDevelopment ? false : true,
        sameSite: true,
    });

    res.cookie(config.cookie.name, value, {
        httpOnly: true,
        domain: config.cookie.domain,
        maxAge: (validitySeconds || config.cookie.validitySeconds) * 1000,
        secure: config.isDevelopment ? false : true,
        sameSite: true,
    });
}

export function removeAuthCookie(res: Response): void {
    setAuthCookie(res, "", "", 0);
}

export const expressJwtOptions: JwtOptions = {
    secret: DataProtection.jwtSecret,
    credentialsRequired: false,
    getToken: req => {
        if (req.headers.authorization && req.headers.authorization.split(" ")[0] === "Bearer") {
            return req.headers.authorization.split(" ")[1];
        } else if (req.cookies && req.cookies[config.cookie.name]) {
            return req.cookies[config.cookie.name];
        }
    },
};

export function expressJwtErrorHandler(err: any, req: Request, res: Response, next: NextFunction) {
    if (!res.headersSent && err && err.name === "UnauthorizedError") {

        // If there is an error thrown by jwt-express e.g. due to an invalid token, then
        // remove the auth cookie to try prevent it from happening again.
        removeAuthCookie(res);
    }

    next(err);
}
