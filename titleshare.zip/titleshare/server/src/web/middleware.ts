import basicAuth from "basic-auth";
import { NextFunction, Request, Response } from "express";

import { createLogger } from "../logger";
import { UserRequest } from "../types/jwt-user";

import config from "./../config";

export function basicAuthMiddleware(req: Request, res: Response, next: NextFunction) {

    // Only check for basic auth if user doesn't have a JWT.
    if (!req.user) {
        const user = basicAuth(req) as { name: string; pass: string } | undefined;
        if (!user || user.name !== config.app.basicAuthUsername || user.pass !== config.app.basicAuthPassword) {
            res.statusCode = 401;
            res.setHeader("WWW-Authenticate", "Basic realm=\"titleShare\"");
            res.end("Access denied");
            return;
        }
    }

    next();
}

export function csrfValidation(req: UserRequest, res: Response, next: NextFunction) {

    // If the user is authenticated and the JWT has a CSRF token associated with
    // it, then the request MUST have a "X-XSRF-TOKEN" header containing the token.
    const skippedMethods = ["GET", "HEAD"];
    if (!skippedMethods.some(m => m === req.method) && req.user && req.user.csrfToken) {
        const csrfToken = (req.headers ? req.headers["X-XSRF-TOKEN"] || req.headers["x-xsrf-token"] : "") || "";
        if (!csrfToken || req.user.csrfToken !== csrfToken) {
            return res.status(400).send("Invalid XSRF token");
        }
    }

    next();
}

/** Ensures that the configured hostname matches that of the request. */
export function hostnameValidation(req: Request, res: Response, next: NextFunction) {
    const endpoint = new URL(config.app.endpoint);
    if (endpoint.hostname === req.hostname) {
        next();
        return;
    }

    // Requests to the root domain should be redirected to the marketing page.
    if (req.hostname === "www.title-share.net" || req.hostname === "title-share.net") {
        res.redirect(301, "https://www.booktrack.com/titleshare");
        return;
    }

    createLogger("hostnameValidation").w(`Invalid hostname. Expected '${endpoint.hostname}' but got '${req.hostname}'`);
    res.status(400).send("Invalid hostname");
}
