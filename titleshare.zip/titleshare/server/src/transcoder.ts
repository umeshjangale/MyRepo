/**
 * The transcoder worker app for the server.
 * The transcoder is responsible for transcoding audio from one S3 object to another by processing messages in a queue.
 */

import bodyParser from "body-parser";
import express from "express";

import config from "./config";
import { createLogger } from "./logger";
import { QueueMessage } from "./queues/queue-message";
import { QueueType } from "./queues/queue-type";
import { serviceContainer } from "./runtime/inversify.config";
import { SYMBOLS } from "./runtime/symbols";
import { ImportStorage } from "./storage/import-storage";

// All dates should be interpreted as UTC by default.
process.env.TZ = "UTC";

const log = createLogger("Transcoder Worker App");
log.i(`Starting titleshare transcoder worker. NODE_ENV: ${config.nodeEnv}`);

const importStorage = serviceContainer.get<ImportStorage>(SYMBOLS.ImportStorage);

// In AWS beanstalk, a HTTP request is made to the worker for each queue message.
const app = express();
app.use(bodyParser.json());

app.post("/", async (req, res) => {

    let messageId: string | undefined;
    try {
        const msgId = req.headers["X-Aws-Sqsd-Msgid"] || req.headers["x-aws-sqsd-msgid"];
        const rCount = req.headers["X-Aws-Sqsd-Receive-Count"] || req.headers["x-aws-sqsd-receive-count"];

        if (!msgId) {
            log.i(`Queue message has no message Id. Message ignored. ${JSON.stringify(req.body)}`);
            return res.sendStatus(400);
        }

        messageId = Array.isArray(msgId) ? msgId[0] : msgId;
        const receivedCount = Array.isArray(rCount) ? rCount[0] : rCount;

        if (req.body.Event === "s3:TestEvent") {
            log.i(`Received test event message. Id: '${messageId}' ${JSON.stringify(req.body)}`);
            return res.sendStatus(200);
        }

        const msg: QueueMessage = {
            queue: req.body.Records ? QueueType.ImportFileEvent : undefined,
            messageId,
            ...req.body,
        };

        log.i(`Processing message. Queue: '${msg.queue}', Id: '${msg.messageId}', Received Count: ${receivedCount} ${JSON.stringify(req.body)}`);

        switch (msg.queue) {
            case QueueType.AudioEncoding:
                await importStorage.doAudioEncoding(msg);
                break;
            case QueueType.LargeAudioEncoding:
                await importStorage.doAudioEncoding(msg);
                break;
            default:
                throw new Error(`Unexpected message for queue '${msg.queue}'`);
        }

        log.i(`Processing complete. Queue: '${msg.queue}', Id: '${msg.messageId}'`);

        // The message will be automatically deleted when the response code is 200 OK.
        return res.sendStatus(200);
    } catch (err) {
        log.e(`Error processing message from HTTP request. MsgId: ${messageId}`, err);
        return res.sendStatus(500);
    }
});

const port = config.app.port;
const server = app.listen(port, err => {
    if (err) {
        log.e(err);
        return;
    }

    log.i(`worker is listening on ${port}`);
});

// Elastic beanstalk requires a http connection open for the entire duration of the task (!), so update the server timeout.
server.timeout = 1200 * 1000; // 20 minutes.
