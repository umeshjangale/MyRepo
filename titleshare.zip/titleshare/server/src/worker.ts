/**
 * The worker app for the server.
 * The worker is responsible for asynchronous work mainly by processing messages in a queue.
 */

import bodyParser from "body-parser";
import express from "express";

import config from "./config";
import { createLogger } from "./logger";
import { MessageHandler } from "./queues/message-handler";
import { QueueMessage } from "./queues/queue-message";
import { QueueService } from "./queues/queue-service";
import { QueueType } from "./queues/queue-type";
import { serviceContainer } from "./runtime/inversify.config";
import { SYMBOLS } from "./runtime/symbols";
import { configureDatabase } from "./storage/helpers/db-helper";

// All dates should be interpreted as UTC by default.
process.env.TZ = "UTC";

const log = createLogger("Worker App");
log.i(`Starting titleshare worker. NODE_ENV: ${config.nodeEnv}`);

configureDatabase()
    .then(c => {
        log.i("Database connection pool initialised");
    })
    .catch(err => log.e("Error initialising database connection pool", err));

const messageHandler = serviceContainer.get<MessageHandler>(SYMBOLS.MessageHandler);
const queueService = serviceContainer.get<QueueService>(SYMBOLS.QueueService);

if (config.isDevelopment) {

    // Run a simple loop to pull messages off the queue in development
    const runMessagePump = async (name: string, func: () => Promise<void>, timeoutMs: number = 3000) => {

        const runLoop = async () => {
            try {
                await func();
            } catch (err) {
                log.e(`Error in ${name} message pump`, err);
            }

            setTimeout(runLoop, timeoutMs);
        };

        return runLoop();
    };

    setTimeout(
        () => {
            const pumps = [
                runMessagePump("Email", async () => queueService.receiveMessage(QueueType.Email, async msg => messageHandler.handleMessage(msg))),
                runMessagePump("ImportFileEvent", async () => queueService.receiveMessage(QueueType.ImportFileEvent, async msg => messageHandler.handleMessage(msg))),
                runMessagePump("ImportBatchTransfer", async () => queueService.receiveMessage(QueueType.ImportBatchTransfer, async msg => messageHandler.handleMessage(msg))),
                runMessagePump("ImportBatchValidation", async () => queueService.receiveMessage(QueueType.ImportBatchValidation, async msg => messageHandler.handleMessage(msg))),
                runMessagePump("ProcessAudioSection", async () => queueService.receiveMessage(QueueType.ProcessAudioSection, async msg => messageHandler.handleMessage(msg))),
                runMessagePump("EndAudioEncoding", async () => queueService.receiveMessage(QueueType.EndAudioEncoding, async msg => messageHandler.handleMessage(msg))),
            ];

            if (!config.app.useLambdaForAudioEncoding) {
                pumps.push(runMessagePump("AudioEncoding", async () => queueService.receiveMessage(QueueType.AudioEncoding, async msg => messageHandler.handleMessage(msg))));
            }

            Promise.all(pumps)
                .catch(err => log.e("Error starting message pump", err));
        },
        5000,
    );

} else {

    // In AWS beanstalk, a HTTP request is made to the worker for each queue message.
    const app = express();
    app.use(bodyParser.json());

    app.post("/", async (req, res) => {

        let messageId: string | undefined;
        try {
            const msgId = req.headers["X-Aws-Sqsd-Msgid"] || req.headers["x-aws-sqsd-msgid"];
            const rCount = req.headers["X-Aws-Sqsd-Receive-Count"] || req.headers["x-aws-sqsd-receive-count"];

            if (!msgId) {
                log.i(`Queue message has no message Id. Message ignored. ${JSON.stringify(req.body)}`);
                return res.sendStatus(400);
            }

            messageId = Array.isArray(msgId) ? msgId[0] : msgId;
            const receivedCount = Array.isArray(rCount) ? rCount[0] : rCount;

            if (req.body.Event === "s3:TestEvent") {
                log.i(`Received test event message. Id: '${messageId}' ${JSON.stringify(req.body)}`);
                return res.sendStatus(200);
            }

            const msg: QueueMessage = {
                queue: req.body.Records ? QueueType.ImportFileEvent : undefined,
                messageId,
                ...req.body,
            };

            log.i(`Processing message. Queue: '${msg.queue}', Id: '${msg.messageId}', Received Count: ${receivedCount} ${JSON.stringify(req.body)}`);

            await messageHandler.handleMessage(msg);

            log.i(`Processing complete. Queue: '${msg.queue}', Id: '${msg.messageId}'`);

            // The message will be automatically deleted when the response code is 200 OK.
            return res.sendStatus(200);
        } catch (err) {
            log.e(`Error processing message from HTTP request. MsgId: ${messageId}`, err);
            return res.sendStatus(500);
        }
    });

    const port = config.app.port;
    const server = app.listen(port, err => {
        if (err) {
            log.e(err);
            return;
        }

        log.i(`worker is listening on ${port}`);
    });

    // Elastic beanstalk requires a http connection open for the entire duration of the task (!), so update the server timeout.
    server.timeout = 1200 * 1000; // 20 minutes.
}
