
import { IncomingHttpHeaders } from "http";
import semver from "semver";

import { getSingleHeaderValue } from "./http-header-utils";

type AppVersion = IosAppVersion | AndroidAppVersion | OtherAppVersion;

interface IosAppVersion {
    platform: "ios";
    env: string;
    appVersion: string;
}

interface AndroidAppVersion {
    platform: "android";
    env: string;
    appVersion: string;
}

interface OtherAppVersion {
    platform: "other";
}

export function getUserAgent(headers: IncomingHttpHeaders): string {
    return getSingleHeaderValue(headers, ["user-agent", "User-Agent"]);
}

export function isSupportedAppVersion(userAgent: string, minIosVersion: string, minAndroidVersion: string): boolean {
    const ua = parseUserAgent(userAgent);

    if (ua.platform === "other") return true;

    switch (ua.platform) {
        case "ios":
            return semver.gte(ua.appVersion, minIosVersion);
        case "android":
            return semver.gte(ua.appVersion, minAndroidVersion);
    }
}

export function parseUserAgent(userAgent: string): AppVersion {

    const mobileAppId = "com.booktrack.titleshare";
    if (!userAgent.startsWith(mobileAppId)) return { platform: "other" };

    let pos = mobileAppId.length;

    const envEndIndex = userAgent.indexOf("/", pos);
    let env = userAgent.substring(pos, envEndIndex);
    pos += env.length + 1;

    if (env.startsWith(".")) env = env.substring(1);

    const appVersionEndIndex = userAgent.indexOf(" ", pos);
    const appVersion = userAgent.substring(pos, appVersionEndIndex);
    pos += appVersion.length + 1;

    const hardwareStartIndex = userAgent.indexOf("(", pos);
    const hardwareEndIndex = userAgent.indexOf(")", hardwareStartIndex);
    const hardwareId = userAgent.substring(hardwareStartIndex + 1, hardwareEndIndex);

    if (hardwareId.toLowerCase().indexOf("ios") >= 0) {
        return {
            platform: "ios",
            env,
            appVersion,
        };
    } else {
        return {
            platform: "android",
            env,
            appVersion,
        };
    }
}
