import { IncomingHttpHeaders } from "http";

export function getSignatureHeader(headers: IncomingHttpHeaders): string {
    return getSingleHeaderValue(headers, ["x-signature", "X-Signature"]);
}

export function getSingleHeaderValue(headers: IncomingHttpHeaders, headerNameVariants: string[]): string {
    if (!headers) return "";

    let value: string | string[] | undefined;
    for (const headerName of headerNameVariants) {
        value = headers[headerName];
        if (value) break;
    }

    if (!value) return "";

    return Array.isArray(value) ? value[0] : value;
}
