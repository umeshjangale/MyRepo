import "jasmine";

import { changeExtension, getLastDirectoryName } from "./path-utils";

describe("Path Utilities", () => {

    describe("changeExtension", () => {
        it("changes wav tp mp3", () => {

            const filename = "bang.wav";
            const expected = "bang.mp3";

            const actual = changeExtension(filename, "mp3");
            expect(actual).toEqual(expected);
        });

        it("retains full path", () => {

            const filename = "abc/123/bang.wav";
            const expected = "abc/123/bang.mp3";

            const actual = changeExtension(filename, "mp3");
            expect(actual).toEqual(expected);
        });

        it("supports file ending in dot", () => {

            const filename = "abc/123/bang.";
            const expected = "abc/123/bang.mp3";

            const actual = changeExtension(filename, "mp3");
            expect(actual).toEqual(expected);
        });

        it("supports dot suffix and extension", () => {

            const filename = "abc/123/bang.wav";
            const expected = "abc/123/bang.32bit.mp3";

            const actual = changeExtension(filename, "32bit.mp3");
            expect(actual).toEqual(expected);
        });

        it("supports removing dot from file", () => {

            const filename = "abc/123/bang.";
            const expected = "abc/123/bang";

            const actual = changeExtension(filename, "");
            expect(actual).toEqual(expected);
        });

        it("supports file without extension", () => {

            const filename = "abc/123/bang";
            const expected = "abc/123/bang.mp3";

            const actual = changeExtension(filename, "mp3");
            expect(actual).toEqual(expected);
        });

        it("supports removing the extension", () => {

            const filename = "bang.wav";
            const expected = "bang";

            const actual = changeExtension(filename, "");
            expect(actual).toEqual(expected);
        });
    });

    describe("getLastDirectoryName", () => {

        it("returns empty string for no directory", () => {
            const inputs = [
                "filename.mp3",
                "/",
                ".",
                "filename",
            ];

            const expected = "";

            for (const input of inputs) {
                const actual = getLastDirectoryName(input);
                expect(actual).toEqual(expected);
            }
        });

        it("returns last directory for path", () => {
            const inputs = [
                "folder/something/lastdir/filename.mp3",
                "something/lastdir/filename.mp3",
                "lastdir/filename",
                "./lastdir/filename",
                "./ssomething/lastdir/",
            ];

            const expected = "lastdir";

            for (const input of inputs) {
                const actual = getLastDirectoryName(input);
                expect(actual).toEqual(expected);
            }
        });
    });
});
