import path from "path";

/** Return the directory name of a path including a "/" at the end. */
export function getDirectoryName(value: string): string {
    if (!value) return "";

    let dirname = path.dirname(value);
    if (!dirname || dirname === ".") return "";

    if (!dirname.endsWith("/")) {
        dirname += "/";
    }

    return dirname;
}

/** Return the last directory name in a path excluding any "/". */
export function getLastDirectoryName(value: string): string {
    if (!value) return "";

    const parts = value.split("/");

    for (let i = parts.length - 2; i >= 0; i--) {
        const dirname = parts[i];
        if (dirname && dirname !== ".") return dirname;
    }
    return "";
}

export function getFilename(value: string): string {
    if (!value || value.endsWith("/")) return "";

    return path.basename(value);
}

export function getFilenameWithoutExtension(value: string) {
    const filename = getFilename(value);
    return changeExtension(filename, "");
}

export function changeExtension(filename: string, newExtensionWithoutDot: string) {
    const ext = path.extname(filename);

    let result = filename;
    if (ext) {
        result = result.substr(0, filename.length - ext.length);
    }

    if (newExtensionWithoutDot) {
        result += `.${newExtensionWithoutDot}`;
    }

    return result;
}

export function getFileExtensionWithoutDot(value: string): string {
    let ext = path.extname(value);

    if (ext.startsWith(".")) {
        ext = ext.substring(1);
    }

    return ext;
}
