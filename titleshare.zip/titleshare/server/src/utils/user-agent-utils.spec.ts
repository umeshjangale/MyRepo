import "jasmine";

import { isSupportedAppVersion, parseUserAgent } from "./user-agent-utils";

describe("User Agent Utilities", () => {

    describe("parseUserAgent", () => {
        it("parses debug 1.0.1 ios UAs", () => {

            const userAgents = [
                "com.booktrack.titleshare.debug/1.0.1 (iOS/12.2.0; iPhone11,8/x86_64_simulator) Alamofire/4.8.2",
                "com.booktrack.titleshare.debug/1.0.1 (iOS/12.1.4; iPhone7,1) Alamofire/4.8.2",
            ];

            for (const userAgent of userAgents) {
                const actual = parseUserAgent(userAgent);

                expect(actual).not.toBeFalsy();
                expect(actual.platform).toEqual("ios");
                if (actual.platform !== "ios") return;

                expect(actual.env).toEqual("debug");
                expect(actual.appVersion).toEqual("1.0.1");
            }
        });

        it("parses stable 1.0.1 ios UAs", () => {

            const userAgents = [
                "com.booktrack.titleshare/1.0.1 (iOS/12.2.0; iPhone11,8/x86_64_simulator) Alamofire/4.8.2",
                "com.booktrack.titleshare/1.0.1 (iOS/12.1.4; iPhone7,1) Alamofire/4.8.2",
            ];

            for (const userAgent of userAgents) {
                const actual = parseUserAgent(userAgent);

                expect(actual).not.toBeFalsy();
                expect(actual.platform).toEqual("ios");
                if (actual.platform !== "ios") return;

                expect(actual.env).toEqual("");
                expect(actual.appVersion).toEqual("1.0.1");
            }
        });

        it("parses unknown UA", () => {

            const userAgent = "something/really random 1.0 ";

            const actual = parseUserAgent(userAgent);

            expect(actual).not.toBeFalsy();
            expect(actual.platform).toEqual("other");
        });
    });

    describe("isSupportedAppVersion", () => {

        it("returns false for higher min version", () => {

            const minVersions = [
                "1.0.2", "2.0.500", "1.0.10",
            ];

            const userAgent = "com.booktrack.titleshare.debug/1.0.1 (iOS/12.2.0; iPhone11,8/x86_64_simulator) Alamofire/4.8.2";

            for (const version of minVersions) {
                const actual = isSupportedAppVersion(userAgent, version, "1.0.1");
                expect(actual).toEqual(false);
            }
        });

        it("returns true for lower or same min version", () => {

            const minVersions = [
                "1.0.0", "1.0.1", "0.0.10", "0.0.5",
            ];

            const userAgent = "com.booktrack.titleshare.debug/1.0.1 (iOS/12.2.0; iPhone11,8/x86_64_simulator) Alamofire/4.8.2";

            for (const version of minVersions) {
                const actual = isSupportedAppVersion(userAgent, version, "1.0.1");
                expect(actual).toEqual(true);
            }
        });
    });
});
