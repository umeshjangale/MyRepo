import "jasmine";

import { getSqlDateStringUtc, secondsToHms } from "./date-utils";

describe("Date Utilities", () => {

    describe("getSqlDateString", () => {
        it("Gets string with precision of 3", () => {

            const date = new Date("2018-07-12T09:14:33.123456Z");
            const expected = "2018-07-12 09:14:33.123";
            const actual = getSqlDateStringUtc(date);

            expect(actual).toEqual(expected);
        });

        it("Pads with 0", () => {

            const date = new Date("2000-01-01T00:01:00.001Z");
            const expected = "2000-01-01 00:01:00.001";
            const actual = getSqlDateStringUtc(date);

            expect(actual).toEqual(expected);
        });
    });

    describe("secondsToHms", () => {
        it("Correctly formats duration", () => {

            const testData = [
                { input: 20, expected: "00:00:20" },
                { input: 120, expected: "00:02:00" },
                { input: 2400, expected: "00:40:00" },
                { input: 3600, expected: "01:00:00" },
                { input: 3605, expected: "01:00:05" },
                { input: 7205, expected: "02:00:05" },
                { input: 8561, expected: "02:22:41" },
                { input: 43205, expected: "12:00:05" },
                { input: 396030, expected: "110:00:30" },
            ];

            for (const item of testData) {
                const actual = secondsToHms(item.input);
                expect(actual).toEqual(item.expected);
            }
        });
    });
});
