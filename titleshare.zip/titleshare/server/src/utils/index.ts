
export * from "./path-utils";
export * from "./date-utils";

export function assertNever(x: never): never {
    throw new Error(`Unexpected object ${JSON.stringify(x)}`);
}
