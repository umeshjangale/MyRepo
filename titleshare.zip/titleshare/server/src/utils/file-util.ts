import fs from "fs";

export async function getFileBytes(filePath: string): Promise<number> {
    return new Promise<number>((res, rej) => {

        fs.stat(filePath, (err, stats) => {
            if (err) {
                rej(err);
                return;
            }
            res(stats.size);
        });
    });
}

export async function getFileAsBase64(filePath: string): Promise<string> {
    return new Promise<string>((res, rej) => {

        fs.readFile(filePath, (err, data) => {
            if (err) {
                rej(err);
            } else {
                res(data.toString("base64"));
            }
        });
    });
}
