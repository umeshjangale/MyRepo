
/** Gets a date string formated suitable for passing to a mysql database. */
export function getSqlDateStringUtc(date: Date): string {

    const year = date.getUTCFullYear();
    const month = toTwoDigitString(date.getUTCMonth() + 1);
    const day = toTwoDigitString(date.getUTCDate());
    const hours = toTwoDigitString(date.getUTCHours());
    const mins = toTwoDigitString(date.getUTCMinutes());
    const seconds = toTwoDigitString(date.getUTCSeconds());
    const milliseconds = toThreeDigitString(date.getUTCMilliseconds());

    return `${year}-${month}-${day} ${hours}:${mins}:${seconds}.${milliseconds}`;
}

/** Converts number of seconds to the format HH:mm:ss */
export function secondsToHms(seconds: number | null) {

    if (!seconds) return "00:00:00";

    let h = Math.floor(seconds / 3600).toString(10);
    let m = Math.floor(seconds % 3600 / 60).toString(10);
    let s = Math.floor(seconds % 3600 % 60).toString(10);

    if (h.length === 1) h = `0${h}`;
    if (m.length === 1) m = `0${m}`;
    if (s.length === 1) s = `0${s}`;

    return `${h}:${m}:${s}`;
}

/* Gets the date formated as yyyy-mm-dd */
export function getDateDisplay(date: Date): string {
    const y = date.getUTCFullYear();
    const m = toTwoDigitString(date.getUTCMonth() + 1);
    const d = toTwoDigitString(date.getUTCDate());

    return `${y}-${m}-${d}`;
}

function getMonthDisplay(zeroBasedMonth: number) {
    if (zeroBasedMonth < 0 || zeroBasedMonth > 11) throw new Error(`Invalid date index: ${zeroBasedMonth}`);
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return monthNames[zeroBasedMonth];
}

function toTwoDigitString(value: number): string {
    if (value < 10) {
        return `0${value}`;
    }

    return String(value);
}

function toThreeDigitString(value: number): string {
    if (value < 10) {
        return `00${value}`;
    } else if (value < 100) {
        return `0${value}`;
    } else {
        return String(value);
    }
}
