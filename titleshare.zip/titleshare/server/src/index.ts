import { ApolloServer } from "apollo-server-express";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { Application } from "express";
import expressJwt from "express-jwt";
import rateLimit from "express-rate-limit";
import path from "path";

import config from "./config";
import { gqlConfig } from "./graphql/config";
import { createLogger } from "./logger";
import { serviceContainer } from "./runtime/inversify.config";
import { SYMBOLS } from "./runtime/symbols";
import { configureDatabase } from "./storage/helpers/db-helper";
import { UserStorage } from "./storage/user-storage";
import { expressJwtErrorHandler, expressJwtOptions } from "./web/auth";
import { corsOptions } from "./web/cors";
import { basicAuthMiddleware, csrfValidation, hostnameValidation } from "./web/middleware";
import { downloadContentBillingReport, downloadContentReportForOrganisation, downloadContentReportForUser, downloadUsersReportForContent, downloadUsersReportForOrganisation, getDynamicImage, redirectToAudio, redirectToCoverImage } from "./web/request-handlers";
import { signatureValidation } from "./web/signature-validator";

// All dates should be interpreted as UTC by default.
process.env.TZ = "UTC";

startup();

function startup(): Application {
    const log = createLogger("index.js");
    log.i(`Starting titleshare server. NODE_ENV: ${config.nodeEnv}`);

    configureDatabase()
        .then(c => {
            log.i("Database connection pool initialised");
            if (config.bootstrap.firstUserEmail && config.bootstrap.firstUserPassword) {
                serviceContainer.get<UserStorage>(SYMBOLS.UserStorage).createFirstUser(config.bootstrap.firstUserEmail, config.bootstrap.firstUserPassword)
                    .then(user => {
                        if (user) {
                            log.i("Created first user");
                        } else {
                            log.i("First user already exists");
                        }
                    })
                    .catch(err => log.e("Error creating first user", err));
            }
        })
        .catch(err => log.e("Error initialising database connection pool", err));

    const app = express();
    app.disable("x-powered-by");
    app.enable("trust proxy"); // See http://expressjs.com/en/guide/behind-proxies.html
    app.use(hostnameValidation);
    app.get("/faq", (req, res) => res.redirect(301, "https://www.booktrack.com/titleshare-faq"));

    const apiLimiter = rateLimit({
        windowMs: config.runtime.rateLimitTimeWindowSeconds * 1000,
        max: config.runtime.rateLimitMaxRequests,
        onLimitReached: (req, res, options) => {
            createLogger("Request Rate Limiter").e(`Request limit reached (${config.runtime.rateLimitMaxRequests}/${config.runtime.rateLimitTimeWindowSeconds}s). IP: ${req.ip}`);
        },
        headers: false,
    });

    // Apply rate limiting to all graphql requests, including login and reset password. Note that this is per instance.
    app.use("/graphql", apiLimiter);
    app.use(cors(corsOptions));
    app.use(bodyParser.json({
        verify: signatureValidation,
    }));
    app.use(cookieParser());
    app.get("/dynamic-image/*", getDynamicImage);
    app.use(expressJwt(expressJwtOptions));
    app.get("/audio/:contentId/:sectionId/:type/:format/:version", redirectToAudio);
    app.get("/cover-image/:contentId/:h/:w/:version", redirectToCoverImage);
    app.get("/report/users-for-organisation/:organisationId", downloadUsersReportForOrganisation);
    app.get("/report/content-for-organisation/:organisationId", downloadContentReportForOrganisation);
    app.get("/report/content-for-user/:userId", downloadContentReportForUser);
    app.get("/report/users-for-content/:contentId", downloadUsersReportForContent);
    app.get("/report/content-billing", downloadContentBillingReport);

    if (config.app.useBasicAuth) {
        app.use(basicAuthMiddleware);
    }

    app.use("/graphql", csrfValidation);

    const server = new ApolloServer(gqlConfig);
    server.applyMiddleware({ app, cors: corsOptions });

    app.use("/", express.static(path.join(__dirname, "_static")));
    app.use("/*", (req, res) => { res.sendFile(path.join(__dirname, "_static/index.html")); });

    app.use(expressJwtErrorHandler);

    const port = config.app.port;
    app.listen(port, err => {
        if (err) {
            log.e(err);
            return;
        }

        log.i(`server is listening on ${port}`);
    });

    return app;
}
