import { inject, injectable } from "inversify";
import { Brackets, getManager } from "typeorm";

import { createLogger } from "../logger";
import { FACTORY_SYMBOLS } from "../runtime/symbols";
import { OperationResult } from "../types/operation-result";
import { EMPTY_PAGINATED, Paginated } from "../types/paginated";

import { BaseStorage } from "./base-storage";
import { Content, ContentCollection, Organisation, RoleType, User } from "./db-entities";
import { DeleteLog } from "./db-entities/delete-log";
import { AccessSource, ContentStatus } from "./db-entities/enums";
import { UserContentAccess } from "./db-entities/user-content-access";
import { UserContentAccessLog } from "./db-entities/user-content-access-log";
import { filterOrganisationRoles, getManageableOrganisationIdsForUser, getOrganisationUser, hasDeletedRows, hasPermission, isSysAdmin } from "./helpers/db-helper";
import { NotificationStorage } from "./notification-storage";
import { ContentCollectionUpdateModel } from "./types/content-collection-update-model";

const log = createLogger("ContentCollectionStorage");

@injectable()
export class ContentCollectionStorage extends BaseStorage {

    constructor(@inject(FACTORY_SYMBOLS.NotificationStorage) private readonly _notificationFactory: () => NotificationStorage) {
        super();
    }

    async searchCollections(currentUser: User, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return EMPTY_PAGINATED;

        const [cc, totalCount] = await getManager().createQueryBuilder(ContentCollection, "cc")
            .where("cc.organisationId = :orgId", { orgId: organisationId })
            .andWhere("cc.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    async searchPotentialContentForCollection(currentUser: User, contentCollectionId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const cc = await getManager().findOne(ContentCollection, contentCollectionId);
        if (!cc) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return EMPTY_PAGINATED;

        const [content, totalCount] = await getManager().createQueryBuilder(Content, "c")
            .where("c.organisationId = :id", { id: cc.organisationId })
            .andWhere("c.status != :status", { status: ContentStatus.Importing })
            .andWhere("c.deletedDateUtc is null")
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    async searchCollectionContent(currentUser: User, contentCollectionId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const mgr = getManager();

        const cc = await mgr.findOne(ContentCollection, contentCollectionId);
        if (!cc) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return EMPTY_PAGINATED;

        const [content, totalCount] = await mgr.createQueryBuilder(Content, "c")
            .leftJoin("c.contentCollections", "cc")
            .where("cc.id = :id", { id: contentCollectionId })
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    async searchPotentialUsersForContentCollection(currentUser: User, contentCollectionId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const mgr = getManager();
        const cc = await mgr.findOne(ContentCollection, contentCollectionId);
        if (!cc) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return EMPTY_PAGINATED;

        const includeSysAdmins = isSysAdmin(currentUser);

        let query = mgr.createQueryBuilder(User, "user")
            .innerJoin("user.userRoles", "role")
            .leftJoin("content_collection_user", "ccu", "ccu.userID = user.id AND ccu.contentCollectionId = :contentCollectionId", { contentCollectionId });

        if (includeSysAdmins) {
            query = query.where(new Brackets(qb =>
                qb.where("role.organisationId = :orgId", { orgId: cc.organisationId })
                    .orWhere("role.type = :type", { type: RoleType.SystemAdmin }),
            ));
        } else {
            query = query.where("role.organisationId = :orgId", { orgId: cc.organisationId });
        }

        const [users, totalCount] = await query
            .andWhere("ccu.contentCollectionId is null")
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };

    }

    async searchCollectionUsers(currentUser: User, contentCollectionId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const cc = await getManager().findOne(ContentCollection, contentCollectionId);
        if (!cc) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return EMPTY_PAGINATED;

        const [users, totalCount] = await getManager().createQueryBuilder(User, "u")
            .leftJoin("u.contentCollections", "cc")
            .where("cc.id = :id", { id: contentCollectionId })
            .andWhere("(u.firstName like :textPattern or u.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async getCollections(currentUser: User, ids: number[]): Promise<Array<ContentCollection | null>> {
        return super.getOrderedEntities(ContentCollection, ids, async cc => hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId));
    }

    async createCollection(currentUser: User, name: string, description: string, organisationId: number)
        : Promise<OperationResult<ContentCollection, "invalid-permissions" | "invalid-organisation" | "name-must-be-unique">> {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return OperationResult.invalidPermissions();

        const manager = getManager();
        const organisation = await manager.findOne(Organisation, { id: organisationId });
        if (!organisation) OperationResult.error("invalid-organisation");

        const cc = manager.create(ContentCollection, {
            name,
            description,
            organisation,
        });

        try {
            await manager.save(cc);
        } catch (err) {
            log.e("Error creating a new content collection", err);

            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error("name-must-be-unique");
            }

            throw err;
        }

        return OperationResult.as(cc);
    }

    async updateCollection(currentUser: User, id: number, data: ContentCollectionUpdateModel)
        : Promise<OperationResult<ContentCollection, "invalid-permissions" | "content-collection-not-found" | "invalid-code" | "duplicate">> {

        const manager = getManager();

        // Check current users permission for the collection.
        const cc = await manager.findOne(ContentCollection, id);
        if (!cc) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return OperationResult.invalidPermissions();

        // Do nothing if nothing to update.
        if (!data.name && !data.description && !data.signUpCode && typeof data.signUpCodeEnabled === "undefined") {
            return OperationResult.as(cc);
        }

        // Require a code if it's being enabled.
        if (data.signUpCodeEnabled && !data.signUpCode && !cc.signUpCode) {
            return OperationResult.error("invalid-code");
        }

        // If the code is empty and will be disabled, set it to null.
        if (data.signUpCode === "" && (data.signUpCodeEnabled === false || (typeof data.signUpCodeEnabled === "undefined" && !cc.signUpCodeEnabled))) {
            data.signUpCode = null;
        }

        // Ensure the code meets basic requirements.
        if (data.signUpCode || data.signUpCode === "") {
            const minLength = 6;
            if (data.signUpCode.length < minLength) return OperationResult.error("invalid-code");

            const invalidCharsRegex = new RegExp("[0oil19g5s]", "i");
            if (invalidCharsRegex.test(data.signUpCode)) return OperationResult.error("invalid-code");
        }

        // A bug in typeorm means passing an object with a property set as undefined will try to update the database column to null. https://github.com/typeorm/typeorm/issues/2331
        // So this avoids defining undefined properties...sigh
        const updateValues: any = {};
        if (data.name) updateValues.name = data.name;
        if (data.description) updateValues.description = data.description;
        if (typeof data.signUpCode !== "undefined") updateValues.signUpCode = data.signUpCode;
        if (typeof data.signUpCodeEnabled !== "undefined") updateValues.signUpCodeEnabled = data.signUpCodeEnabled;

        try {
            await manager.createQueryBuilder().update(ContentCollection).set(updateValues).where("id = :id", { id: cc.id }).execute();
        } catch (err) {
            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error("duplicate");
            }

            throw err;
        }

        const updatedCc = await manager.findOne(ContentCollection, id);

        // The small chance someone else has deleted the collection during this update.
        if (!updatedCc) return OperationResult.error("content-collection-not-found");
        return OperationResult.as(updatedCc);
    }

    async removeCollection(currentUser: User, id: number): Promise<OperationResult<ContentCollection>> {
        const manager = getManager();

        // Check current users permission for the collection.
        const cc = await manager.findOne(ContentCollection, id);
        if (!cc) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, cc.organisationId)) return OperationResult.invalidPermissions();

        // Delete the collection and all its relations.
        await manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder().delete().from(UserContentAccess).where("contentCollectionId = :id", { id }).execute();

            const users: User[] = await trans.createQueryBuilder().relation(ContentCollection, "users").of(cc).loadMany();
            const content: Content[] = await trans.createQueryBuilder().relation(ContentCollection, "content").of(cc).loadMany();

            // Record revoked access to content for each user.
            if (content && content.length && users && users.length) {

                const accessLogs: Array<Partial<UserContentAccessLog>> = [];

                for (const u of users) {
                    for (const c of content) {
                        accessLogs.push({
                            contentId: c.id,
                            userId: u.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId: cc.id }),
                        });
                    }
                }

                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(accessLogs).execute();
            }

            // Log the deletion.
            await trans.createQueryBuilder().insert().into(DeleteLog).values({
                byUser: currentUser,
                entityType: "ContentCollection",
                entityId: cc.id,
                details: JSON.stringify({ organisationId: cc.organisationId, name: cc.name }),

            }).execute();

            await trans.remove(cc);
        });

        return OperationResult.as(cc);
    }

    async addCollectionItem(currentUser: User, contentCollectionId: number, contentId: number)
        : Promise<OperationResult<{ contentCollection: ContentCollection; content: Content }, "content-collection-not-found" | "content-not-found" | "invalid-permissions">> {

        const manager = getManager();

        // Check current users permission for the collection.
        const contentCollection = await manager.findOne(ContentCollection, contentCollectionId);
        if (!contentCollection) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, contentCollection.organisationId)) return OperationResult.invalidPermissions();

        // Ensure the content is associated with the same organisation
        const content = await manager.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content || content.organisationId !== contentCollection.organisationId) return OperationResult.error("content-not-found");

        return manager.transaction("READ COMMITTED", async trans => {

            // Typeorm can't yet add locks to relationship tables TODO: remove this raw query once it can.
            // Add a shared lock to avoid users being removed from the content collection while we grant users access to the collection's content.
            const results = await trans.query("SELECT userId FROM `content_collection_user` WHERE `contentCollectionId` = ? LOCK IN SHARE MODE", [contentCollection.id]);
            const userIds: number[] = results.map(r => r.userId);

            // Add the content to the collection.
            try {
                await trans.createQueryBuilder().relation(ContentCollection, "content").of(contentCollection).add(content);
            } catch (err) {
                if (err && err.code === "ER_DUP_ENTRY") {
                    // If the content is already included, return a successful result i.e no error.
                    return OperationResult.as({ contentCollection, content });
                }

                throw err;
            }

            if (userIds && userIds.length) {

                // Give all users with access to the collection access to the content.
                await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                    userIds.map(uId => ({
                        contentId: content.id,
                        userId: uId,
                        source: AccessSource.ContentCollection,
                        contentCollectionId: contentCollection.id,
                    })),
                ).execute();

                // Record access.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    userIds.map(uId => ({
                        contentId: content.id,
                        userId: uId,
                        action: "access-granted",
                        eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId }),
                    })),
                ).execute();

                // Queue a notification for each user.
                for (const userId of userIds) {
                    this._notificationFactory().queueNewContent(userId, content.id, content.organisationId);
                }
            }

            return OperationResult.as({ contentCollection, content });
        });
    }

    async removeCollectionItem(currentUser: User, contentCollectionId: number, contentId: number)
        : Promise<OperationResult<{ contentCollection: ContentCollection; content: Content }, "content-collection-not-found" | "content-not-found" | "invalid-permissions">> {

        // Check current users permission for the collection.
        const manager = getManager();
        const contentCollection = await manager.findOne(ContentCollection, contentCollectionId);
        if (!contentCollection) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, contentCollection.organisationId)) return OperationResult.invalidPermissions();

        const content = await manager.findOne(Content, contentId);
        if (!content) return OperationResult.error("content-not-found");

        return manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder().relation(ContentCollection, "content").of(contentCollection).remove(content);

            // Remove users access to the content via this content collection
            // If access if is given elsewhere e.g. via user group, then the user will still have access.
            const deleteResult = await trans.createQueryBuilder().delete().from(UserContentAccess)
                .where("contentId = :contentId", { contentId: content.id })
                .andWhere("contentCollectionId = :ccId", { ccId: contentCollection.id })
                .execute();

            if (hasDeletedRows(deleteResult)) {
                const users = await trans.createQueryBuilder().relation(ContentCollection, "users").of(contentCollection).loadMany();
                if (users && users.length) {

                    // Record access.
                    await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                        users.map(u => ({
                            contentId: content.id,
                            userId: u.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId }),
                        })),
                    ).execute();
                }
            }
            return OperationResult.as({ contentCollection, content });
        });
    }

    async addCollectionUser(currentUser: User, contentCollectionId: number, userId: number)
        : Promise<OperationResult<{ contentCollection: ContentCollection; user: User }, "content-collection-not-found" | "user-not-found" | "invalid-permissions">> {

        const manager = getManager();

        // Check current users permission for the collection.
        const contentCollection = await manager.findOne(ContentCollection, contentCollectionId);
        if (!contentCollection) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, contentCollection.organisationId)) return OperationResult.invalidPermissions();

        return manager.transaction("READ COMMITTED", async trans => {

            // Ensure the user is associated with the same organisation
            const user = await getOrganisationUser(trans, userId, contentCollection.organisationId, true);
            if (!user) return OperationResult.error("user-not-found");

            // Add a shared lock to avoid content being removed from the collection while we grant the user access to the collection's content.
            const results = await trans.query("SELECT contentId FROM `content_collection_item` WHERE `contentCollectionId` = ? LOCK IN SHARE MODE", [contentCollection.id]);
            const contentIds: number[] = results.map(r => r.contentId);

            // Add the user to the collection.
            try {
                await trans.createQueryBuilder().relation(ContentCollection, "users").of(contentCollection).add(user);
            } catch (err) {
                if (err && err.code === "ER_DUP_ENTRY") {
                    // If the user is already included, return a successful result i.e no error.
                    return OperationResult.as({ contentCollection, user });
                }

                throw err;
            }

            if (contentIds && contentIds.length) {

                // Give the user access to all content in the collection.
                await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                    contentIds.map(cId => ({
                        contentId: cId,
                        userId: user.id,
                        source: AccessSource.ContentCollection,
                        contentCollectionId: contentCollection.id,
                    })),
                ).execute();

                // Record access.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    contentIds.map(cId => ({
                        contentId: cId,
                        userId: user.id,
                        action: "access-granted",
                        eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId }),
                    })),
                ).execute();

                // Queue Notification
                this._notificationFactory().queueNewContent(user.id, contentIds, contentCollection.organisationId);
            }

            return OperationResult.as({ contentCollection, user });
        });
    }

    async removeCollectionUser(currentUser: User, contentCollectionId: number, userId: number)
        : Promise<OperationResult<{ contentCollection: ContentCollection; user: User }, "content-collection-not-found" | "user-not-found" | "invalid-permissions">> {

        const manager = getManager();

        // Check current users permission for the collection.
        const contentCollection = await manager.findOne(ContentCollection, contentCollectionId);
        if (!contentCollection) return OperationResult.error("content-collection-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, contentCollection.organisationId)) return OperationResult.invalidPermissions();

        // Ensure the user is associated with the same organisation
        const user = await getOrganisationUser(manager, userId, contentCollection.organisationId);
        if (!user) return OperationResult.error("user-not-found");

        return manager.transaction("READ COMMITTED", async trans => {
            await trans.createQueryBuilder().relation(ContentCollection, "users").of(contentCollection).remove(user);

            // Remove users access to all content via this content collection
            // If access if is given elsewhere e.g. via user group, then the user will still have access.
            const deleteResult = await trans.createQueryBuilder().delete().from(UserContentAccess)
                .where("userId = :userId", { userId: user.id })
                .andWhere("contentCollectionId = :ccId", { ccId: contentCollection.id })
                .execute();

            if (hasDeletedRows(deleteResult)) {
                const content: Content[] = await trans.createQueryBuilder().relation(ContentCollection, "content").of(contentCollection).loadMany();
                if (content && content.length) {

                    // Record access.
                    await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                        content.map(c => ({
                            contentId: c.id,
                            userId: user.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId }),
                        })),
                    ).execute();
                }
            }
            return OperationResult.as({ contentCollection, user });
        });
    }

}
