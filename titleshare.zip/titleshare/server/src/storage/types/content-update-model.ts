
export interface ContentUpdateModel {
    title: string | undefined;
    subtitle: string | undefined;
    description: string | undefined;
    author: string | undefined;
    narrator: string | undefined;
    publisher: string | undefined;
    releaseDate: Date | null | undefined;
    genreCode: string | undefined;
    secondGenreCode: string | null | undefined;
    languageCode: string | undefined;
    nonBillable: boolean | undefined;
    nonBillableReason: string | undefined;
}
