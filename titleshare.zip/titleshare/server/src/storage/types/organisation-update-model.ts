
export interface OrganisationUpdateModel {
    name: string | undefined;
    importStorageBucket: string | undefined;
    importNarrationFilenameRegex: string | undefined;
    importSoundtrackFilenameRegex: string | undefined;
    importCoverImageFilenameRegex: string | undefined;
    importSftpUsername: string | undefined;
    importSftpPassword: string | undefined;
}
