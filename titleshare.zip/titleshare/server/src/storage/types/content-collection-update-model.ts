
export interface ContentCollectionUpdateModel {
    name: string | undefined;
    description: string | undefined;
    signUpCodeEnabled: boolean | undefined;
    signUpCode: string | null | undefined;
}
