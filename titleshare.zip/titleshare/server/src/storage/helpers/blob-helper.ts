import AWS, { AWSError } from "aws-sdk";
import concat from "concat-stream";
import fs from "fs";

import config from "../../config";

export function getS3() {
    return new AWS.S3({ region: config.s3.region });
}

export async function bucketExists(bucket: string): Promise<boolean> {

    const s3 = getS3();

    // Any better way to do this? headBucket doesn't seem to work (always returns true)
    const response = await s3.listBuckets().promise();
    if (response.Buckets) {

        for (const b of response.Buckets) {
            if (b.Name === bucket) {
                return true;
            }
        }
    }

    return false;
}

export async function downloadToFile(bucket: string, key: string, filename: string): Promise<{ mimeType: string }> {

    return new Promise<{ mimeType: string }>((res, rej) => {

        const s3 = getS3();

        let mimeType: string = "";
        const fileStream = fs.createWriteStream(filename);

        const request = s3.getObject({ Bucket: bucket, Key: key });
        request.on("httpHeaders", (statusCode, headers) => {
            mimeType = headers["content-type"];
        });

        const objStream = request.createReadStream();
        objStream.pipe(fileStream);

        objStream.on("end", () => {
            res({ mimeType });
        }).on("error", err => {
            rej(err);
        });
    });
}

export async function downloadToBuffer(bucket: string, key: string): Promise<{ mimeType: string; buffer: Buffer }> {

    return new Promise<{ mimeType: string; buffer: Buffer }>((res, rej) => {

        const s3 = getS3();

        let mimeType: string = "";

        const request = s3.getObject({ Bucket: bucket, Key: key });
        request.on("httpHeaders", (statusCode, headers) => {
            mimeType = headers["content-type"];
        });

        const concatStream = concat(buffer => {
            if (Buffer.isBuffer(buffer)) {
                res({ mimeType, buffer });
            } else {
                rej(new Error("Unexpected data type"));
            }
        });

        const objStream = request.createReadStream();
        objStream.pipe(concatStream);

        objStream.on("error", err => {
            rej(err);
        });
    });
}

export async function signImageUri(storagePath: string, height: number, width: number): Promise<string> {

    const path = `${storagePath}?h=${height}&w=${width}`;

    if (config.cloudFront.enabled && !config.isDevelopment) {
        return signCloudFrontUri(config.cloudFront.dynamicImageEndpoint, path);
    }

    // Return the app uri directly with no authentication (used for development)
    return `${config.app.endpoint}/dynamic-image/${path}`;
}

export async function signUri(bucket: string, storagePath: string): Promise<string> {

    if (config.cloudFront.enabled) {
        return signCloudFrontUri(config.cloudFront.endpoint, storagePath);
    }
    const s3 = getS3();

    const params: AWS.S3.GetObjectRequest & { Expires: number } = {
        Bucket: bucket,
        Key: storagePath,
        Expires: config.cloudFront.urlExpirySeconds,
    };

    return new Promise<string>((resolve, reject) => {
        s3.getSignedUrl("getObject", params, (err, url) => {
            if (err) {
                reject(err);
                return;
            }

            resolve(url);
        });
    });
}

async function signCloudFrontUri(cloudFontEndpoint: string, storagePath: string): Promise<string> {

    let privateKey: string | undefined;

    if (config.cloudFront.privateKeyBase64String) {
        privateKey = Buffer.from(config.cloudFront.privateKeyBase64String, "base64").toString("utf8");
    } else {
        if (!config.cloudFront.privateKeyPath) {
            throw new Error("No private key for cloud front could be found in the environments configuration");
        }

        privateKey = await new Promise<string>((res, rej) => {
            fs.readFile(config.cloudFront.privateKeyPath, (err, buf) => {
                if (err) {
                    rej(err);
                    return;
                }
                res(buf.toString("utf8"));
            });
        });
    }

    const cfSign = new AWS.CloudFront.Signer(config.cloudFront.keypairId, privateKey);

    return new Promise<string>((resolve, reject) => {
        const options = {
            expires: Math.floor(Date.now() / 1000) + config.cloudFront.urlExpirySeconds,
            url: `${cloudFontEndpoint}/${storagePath}`,
        };

        cfSign.getSignedUrl(options, (err, url) => {
            if (err) {
                reject(err);
                return;
            }

            resolve(url);
        });
    });
}
