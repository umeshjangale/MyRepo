import { Connection, createConnection, DeleteResult, EntityManager, getManager, UpdateResult } from "typeorm";

import { createLogger } from "../../logger";
import { Organisation, RoleType, User, UserRole } from "../db-entities";
import dbConfig from "../typeorm-config";

export async function configureDatabase(): Promise<Connection> {

    // Our AWS test environments use serverless databases which 'pause', so failing to connect while they 'warm up' is common.
    const retries = 10;
    for (let attemptNum = 1; attemptNum <= retries; attemptNum++) {

        try {
            // "TypeORM's Connection does not setup a database connection as it might seem, instead it setups a connection pool"
            const connection = await createConnection(dbConfig);
            return connection;
        } catch (err) {
            createLogger("configureDatabase").e(`Error while configuring database. (Attempt ${attemptNum})`, err);
        }
    }

    throw new Error(`Failed to configure the database connection after ${retries} retries.`);
}

export function isSysAdmin(user: User) {
    if (!user || !user.userRoles) return false;

    if (user.userRoles.some(r => r.type === RoleType.SystemAdmin)) return true;

    return false;
}

export function hasPermission(user: User, roleType: RoleType, org?: Organisation | number): boolean {

    if (!user || !user.userRoles) return false;

    // sys-admin always has permission for all organisations.
    if (isSysAdmin(user)) return true;

    if (!org) return false;
    const orgId = org instanceof Organisation ? org.id : org;

    const roles = user.userRoles.filter(ur => ur.organisationId === orgId);

    switch (roleType) {
        case RoleType.Consumer:
            // org-admins have all the permissions consumers have
            if (roles.some((r => r.type === roleType || r.type === RoleType.OrganisationAdmin))) return true;
            break;
        default:
            if (roles.some((r => r.type === roleType))) return true;

    }

    return false;
}

type OrganisationRoleType = RoleType.Consumer | RoleType.OrganisationAdmin | RoleType.OrganisationContentUploader;
export function filterOrganisationRoles(roles: UserRole[] | null, type?: OrganisationRoleType): Array<{ organisationId: number; type: OrganisationRoleType }> {

    if (!roles) return [];

    const filteredRoles = type ? roles.filter(r => r.type === type) : roles;

    const result: Array<{ organisationId: number; type: OrganisationRoleType }> = [];
    for (const r of filteredRoles) {
        if (r.organisationId && r.type !== RoleType.SystemAdmin) {
            result.push({ organisationId: r.organisationId, type: r.type });
        }
    }

    return result;
}

export function canManageUser(currentUser: User, user: User): boolean {
    if (hasPermission(currentUser, RoleType.SystemAdmin)) return true;
    if (!user.userRoles) return false;
    for (const role of user.userRoles) {
        if (hasPermission(currentUser, RoleType.OrganisationAdmin, role.organisationId || undefined)) return true;
    }

    return false;
}

export function getManageableOrganisationIdsForUser(currentUser: User, user: User): number[] {

    // Intersect the organisations of the current user and the user in context.
    let orgIds: number[] = [];
    if (hasPermission(user, RoleType.SystemAdmin)) {
        orgIds = filterOrganisationRoles(currentUser.userRoles, RoleType.OrganisationAdmin).map(r => r.organisationId);
    } else {
        const orgRoles = filterOrganisationRoles(user.userRoles);
        orgIds = orgRoles.filter(r => hasPermission(currentUser, RoleType.OrganisationAdmin, r.organisationId)).map(r => r.organisationId);
    }

    return orgIds;
}

/**
 * Gets a user while ensuring the user is associated with an organisation (or is a sys-admin).
 * @param mgr The current entity manager/transaction.
 * @param userId The id of the user.
 * @param organisationId The id of the organisation.
 * @param lockUserRole Set to true to add a shared lock on the users role. This must be true for all operations that grant access to content.
 */
export async function getOrganisationUser(mgr: EntityManager, userId: number, organisationId: number, lockUserRole: boolean = false): Promise<User | null> {

    const u = await mgr.findOne(User, userId, { relations: ["userRoles"] });
    if (!u || !u.userRoles) return null;

    const role = u.userRoles.find(r => r.organisationId === organisationId || r.type === RoleType.SystemAdmin);
    if (!role) return null;

    if (lockUserRole) {
        // Add a shared lock to the user's role relation.
        const member: any[] = await mgr.query("SELECT userId, userRoleId FROM user_role_member WHERE userId = ? AND userRoleId = ? LOCK IN SHARE MODE", [u.id, role.id]);
        if (!member || !member.length) return null;
    }

    return u;
}

export function hasDeletedRows(deleteResult: DeleteResult): boolean {

    // Returning the number of deleted rows isn't implemented by typeorm, but raw results are returned by mysql so we can pull the info from there.
    if (deleteResult && deleteResult.raw && deleteResult.raw.affectedRows > 0) {
        return true;
    }

    return false;
}

export function hasUpdatedRows(updateResult: UpdateResult): boolean {

    // Returning the number of updated rows isn't implemented by typeorm, but raw results are returned by mysql so we can pull the info from there.
    if (updateResult && updateResult.raw && updateResult.raw.affectedRows > 0) {
        return true;
    }

    return false;
}
