import AWS from "aws-sdk";
import { injectable } from "inversify";
import { getManager } from "typeorm";

import config from "../config";

import { Node } from "./db-entities";

@injectable()
export abstract class BaseStorage {

    async getOrderedEntities<T extends Node>(entityType: new() => T, ids: number[], condition: (e: T) => Promise<boolean>): Promise<Array<T | null>> {
        const rows = await getManager().findByIds(entityType, ids);

        return this.orderRowsByIds<T>(ids, rows, condition);
    }

    async orderRowsByIds<T extends Node>(ids: number[], rows: T[], condition: (e: T) => Promise<boolean>) {
        const result: Array<T | null> = [];
        for (const id of ids) {
            const row = rows.find(r => r.id === id);
            if (row && await condition(row)) {
                result.push(row);
            } else {
                result.push(null);
            }
        }
        return result;
    }
}
