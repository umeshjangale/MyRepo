import { MigrationInterface, QueryRunner } from "typeorm";

export class seedData1555020738387 implements MigrationInterface {

    languages = [
        { code: "english", name: "English ", sortOrder: "10" },
        { code: "german", name: "German", sortOrder: "20" },
        { code: "french", name: "French", sortOrder: "30" },
        { code: "italian", name: "Italian", sortOrder: "40" },
        { code: "spanish", name: "Spanish", sortOrder: "50" },
        { code: "danish", name: "Danish", sortOrder: "60" },
        { code: "russian", name: "Russian", sortOrder: "70" },
        { code: "chinese", name: "Chinese", sortOrder: "80" },
        { code: "swedish", name: "Swedish", sortOrder: "90" },
        { code: "portuguese", name: "Portuguese", sortOrder: "100" },
        { code: "dutch", name: "Dutch", sortOrder: "110" },
        { code: "japanese", name: "Japanese", sortOrder: "120" },
        { code: "greek", name: "Greek", sortOrder: "130" },
    ];

    genres = [
        { code: "action-adventure", name: "Action & Adventure", sortOrder: "10" },
        { code: "arts-entertainment", name: "Arts & Entertainment", sortOrder: "20" },
        { code: "biographies-memoirs", name: "Biographies & Memoirs", sortOrder: "30" },
        { code: "business", name: "Business", sortOrder: "40" },
        { code: "children", name: "Children", sortOrder: "50" },
        { code: "classics", name: "Classics", sortOrder: "60" },
        { code: "comedy", name: "Comedy", sortOrder: "70" },
        { code: "crime-thrillers", name: "Crime & Thrillers", sortOrder: "80" },
        { code: "education", name: "Education", sortOrder: "90" },
        { code: "erotica", name: "Erotica", sortOrder: "100" },
        { code: "fiction", name: "Fiction", sortOrder: "110" },
        { code: "film-radio-tv", name: "Film, Radio & TV", sortOrder: "120" },
        { code: "health-personal-dev", name: "Health & Personal Development", sortOrder: "130" },
        { code: "history", name: "History", sortOrder: "140" },
        { code: "languages", name: "Languages", sortOrder: "150" },
        { code: "newspapers-magazines", name: "Newspapers & Magazines", sortOrder: "160" },
        { code: "non-fiction", name: "Non-fiction", sortOrder: "170" },
        { code: "religion-spirituality", name: "Religion & Spirituality", sortOrder: "180" },
        { code: "sci-fi-fantasy", name: "Sci-Fi & Fantasy", sortOrder: "190" },
        { code: "sport", name: "Sport", sortOrder: "200" },
        { code: "travel-adventure", name: "Travel & Adventure", sortOrder: "210" },
        { code: "young-adults", name: "Young Adults", sortOrder: "220" },
    ];

    async up(queryRunner: QueryRunner): Promise<any> {

        for (const l of this.languages) {
            await queryRunner.query(`INSERT INTO language (code, name, sortOrder) VALUES ('${l.code}', '${l.name}', ${l.sortOrder})`);
        }

        for (const g of this.genres) {
            await queryRunner.query(`INSERT INTO genre (code, name, sortOrder) VALUES ('${g.code}', '${g.name}', ${g.sortOrder})`);
        }
    }

    async down(queryRunner: QueryRunner): Promise<any> {
        for (const l of this.languages) {
            await queryRunner.query(`DELETE FROM language WHERE code = '${l.code}'`);
        }

        for (const g of this.genres) {
            await queryRunner.query(`DELETE FROM genre WHERE code = '${g.code}'`);
        }
    }

}
