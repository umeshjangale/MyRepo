import { MigrationInterface, QueryRunner } from "typeorm";
import { User } from "../db-entities";
import * as DataProtection from "../../security/data-protection";

export class lowerEmails1559698649035 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {

        const users = await queryRunner.manager.createQueryBuilder(User, "u").getMany();

        // Lower case all emails 
        for (const user of users) {
            const email = DataProtection.decryptEmail(user.email);
            const newEmail = DataProtection.encryptEmail(email.toLowerCase());
            await queryRunner.query("UPDATE `user` SET `email` = ? WHERE `email` = ?", [newEmail, user.email]);
        }
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
    }

}
