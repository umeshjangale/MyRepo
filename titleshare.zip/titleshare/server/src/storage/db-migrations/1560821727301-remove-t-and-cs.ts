import { MigrationInterface, QueryRunner } from "typeorm";

export class removeTAndCs1560821727301 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `termsAcceptedDateUtc`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `termsVersion`");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` ADD `termsVersion` float NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `termsAcceptedDateUtc` datetime(3) NULL");
    }

}
