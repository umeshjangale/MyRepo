import { MigrationInterface, QueryRunner } from "typeorm";

export class userSchema1560826267295 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` ADD `createdReason` varchar(255) NOT NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `loginAllowed` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `inviteAcceptedDateUtc` datetime(3) NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `emailVerified` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `setPasswordEmailSentDateUtc` datetime(3) NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `firstPasswordSetDateUtc` datetime(3) NULL");
        await queryRunner.query("ALTER TABLE `user` ADD `lastPasswordSetDateUtc` datetime(3) NULL");

        await queryRunner.query("UPDATE `user` SET loginAllowed = TRUE, emailVerified = TRUE WHERE `inviteStatus` = 'accepted'");
        await queryRunner.query("UPDATE `user` u \
                    LEFT JOIN (\
                            SELECT ua.userId, MIN(ua.createdDateUtc) minDate \
                            FROM user_agent ua \
                            GROUP BY ua.userId\
                    ) AS ua \
                    ON u.id = ua.userId \
                    SET inviteAcceptedDateUtc = IFNULL(IFNULL(ua.minDate, u.lastLoginDateUtc), u.lastUpdatedDateUtc)\
                    , lastPasswordSetDateUtc = IFNULL(IFNULL(ua.minDate, u.lastLoginDateUtc), u.lastUpdatedDateUtc)\
                    , firstPasswordSetDateUtc = IFNULL(IFNULL(ua.minDate, u.lastLoginDateUtc), u.lastUpdatedDateUtc)\
                     WHERE inviteStatus = 'accepted'\
        ");
        await queryRunner.query("UPDATE `user` SET `createdReason` = 'invite'");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `lastPasswordSetDateUtc`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `firstPasswordSetDateUtc`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `setPasswordEmailSentDateUtc`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `emailVerified`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `inviteAcceptedDateUtc`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `loginAllowed`");
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `createdReason`");
    }

}
