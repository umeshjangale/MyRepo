import { MigrationInterface, QueryRunner } from "typeorm";

export class totalBytesDataType1556583529583 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `audio_summary` MODIFY `totalBytes` BIGINT NOT NULL");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `audio_summary` MODIFY `totalBytes` int NOT NULL");
    }
}
