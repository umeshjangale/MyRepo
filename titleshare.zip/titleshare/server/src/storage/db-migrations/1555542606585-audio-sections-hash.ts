import { MigrationInterface, QueryRunner } from "typeorm";

export class audioSectionsHash1555542606585 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `content` ADD `audioSectionsHash` varchar(255) NOT NULL");
        await queryRunner.query("UPDATE `content` SET `audioSectionsHash` = '0'")
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `content` DROP COLUMN `audioSectionsHash`");
    }

}
