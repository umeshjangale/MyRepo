import { MigrationInterface, QueryRunner } from "typeorm";

export class defaultValues1561510128890 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user_content_access` CHANGE `omitNotification` `omitNotification` tinyint NOT NULL DEFAULT 0");
        await queryRunner.query("ALTER TABLE `user` CHANGE `loginAllowed` `loginAllowed` tinyint NOT NULL DEFAULT 0");
        await queryRunner.query("ALTER TABLE `user` CHANGE `emailVerified` `emailVerified` tinyint NOT NULL DEFAULT 0");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` CHANGE `emailVerified` `emailVerified` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `user` CHANGE `loginAllowed` `loginAllowed` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `user_content_access` CHANGE `omitNotification` `omitNotification` tinyint NOT NULL");
    }

}
