import { MigrationInterface, QueryRunner } from "typeorm";
import config from "../../config";

export class audioFileBucket1555290701714 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `audio_file` ADD `bucket` varchar(255) NOT NULL");
        await queryRunner.query("ALTER TABLE `import` MODIFY `message` varchar(2047) NOT NULL");

        const bucket = config.s3.bucket;
        const stagingBucket = config.s3.stagingBucket;
        await queryRunner.query(`UPDATE audio_file SET bucket = '${bucket}' WHERE bucket = '' AND format <> 'original'`);
        await queryRunner.query(`UPDATE audio_file SET bucket = '${stagingBucket}' WHERE bucket = '' AND format = 'original'`);
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `import` MODIFY `message` varchar(255) NOT NULL");
        await queryRunner.query("ALTER TABLE `audio_file` DROP COLUMN `bucket`");
    }

}
