import { MigrationInterface, QueryRunner } from "typeorm";

export class removeInviteStatus1560830728849 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` DROP COLUMN `inviteStatus`");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user` ADD `inviteStatus` enum ('not-invited', 'pending', 'sent', 'accepted') NOT NULL");
        await queryRunner.query("UPDATE `user` SET `inviteStatus` = 'sent' where `inviteSentDateUtc` IS NOT NULL");
        await queryRunner.query("UPDATE `user` SET `inviteStatus` = 'accepted' where `inviteAcceptedDateUtc` IS NOT NULL");
    }

}
