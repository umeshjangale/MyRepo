import { MigrationInterface, QueryRunner } from "typeorm";

export class contentBillable1560738000382 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `content` ADD `nonBillable` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `content` ADD `nonBillableReason` varchar(255) NOT NULL");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `content` DROP COLUMN `nonBillableReason`");
        await queryRunner.query("ALTER TABLE `content` DROP COLUMN `nonBillable`");
    }

}
