import { MigrationInterface, QueryRunner } from "typeorm";

export class moreGenresA1577069160754 implements MigrationInterface {

    genres = [
        { code: "domestic-psychological-thriller", name: "Domestic & Psychological Thriller", sortOrder: "85" },
        { code: "historical-fiction", name: "Historical Fiction", sortOrder: "135" },
        { code: "popular-science", name: "Popular Science", sortOrder: "173" },
        { code: "real-life-stories-tragedy-survival", name: "Real Life Stories Of Tragedy & Survival", sortOrder: "177" },
        { code: "saga", name: "Saga", sortOrder: "185" },
        { code: "true-crime", name: "True Crime", sortOrder: "213" },
        { code: "womens-fiction-uplit", name: "Women’s Fiction & UpLit", sortOrder: "217" },
    ];

    public async up(queryRunner: QueryRunner): Promise<any> {
        for (const g of this.genres) {
            await queryRunner.query(`INSERT INTO genre (code, name, sortOrder) VALUES ('${g.code}', '${g.name}', ${g.sortOrder})`);
        }
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        for (const g of this.genres) {
            await queryRunner.query(`DELETE FROM genre WHERE code = '${g.code}'`);
        }
    }

}
