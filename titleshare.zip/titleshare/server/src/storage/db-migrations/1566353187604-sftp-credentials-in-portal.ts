import { MigrationInterface, QueryRunner } from "typeorm";

export class sftpCredentialsInPortal1566353187604 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `organisation` ADD `importSftpUsername` varchar(255) NULL");
        await queryRunner.query("ALTER TABLE `organisation` ADD `importSftpPassword` varchar(255) NULL");
        await queryRunner.query("ALTER TABLE `user_role` CHANGE `type` `type` enum ('sys-admin', 'org-admin', 'org-content-uploader', 'consumer') NOT NULL");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user_role` CHANGE `type` `type` enum ('sys-admin', 'org-admin', 'consumer') NOT NULL");
        await queryRunner.query("ALTER TABLE `organisation` DROP COLUMN `importSftpPassword`");
        await queryRunner.query("ALTER TABLE `organisation` DROP COLUMN `importSftpUsername`");
    }

}
