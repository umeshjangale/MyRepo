import { MigrationInterface, QueryRunner } from "typeorm";

export class clientTechnicalIssues1561414757323 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("CREATE TABLE `client_technical_issue` (`id` int NOT NULL AUTO_INCREMENT, `userId` int NOT NULL, `userAgent` varchar(255) NOT NULL, `data` varchar(8000) NOT NULL, `createdDateUtc` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), PRIMARY KEY (`id`)) ENGINE=InnoDB");
        await queryRunner.query("ALTER TABLE `client_technical_issue` ADD CONSTRAINT `FK_fa0e8e674f7eba287817e4e8522` FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE NO ACTION ON UPDATE NO ACTION");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `client_technical_issue` DROP FOREIGN KEY `FK_fa0e8e674f7eba287817e4e8522`");
        await queryRunner.query("DROP TABLE `client_technical_issue`");
    }

}
