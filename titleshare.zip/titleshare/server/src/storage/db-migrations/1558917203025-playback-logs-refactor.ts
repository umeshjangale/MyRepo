import { MigrationInterface, QueryRunner } from "typeorm";
import { UserContentPlayback } from "../db-entities/user-content-playback";

export class playbackLogsRefactor1558917203025 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {

        await queryRunner.query(`UPDATE user_content_playback p
            JOIN content c ON p.contentId = c.id
            JOIN audio_section s ON c.id = s.contentId AND p.startAudioSectionIndex = s.sequence
            SET endAudioSectionIndex = startAudioSectionIndex, endTime = s.approximateDuration
            WHERE endAudioSectionIndex = startAudioSectionIndex + 1 AND endTime = 0`);

        const sectionSpanningPlaybackRegions = await queryRunner.manager.createQueryBuilder(UserContentPlayback, "p").where("p.startAudioSectionIndex != p.endAudioSectionIndex").getCount();
        if (sectionSpanningPlaybackRegions > 0) {
            throw new Error(`Found ${sectionSpanningPlaybackRegions} playback regions still spanning audio sections. Fix these before running this migration again.`)
        }

        await queryRunner.query("ALTER TABLE `user_content_playback` CHANGE COLUMN `startAudioSectionIndex` `audioSectionIndex` int NOT NULL");
        await queryRunner.query("ALTER TABLE `user_content_playback` DROP COLUMN `endAudioSectionIndex`");
        await queryRunner.query("ALTER TABLE `user_content_playback` ADD `audioSectionsHash` varchar(255) NOT NULL");

    }

    public async down(queryRunner: QueryRunner): Promise<any> {

    }

}
