import { MigrationInterface, QueryRunner } from "typeorm";

export class signUpCode1560989078712 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `content_collection` ADD `signUpCode` varchar(255) NULL");
        await queryRunner.query("ALTER TABLE `content_collection` ADD UNIQUE INDEX `IDX_657de766695ae15f148ac4f55b` (`signUpCode`)");
        await queryRunner.query("ALTER TABLE `content_collection` ADD `signUpCodeEnabled` tinyint NOT NULL");
        await queryRunner.query("ALTER TABLE `user_content_access` ADD `omitNotification` tinyint NOT NULL");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `user_content_access` DROP COLUMN `omitNotification`");
        await queryRunner.query("ALTER TABLE `content_collection` DROP COLUMN `signUpCodeEnabled`");
        await queryRunner.query("ALTER TABLE `content_collection` DROP INDEX `IDX_657de766695ae15f148ac4f55b`");
        await queryRunner.query("ALTER TABLE `content_collection` DROP COLUMN `signUpCode`");
    }

}
