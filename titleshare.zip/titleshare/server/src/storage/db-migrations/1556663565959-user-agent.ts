import { MigrationInterface, QueryRunner } from "typeorm";

export class userAgent1556663565959 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("CREATE TABLE `user_agent` (`id` int NOT NULL AUTO_INCREMENT, `userId` int NOT NULL, `value` varchar(255) NOT NULL, `ipAddress` varchar(255) NOT NULL, `loginCount` int NOT NULL, `lastLoginDateUtc` datetime(3) NULL, `createdDateUtc` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), `lastUpdatedDateUtc` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), UNIQUE INDEX `IDX_91c92c9051b727eb5e43273250` (`userId`, `value`), PRIMARY KEY (`id`)) ENGINE=InnoDB");
        await queryRunner.query("ALTER TABLE `user_agent` ADD CONSTRAINT `FK_e9bcd2e186179bdd5dbd5be33d3` FOREIGN KEY (`userId`) REFERENCES `user`(`id`)");

        await queryRunner.query("ALTER TABLE `content` DROP FOREIGN KEY `FK_415bcfa7dc4848764f52c54f1a3`");
        await queryRunner.query("ALTER TABLE `content` DROP COLUMN `importId`");
        await queryRunner.query("ALTER TABLE `import` MODIFY `contentId` INT NULL");
        await queryRunner.query("UPDATE `import` SET contentId = NULL WHERE contentId = 0");

        await queryRunner.query("ALTER TABLE `import` ADD UNIQUE INDEX `IDX_43d213c95de6ba3c09c022d9ba` (`contentId`)");
        await queryRunner.query("ALTER TABLE `import` ADD CONSTRAINT `FK_43d213c95de6ba3c09c022d9ba1` FOREIGN KEY (`contentId`) REFERENCES `content`(`id`) ON DELETE NO ACTION ON UPDATE NO ACTION");

        await queryRunner.query("CREATE INDEX `IDX_9e8ae5e93f9069b1297a10eb31` ON `user_role_member` (`userId`)");
        await queryRunner.query("CREATE INDEX `IDX_9107a35da9d95deefe184a74da` ON `user_role_member` (`userRoleId`)");
        await queryRunner.query("CREATE INDEX `IDX_d573dcdef93033accde5ab32be` ON `user_group_member` (`userId`)");
        await queryRunner.query("CREATE INDEX `IDX_07ac24eb06b7a4895dba50c46d` ON `user_group_member` (`userGroupId`)");
        await queryRunner.query("CREATE INDEX `IDX_e3df43dd2c72db1337e88299d6` ON `user_group_content` (`userGroupId`)");
        await queryRunner.query("CREATE INDEX `IDX_d0c280253c77ff31ddc8a9836b` ON `user_group_content` (`contentId`)");
        await queryRunner.query("CREATE INDEX `IDX_6d2b2b6d85a77516847b632873` ON `content_collection_item` (`contentCollectionId`)");
        await queryRunner.query("CREATE INDEX `IDX_41f6b409f8e2d8d2f6bdee7643` ON `content_collection_item` (`contentId`)");
        await queryRunner.query("CREATE INDEX `IDX_7e1993ee965158a23933af93bc` ON `content_collection_user` (`contentCollectionId`)");
        await queryRunner.query("CREATE INDEX `IDX_7ed18974c5110904ea0410e2ef` ON `content_collection_user` (`userId`)");

    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("DROP INDEX `IDX_7ed18974c5110904ea0410e2ef` ON `content_collection_user`");
        await queryRunner.query("DROP INDEX `IDX_7e1993ee965158a23933af93bc` ON `content_collection_user`");
        await queryRunner.query("DROP INDEX `IDX_41f6b409f8e2d8d2f6bdee7643` ON `content_collection_item`");
        await queryRunner.query("DROP INDEX `IDX_6d2b2b6d85a77516847b632873` ON `content_collection_item`");
        await queryRunner.query("DROP INDEX `IDX_d0c280253c77ff31ddc8a9836b` ON `user_group_content`");
        await queryRunner.query("DROP INDEX `IDX_e3df43dd2c72db1337e88299d6` ON `user_group_content`");
        await queryRunner.query("DROP INDEX `IDX_07ac24eb06b7a4895dba50c46d` ON `user_group_member`");
        await queryRunner.query("DROP INDEX `IDX_d573dcdef93033accde5ab32be` ON `user_group_member`");
        await queryRunner.query("DROP INDEX `IDX_9107a35da9d95deefe184a74da` ON `user_role_member`");
        await queryRunner.query("DROP INDEX `IDX_9e8ae5e93f9069b1297a10eb31` ON `user_role_member`");

        await queryRunner.query("ALTER TABLE `import` DROP FOREIGN KEY `FK_43d213c95de6ba3c09c022d9ba1`");
        await queryRunner.query("DROP INDEX `REL_43d213c95de6ba3c09c022d9ba` ON `import`");
        await queryRunner.query("ALTER TABLE `import` DROP INDEX `IDX_43d213c95de6ba3c09c022d9ba`");
        await queryRunner.query("ALTER TABLE `import` MODIFY `contentId` INT NOT NULL");
        await queryRunner.query("ALTER TABLE `content` ADD `importId` int NULL");
        await queryRunner.query("ALTER TABLE `content` ADD CONSTRAINT `FK_415bcfa7dc4848764f52c54f1a3` FOREIGN KEY (`importId`) REFERENCES `import`(`id`) ON DELETE NO ACTION ON UPDATE NO ACTION");

        await queryRunner.query("ALTER TABLE `user_agent` DROP FOREIGN KEY `FK_e9bcd2e186179bdd5dbd5be33d3`");
        await queryRunner.query("DROP INDEX `IDX_91c92c9051b727eb5e43273250` ON `user_agent`");
        await queryRunner.query("DROP TABLE `user_agent`");

    }
}
