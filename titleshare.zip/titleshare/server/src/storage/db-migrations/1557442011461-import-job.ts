import { MigrationInterface, QueryRunner } from "typeorm";

export class importJob1557442011461 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("CREATE TABLE `import_job` (`id` int NOT NULL AUTO_INCREMENT, `pipelineId` varchar(255) NOT NULL, `stage` varchar(255) NOT NULL, `jobId` varchar(255) NOT NULL, `status` varchar(255) NOT NULL, `message` varchar(2047) NOT NULL, `importId` int NOT NULL, `createdDateUtc` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), `lastUpdatedDateUtc` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), PRIMARY KEY (`id`)) ENGINE=InnoDB");
        await queryRunner.query("ALTER TABLE `import_job` ADD CONSTRAINT `FK_b0fb2e05c855e41ec9ad2566453` FOREIGN KEY (`importId`) REFERENCES `import`(`id`) ON DELETE NO ACTION ON UPDATE NO ACTION");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `import_job` DROP FOREIGN KEY `FK_b0fb2e05c855e41ec9ad2566453`");
        await queryRunner.query("DROP TABLE `import_job`");
    }

}
