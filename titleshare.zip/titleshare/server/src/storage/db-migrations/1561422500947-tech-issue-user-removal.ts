import { MigrationInterface, QueryRunner } from "typeorm";

export class techIssueUserRemoval1561422500947 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `client_technical_issue` DROP FOREIGN KEY `FK_fa0e8e674f7eba287817e4e8522`");
        await queryRunner.query("ALTER TABLE `client_technical_issue` DROP COLUMN `userId`");
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query("ALTER TABLE `client_technical_issue` ADD `userId` int NOT NULL");
        await queryRunner.query("ALTER TABLE `client_technical_issue` ADD CONSTRAINT `FK_fa0e8e674f7eba287817e4e8522` FOREIGN KEY (`userId`, `userId`, `userId`) REFERENCES `user`(`id`,`id`,`id`) ON DELETE NO ACTION ON UPDATE NO ACTION");
    }

}
