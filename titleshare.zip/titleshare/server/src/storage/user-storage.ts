import crypto from "crypto";
import { inject, injectable } from "inversify";
import { DeepPartial, EntityManager, FindOneOptions, getManager } from "typeorm";

import config from "../config";
import { EmailService } from "../email/email-service";
import { createLogger } from "../logger";
import { FACTORY_SYMBOLS, SYMBOLS } from "../runtime/symbols";
import * as DataProtection from "../security/data-protection";
import { OperationResult } from "../types/operation-result";
import { EMPTY_PAGINATED, Paginated } from "../types/paginated";
import { assertNever } from "../utils";

import { BaseStorage } from "./base-storage";
import { Content, ContentCollection, Organisation, RoleType, User, UserContent, UserGroup, UserRole } from "./db-entities";
import { ClientTechnicalIssue } from "./db-entities/client-technical-issue";
import { AccessSource, ContentStatus } from "./db-entities/enums";
import { UserAgent } from "./db-entities/user-agent";
import { UserContentAccess } from "./db-entities/user-content-access";
import { UserContentAccessLog } from "./db-entities/user-content-access-log";
import { UserContentPlayback } from "./db-entities/user-content-playback";
import { canManageUser, filterOrganisationRoles, getManageableOrganisationIdsForUser, getOrganisationUser, hasPermission, hasUpdatedRows, isSysAdmin } from "./helpers/db-helper";
import { NotificationStorage } from "./notification-storage";

const log = createLogger("UserStorage");

@injectable()
export class UserStorage extends BaseStorage {

    constructor(
        @inject(FACTORY_SYMBOLS.NotificationStorage) private readonly _notificationFactory: () => NotificationStorage,
        @inject(SYMBOLS.EmailService) private readonly _email: EmailService,
    ) {
        super();
    }

    async getUser(id: number, includeRoles: boolean = false): Promise<User | undefined> {

        const options: FindOneOptions = {};
        if (includeRoles) {
            options.relations = ["userRoles"];
        }

        const user = await getManager().findOne(User, id, options);
        return user;
    }

    async getUsers(currentUser: User, ids: number[]): Promise<Array<User | null>> {

        const users = await getManager().findByIds(User, ids, { relations: ["userRoles"] });

        return super.orderRowsByIds(ids, users, async user => canManageUser(currentUser, user));
    }

    async getUserForAdmin(currentUser: User, userId: number): Promise<User | undefined> {

        const user = await getManager().findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return undefined;

        if (!canManageUser(currentUser, user)) return undefined;

        return user;
    }

    async getUserContent(currentUser: User, contentId: number): Promise<UserContent | undefined> {
        return getManager().createQueryBuilder(UserContent, "uc")
            .where("uc.userId = :userId", { userId: currentUser.id })
            .andWhere("uc.contentId = :contentId", { contentId })
            .getOne();
    }

    async logPlayback(currentUser: User, contentId: number, playbackRegions: Array<{ audioSectionsHash: string; audioSectionIndex: number; startTime: number; endTime: number; endTimestamp: Date }>)
        : Promise<OperationResult<Content, "content-not-found">> {

        const mgr = getManager();
        const content = await mgr.createQueryBuilder(Content, "c")
            .innerJoin("c.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id })
            .where("c.id = :contentId", { contentId })
            .getOne();

        if (!content) return OperationResult.error("content-not-found");

        if (!playbackRegions.length) return OperationResult.as(content);

        playbackRegions.sort((a, b) => +b.endTimestamp - +a.endTimestamp);
        const lastRegion = playbackRegions[0];

        // Set the users bookmark based on the end position of the reading session.
        const bookmarkedAudioSectionIndex = lastRegion.audioSectionIndex;
        const bookmarkedAudioSectionTime = lastRegion.endTime;

        await mgr.transaction(async trans => {
            const result = await trans.update(
                UserContent,
                { userId: currentUser.id, contentId },
                {
                    bookmarkedAudioSectionIndex,
                    bookmarkedAudioSectionTime,
                });

            if (!hasUpdatedRows(result)) {
                // Insert new row.
                await trans.insert(UserContent, {
                    userId: currentUser.id,
                    contentId,
                    bookmarkedAudioSectionIndex,
                    bookmarkedAudioSectionTime,
                });
            }

            await trans.insert(UserContentPlayback, playbackRegions.map(r => ({
                userId: currentUser.id,
                contentId,
                audioSectionsHash: r.audioSectionsHash,
                audioSectionIndex: r.audioSectionIndex,
                startTime: r.startTime,
                endTime: r.endTime,
                clientEndTimestamp: r.endTimestamp,
            })));
        });

        return OperationResult.as(content);
    }

    async requestResetPassword(email: string): Promise<OperationResult<void, "user-not-found">> {

        const lowerEmail = email.toLowerCase();

        const mgr = getManager();
        const user = await mgr.findOne(User, { email: DataProtection.encryptEmail(lowerEmail) });
        if (!user) return OperationResult.error("user-not-found");

        if (!user.passwordResetNonce) {
            user.passwordResetNonce = crypto.randomBytes(16).toString("hex");
            await mgr.update(User, user.id, { passwordResetNonce: user.passwordResetNonce });
        }

        const resetPasswordUrl = config.externalLinks.resetPasswordUrlFormat
            .replace("{}", DataProtection.createPasswordResetToken(user.id, user.passwordResetNonce))
            .replace("{}", encodeURIComponent(lowerEmail));

        await this._email.sendPasswordReset(lowerEmail, user.firstName, user.lastName, resetPasswordUrl);

        return OperationResult.okay();
    }

    async resetPassword(email: string, password: string, resetToken: string): Promise<OperationResult<User, "invalid-email-or-token" | "password-too-weak">> {

        const user = await getManager().findOne(User, { email: DataProtection.encryptEmail(email) });
        if (!user || !user.passwordResetNonce) return OperationResult.error("invalid-email-or-token");

        if (!DataProtection.validatePasswordResetToken(resetToken, user.id, user.passwordResetNonce)) {
            return OperationResult.error("invalid-email-or-token");
        }

        // Perform a sanity check on the password strength. Proper strength checking can be done on the client.
        if (password.length < 6) return OperationResult.error("password-too-weak");

        const encPassword = await DataProtection.hashPassword(password);

        const now = new Date();
        await getManager().createQueryBuilder()
            .update(User)
            .set({
                passwordResetNonce: "",
                password: encPassword,
                firstPasswordSetDateUtc: user.firstPasswordSetDateUtc ? user.firstPasswordSetDateUtc : now,
                lastPasswordSetDateUtc: now,
                emailVerified: true, // Password resets are done via email only.
                loginAllowed: true,
                inviteAcceptedDateUtc: user.inviteSentDateUtc && !user.inviteAcceptedDateUtc ? now : user.inviteAcceptedDateUtc,
            })
            .where("id = :userId", { userId: user.id })
            .execute();

        return OperationResult.as(user);
    }

    async getUserRoles(currentUser: User, userId: number, includeOrg?: boolean): Promise<UserRole[]> {
        let queryBuilder = getManager().createQueryBuilder(UserRole, "role")
            .leftJoin("role.users", "user");

        if (includeOrg) {
            queryBuilder = queryBuilder.leftJoinAndSelect("role.organisation", "org");
        }

        queryBuilder = queryBuilder.where("user.id = :userId", { userId });

        let roles = await queryBuilder.getMany();

        if (hasPermission(currentUser, RoleType.SystemAdmin) || currentUser.id === userId) {
            return roles;
        }

        // Limit roles to only ones the current user administers.
        roles = roles.filter(r => hasPermission(currentUser, RoleType.OrganisationAdmin, r.organisationId || undefined));

        return roles;
    }

    async expireAllUserSessions(currentUser: User): Promise<void> {

        // This will expire all logins for the user since we only hold a single session token for all devices.
        await getManager().createQueryBuilder()
            .update(User)
            .set({
                sessionToken: "",
            })
            .where("id = :id", { id: currentUser.id })
            .andWhere("sessionToken = :sessionToken", { sessionToken: currentUser.sessionToken })
            .execute();
    }

    async authenticateUser(email: string, password: string, ipAddress: string, userAgent: string): Promise<User | undefined> {

        const manager = getManager();

        const encEmail = DataProtection.encryptEmail(email);
        const user = await manager.findOne(User, { email: encEmail });
        if (!user) return undefined;

        if (!await DataProtection.comparePassword(password, user.password)) {
            return undefined;
        }

        if (!user.loginAllowed) return undefined;

        const now = new Date();

        const byteSize = 16;
        if (!user.sessionToken) user.sessionToken = crypto.randomBytes(byteSize).toString("hex");
        user.loginCount += 1;
        user.ipAddress = ipAddress;
        user.lastLoginDateUtc = now;

        await manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder()
                .update(User)
                .set({
                    sessionToken: user.sessionToken,
                    loginCount: () => "loginCount + 1", // Increment based on DB value to avoid select-update race condition
                    lastLoginDateUtc: now,
                    ipAddress: user.ipAddress,
                })
                .where("id = :id", { id: user.id })
                .execute();

            await this.logUserAgentWithLogin(trans, user.id, ipAddress, userAgent, now);
        });

        return user;
    }

    async signUpWithCode(email: string, code: string, ipAddress: string, userAgent: string): Promise<OperationResult<User | { actionRequired: "login" | "set-password" }, "invalid-code">> {

        const manager = getManager();

        const encEmail = DataProtection.encryptEmail(email);
        const maybeUser = await manager.findOne(User, { email: encEmail }, { relations: ["userRoles"] });

        const contentCollection = await manager.findOne(ContentCollection, { signUpCode: code, signUpCodeEnabled: true }, { relations: ["organisation"] });
        if (!contentCollection || !contentCollection.organisation) return OperationResult.error("invalid-code");

        const role = await this.getOrCreateUserRole(RoleType.Consumer, contentCollection.organisation);

        if (maybeUser) {
            await manager.transaction("READ COMMITTED", async trans => {

                // Give the user the consumer role in the organisation if they don't yet have a role.
                if (!maybeUser.userRoles || !maybeUser.userRoles.some(x => x.type === RoleType.SystemAdmin || x.organisationId === contentCollection.organisationId)) {
                    await trans.createQueryBuilder().relation(User, "userRoles").of(maybeUser).add(role);
                }

                await this.addToContentCollection(trans, maybeUser, contentCollection, code);
            });

            if (!maybeUser.firstPasswordSetDateUtc) {
                return OperationResult.as({ actionRequired: "set-password" });
            } else {
                return OperationResult.as({ actionRequired: "login" });
            }
        }

        const newUser = await manager.transaction("READ COMMITTED", async trans => {

            const now = new Date();
            const u = await this.createUserCore(encEmail, "", "", role, "sign-up-code", trans, {
                ipAddress,
                loginCount: 1, // It is assumed the user is automatically logged in after signing up with a code.
                lastLoginDateUtc: now,
                sessionToken: crypto.randomBytes(16).toString("hex"),
            });

            await this.addToContentCollection(trans, u, contentCollection, code);
            await this.logUserAgentWithLogin(trans, u.id, ipAddress, userAgent, u.createdDateUtc);
            return u;
        });

        this._notificationFactory().queueEmailToSetFirstPassword(newUser.id, contentCollection.organisationId);

        return OperationResult.as(newUser);
    }

    async joinContentCollectionWithCode(currentUser: User, code: string): Promise<OperationResult<ContentCollection, "invalid-code">> {
        const mgr = getManager();

        const contentCollection = await mgr.findOne(ContentCollection, { signUpCode: code, signUpCodeEnabled: true }, { relations: ["organisation"] });
        if (!contentCollection || !contentCollection.organisation) return OperationResult.error("invalid-code");

        const role = await this.getOrCreateUserRole(RoleType.Consumer, contentCollection.organisation);

        await mgr.transaction("READ COMMITTED", async trans => {

            // Give the user the consumer role in the organisation if they don't yet have a role.
            if (!currentUser.userRoles || !currentUser.userRoles.some(x => x.type === RoleType.SystemAdmin || x.organisationId === contentCollection.organisationId)) {
                await trans.createQueryBuilder().relation(User, "userRoles").of(currentUser).add(role);
            }

            await this.addToContentCollection(trans, currentUser, contentCollection, code);
        });

        return OperationResult.as(contentCollection);
    }

    async logUserAgent(currentUser: User, ipAddress: string, userAgent: string) {

        const mgr = getManager();

        await mgr.transaction("READ COMMITTED", async trans => {

            const updateResult = await trans.createQueryBuilder()
                .update(UserAgent)
                .set({
                    ipAddress,
                })
                .where("userId = :userId", { userId: currentUser.id })
                .andWhere("value = :userAgent", { userAgent })
                .execute();

            if (!hasUpdatedRows(updateResult)) {
                // Insert new row.
                await trans.insert(UserAgent, {
                    userId: currentUser.id,
                    value: userAgent,
                    loginCount: 0,
                    lastLoginDateUtc: null,
                    ipAddress,
                });
            }
        });
    }

    async logUserAgentWithLogin(transaction: EntityManager, userId: number, ipAddress: string, userAgent: string, lastLoginDateUtc: Date) {
        const updateResult = await transaction.createQueryBuilder()
            .update(UserAgent)
            .set({
                loginCount: () => "loginCount + 1",
                lastLoginDateUtc,
                ipAddress,
            })
            .where("userId = :userId", { userId })
            .andWhere("value = :userAgent", { userAgent })
            .execute();

        if (!hasUpdatedRows(updateResult)) {
            // Insert new row.
            await transaction.insert(UserAgent, {
                userId,
                value: userAgent,
                loginCount: 1,
                lastLoginDateUtc,
                ipAddress,
            });
        }
    }

    async updateSelf(currentUser: User, firstName: string | undefined, lastName: string | undefined, currentPassword: string | undefined, newPassword: string | undefined)
        : Promise<OperationResult<User, "incorrect-password" | "user-not-found" | "password-too-weak">> {

        const mgr = getManager();
        const dbUser = await mgr.findOne(User, currentUser.id);
        if (!dbUser) return OperationResult.error("user-not-found");

        const updateData: Partial<User> = {};

        if (currentPassword || newPassword) {
            if (!currentPassword || !await DataProtection.comparePassword(currentPassword, dbUser.password)) {
                return OperationResult.error("incorrect-password");
            }

            // Perform a sanity check on the password strength. Proper strength checking can be done on the client.
            if (!newPassword || newPassword.length < 6) return OperationResult.error("password-too-weak");

            updateData.password = await DataProtection.hashPassword(newPassword);
            updateData.passwordResetNonce = "";
            updateData.lastPasswordSetDateUtc = new Date();
        }

        if (firstName) updateData.firstName = firstName;
        if (lastName) updateData.lastName = lastName;

        await mgr.createQueryBuilder().update(User).set(updateData).where("id = :id", { id: currentUser.id }).execute();

        Object.assign(dbUser, updateData);
        return OperationResult.as(dbUser);
    }

    async updateUser(currentUser: User, userId: number, firstName: string | undefined, lastName: string | undefined)
        : Promise<OperationResult<User, "invalid-permissions" | "user-not-found">> {

        const mgr = getManager();

        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return OperationResult.error("user-not-found");

        if (!isSysAdmin(currentUser)) {
            const roles = filterOrganisationRoles(user.userRoles);

            if (!roles.some(x => hasPermission(currentUser, RoleType.OrganisationAdmin, x.organisationId))) {
                return OperationResult.invalidPermissions();
            }
        }

        const updateData: Partial<User> = {};

        if (firstName) updateData.firstName = firstName;
        if (lastName) updateData.lastName = lastName;

        await mgr.createQueryBuilder().update(User).set(updateData).where("id = :id", { id: userId }).execute();

        Object.assign(user, updateData);
        return OperationResult.as(user);
    }

    async inviteSystemAdmin(currentUser: User, email: string, firstName: string, lastName: string): Promise<OperationResult<User, "invalid-permissions" | "already-invited">> {
        const manager = getManager();
        const encEmail = DataProtection.encryptEmail(email);

        // Only system admins can create system admins
        if (!hasPermission(currentUser, RoleType.SystemAdmin)) return OperationResult.invalidPermissions();

        const role = await manager.findOne(UserRole, { type: RoleType.SystemAdmin });
        if (!role) throw new Error("sys-admin user role should always exist.");

        let user = await manager.findOne(User, { email: encEmail }, { relations: ["userRoles"] });

        if (user && user.userRoles && user.userRoles.some(r => r.type === RoleType.SystemAdmin)) {
            return OperationResult.error("already-invited");
        }

        if (!user) {
            user = await this.createUserCore(encEmail, firstName, lastName, role, "invite");
        } else {
            try {
                await manager.transaction("READ COMMITTED", async trans => {
                    if (!user) return;

                    // Strip all existing roles for this organisation.
                    if (user.userRoles) {
                        await trans.createQueryBuilder().relation(User, "userRoles").of(user).remove(user.userRoles);
                    }

                    // Simply assign the role to the user.
                    await trans.createQueryBuilder().relation(User, "userRoles").of(user).add(role);

                    if (user.createdReason === "sign-up-code" && !user.firstPasswordSetDateUtc) {
                        // If the user was created by a sign up code and has not yet set their password, it is important to invalidate their
                        // login session and avoid giving them access to new titles before they validate the email address.
                        await trans.createQueryBuilder().update(User).set({ sessionToken: "" }).where({ id: user.id }).execute();
                    }
                });

            } catch (err) {
                // Check if its due duplicate entries.
                if (err && err.code === "ER_DUP_ENTRY") {
                    return OperationResult.error("already-invited");
                }

                throw err;
            }

            // Keep this instance up to date.
            if (!user.userRoles) user.userRoles = [];
            user.userRoles.push(role);
        }

        this._notificationFactory().queueSysAdminInvitation(user.id);

        return OperationResult.as(user);
    }

    async inviteUser(currentUser: User, organisationId: number, roleType: RoleType.Consumer | RoleType.OrganisationAdmin, email: string, firstName: string, lastName: string): Promise<OperationResult<User>> {

        const errorCodes = {
            orgNotFound: "organisation-not-found",
            invalidPermissions: "invalid-permissions",
            alreadyInvited: "already-invited",
            alreadySysAdmin: "sys-admin-can-only-be-sys-admin",
        };

        const manager = getManager();
        const encEmail = DataProtection.encryptEmail(email);

        let user: User | undefined;
        let role: UserRole;

        const org = await manager.findOne(Organisation, { id: organisationId });
        if (!org) return OperationResult.error(errorCodes.orgNotFound);

        // Only system admins and org admins can create users.
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, org)) return OperationResult.error(errorCodes.invalidPermissions);

        user = await manager.findOne(User, { email: encEmail }, { relations: ["userRoles"] });

        if (user && user.userRoles) {
            if (user.userRoles.some(r => r.type === RoleType.SystemAdmin)) {
                return OperationResult.error(errorCodes.alreadySysAdmin);
            }

            if (user.userRoles.some(r => (r.type === roleType || r.type === RoleType.OrganisationAdmin) && r.organisationId === org.id)) {
                return OperationResult.error(errorCodes.alreadyInvited);
            }
        }

        // Create the role in the organisation if it doesn't already exist.
        role = await this.getOrCreateUserRole(roleType, org);

        try {
            if (!user) {
                user = await this.createUserCore(encEmail, firstName, lastName, role, "invite");
            } else {
                await manager.transaction("READ COMMITTED", async trans => {

                    if (!user) return;

                    // Strip all existing roles for this organisation.
                    if (user.userRoles) {
                        await trans.createQueryBuilder().relation(User, "userRoles").of(user).remove(user.userRoles.filter(r => r.organisationId === organisationId));
                    }

                    // Simply assign the role to the user.
                    await trans.createQueryBuilder().relation(User, "userRoles").of(user).add(role);

                    if (user.createdReason === "sign-up-code" && !user.firstPasswordSetDateUtc) {
                        // If the user was created by a sign up code and has not yet set their password, it is important to invalidate their
                        // login session and avoid giving them access to new titles before they validate the email address.
                        await trans.createQueryBuilder().update(User).set({ sessionToken: "" }).where({ id: user.id }).execute();
                    }
                });

                // And keep this instance up to date.
                user.userRoles = user.userRoles
                    ? user.userRoles.filter(r => r.organisationId !== organisationId)
                    : [];
                user.userRoles.push(role);
            }

            this._notificationFactory().queueInvitation(user.id, organisationId);

            return OperationResult.as(user);
        } catch (err) {
            log.e("Error creating a new user with role", err);

            // Check if its due duplicate entries.
            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error(errorCodes.alreadyInvited);
            }

            throw err;
        }
    }

    async grantUserSpecialisedOrganisationAdminRole(currentUser: User, organisationId: number, roleType: RoleType.OrganisationContentUploader, userId: number): Promise<OperationResult<User>> {

        const errorCodes = {
            orgNotFound: "organisation-not-found",
            invalidPermissions: "invalid-permissions",
            userNotFound: "user-not-found",
            alreadyAssignedRole: "already-assigned-role",
            alreadySysAdmin: "sys-admin-can-only-be-sys-admin",
            missingOrgAdminRole: "missing-org-admin-role",
        };

        const manager = getManager();

        let user: User | undefined;
        let role: UserRole;

        const org = await manager.findOne(Organisation, { id: organisationId });
        if (!org) return OperationResult.error(errorCodes.orgNotFound);

        if (roleType === RoleType.OrganisationContentUploader) {
            // OrganisationContentUploaders can adjust the same permission of other org admins
            if (!hasPermission(currentUser, RoleType.OrganisationContentUploader, organisationId)) {
                return OperationResult.error(errorCodes.invalidPermissions);
            }
        } else {
            // Future proofing with sensible default...
            // Only system admins can assign specialised organisation roles to users.
            if (!isSysAdmin(currentUser)) return OperationResult.error(errorCodes.invalidPermissions);
        }

        user = await manager.findOne(User, { id: userId }, { relations: ["userRoles"] });

        if (!user || !user.userRoles) return OperationResult.error(errorCodes.userNotFound);

        if (user.userRoles.some(r => r.type === RoleType.SystemAdmin)) {
            return OperationResult.error(errorCodes.alreadySysAdmin);
        }

        if (user.userRoles.some(r => r.type === roleType && r.organisationId === org.id)) {
            return OperationResult.error(errorCodes.alreadyAssignedRole);
        }

        // Can only assign specialised roles to org admins
        if (!user.userRoles.some(r => r.type === RoleType.OrganisationAdmin && r.organisationId === org.id)) {
            return OperationResult.error(errorCodes.missingOrgAdminRole);
        }

        // Create the role in the organisation if it doesn't already exist.
        role = await this.getOrCreateUserRole(roleType, org);

        try {
            await manager.transaction("READ COMMITTED", async trans => {
                await trans.createQueryBuilder().relation(User, "userRoles").of(user).add(role);
            });

            // And keep this instance up to date.
            user.userRoles.push(role);

            return OperationResult.as(user);
        } catch (err) {
            log.e("Error assigning specialised organisation admin role to user", err);

            // Check if its due duplicate entries.
            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error(errorCodes.alreadyAssignedRole);
            }

            throw err;
        }
    }

    async removeSystemAdmin(currentUser: User, userId: number): Promise<OperationResult<void>> {

        if (!isSysAdmin(currentUser)) return OperationResult.invalidPermissions();

        return getManager().transaction("READ COMMITTED", async trans => {

            const user = await trans.findOne(User, userId, { relations: ["userRoles"] });
            if (!user || !user.userRoles) return OperationResult.error("user-not-found");

            // If a user is a sys admin, they can't have organisation specific roles.
            const role = user.userRoles.find(r => r.type === RoleType.SystemAdmin);
            if (!role) return OperationResult.error("user-not-found");

            // WARN: All operations that grant access to content should request a shared lock on the
            // users role to avoid access being granted based on cached role data.
            await trans.createQueryBuilder().relation(User, "userRoles").of(user).remove(role);

            // Remove user from all groups and content collections.
            // Any better way to do this rather than a raw query?
            await trans.query("DELETE FROM `user_group_member` WHERE `userId` = ?", [user.id]);
            await trans.query("DELETE FROM `content_collection_user` WHERE `userId` = ?", [user.id]);

            const access = await trans.createQueryBuilder(UserContentAccess, "uca")
                .where("uca.userId = :userId", { userId: user.id })
                .getMany();

            if (access && access.length) {
                await trans.remove(access);
            }

            // If the user has never logged in then delete them.
            if (!user.firstPasswordSetDateUtc && user.loginCount === 0) {

                // Delete meaningless logs.
                await trans.createQueryBuilder().delete().from(UserContentAccessLog).where("userId = :userId", { userId: user.id }).execute();

                // They should not have any other relations. PlaybackLogs and UserContent can only get created when the user is logged in.
                await trans.remove(user);

            } else if (access && access.length) {
                // Log access-revoked
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(access.map(a => ({
                    contentId: a.contentId,
                    userId: user.id,
                    action: "access-revoked",
                    eventData: JSON.stringify({ via: a.source, contentCollectionId: a.contentCollectionId || undefined, userGroupId: a.userGroupId || undefined }),
                }))).execute();
            }

            return OperationResult.okay();
        });
    }

    async removeUserFromOrganisation(currentUser: User, userId: number, organisationId: number): Promise<OperationResult<User>> {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return OperationResult.invalidPermissions();

        const manager = getManager();

        const user = await manager.findOne(User, userId, { relations: ["userRoles"] });
        if (!user || !user.userRoles) return OperationResult.error("user-not-found");

        const roles = user.userRoles.filter(r => r.organisationId === organisationId);
        if (roles.length === 0) return OperationResult.error("user-not-found");

        const isLastRole = !user.userRoles.some(r => r.organisationId !== organisationId);

        await manager.transaction("READ COMMITTED", async trans => {

            // WARN: All operations that grant access to content should request a shared lock on the
            // users role to avoid access being granted based on cached role data.
            await trans.createQueryBuilder().relation(User, "userRoles").of(user).remove(roles);

            // Remove user from all groups in the organisation.
            const groups = await trans.createQueryBuilder(UserGroup, "ug")
                .select("ug.id")
                .innerJoin("ug.users", "u")
                .where("ug.organisationId = :organisationId", { organisationId })
                .andWhere("u.id = :id", { id: user.id })
                .getMany();

            await trans.createQueryBuilder().relation(User, "userGroups").of(user).remove(groups);

            // Remove user from all content collections in the organisation.
            const cc = await trans.createQueryBuilder(ContentCollection, "cc")
                .select("cc.id")
                .innerJoin("cc.users", "u")
                .where("cc.organisationId = :organisationId", { organisationId })
                .andWhere("u.id = :id", { id: user.id })
                .getMany();

            await trans.createQueryBuilder().relation(User, "contentCollections").of(user).remove(cc);

            const access = await trans.createQueryBuilder(UserContentAccess, "uca")
                .innerJoin("uca.content", "c")
                .where("c.organisationId = :organisationId", { organisationId })
                .andWhere("uca.userId = :userId", { userId: user.id })
                .getMany();

            if (access && access.length) {
                await trans.remove(access);
            }

            // If the user has never logged in and they don't have any other roles then delete them.
            if (isLastRole && !user.firstPasswordSetDateUtc && user.loginCount === 0) {

                // Delete meaningless logs.
                await trans.createQueryBuilder().delete().from(UserContentAccessLog).where("userId = :userId", { userId: user.id }).execute();

                // They should not have any other relations. PlaybackLogs and UserContent can only get created when the user is logged in.
                await trans.remove(user);
            } else if (access && access.length) {
                // Log access-revoked
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(access.map(a => ({
                    contentId: a.contentId,
                    userId: user.id,
                    action: "access-revoked",
                    eventData: JSON.stringify({ via: a.source, contentCollectionId: a.contentCollectionId || undefined, userGroupId: a.userGroupId || undefined }),
                }))).execute();
            }
        });

        // Return the updated instance.
        user.userRoles = user.userRoles.filter(r => !roles.some(deletedRole => r.id === deletedRole.id));
        return OperationResult.as(user);
    }

    async revokeUserSpecialisedOrganisationAdminRole(currentUser: User, organisationId: number, roleType: RoleType.OrganisationContentUploader, userId: number): Promise<OperationResult<User>> {

        const errorCodes = {
            orgNotFound: "organisation-not-found",
            invalidPermissions: "invalid-permissions",
            userNotFound: "user-not-found",
            roleNotFound: "role-not-found",
            alreadySysAdmin: "sys-admin-can-only-be-sys-admin",
            missingOrgAdminRole: "missing-org-admin-role",
        };

        const manager = getManager();

        const org = await manager.findOne(Organisation, { id: organisationId });
        if (!org) return OperationResult.error(errorCodes.orgNotFound);

        if (roleType === RoleType.OrganisationContentUploader) {
            // OrganisationContentUploaders can adjust the same permission of other org admins
            if (!hasPermission(currentUser, RoleType.OrganisationContentUploader, organisationId)) {
                return OperationResult.error(errorCodes.invalidPermissions);
            }
        } else {
            // Future proofing with sensible default...
            // Only system admins can revoke specialised organisation roles to users.
            if (!isSysAdmin(currentUser)) return OperationResult.error(errorCodes.invalidPermissions);
        }

        const user = await manager.findOne(User, { id: userId }, { relations: ["userRoles"] });
        if (!user || !user.userRoles) return OperationResult.error(errorCodes.userNotFound);

        const role = user.userRoles.find(r => r.type === roleType && r.organisationId === org.id);
        if (!role) {
            return OperationResult.error(errorCodes.roleNotFound);
        }

        await manager.transaction("READ COMMITTED", async trans => {
            await trans.createQueryBuilder().relation(User, "userRoles").of(user).remove(role);
        });

        // And keep this instance up to date.
        user.userRoles = user.userRoles.filter(r => r.id !== role.id);

        return OperationResult.as(user);
    }

    async searchUsers(currentUser: User, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const org = await getManager().findOne(Organisation, { id: organisationId });
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, org)) return EMPTY_PAGINATED;

        const [users, totalCount] = await getManager().createQueryBuilder(User, "user")
            .leftJoin("user.userRoles", "role")
            .where("role.organisationId = :orgId", { orgId: organisationId })
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async searchSysAdmins(currentUser: User, pageSize: number, pageNumber: number): Promise<Paginated<User>> {

        if (!hasPermission(currentUser, RoleType.SystemAdmin)) return EMPTY_PAGINATED;

        const [users, totalCount] = await getManager().createQueryBuilder(User, "user")
            .leftJoin("user.userRoles", "role")
            .where("role.type = :roleType", { roleType: RoleType.SystemAdmin })
            .andWhere("role.organisationId is null")
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async createFirstUser(email: string, password: string): Promise<User | undefined> {

        const passwordHash = await DataProtection.hashPassword(password);
        const encEmail = DataProtection.encryptEmail(email);

        const result = await getManager().transaction(async trans => {

            if (await trans.findOne(User)) {
                return undefined;
            }

            const role = trans.create(UserRole, {
                name: "System Admin",
                type: RoleType.SystemAdmin,
                organisation: null,
            });

            await trans.save(role);

            const user = trans.create(User, {
                email: encEmail,
                password: passwordHash,
                userRoles: [role],
                loginAllowed: true,
                emailVerified: true,
            });

            await trans.save(user);
            return user;
        });

        return result;

    }

    async searchUserGroupsUserIsAMemberOf(currentUser: User, userId: number, organisationId: number | null, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {

        if (organisationId) {
            return this.searchUserGroupsUserIsAMemberOfWithinOrganisation(currentUser, userId, organisationId, pageSize, pageNumber, searchText);
        }

        const mgr = getManager();

        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return EMPTY_PAGINATED;

        let query = mgr.createQueryBuilder(UserGroup, "group")
            .innerJoin("group.users", "user", "user.id = :userId", { userId })
            .where("group.name like :textPattern", { textPattern: `%${searchText}%` });

        if (!isSysAdmin(currentUser) || !isSysAdmin(user)) {
            const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
            if (!orgIds) return EMPTY_PAGINATED;
            query = query.andWhere("group.organisationId in (:orgIds)", { orgIds });
        }

        const [groups, totalCount] = await query
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: groups,
            totalCount,
        };
    }

    async searchContentCollectionsUserIsAMemberOf(currentUser: User, userId: number, organisationId: number | null, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {

        if (organisationId) {
            return this.searchContentCollectionsUserIsAMemberOfWithinOrganisation(currentUser, userId, organisationId, pageSize, pageNumber, searchText);
        }

        const mgr = getManager();

        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return EMPTY_PAGINATED;

        let query = mgr.createQueryBuilder(ContentCollection, "cc")
            .innerJoin("cc.users", "user", "user.id = :userId", { userId })
            .where("cc.name like :textPattern", { textPattern: `%${searchText}%` });

        if (!isSysAdmin(currentUser) || !isSysAdmin(user)) {
            const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
            if (!orgIds) return EMPTY_PAGINATED;
            query = query.andWhere("cc.organisationId in (:orgIds)", { orgIds });
        }

        const [cc, totalCount] = await query
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    async searchPotentialContentDirectlyAccessibleForUser(currentUser: User, userId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const mgr = getManager();

        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user || !user.userRoles) return EMPTY_PAGINATED;

        let query = mgr.createQueryBuilder(Content, "c")
            .leftJoin("c.userContentAccess", "uca", "uca.userId = :userId AND uca.source = :source", { userId, source: AccessSource.Direct });

        // If both the current user and the user in context are super admins, don't filter by any organisation.
        if (!hasPermission(currentUser, RoleType.SystemAdmin) || !hasPermission(user, RoleType.SystemAdmin)) {
            const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
            if (!orgIds) return EMPTY_PAGINATED;
            query = query.where("c.organisationId in (:orgIds)", { orgIds });
        }

        const [content, totalCount] = await query
            .andWhere("uca.userId is null")
            .andWhere("c.status != :status", { status: ContentStatus.Importing })
            .andWhere("c.deletedDateUtc is null")
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    async searchPotentialUserGroupsForUser(currentUser: User, userId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {

        const mgr = getManager();
        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user || !user.userRoles) return EMPTY_PAGINATED;

        let query = mgr.createQueryBuilder(UserGroup, "g")
            .leftJoin("user_group_member", "m", "m.userGroupId = g.id AND m.userId = :userId", { userId });

        // If both the current user and the user in context are super admins, don't filter by any organisation.
        if (!hasPermission(currentUser, RoleType.SystemAdmin) || !hasPermission(user, RoleType.SystemAdmin)) {
            const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
            if (!orgIds) return EMPTY_PAGINATED;
            query = query.where("g.organisationId in (:orgIds)", { orgIds });
        }

        const [content, totalCount] = await query
            .andWhere("m.userId is null")
            .andWhere("g.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    async searchPotentialContentCollectionsForUser(currentUser: User, userId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {

        const mgr = getManager();
        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user || !user.userRoles) return EMPTY_PAGINATED;

        let query = mgr.createQueryBuilder(ContentCollection, "cc")
            .leftJoin("content_collection_user", "ccu", "ccu.contentCollectionId = cc.id AND ccu.userId = :userId", { userId });

        // If both the current user and the user in context are super admins, don't filter by any organisation.
        if (!hasPermission(currentUser, RoleType.SystemAdmin) || !hasPermission(user, RoleType.SystemAdmin)) {
            const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
            if (!orgIds) return EMPTY_PAGINATED;
            query = query.where("cc.organisationId in (:orgIds)", { orgIds });
        }

        const [cc, totalCount] = await query
            .andWhere("ccu.userId is null")
            .andWhere("cc.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    async recordTechnicalIssues(userAgent: string, data: string[]): Promise<void> {
        // We do not store a user against this data due to GDPR.
        await getManager().createQueryBuilder().insert().into(ClientTechnicalIssue).values(data.map(d => ({
            userAgent,
            data: d,
        }))).execute();
    }

    private async searchContentCollectionsUserIsAMemberOfWithinOrganisation(currentUser: User, userId: number, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {

        const mgr = getManager();

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return EMPTY_PAGINATED;

        const user = await getOrganisationUser(mgr, userId, organisationId);
        if (!user) return EMPTY_PAGINATED;

        const [cc, totalCount] = await mgr.createQueryBuilder(ContentCollection, "cc")
            .innerJoin("cc.users", "user", "user.id = :userId", { userId })
            .where("cc.organisationId = :organisationId", { organisationId })
            .andWhere("cc.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    private async searchUserGroupsUserIsAMemberOfWithinOrganisation(currentUser: User, userId: number, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {
        const mgr = getManager();

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return EMPTY_PAGINATED;

        const user = await getOrganisationUser(mgr, userId, organisationId);
        if (!user) return EMPTY_PAGINATED;

        const [groups, totalCount] = await mgr.createQueryBuilder(UserGroup, "group")
            .innerJoin("group.users", "user", "user.id = :userId", { userId })
            .where("group.organisationId = :organisationId", { organisationId })
            .andWhere("group.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: groups,
            totalCount,
        };
    }

    private async createUserCore(encEmail: string, firstName: string, lastName: string, role: UserRole, createdReason: "invite" | "sign-up-code", transaction?: EntityManager, additionalMetadata?: DeepPartial<User>): Promise<User> {
        const mgr = transaction || getManager();
        const u = mgr.create(User, {
            email: encEmail,
            password: await DataProtection.hashPassword(crypto.randomBytes(16).toString("base64")),
            firstName,
            lastName,
            createdReason,
            userRoles: [role],
            loginAllowed: false,
            emailVerified: false,
            passwordResetNonce: crypto.randomBytes(16).toString("hex"),
            ...additionalMetadata,
        });
        await mgr.save(u);
        return u;
    }

    private async getOrCreateUserRole(roleType: RoleType, org: Organisation): Promise<UserRole> {

        if (roleType === RoleType.SystemAdmin) throw Error("sys-admin isn't supported by this function.");

        const manager = getManager();
        const userRole = await manager.findOne(UserRole, { type: roleType, organisationId: org.id });
        if (userRole) return userRole;

        return manager.transaction(async trans => {
            let newUserRole = await trans.createQueryBuilder(UserRole, "userRole")
                .setLock("pessimistic_write")
                .where("userRole.type = :type", { type: roleType })
                .andWhere("userRole.organisationId = :orgId", { orgId: org.id })
                .getOne();

            if (!newUserRole) {

                let name = roleType.toString();
                switch (roleType) {
                    case RoleType.OrganisationAdmin:
                        name = "Organisation Admin";
                        break;
                    case RoleType.OrganisationContentUploader:
                        name = "Organisation Content Uploader";
                        break;
                    case RoleType.Consumer:
                        name = "Consumer";
                }

                newUserRole = trans.create(UserRole, {
                    name,
                    type: roleType,
                    organisation: org,
                });

                await trans.save(newUserRole);
            }
            return newUserRole;
        });
    }

    private async addToContentCollection(trans: EntityManager, user: User, contentCollection: ContentCollection, code: string) {
        // Add a shared lock to avoid content being removed from the collection while we grant the user access to the collection's content.
        const results = await trans.query("SELECT contentId FROM `content_collection_item` WHERE `contentCollectionId` = ? LOCK IN SHARE MODE", [contentCollection.id]);
        const contentIds: number[] = results.map(r => r.contentId);

        // Add the user to the collection.
        try {
            await trans.createQueryBuilder().relation(ContentCollection, "users").of(contentCollection).add(user);
        } catch (err) {
            if (err && err.code === "ER_DUP_ENTRY") {
                // If the user is already included then there's nothing further to do.
                return;
            }

            throw err;
        }

        if (contentIds && contentIds.length) {

            // Give the user access to all content in the collection.
            await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                contentIds.map(cId => ({
                    contentId: cId,
                    userId: user.id,
                    source: AccessSource.ContentCollection,
                    contentCollectionId: contentCollection.id,
                    omitNotification: true,
                })),
            ).execute();

            // Record access.
            await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                contentIds.map(cId => ({
                    contentId: cId,
                    userId: user.id,
                    action: "access-granted",
                    eventData: JSON.stringify({ via: AccessSource.ContentCollection, contentCollectionId: contentCollection.id, signUpCode: code }),
                })),
            ).execute();
        }
    }
}
