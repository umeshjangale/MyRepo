import AWS from "aws-sdk";
import crypto from "crypto";
import fs from "fs";
import { inject, injectable } from "inversify";
import { getManager } from "typeorm";

import { AudioProfile, fromDbAudioFormat, toDbAudioFormat } from "../audio/audio-format";
import { AudioService } from "../audio/audio-service";
import config from "../config";
import { EmailService } from "../email/email-service";
import { createLogger } from "../logger";
import { AudioEncodingQueueMessage, LargeAudioEncodingQueueMessage, ProcessAudioSectionQueueMessage } from "../queues/queue-message";
import { QueueService } from "../queues/queue-service";
import { QueueType } from "../queues/queue-type";
import { SYMBOLS } from "../runtime/symbols";
import { TempFileHelper } from "../runtime/temp-file-helper";
import * as DataProtection from "../security/data-protection";
import { NodeType } from "../types/node-id";
import { changeExtension, getDirectoryName, getFileExtensionWithoutDot, getFilename, getFilenameWithoutExtension, getLastDirectoryName, getSqlDateStringUtc } from "../utils";
import { getFileBytes } from "../utils/file-util";

import { BaseStorage } from "./base-storage";
import { AudioFile, AudioSection, AudioSummary, Content, Import, Organisation, User } from "./db-entities";
import { AudioFormat, ContentStatus, ImportStatus, RoleType } from "./db-entities/enums";
import { downloadToFile, getS3 } from "./helpers/blob-helper";
import { ReferenceDataStorage } from "./reference-data-storage";

const log = createLogger("Import Storage");

enum Stage {
    ProcessAudioSection = "process-audio-section",
}

interface FileStats {
    filename: string;
    duration: number;
    fileBytes: number;
}

@injectable()
export class ImportStorage extends BaseStorage {

    constructor(
        @inject(SYMBOLS.QueueService) private readonly _queue: QueueService,
        @inject(SYMBOLS.ReferenceDataStorage) private readonly _referenceData: ReferenceDataStorage,
        @inject(SYMBOLS.AudioService) private readonly _audio: AudioService,
        @inject(SYMBOLS.EmailService) private readonly _email: EmailService,
    ) {
        super();
    }

    async processImportFileEvents(bucket: string, events: Array<{ key: string; size: number; eventTime: number; callerId: string }>): Promise<void> {

        // TODO: cache the appId.
        const appId = await new AWS.STS().getCallerIdentity().promise();
        const eventsOfInterest = events.filter(e => {

            // Ignore events from the archive 'folder'.
            if (e.key.startsWith(config.import.archivePrefix)) return false;

            // Ignore 'folders'
            if (!getFilename(e.key)) return false;

            // Exclude events caused by the app itself e.g from when files are transferred to archive.
            if (appId && appId.UserId && e.callerId.includes(appId.UserId)) return false;
            return true;
        });

        if (!eventsOfInterest.length) return;

        const mgr = getManager();
        const org = await mgr.createQueryBuilder(Organisation, "org")
            .where("org.importStorageBucket = :bucket", { bucket })
            .getOne();

        if (!org) {
            log.w(`An import file event occurred, but no organisation was found with bucket ${bucket}`);
            return;
        }

        // Create a separate import for each 'folder'
        const folders = this._getKeysGroupedByFolder(eventsOfInterest.map(e => e.key));
        const latestEventTime = new Date(eventsOfInterest.map(e => e.eventTime).sort((a, b) => b - a)[0]);

        for (const folder of folders.keys()) {

            await mgr.transaction("READ COMMITTED", async trans => {

                const existingImport = await trans.createQueryBuilder(Import, "i")
                    .setLock("pessimistic_write")
                    .where("i.organisationId = :orgId", { orgId: org.id })
                    .andWhere("i.importStoragePrefix = :folder", { folder })
                    .andWhere("i.status = :status", { status: ImportStatus.Waiting })
                    .getOne();

                if (existingImport) {
                    if (existingImport.lastFileModifiedDateUtc < latestEventTime) {

                        // Update the lastFileModifiedDateUtc for all pending imports of the organisation, not just one 'folder'.
                        await trans.createQueryBuilder(Import, "import")
                            .update()
                            .set({ lastFileModifiedDateUtc: () => `GREATEST(lastFileModifiedDateUtc, '${getSqlDateStringUtc(latestEventTime)}')` })
                            .where("organisationId = :orgId", { orgId: org.id })
                            .andWhere("status = :status", { status: ImportStatus.Waiting })
                            .execute();
                    }
                } else {
                    const reference = new Date(Date.now());

                    const i = await trans.save(trans.create(Import, {
                        timestampReference: reference,
                        importStoragePrefix: folder,
                        stagingStoragePrefix: _getStagingStoragePrefix(org, reference, folder),
                        organisation: org,
                        status: ImportStatus.Waiting,
                        lastFileModifiedDateUtc: latestEventTime,
                    }));

                    // Queue a message to later check if activity has stopped in this bucket and attempt the transfer to the staging bucket.
                    await this._queue.addMessage(
                        {
                            queue: QueueType.ImportBatchTransfer,
                            importId: i.id,
                        },
                        config.import.transferTimeoutSeconds);
                }
            });
        }
    }

    async attemptImportFilesTransfer(importId: number): Promise<void> {

        const mgr = getManager();
        const i = await mgr.findOne(Import, importId, { relations: ["organisation"] });
        if (!i || !i.organisation || !i.organisation.importStorageBucket) return;

        const threshold = new Date(Date.now() - (config.import.transferTimeoutSeconds * 1000));
        if (i.lastFileModifiedDateUtc > threshold) {

            // If there is still activity in the import bucket, add a message to later check if activity has stopped.
            const delay = (i.lastFileModifiedDateUtc.getTime() - threshold.getTime()) / 1000;
            await this._queue.addMessage(
                {
                    queue: QueueType.ImportBatchTransfer,
                    importId: i.id,
                },
                delay);
            return;
        }

        await mgr.update(Import, i.id, { status: ImportStatus.Transferring, message: "" });

        const s3 = getS3();

        // NB: This only supports fetching up to 1000 objects, which should be plenty for a single audiobook. In future we may need to support importing multiple audiobooks in the same folder.
        const listResult = await s3.listObjectsV2({ Bucket: i.organisation.importStorageBucket, Prefix: i.importStoragePrefix, Delimiter: "/" }).promise();

        if (!listResult.Contents || !listResult.Contents.length) {
            await mgr.update(Import, i.id, { status: ImportStatus.Failed, message: "No files found in import bucket" });
            log.i(`No files found while attempting to transfer import files to staging. importId: ${i.id}, bucket: ${i.organisation.importStorageBucket}, prefix: ${i.importStoragePrefix}`);
            return;
        }

        const stagingPrefix = i.stagingStoragePrefix;
        const archivePrefix = _getArchiveStoragePrefix(config.import.archivePrefix, i.timestampReference, i.importStoragePrefix);

        const importStorageBucket = i.organisation.importStorageBucket;
        await Promise.all(listResult.Contents.map(async obj => {
            // Can key actually ever be undefined?
            if (!obj.Key) return;
            if (obj.Key.startsWith(config.import.archivePrefix)) return;

            // Copy the file to staging
            const copySource = `/${importStorageBucket}/${obj.Key}`;
            await s3.copyObject(
                {
                    Bucket: config.s3.stagingBucket,
                    CopySource: copySource,
                    Key: `${stagingPrefix}${getFilename(obj.Key)}`,
                }).promise();

            // Copy the file to the archive 'folder'
            await s3.copyObject(
                {
                    Bucket: importStorageBucket,
                    CopySource: copySource,
                    Key: `${archivePrefix}${getFilename(obj.Key)}`,
                }).promise();

            // Delete.
            await s3.deleteObject(
                {
                    Bucket: importStorageBucket,
                    Key: obj.Key,
                }).promise();
        }));

        await this._queue.addMessage(
            {
                queue: QueueType.ImportBatchValidation,
                importId: i.id,
            });
    }

    async validateImportFilesAndImportContent(importId: number): Promise<void> {

        // Validate files in the staging bucket.
        const mgr = getManager();
        const i = await mgr.findOne(Import, importId, { relations: ["organisation"] });
        if (!i || !i.organisation) return;

        await mgr.update(Import, i.id, { status: ImportStatus.Validating, message: "" });

        const s3 = getS3();
        const listResult = await s3.listObjectsV2({ Bucket: config.s3.stagingBucket, Prefix: i.stagingStoragePrefix, Delimiter: "/" }).promise();

        if (!listResult.Contents || !listResult.Contents.length) {
            await mgr.update(Import, i.id, { status: ImportStatus.Failed, message: "No files found in staging bucket" });
            log.i(`No files found to validate in staging. importId: ${i.id}, bucket: ${i.organisation.importStorageBucket}, prefix: ${i.stagingStoragePrefix}`);
            return;
        }

        const objects = listResult.Contents.map(c => ({ key: c.Key, size: c.Size })).filter((obj): obj is { key: string; size: number } => !!obj.key && typeof obj.size === "number");

        const validationResult = this._validateImportFilesAndExtractStructure(i.organisation, objects);
        if (validationResult.errors && validationResult.errors.length) {

            validationResult.errors.forEach(e => log.i(`Import failed. id: ${i.id}, error: ${e}`));
            await mgr.update(Import, i.id, { status: ImportStatus.Failed, message: (`Validation errors. ${validationResult.errors.join(". ")}`).substring(0, 2000) });

            await this._email.sendImportFailed(await this._getImportNotificationEmailAddresses(i.organisationId), i.importStoragePrefix, i.organisation.name, validationResult.errors);
            return;
        }

        await this._importContent(i, i.organisation, validationResult.isbn, validationResult.stagedCoverImageKey, validationResult.hasSoundtrack, validationResult.audioSections);
    }

    async validateAndImportAudioSection(contentId: number, pipelineId: string, sequence: number, narrationStoragePath: string, narrationSize: number, soundtrackStoragePath: string | undefined, soundtrackSize: number | undefined, totalNumOfSections: number) {
        // Create the audio section and trigger processes for each encoding of the original file.

        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { relations: ["import"] });
        if (!content || !content.import) return;

        await mgr.transaction("READ COMMITTED", async trans => {
            // Remove any existing section and files from possible previously failed import.
            let section = await trans.findOne(AudioSection, { where: { sequence, contentId } });
            if (section) {
                await trans.delete(AudioFile, { audioSectionId: section.id });
                await trans.remove(section);
            }

            section = await trans.save(AudioSection, trans.create(AudioSection, {
                title: getFilenameWithoutExtension(narrationStoragePath),
                content,
                sequence,
            }));

            await trans.save(mgr.create(AudioFile, {
                type: "narration",
                format: AudioFormat.Original,
                bucket: config.s3.stagingBucket,
                storagePath: narrationStoragePath,
                audioSection: section,
            }));

            if (soundtrackStoragePath) {
                await trans.save(mgr.create(AudioFile, {
                    type: "soundtrack",
                    format: AudioFormat.Original,
                    bucket: config.s3.stagingBucket,
                    storagePath: soundtrackStoragePath,
                    audioSection: section,
                }));
            }

            const formats = this._audio.supportedFormats();
            const typesAndSizes: Array<{ type: AudioProfile; size: number }> = [{ type: "narration", size: narrationSize }];
            if (soundtrackStoragePath) typesAndSizes.push({ type: "soundtrack", size: typeof soundtrackSize === "number" ? soundtrackSize : 0 });

            // The total number of audio file encodings that will be created by all sections.
            const totalFiles = totalNumOfSections * formats.length * typesAndSizes.length;

            const audioSectionId = section.id;
            const completionQueueUrl = await this._queue.getQueueUrl(QueueType.EndAudioEncoding);

            const audioEncodingMessages: AudioEncodingQueueMessage[] = [];
            const largeAudioEncodingMessages: LargeAudioEncodingQueueMessage[] = [];
            const largeAudioThreshold = config.import.largeFileThresholdSize;
            for (const { type, size } of typesAndSizes) {
                const storagePath = type === "soundtrack" && soundtrackStoragePath ? soundtrackStoragePath : narrationStoragePath;

                for (const format of formats) {
                    const message = {
                        contentId,
                        audioSectionId,
                        sourceStoragePath: storagePath,
                        format: toDbAudioFormat(format),
                        totalFiles,
                        type,
                        sourceBucket: config.s3.stagingBucket,
                        destinationBucket: config.s3.bucket,
                        destinationContentType: format.mimeType,
                        destinationMetadata: {
                            originalFile: storagePath,
                            contentId: DataProtection.encryptId(NodeType.Content, content.id),
                        },
                        destinationStoragePath: _getNewAudioFileStorageKey(content.organisationId, content.id, sequence, type, format.suffixAndExtension),
                        completionQueueUrl,
                        completionQueue: QueueType.EndAudioEncoding as QueueType.EndAudioEncoding,
                    };
                    if (size < largeAudioThreshold) {
                        audioEncodingMessages.push({
                            queue: QueueType.AudioEncoding as QueueType.AudioEncoding,
                            ...message,
                        });
                    } else {
                        largeAudioEncodingMessages.push({
                            queue: QueueType.LargeAudioEncoding as QueueType.LargeAudioEncoding,
                            ...message,
                        });
                    }
                }
            }

            await this._queue.addMessages(QueueType.AudioEncoding, audioEncodingMessages);
            await this._queue.addMessages(QueueType.LargeAudioEncoding, largeAudioEncodingMessages);
        });
    }

    // Used for large files, and also when config.app.useLambdaForAudioEncoding is false
    async doAudioEncoding(message: AudioEncodingQueueMessage | LargeAudioEncodingQueueMessage) {
        const s3 = getS3();
        const tempFileHelper = new TempFileHelper(config.runtime.tempDirectory);

        try {
            const format = fromDbAudioFormat(message.format);
            if (!format) return;

            const filename = getFilename(message.sourceStoragePath);
            const tmpPath = tempFileHelper.getFullPath(filename);
            await downloadToFile(message.sourceBucket, message.sourceStoragePath, tmpPath);

            const outputPath = tempFileHelper.getFullPath(changeExtension(filename, format.suffixAndExtension));
            try {
                await this._audio.convert(tmpPath, outputPath, format, message.type);
            } catch (err) {
                log.e(`Error while converting audio file to format ${format.suffixAndExtension}. sectionId: ${message.audioSectionId}, type: ${message.type}`, err);
                throw err;
            }

            await s3.putObject({
                Bucket: message.destinationBucket,
                Key: message.destinationStoragePath,
                Body: fs.createReadStream(outputPath),
                ContentType: message.destinationContentType,
                Metadata: message.destinationMetadata,
            }).promise();

            await this._queue.addMessage({
                ...message,
                queue: QueueType.EndAudioEncoding,
                fileBytes: await getFileBytes(outputPath),
                duration: await this._audio.getDurationFromHeader(outputPath),
            });

        } finally {
            tempFileHelper.cleanup();
        }
    }

    async endAudioEncoding(contentId: number, audioSectionId: number, bucket: string, fileStoragePath: string, fileBytes: number, duration: number, dbAudioFormat: AudioFormat, type: "narration" | "soundtrack", totalFiles: number) {

        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { relations: ["import"] });
        if (!content) return;

        const s3 = getS3();

        await mgr.transaction("READ COMMITTED", async trans => {
            // Remove existing file from possible previously failed import (if the existing storage path is different)
            const existingFile = await trans.findOne(AudioFile, { where: { audioSectionId, format: dbAudioFormat, type } });
            if (existingFile) {
                if (existingFile.storagePath && existingFile.bucket && (existingFile.storagePath !== fileStoragePath || existingFile.bucket !== bucket)) {
                    s3.deleteObject(
                        {
                            Bucket: existingFile.bucket,
                            Key: existingFile.storagePath,
                        },
                        err => {
                            if (err) {
                                log.w("Error deleting replaced audio file.", err);
                            }
                        });
                }

                await trans.remove(existingFile);
            }

            if (type === "narration") {
                await trans.update(AudioSection, audioSectionId, { approximateDuration: duration });
            }

            await trans.save(AudioFile, trans.create(AudioFile, {
                audioSectionId,
                type,
                format: dbAudioFormat,
                bytes: fileBytes,
                bucket,
                storagePath: fileStoragePath,
            }));
        });

        await this._checkIfImportIsComplete(content, totalFiles);
    }

    private async _checkIfImportIsComplete(content: Content, totalFiles: number): Promise<void> {

        const mgr = getManager();
        const contentId = content.id;

        // Fetch all audio files
        const allFiles = await mgr.createQueryBuilder(AudioFile, "af")
            .innerJoin("af.audioSection", "sec", "sec.contentId = :contentId", { contentId })
            .getMany();

        const encodedFiles = allFiles.filter(f => f.format !== AudioFormat.Original);

        if (encodedFiles.length < totalFiles) {
            return;
        }

        const summaries: AudioSummary[] = [];
        const types: AudioProfile[] = ["narration"];
        if (content.hasSoundtrack) types.push("soundtrack");

        for (const type of types) {
            for (const format of this._audio.supportedFormats()) {

                const dbFormat = toDbAudioFormat(format);
                const totalBytes = encodedFiles.filter(f => f.format === dbFormat && f.type === type)
                    .map(f => f.bytes)
                    .reduce((prev, curr) => (prev + curr));

                summaries.push(mgr.create(AudioSummary, {
                    format: dbFormat,
                    type,
                    totalBytes,
                    content,
                }));
            }
        }

        await mgr.transaction("READ COMMITTED", async trans => {

            // Delete any existing summaries for the content (possible from a previously failed attempt)
            await trans.delete(AudioSummary, { contentId });
            await trans.save(summaries);

            if (content.import) {
                await trans.update(Import, content.import.id, { status: ImportStatus.Done, message: "" });
            }

            const audioSections = await mgr.createQueryBuilder(AudioSection, "sec").where("contentId = :contentId", { contentId }).getMany();
            const totalDuration = audioSections.map(f => f.approximateDuration).reduce((prev, curr) => (prev + curr));
            await trans.update(Content, content.id, { status: ContentStatus.Available, totalDuration });
        });

        const org = await mgr.findOne(Organisation, content.organisationId);
        const orgName = org ? org.name : "";
        const importStoragePrefix = content.import ? content.import.importStoragePrefix : content.title;

        await this._email.sendImportSucceeded(await this._getImportNotificationEmailAddresses(content.organisationId), importStoragePrefix, orgName);
    }

    private async _importContent(i: Import, org: Organisation, isbn: string | undefined, stagedCoverImageKey: string, hasSoundtrack: boolean, audioSections: Array<{ sequence: number; narrationKey: string; narrationSize: number; soundtrackKey: string | undefined; soundtrackSize: number | undefined }>) {

        const mgr = getManager();

        let content = i.contentId ? await mgr.findOne(Content, i.contentId) : undefined;

        let title = getLastDirectoryName(i.stagingStoragePrefix);
        if (!title) title = `New Content ${new Date().toISOString()}`;

        if (!content) {
            content = await mgr.transaction(async trans => {
                const c = await trans.save(trans.create(Content, {
                    import: i,
                    organisation: org,
                    title,
                    description: i.stagingStoragePrefix,
                    subtitle: isbn || "",
                    status: ContentStatus.Importing,
                    genre: await this._referenceData.getDefaultGenre(),
                    language: await this._referenceData.getDefaultLanguage(),
                    hasSoundtrack,
                }));

                await trans.update(Import, i.id, { contentId: c.id });
                i.contentId = c.id;
                return c;
            });
        }

        if (stagedCoverImageKey) {
            // TODO: Do we need to process the cover image and put it in its own queue?
            // Copy the cover image to the app's primary bucket.
            const coverImageStoragePath = _getNewCoverImageStorageKey(org, content.id, getFileExtensionWithoutDot(stagedCoverImageKey));

            const s3 = getS3();
            await s3.copyObject({
                Bucket: config.s3.bucket,
                CopySource: `/${config.s3.stagingBucket}/${stagedCoverImageKey}`,
                Key: coverImageStoragePath,
            }).promise();

            await mgr.createQueryBuilder(Content, "c").update().set({ coverImageStoragePath }).where({ id: content.id }).execute();
        }
        // Queue a message for each audio file to be processed.
        const contentId = content.id;
        const pipelineId = `${crypto.randomBytes(4).toString("hex")}_${new Date().toISOString()}`;

        await this._queue.addMessages(QueueType.ProcessAudioSection, audioSections.map<ProcessAudioSectionQueueMessage>(audioSection => (
            {
                queue: QueueType.ProcessAudioSection,
                pipelineId,
                contentId,
                sequence: audioSection.sequence,
                originalNarrationStoragePath: audioSection.narrationKey,
                originalNarrationSize: audioSection.narrationSize,
                originalSoundtrackStoragePath: audioSection.soundtrackKey,
                originalSoundtrackSize: audioSection.soundtrackSize,
                totalSections: audioSections.length,
            })));

        // TODO: Put a lock on all files to avoid them being deleted. Can we use object retention? https://docs.aws.amazon.com/AmazonS3/latest/dev/object-lock-managing.html
        // s3.putBucketPolicy({
        //     Bucket: config.s3.stagingBucket,
        //     Policy: {
        //         //TODO
        //     },
        // });
    }

    private _validateImportFilesAndExtractStructure(org: Organisation, objects: Array<{ key: string; size: number }>): {
        errors: string[];
        stagedCoverImageKey: string;
        hasSoundtrack: boolean;
        isbn: string | undefined;
        audioSections: Array<{ sequence: number; narrationKey: string; narrationSize: number; soundtrackKey: string | undefined; soundtrackSize: number | undefined }>;
    } {

        let stagedCoverImageKey = "";
        const errors: string[] = [];

        const narrationFilenameRegex = RegExp(org.importNarrationFilenameRegex || config.import.defaultNarrationFileRegex, "i");
        const soundtrackFilenameRegex = RegExp(org.importSoundtrackFilenameRegex || config.import.defaultSoundtrackFileRegex, "i");
        const coverImageFilenameRegex = new RegExp(org.importCoverImageFilenameRegex || config.import.defaultCoverImageFileRegex, "i");

        const narrationObjects: Array<{ key: string; size: number }> = [];
        const soundtrackObjects: Array<{ key: string; size: number }> = [];

        for (const obj of objects.sort((a, b) => a.key.localeCompare(b.key))) {

            const filename = getFilename(obj.key);
            if (!filename) continue;

            const isNarration = narrationFilenameRegex.test(filename);
            const isSoundtrack = soundtrackFilenameRegex.test(filename);
            const isCover = coverImageFilenameRegex.test(filename);

            const matchCount = [isNarration, isCover, isSoundtrack].filter(b => b).length;
            if (matchCount === 0) {
                errors.push(`Unrecognized filename format '${filename}' does not match any of the import file patterns: '${narrationFilenameRegex.source}' or '${coverImageFilenameRegex.source}'`);
                continue;
            }

            if (obj.size > config.import.maxImportFileSize) {
                errors.push(`File '${filename}' exceeds the maximum allowed file size of ${config.import.maxImportFileSize}. Size: ${obj.size}`);
                continue;
            }

            if (matchCount > 1) {
                if (isSoundtrack && isNarration && !isCover) {
                    // If the filename matches both soundtrack and narration, then this assumes it's a soundtrack.
                } else {
                    const matchedPatterns: string[] = [];
                    if (isNarration) matchedPatterns.push(narrationFilenameRegex.source);
                    if (isSoundtrack) matchedPatterns.push(soundtrackFilenameRegex.source);
                    if (isCover) matchedPatterns.push(coverImageFilenameRegex.source);
                    errors.push(`Invalid filename format '${filename}' matches more than one file pattern: '${matchedPatterns.join("', '")}'`);
                    continue;
                }
            }

            if (isCover) {
                stagedCoverImageKey = obj.key;
                continue;
            } else if (isSoundtrack) {
                soundtrackObjects.push(obj);
            } else {
                narrationObjects.push(obj);
            }
        }

        if (!stagedCoverImageKey) {
            errors.push(`No cover image found matching the required pattern: ${coverImageFilenameRegex.source}`);
        }

        if (!narrationObjects.length) {
            errors.push(`No narration files found matching the required pattern: ${narrationFilenameRegex.source}`);
        }

        if (soundtrackObjects.length && narrationObjects.length !== soundtrackObjects.length) {
            errors.push(`Inconsistent number of narration and soundtrack files. Narration: ${narrationObjects.length}, Soundtrack: ${soundtrackObjects.length}`);
        }

        const audioSections: Array<{ sequence: number; narrationKey: string; narrationSize: number; soundtrackKey: string | undefined; soundtrackSize: number | undefined }> = [];
        for (let i = 0; i < narrationObjects.length; i++) {
            audioSections.push({
                sequence: i,
                narrationKey: narrationObjects[i].key,
                narrationSize: narrationObjects[i].size,
                soundtrackKey: soundtrackObjects.length ? soundtrackObjects[i].key : undefined,
                soundtrackSize: soundtrackObjects.length ? soundtrackObjects[i].size : undefined,
            });
        }

        // TODO: use capture groups to parse out the ISBN?
        const isbn = undefined;

        return {
            errors,
            audioSections,
            isbn,
            hasSoundtrack: !!soundtrackObjects.length,
            stagedCoverImageKey,
        };
    }

    private async _getImportNotificationEmailAddresses(organisationId: number): Promise<Array<{ email: string; firstName: string; lastName: string }>> {
        const result = [
            ...config.import.notificationEmailAddresses.map(e => ({
                email: e,
                firstName: "",
                lastName: "",
            })),
        ];

        const mgr = getManager();

        // Get org admins to notify.
        const admins = await mgr.createQueryBuilder(User, "u")
            .innerJoin("u.userRoles", "r", "r.organisationId = :organisationId and r.type = :roleType", { organisationId, roleType: RoleType.OrganisationAdmin })
            .getMany();

        for (const user of admins) {
            const email = DataProtection.decryptEmail(user.email);
            result.push({
                email,
                firstName: user.firstName,
                lastName: user.lastName,
            });
        }

        return result;
    }

    private _getKeysGroupedByFolder(keys: string[]): Map<string, string[]> {
        const keysGroupedByFolder = new Map<string, string[]>();

        for (const key of keys) {
            const folder = getDirectoryName(key);

            const files = keysGroupedByFolder.get(folder);
            if (files) {
                files.push(key);
            } else {
                keysGroupedByFolder.set(folder, [key]);
            }
        }

        return keysGroupedByFolder;
    }
}

function _getStagingStoragePrefix(org: Organisation, timestampReference: Date, importStoragePrefix: string): string {
    return `${org.importStorageBucket}/${timestampReference.toISOString()}/${importStoragePrefix}`;
}

function _getArchiveStoragePrefix(archivePrefix: string, timestampReference: Date, importStoragePrefix: string): string {
    return `${archivePrefix}/${timestampReference.toISOString()}/${importStoragePrefix}`;
}

function _getNewCoverImageStorageKey(org: Organisation, contentId: number, fileExtensionWithoutDot: string): string {
    const orgId = DataProtection.encryptId(NodeType.Organisation, org.id);
    const cId = DataProtection.encryptId(NodeType.Content, contentId);
    const imageId = crypto.randomBytes(16).toString("hex");
    return `images/${orgId}/${cId}/${imageId}.${fileExtensionWithoutDot}`;
}

function _getNewAudioFileStorageKey(organisationId: number, contentId: number, sequence: number, type: "narration" | "soundtrack", suffixAndExtension: string): string {
    const orgId = DataProtection.encryptId(NodeType.Organisation, organisationId);
    const cId = DataProtection.encryptId(NodeType.Content, contentId);
    const audioId = crypto.randomBytes(16).toString("hex");
    return `audio/${orgId}/${cId}/${sequence}_${type}_${audioId}.${suffixAndExtension}`;
}
