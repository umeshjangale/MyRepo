import { inject, injectable } from "inversify";
import { Brackets, getManager } from "typeorm";

import { ContentAccessSource } from "../graphql/type-defs/types";
import { FACTORY_SYMBOLS } from "../runtime/symbols";
import { OperationResult } from "../types/operation-result";
import { EMPTY_PAGINATED, Paginated } from "../types/paginated";

import { BaseStorage } from "./base-storage";
import { Content, ContentCollection, Genre, Language, Organisation, RoleType, User, UserGroup } from "./db-entities";
import { AccessSource, ContentStatus } from "./db-entities/enums";
import { UserContentAccess } from "./db-entities/user-content-access";
import { UserContentAccessLog } from "./db-entities/user-content-access-log";
import { getManageableOrganisationIdsForUser, getOrganisationUser, hasDeletedRows, hasPermission, isSysAdmin } from "./helpers/db-helper";
import { NotificationStorage } from "./notification-storage";
import { ContentUpdateModel } from "./types/content-update-model";

@injectable()
export class ContentStorage extends BaseStorage {

    constructor(@inject(FACTORY_SYMBOLS.NotificationStorage) private readonly _notificationFactory: () => NotificationStorage) {
        super();
    }

    async getContent(currentUser: User, contentId: number): Promise<Content | null> {

        const content = await getManager().createQueryBuilder(Content, "content")
            .leftJoinAndSelect("content.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id })
            .where("content.id = :contentId", { contentId })
            .andWhere("content.deletedDateUtc is null")
            .getOne();

        if (!content || content.status === ContentStatus.Importing) return null;

        if (content.userContentAccess && content.userContentAccess.length) {
            return content;
        }

        if (hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return content;
        }

        return null;
    }

    async getContentList(currentUser: User, ids: number[]): Promise<Array<Content | null>> {

        const contentList = await getManager().createQueryBuilder(Content, "content")
            .leftJoinAndSelect("content.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id })
            .where("content.id in (:ids)", { ids })
            .andWhere("content.deletedDateUtc is null")
            .getMany();

        return super.orderRowsByIds(ids, contentList, async c => {

            if (c.status === ContentStatus.Importing) return false;
            if (c.userContentAccess && c.userContentAccess.length) return true;
            if (hasPermission(currentUser, RoleType.OrganisationAdmin, c.organisationId)) return true;

            return false;
        });
    }

    async softDeleteContent(currentUser: User, contentId: number): Promise<OperationResult<number, "invalid-permissions">> {

        const mgr = getManager();
        return mgr.transaction("READ COMMITTED", async trans => {

            const content = await trans.findOne(Content, contentId);
            if (!content || !hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return OperationResult.invalidPermissions();

            const access = await trans.createQueryBuilder(UserContentAccess, "uca")
                .setLock("pessimistic_write")
                .where("uca.contentId = :contentId", { contentId })
                .getMany();

            if (access && access.length) {
                // Log access revoked.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    access.map(a => ({
                        contentId,
                        userId: a.userId,
                        action: "access-revoked",
                        eventData: JSON.stringify({
                            reason: "content deleted",
                            via: a.source,
                            contentCollectionId: a.contentCollectionId || undefined,
                            userGroupId: a.userGroupId || undefined,
                        }),
                    })),
                ).execute();
            }

            /**
             * Remove all relations except:
             *    userContent
             *    playbackLogs
             *    accessLogs
             *    import
             *
             * These can be cleaned up during a hard delete.
             */

            await trans.query("DELETE FROM `user_content_access` WHERE `contentId` = ?", [contentId]);
            await trans.query("DELETE FROM `content_collection_item` WHERE `contentId` = ?", [contentId]);
            await trans.query("DELETE FROM `user_group_content` WHERE `contentId` = ?", [contentId]);

            // A non null deleted date indicates the content is soft deleted.
            await trans.update(Content, contentId, { deletedDateUtc: new Date() });

            return OperationResult.as(content.organisationId);
        });
    }

    /** Searches content available to the current user and returns the content only */
    async searchContent(currentUser: User, pageSize: number, pageNumber: number): Promise<Paginated<Content>> {

        const [content, totalCount] = await getManager().createQueryBuilder(Content, "content")
            .innerJoin("content.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id })
            .where("content.status = :status", { status: ContentStatus.Available })
            .andWhere("content.deletedDateUtc is null")
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    /** Searches content assigned a user (optionally filtered by an organisation) and returns the content and all content access rows.  */
    async searchContentAssignedToUser(currentUser: User, userId: number, withinOrganisationId: number | null, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const mgr = getManager();

        if (withinOrganisationId) {
            return this.searchContentAssignedToUserWithinOrganisation(currentUser, userId, withinOrganisationId, pageSize, pageNumber, searchText);
        } else {

            const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
            if (!user) return EMPTY_PAGINATED;

            let query = mgr.createQueryBuilder(Content, "content")
                .innerJoinAndSelect("content.userContentAccess", "uca", "uca.userId = :userId", { userId: user.id })
                .where("content.title like :textPattern", { textPattern: `%${searchText}%` });

            if (!isSysAdmin(currentUser) || !isSysAdmin(user)) {
                const orgIds = getManageableOrganisationIdsForUser(currentUser, user);
                if (!orgIds) return EMPTY_PAGINATED;
                query = query.andWhere("content.organisationId in (:orgIds)", { orgIds });
            }

            const [content, totalCount] = await query
                .skip((pageNumber - 1) * pageSize)
                .take(pageSize)
                .getManyAndCount();

            return {
                items: content,
                totalCount,
            };
        }
    }

    async hasDirectAccess(currentUser: User, userId: number, contentId: number): Promise<OperationResult<boolean, "invalid-permissions">> {
        const mgr = getManager();

        const content = await mgr.findOne(Content, contentId);
        if (!content || !hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return OperationResult.invalidPermissions();

        const count = await mgr.createQueryBuilder(UserContentAccess, "uca")
            .where("uca.contentId = :contentId", { contentId })
            .andWhere("uca.userId = :userId", { userId })
            .andWhere("uca.source = :source", { source: AccessSource.Direct })
            .getCount();

        return OperationResult.as(count > 0);
    }

    async searchPotentialUsersToDirectlyAccessContent(currentUser: User, contentId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content || !hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return EMPTY_PAGINATED;

        const includeSysAdmins = isSysAdmin(currentUser);

        let query = getManager().createQueryBuilder(User, "user")
            .innerJoin("user.userRoles", "role")
            .leftJoin("user.userContentAccess", "uca", "uca.contentId = :contentId AND uca.source = :source", { contentId, source: AccessSource.Direct });

        if (includeSysAdmins) {
            query = query.where(new Brackets(qb =>
                qb.where("role.organisationId = :orgId", { orgId: content.organisationId })
                    .orWhere("role.type = :type", { type: RoleType.SystemAdmin }),
            ));
        } else {
            query = query.where("role.organisationId = :orgId", { orgId: content.organisationId });
        }

        const [users, totalCount] = await query
            .andWhere("uca.contentId is null")
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async searchUsersWithAccessToContent(currentUser: User, contentId: number, accessSource: AccessSource | undefined, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const content = await getManager().findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content || !hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return EMPTY_PAGINATED;

        let query = getManager().createQueryBuilder(User, "user")
            .innerJoinAndSelect("user.userContentAccess", "uca")
            .where("uca.contentId = :contentId", { contentId });

        if (accessSource) {
            query = query.andWhere("uca.source = :accessSource", { accessSource });
        }

        const [users, totalCount] = await query
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async searchPotentialContentCollectionsForContent(currentUser: User, contentId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {
        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return EMPTY_PAGINATED;
        }

        const [cc, totalCount] = await mgr.createQueryBuilder(ContentCollection, "cc")
            .leftJoin("cc.content", "content", "content.id = :contentId", { contentId })
            .where("cc.organisationId = :orgId", { orgId: content.organisationId })
            .andWhere("content.id is null")
            .andWhere("cc.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    async searchContentCollectionsWithContent(currentUser: User, contentId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<ContentCollection>> {
        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return EMPTY_PAGINATED;
        }

        const [cc, totalCount] = await mgr.createQueryBuilder(ContentCollection, "cc")
            .innerJoinAndSelect("cc.content", "c")
            .where("c.id = :contentId", { contentId })
            .andWhere("cc.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: cc,
            totalCount,
        };
    }

    async searchPotentialUserGroupsForContent(currentUser: User, contentId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {
        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return EMPTY_PAGINATED;
        }

        const [groups, totalCount] = await mgr.createQueryBuilder(UserGroup, "g")
            .leftJoin("g.content", "content", "content.id = :contentId", { contentId })
            .where("g.organisationId = :orgId", { orgId: content.organisationId })
            .andWhere("content.id is null")
            .andWhere("g.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: groups,
            totalCount,
        };
    }

    async searchUserGroupsWithAccessToContent(currentUser: User, contentId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {
        const mgr = getManager();
        const content = await mgr.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return EMPTY_PAGINATED;
        }

        const [userGroups, totalCount] = await mgr.createQueryBuilder(UserGroup, "ug")
            .innerJoinAndSelect("ug.content", "c")
            .where("c.id = :contentId", { contentId })
            .andWhere("ug.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: userGroups,
            totalCount,
        };
    }

    async searchUserGroupsMakingContentAccessibleToUser(currentUser: User, contentId: number, userId: number, pageSize: number, pageNumber: number): Promise<Paginated<UserGroup>> {
        const mgr = getManager();

        const content = await mgr.findOne(Content, contentId);
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) { return EMPTY_PAGINATED; }

        const [userGroups, totalCount] = await mgr.createQueryBuilder(UserGroup, "ug")
            .innerJoin("ug.userContentAccess", "uca")
            .where("uca.contentId = :contentId", { contentId })
            .andWhere("uca.userId = :userId", { userId })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: userGroups,
            totalCount,
        };
    }

    async searchContentCollectionsMakingContentAccessibleToUser(currentUser: User, contentId: number, userId: number, pageSize: number, pageNumber: number): Promise<Paginated<ContentCollection>> {
        const mgr = getManager();

        const content = await mgr.findOne(Content, contentId);
        if (!content) return EMPTY_PAGINATED;

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) { return EMPTY_PAGINATED; }

        const [contentCollections, totalCount] = await mgr.createQueryBuilder(ContentCollection, "cc")
            .innerJoin("cc.userContentAccess", "uca")
            .where("uca.contentId = :contentId", { contentId })
            .andWhere("uca.userId = :userId", { userId })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: contentCollections,
            totalCount,
        };
    }

    async updateContent(currentUser: User, id: number, updateModel: ContentUpdateModel):
        Promise<OperationResult<Content, "invalid-permissions" | "content-not-found" | "invalid-genre" | "invalid-second-genre" | "invalid-language" | "non-billable-reason-required">> {

        const manager = getManager();

        // Check current users permission for the content.
        const content = await manager.findOne(Content, id, { where: { deletedDateUtc: null } });
        if (!content) return OperationResult.error("content-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return OperationResult.invalidPermissions();

        if (updateModel.genreCode) {
            const genre = await manager.findOne(Genre, { code: updateModel.genreCode });
            if (!genre) return OperationResult.error("invalid-genre");
        }

        if (updateModel.secondGenreCode) {
            const genre = await manager.findOne(Genre, { code: updateModel.secondGenreCode });
            if (!genre) return OperationResult.error("invalid-second-genre");
        }

        if (updateModel.languageCode) {
            const l = await manager.findOne(Language, { code: updateModel.languageCode });
            if (!l) return OperationResult.error("invalid-language");
        }

        if (updateModel.nonBillable !== undefined || updateModel.nonBillableReason) {
            if (!isSysAdmin(currentUser)) {
                return OperationResult.invalidPermissions();
            }

            if (updateModel.nonBillable) {
                if (!updateModel.nonBillableReason || !updateModel.nonBillableReason.trim()) {
                    return OperationResult.error("non-billable-reason-required");
                }
            } else {
                updateModel.nonBillableReason = "";
            }
        }

        // A bug in typeorm means passing an object with a property set as undefined will try to update the database column to null. https://github.com/typeorm/typeorm/issues/2331
        // So this avoids defining undefined properties...sigh
        const updateValues: any = {};
        for (const prop of Object.keys(updateModel)) {
            const val = updateModel[prop];
            if (typeof val !== "undefined") updateValues[prop] = val;
        }

        // Do nothing if nothing to update.
        if (Object.keys(updateValues).length === 0) return OperationResult.as(content);

        await manager.createQueryBuilder().update(Content).set(updateValues).where("id = :id", { id: content.id }).execute();

        const updatedContent = await manager.findOne(Content, id);

        // The small chance someone else has deleted the content during this update.
        if (!updatedContent) return OperationResult.error("content-not-found");
        return OperationResult.as(updatedContent);
    }

    async addUserAccess(currentUser: User, contentId: number, userId: number)
        : Promise<OperationResult<{ user: User; content: Content }, "invalid-permissions" | "content-not-found" | "user-not-found">> {

        const manager = getManager();

        // Check current users permission for the content.
        const content = await manager.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content) return OperationResult.error("content-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return OperationResult.invalidPermissions();

        return manager.transaction("READ COMMITTED", async trans => {

            // Ensure the user is associated with the same organisation and add a shared lock to the role relation.
            const user = await getOrganisationUser(trans, userId, content.organisationId, true);
            if (!user) return OperationResult.error("user-not-found");

            try {
                // Give the user access to the content.
                await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                    {
                        contentId: content.id,
                        userId: user.id,
                        source: AccessSource.Direct,
                    },
                ).execute();
            } catch (err) {
                if (err && err.code === "ER_DUP_ENTRY") {
                    // If the user is already has access, return a successful result i.e no error.
                    return OperationResult.as({ user, content });
                }

                throw err;
            }

            // Record access.
            await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                {
                    contentId: content.id,
                    userId: user.id,
                    action: "access-granted",
                    eventData: JSON.stringify({ via: AccessSource.Direct }),
                },
            ).execute();

            // Queue a notification.
            this._notificationFactory().queueNewContent(user.id, content.id, content.organisationId);

            return OperationResult.as({ user, content });
        });
    }

    async removeUserAccess(currentUser: User, contentId: number, userId: number)
        : Promise<OperationResult<{ user: User; content: Content }, "invalid-permissions" | "content-not-found" | "user-not-found">> {

        const manager = getManager();

        // Check current users permission for the content.
        const content = await manager.findOne(Content, contentId);
        if (!content) return OperationResult.error("content-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) return OperationResult.invalidPermissions();

        // Ensure the user is associated with the same organisation
        const user = await getOrganisationUser(manager, userId, content.organisationId);
        if (!user) return OperationResult.error("user-not-found");

        await manager.transaction("READ COMMITTED", async trans => {

            const deleteResult = await trans.createQueryBuilder().delete().from(UserContentAccess)
                .where("contentId = :contentId", { contentId: content.id })
                .andWhere("userId = :userId", { userId: user.id })
                .andWhere("source = 'direct'")
                .execute();

            if (hasDeletedRows(deleteResult)) {
                // Record access.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    {
                        contentId: content.id,
                        userId: user.id,
                        action: "access-revoked",
                        eventData: JSON.stringify({ via: AccessSource.Direct }),
                    },
                ).execute();
            }
        });

        return OperationResult.as({ user, content });
    }

    private async searchContentAssignedToUserWithinOrganisation(currentUser: User, userId: number, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const mgr = getManager();
        // Search within the context of the organisation
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return EMPTY_PAGINATED;

        // Ensure the user is associated with the given organisation.
        const user = await getOrganisationUser(mgr, userId, organisationId);
        if (!user) return EMPTY_PAGINATED;

        const [content, totalCount] = await mgr.createQueryBuilder(Content, "content")
            .innerJoinAndSelect("content.userContentAccess", "uca", "uca.userId = :userId", { userId: user.id })
            .where("content.organisationId = :organisationId", { organisationId })
            .andWhere("content.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }
}
