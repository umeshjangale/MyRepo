import { injectable } from "inversify";
import { getManager } from "typeorm";

import { BaseStorage } from "./base-storage";
import { Genre, Language } from "./db-entities";

@injectable()
export class ReferenceDataStorage extends BaseStorage {

    async getLanguage(code: string): Promise<Language | undefined> {
        const lang = await getManager().findOne(Language, { code });
        return lang;
    }

    async getLanguages(): Promise<Language[]> {
        const langs = await getManager().createQueryBuilder(Language, "l").orderBy("sortOrder").getMany();
        return langs;
    }

    async getGenre(code: string): Promise<Genre | undefined> {
        const g = await getManager().findOne(Genre, { code });
        return g;
    }

    async getGenres(): Promise<Genre[]> {
        const genres = await getManager().createQueryBuilder(Genre, "g").orderBy("sortOrder").getMany();
        return genres;
    }

    async getDefaultGenre(): Promise<Genre> {
        const g = await getManager().createQueryBuilder(Genre, "g").orderBy("sortOrder").getOne();
        if (!g) throw new Error("No genres found in database.");
        return g;
    }

    async getDefaultLanguage(): Promise<Language> {
        const l = await getManager().createQueryBuilder(Language, "g").orderBy("sortOrder").getOne();
        if (!l) throw new Error("No languages found in database.");
        return l;
    }
}
