-- Create a sproc which duplicates DB content. Useful for creating lots of data to load test with.

/*
DROP procedure duplicate_content_rows

CALL duplicate_content_rows();
*/

DELIMITER $$
CREATE PROCEDURE duplicate_content_rows()
BEGIN
DECLARE _contentId INT DEFAULT 1;
DECLARE _new_content_id INT DEFAULT 0;

DECLARE i INT DEFAULT 1;

WHILE i <= 100000 DO

		INSERT INTO `titleshare-dev-loadtest`.`import`
		(
		`timestampReference`,
		`status`,
		`message`,
		`importStoragePrefix`,
		`stagingStoragePrefix`,
		`lastFileModifiedDateUtc`,
		`organisationId`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`,
		`contentId`)
		SELECT `timestampReference`,
		`status`,
		`message`,
		`importStoragePrefix`,
		`stagingStoragePrefix`,
		`lastFileModifiedDateUtc`,
		`organisationId`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`,
		0
		FROM `import`
		WHERE contentId =_contentId;

		INSERT INTO `content` ( `content`.`title`,
			`content`.`subtitle`,
			`content`.`author`,
			`content`.`narrator`,
			`content`.`publisher`,
			`content`.`releaseDate`,
			`content`.`totalDuration`,
			`content`.`hasSoundtrack`,
			`content`.`languageCode`,
			`content`.`genreCode`,
			`content`.`secondGenreCode`,
			`content`.`type`,
			`content`.`organisationId`,
			`content`.`createdDateUtc`,
			`content`.`lastUpdatedDateUtc`,
			`content`.`coverImageStoragePath`,
			`content`.`status`,
			`content`.`importId`,
			`content`.`description`)
		SELECT 
			`content`.`title`,
			`content`.`subtitle`,
			`content`.`author`,
			`content`.`narrator`,
			`content`.`publisher`,
			`content`.`releaseDate`,
			`content`.`totalDuration`,
			`content`.`hasSoundtrack`,
			`content`.`languageCode`,
			`content`.`genreCode`,
			`content`.`secondGenreCode`,
			`content`.`type`,
			`content`.`organisationId`,
			`content`.`createdDateUtc`,
			`content`.`lastUpdatedDateUtc`,
			`content`.`coverImageStoragePath`,
			`content`.`status`,
			LAST_INSERT_ID(),
			`content`.`description`
		FROM `titleshare-dev-loadtest`.`content` WHERE id = _contentId;

		SET _new_content_id = LAST_INSERT_ID();

		INSERT INTO `titleshare-dev-loadtest`.`audio_summary`
		(
		`type`,
		`format`,
		`totalBytes`,
		`contentId`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`)
		SELECT
		`type`,
		`format`,
		`totalBytes`,
		 _new_content_id,
		`createdDateUtc`,
		`lastUpdatedDateUtc`
		FROM `audio_summary`
		where contentId = _contentId;

		INSERT INTO `titleshare-dev-loadtest`.`audio_section`
		(
		`title`,
		`sequence`,
		`approximateDuration`,
		`contentId`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`,
		`versionNumber`)
		SELECT `title`,
		`sequence`,
		`approximateDuration`,
		 _new_content_id,
		`createdDateUtc`,
		`lastUpdatedDateUtc`,
		`versionNumber`
		FROM `audio_section`
		WHERE contentId = _contentId;

		INSERT INTO `titleshare-dev-loadtest`.`content_collection_item`
		(`contentCollectionId`,
		`contentId`)
		SELECT `contentCollectionId`, _new_content_id
		FROM `content_collection_item`
		WHERE contentId = _contentId;
        
        
		INSERT INTO `titleshare-dev-loadtest`.`user_group_content`
		(`userGroupId`,
		`contentId`)
		SELECT `userGroupId`, _new_content_id
		FROM `user_group_content`
		WHERE contentId = _contentId;

		INSERT INTO `titleshare-dev-loadtest`.`user_content_access`
		(
		`userId`,
		`contentId`,
		`source`,
		`userGroupId`,
		`contentCollectionId`,
		`notificationSentDateUtc`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`)
		SELECT `userId`,
		_new_content_id,
		`source`,
		`userGroupId`,
		`contentCollectionId`,
		`notificationSentDateUtc`,
		`createdDateUtc`,
		`lastUpdatedDateUtc`
		FROM `user_content_access`
		WHERE contentId = _contentId;

	SET i = i + 1;
END WHILE;


END$$
DELIMITER ;
