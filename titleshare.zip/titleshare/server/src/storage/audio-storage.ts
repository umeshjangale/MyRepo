import { injectable } from "inversify";
import { getManager } from "typeorm";

import { AudioFormat } from "../audio/audio-format";
import { Paginated } from "../types/paginated";
import { assertNever } from "../utils";

import { BaseStorage } from "./base-storage";
import { AudioFile, AudioFormat as DbAudioFormat, AudioSection, AudioSummary, RoleType, User } from "./db-entities";
import { signUri } from "./helpers/blob-helper";
import { hasPermission } from "./helpers/db-helper";

@injectable()
export class AudioStorage extends BaseStorage {

    async searchAudioSections(currentUser: User, contentId: number, pageSize: number, pageNumber: number): Promise<Paginated<AudioSection>> {

        let query = getManager().createQueryBuilder(AudioSection, "sec")
            .innerJoin("sec.content", "c", "c.id = :contentId", { contentId });

        if (!hasPermission(currentUser, RoleType.SystemAdmin)) {
            query = query.innerJoin("c.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id });
        }

        const [items, totalCount] = await query.orderBy("sec.sequence")
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items,
            totalCount,
        };
    }

    async getSignedAudioUri(currentUser: User, contentId: number, sectionId: number, type: "narration" | "soundtrack", format: DbAudioFormat): Promise<string | null> {
        const mgr = getManager();

        let query = mgr.createQueryBuilder(AudioFile, "af")
            .innerJoin("af.audioSection", "sec", "sec.id = :sectionId", { sectionId })
            .innerJoin("sec.content", "c", "c.id = :contentId", { contentId });

        if (!hasPermission(currentUser, RoleType.SystemAdmin)) {
            query = query.innerJoin("c.userContentAccess", "uca", "uca.userId = :userId", { userId: currentUser.id });
        }

        const file = await query
            .where("af.type = :type", { type })
            .andWhere("af.format = :format", { format })
            .getOne();

        if (!file) return null;
        return signUri(file.bucket, file.storagePath);
    }

    async getTotalBytes(contentId: number, format: DbAudioFormat): Promise<number> {

        // WARN: No authorization is checked here.

        const mgr = getManager();

        const summaries = await mgr.createQueryBuilder(AudioSummary, "s")
            .where("s.contentId = :contentId", { contentId })
            .andWhere("s.format = :format", { format })
            .select(["s.totalBytes"])
            .getMany();

        // Sum soundtrack and narration totals.
        const totalForAllTypes = summaries.map(s => s.totalBytes).reduce((p, c) => p + c);
        return totalForAllTypes;
    }
}
