import crypto from "crypto";
import { inject, injectable, LazyServiceIdentifer } from "inversify";
import { EntityManager, getManager } from "typeorm";

import config from "../config";
import { EmailService } from "../email/email-service";
import { EmailType } from "../email/email-type";
import { ImageService } from "../images/image-service";
import { createLogger } from "../logger";
import { QueueService } from "../queues/queue-service";
import { QueueType } from "../queues/queue-type";
import { FACTORY_SYMBOLS, SYMBOLS } from "../runtime/symbols";
import * as DataProtection from "../security/data-protection";
import { getFilename } from "../utils";

import { BaseStorage } from "./base-storage";
import { Content, Organisation, User, UserRole } from "./db-entities";
import { UserContentAccess } from "./db-entities/user-content-access";
import { downloadToBuffer } from "./helpers/blob-helper";

const log = createLogger("Notification Storage");

@injectable()
export class NotificationStorage extends BaseStorage {

    constructor(
        @inject(new LazyServiceIdentifer(() => SYMBOLS.QueueService)) private readonly _queue: QueueService,
        @inject(SYMBOLS.EmailService) private readonly _email: EmailService,
        @inject(SYMBOLS.ImageService) private readonly _image: ImageService) {
        super();
    }

    /** Asynchronously adds a message to the queue to send an invitation email to a system admin  */
    queueSysAdminInvitation(userId: number): void {
        this._queue.addMessage(
            {
                queue: QueueType.Email,
                userId,
                emailType: EmailType.SysAdminInvitation,
            },
            config.notifications.inviteUserDelayMinutes * 60)
            .catch(err => { log.e(`Error queueing invitation email for user ${userId}`, err); });
    }

    /** Asynchronously adds a message to the queue to send an invitation email to the user */
    queueInvitation(userId: number, organisationId: number): void {
        this._queue.addMessage(
            {
                queue: QueueType.Email,
                userId,
                emailType: EmailType.Invitation,
                organisationId,
            },
            config.notifications.inviteUserDelayMinutes * 60)
            .catch(err => { log.e(`Error queueing invitation email for user ${userId}`, err); });
    }

    /** Asynchronously adds a message to the queue to send the 'set first password' email to the user */
    queueEmailToSetFirstPassword(userId: number, organisationId: number): void {
        this._queue.addMessage(
            {
                queue: QueueType.Email,
                userId,
                emailType: EmailType.SetFirstPassword,
                organisationId,
            },
            config.notifications.setFirstPasswordDelayMinutes * 60)
            .catch(err => { log.e(`Error queueing set-first-password email for user ${userId}`, err); });
    }

    /** Asynchronously adds a message to the queue to send a 'new content' notification email */
    queueNewContent(userId: number, content: number | number[], organisationId: number): void {
        this._queue.addMessage(
            {
                queue: QueueType.Email,
                userId,
                emailType: EmailType.NewContentAvailable,
                content,
                organisationId,
            },
            config.notifications.newContentDelayMinutes * 60)
            .catch(err => {
                const cIds = typeof content === "number" ? content : content.join();
                log.e(`Error queueing new content email for user ${userId}, content ${cIds}`, err);
            });
    }

    async sendSysAdminInvitation(userId: number): Promise<void> {
        const manager = getManager();

        const user = await manager.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return;

        const email = DataProtection.decryptEmail(user.email);
        const createPasswordUrl = await this.getResetPasswordUrl(user, email);

        const newContentIds = await this.getUsersNewContent(userId, null);
        const content = await this.fetchContent(newContentIds);

        await this._email.sendSysAdminInvite(email, user.firstName, user.lastName, content, createPasswordUrl);

        if (!user.inviteSentDateUtc) {
            await manager.createQueryBuilder().update(User).set({ inviteSentDateUtc: new Date(Date.now()) }).where("id = :id", { id: user.id }).execute();
        }

        await this.setNotificationSentDate(userId, newContentIds);
    }

    async sendInvitation(userId: number, organisationId: number): Promise<void> {
        const manager = getManager();

        const org = organisationId
            ? await manager.findOne(Organisation, organisationId)
            : undefined;

        const user = await manager.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return;

        const email = DataProtection.decryptEmail(user.email);
        const createPasswordUrl = await this.getResetPasswordUrl(user, email);

        const newContentIds = await this.getUsersNewContent(userId, organisationId);
        const content = await this.fetchContent(newContentIds);

        const roleName = this.getRoleName(user, organisationId);

        const hasAlreadySetPassword = !!user.firstPasswordSetDateUtc;
        const isSubsequentInviteWithoutPassword = !!user.inviteSentDateUtc && !hasAlreadySetPassword;

        await this._email.sendUserInvite(email, user.firstName, user.lastName, org ? org.name : "", roleName, isSubsequentInviteWithoutPassword, hasAlreadySetPassword, content, createPasswordUrl);

        if (!user.inviteSentDateUtc) {
            await manager.createQueryBuilder().update(User).set({ inviteSentDateUtc: new Date(Date.now()) }).where("id = :id", { id: user.id }).execute();
        }

        await this.setNotificationSentDate(userId, newContentIds);
    }

    async sendEmailToSetFirstPassword(userId: number, organisationId: number): Promise<void> {
        const manager = getManager();

        const org = organisationId
            ? await manager.findOne(Organisation, organisationId)
            : undefined;

        const user = await manager.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return;

        const email = DataProtection.decryptEmail(user.email);
        const createPasswordUrl = await this.getResetPasswordUrl(user, email);

        const hasAlreadySetPassword = !!user.firstPasswordSetDateUtc;
        const isSubsequentEmailWithoutPassword = !!user.inviteSentDateUtc && !hasAlreadySetPassword;

        await this._email.sendEmailToSetFirstPassword(email, user.firstName, user.lastName, org ? org.name : "", isSubsequentEmailWithoutPassword, createPasswordUrl);

        if (!user.setPasswordEmailSentDateUtc) {
            await manager.createQueryBuilder().update(User).set({ setPasswordEmailSentDateUtc: new Date(Date.now()) }).where("id = :id", { id: user.id }).execute();
        }
    }

    /**
     * This will send a notification about ALL content available to the user which the user hasn't
     * yet been notified about ONLY if the user hasn't been notified about the given content.
     * This is essentially a way of batching notifications.
     */
    async sendNewContent(userId: number, content: number | number[], organisationId: number): Promise<void> {

        const manager = getManager();

        const user = await manager.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return;

        // User must be sent an invitation first.
        if (!user.inviteSentDateUtc) return;

        const org = await manager.findOne(Organisation, organisationId);
        if (!org) return;

        // Get all content the user hasn't yet been notified about.
        const newContentIds = await this.getUsersNewContent(userId, organisationId);
        if (!newContentIds || !newContentIds.length) return;

        // If there is no new content matching the content ids passed in, assume another queue message already handled the notification.
        const sendNotification = typeof content === "number"
            ? newContentIds.some(id => id === content)
            : newContentIds.some(id => content.some(c => c === id));

        if (!sendNotification) {
            return;
        }

        const roleName = this.getRoleName(user, organisationId);
        const dbContent = await this.fetchContent(newContentIds);

        const email = DataProtection.decryptEmail(user.email);
        await this._email.sendNewContent(email, user.firstName, user.lastName, org.name, roleName, dbContent);

        await this.setNotificationSentDate(userId, newContentIds);
    }

    private async getUsersNewContent(userId: number, organisationId: number | null): Promise<number[]> {

        const manager = getManager();

        // Get all content the user hasn't yet been notified about.
        let query = manager.createQueryBuilder(UserContentAccess, "a");
        if (organisationId) {
            query = query.innerJoin("a.content", "content", "content.organisationId = :organisationId", { organisationId });
        }

        query = query.where("a.userId = :userId", { userId })
            .andWhere("a.omitNotification = false")
            .groupBy("a.contentId")
            .select("a.contentId", "contentId")
            .addSelect("MAX(a.notificationSentDateUtc)", "nsd")
            .having("nsd is null");

        const newContent: Array<{ contentId: number }> = await query.getRawMany();

        if (!newContent) return [];
        return newContent.map(c => c.contentId);
    }

    private async setNotificationSentDate(userId: number, contentIds: number[]): Promise<void> {
        if (!contentIds || !contentIds.length) return;

        await getManager().createQueryBuilder()
            .update(UserContentAccess)
            .set({ notificationSentDateUtc: new Date(Date.now()) })
            .where("userId = :userId", { userId })
            .andWhere("contentId IN (:contentIds)", { contentIds })
            .andWhere("notificationSentDateUtc is null")
            .execute();
    }

    private getRoleName(user: User, organisationId: number) {
        let role: UserRole | null = null;
        if (user.userRoles) {
            role = user.userRoles.find(r => r.organisationId === organisationId) || null;
        }

        const roleName = role ? role.name : "";
        return roleName;
    }

    private async fetchContent(contentIds: number[]) {
        if (!contentIds || !contentIds.length) return [];

        return Promise.all((await getManager().findByIds(Content, contentIds, { where: { deletedDateUtc: null } })).map(async c => {
            const image = await this.fetchImageBase64(c.coverImageStoragePath);
            return {
                title: c.title,
                author: c.author,
                image,
            };
        }));
    }

    private async fetchImageBase64(imageStoragePath: string): Promise<{ base64: string; mimeType: string; filename: string }> {
        const { mimeType, buffer } = await downloadToBuffer(config.s3.bucket, imageStoragePath);
        const resizedImage = await this._image.resizeImage(buffer, config.email.imageSize.h, config.email.imageSize.w);
        const base64 = resizedImage.toString("base64");
        return { base64, mimeType, filename: getFilename(imageStoragePath) };
    }

    private async getResetPasswordUrl(user: User, email: string) {

        if (!user.passwordResetNonce) {
            user.passwordResetNonce = crypto.randomBytes(16).toString("hex");
            await getManager().update(User, user.id, { passwordResetNonce: user.passwordResetNonce });
        }

        return config.externalLinks.resetPasswordUrlFormat
            .replace("{}", DataProtection.createPasswordResetToken(user.id, user.passwordResetNonce))
            .replace("{}", encodeURIComponent(email));
    }
}
