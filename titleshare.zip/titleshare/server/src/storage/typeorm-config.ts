import path from "path";
import { ConnectionOptions } from "typeorm";

import config from "../config";

const dbConfig: ConnectionOptions = {
    type: "mysql",
    host: config.database.host,
    port: config.database.port,
    username: config.database.username,
    password: config.database.password,
    database: config.database.dbName,
    logging: config.database.logging,
    connectTimeout: config.database.connectTimeout,
    supportBigNumbers: true,
    bigNumberStrings: false,
    timezone: "Z",

    entities: [
        path.join(__dirname, "db-entities", "**", "*.js"),
        path.join(__dirname, "db-entities", "**", "*.ts"),
    ],
    migrations: [
        path.join(__dirname, "db-migrations", "**", "*.js"),
    ],

    // If migrationsRun is true, the migrations in db-migrations will be run on startup.
    // If synchronize is true, database schema changes will automatically be synced regardless of migrations (for development only)
    migrationsRun: !config.database.autoSyncSchema,
    synchronize: config.database.autoSyncSchema,

    // These options only need to be present during development
    cli: {
        entitiesDir: "src/storage/db-entities",
        migrationsDir: "src/storage/db-migrations",
        subscribersDir: "src/storage/db-subscribers",
    },

};

export = dbConfig;
