import fs from "fs";
import { pipeline } from "stream";

import { data } from "../../test/test-data";
import { serviceContainer } from "../runtime/inversify.config";
import { SYMBOLS } from "../runtime/symbols";
import { csvTransform } from "../types/csv-transform";

import { ReportStorage } from "./report-storage";
describe("ReportStorage", () => {

    describe("getOrganisationUsers", () => {
        it("streams data", async () => {

            try {
                const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
                const result = await reports.getOrganisationUsers(data.users.sysAdmin, data.organisations.hashMeat.id);

                if (result.hasError) {
                    fail(result.error);
                    return;
                }

                await new Promise<void>(ok => {
                    let hasRows = false;
                    result.obj.on("data", r => {
                        expect(r.firstName).toBeTruthy();
                        expect(r.inviteAcceptedDateUtc).toBeTruthy();
                        expect(r.lastLoginDateUtc).toBeTruthy();
                        hasRows = true;
                    });

                    result.obj.on("end", () => {
                        expect(hasRows).toBeTruthy();
                        ok();
                    });
                });
            } catch (err) {
                console.log(err);
            }
        });
    });

    describe("getContentPlaybackForUser", () => {
        it("streams data", async () => {

            const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
            const result = await reports.getContentPlaybackForUser(data.users.sysAdmin, data.users.alex.id, null);

            if (result.hasError) {
                fail(result.error);
                return;
            }

            await new Promise<void>(ok => {
                let hasRows = false;
                result.obj.on("data", r => {
                    expect(r.firstName).toBeTruthy();
                    expect(r.title).toBeTruthy();
                    expect(r.playbackTime).toBeTruthy();
                    hasRows = true;
                });

                result.obj.on("end", () => {
                    expect(hasRows).toBeTruthy();
                    ok();
                });
            });
        });
    });

    describe("getUsersPlaybackForContent", () => {
        it("streams data", async () => {

            const reports = serviceContainer.get<ReportStorage>(SYMBOLS.ReportStorage);
            const result = await reports.getUsersPlaybackForContent(data.users.sysAdmin, data.content.hashMeat.theBookOfBooks.id);

            if (result.hasError) {
                fail(result.error);
                return;
            }

            await new Promise<void>(ok => {
                let hasRows = false;
                result.obj.on("data", r => {
                    expect(r.firstName).toBeTruthy();
                    expect(r.title).toBeTruthy();
                    expect(r.playbackTime).toBeTruthy();
                    hasRows = true;
                });

                result.obj.on("end", () => {
                    expect(hasRows).toBeTruthy();
                    ok();
                });
            });
        });
    });
});
