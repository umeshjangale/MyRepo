import { inject, injectable } from "inversify";
import { Brackets, getManager } from "typeorm";

import { createLogger } from "../logger";
import { FACTORY_SYMBOLS } from "../runtime/symbols";
import { OperationResult } from "../types/operation-result";
import { EMPTY_PAGINATED, Paginated } from "../types/paginated";

import { BaseStorage } from "./base-storage";
import { Content, Organisation, RoleType, User, UserGroup } from "./db-entities";
import { DeleteLog } from "./db-entities/delete-log";
import { AccessSource, ContentStatus } from "./db-entities/enums";
import { UserContentAccess } from "./db-entities/user-content-access";
import { UserContentAccessLog } from "./db-entities/user-content-access-log";
import { getOrganisationUser, hasDeletedRows, hasPermission, isSysAdmin } from "./helpers/db-helper";
import { NotificationStorage } from "./notification-storage";

const log = createLogger("UserGroupStorage");

@injectable()
export class UserGroupStorage extends BaseStorage {

    constructor(@inject(FACTORY_SYMBOLS.NotificationStorage) private readonly _notificationFactory: () => NotificationStorage) {
        super();
    }

    async searchUserGroups(currentUser: User, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<UserGroup>> {

        const org = await getManager().findOne(Organisation, { id: organisationId });
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, org)) return EMPTY_PAGINATED;

        const [userGroups, totalCount] = await getManager().createQueryBuilder(UserGroup, "group")
            .where("group.organisationId = :orgId", { orgId: organisationId })
            .andWhere("group.name like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: userGroups,
            totalCount,
        };
    }

    async searchGroupMembers(currentUser: User, groupId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const group = await getManager().findOne(UserGroup, groupId);
        if (!group) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return EMPTY_PAGINATED;

        const [users, totalCount] = await getManager().createQueryBuilder(User, "user")
            .leftJoin("user.userGroups", "g")
            .where("g.id = :groupId", { groupId })
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async searchGroupContent(currentUser: User, groupId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        const group = await getManager().findOne(UserGroup, groupId);
        if (!group) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return EMPTY_PAGINATED;

        const [content, totalCount] = await getManager().createQueryBuilder(Content, "c")
            .leftJoin("c.userGroups", "g")
            .where("g.id = :groupId", { groupId })
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }

    async searchPotentialGroupMembers(currentUser: User, groupId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<User>> {

        const group = await getManager().findOne(UserGroup, groupId);
        if (!group) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return EMPTY_PAGINATED;

        const includeSysAdmins = isSysAdmin(currentUser);

        let query = getManager().createQueryBuilder(User, "user")
            .innerJoin("user.userRoles", "role")
            .leftJoin("user_group_member", "groupMember", "groupMember.userId = user.id AND groupMember.userGroupId = :groupId", { groupId });

        if (includeSysAdmins) {
            query = query.where(new Brackets(qb =>
                qb.where("role.organisationId = :orgId", { orgId: group.organisationId })
                    .orWhere("role.type = :type", { type: RoleType.SystemAdmin }),
            ));
        } else {
            query = query.where("role.organisationId = :orgId", { orgId: group.organisationId });
        }

        const [users, totalCount] = await query
            .andWhere("(groupMember.userGroupId != :groupId OR groupMember.userGroupId is null)", { groupId })
            .andWhere("(user.firstName like :textPattern or user.lastName like :textPattern)", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: users,
            totalCount,
        };
    }

    async searchPotentialContentForUserGroup(currentUser: User, groupId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {
        const mgr = getManager();

        const group = await mgr.findOne(UserGroup, groupId);
        if (!group) return EMPTY_PAGINATED;
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return EMPTY_PAGINATED;

        const [c, totalCount] = await mgr.createQueryBuilder(Content, "c")
            .leftJoin("user_group_content", "ugc", "ugc.contentId = c.id AND ugc.userGroupId = :groupId", { groupId })
            .where("c.organisationId = :orgId", { orgId: group.organisationId })
            .andWhere("ugc.userGroupId is null")
            .andWhere("c.status != :status", { status: ContentStatus.Importing })
            .andWhere("c.deletedDateUtc is null")
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: c,
            totalCount,
        };
    }

    async getUserGroups(currentUser: User, ids: number[]): Promise<Array<UserGroup | null>> {
        return super.getOrderedEntities(UserGroup, ids, async group => hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId));
    }

    async createGroup(currentUser: User, name: string, description: string, organisationId: number)
        : Promise<OperationResult<UserGroup, "invalid-permissions" | "invalid-organisation" | "name-must-be-unique">> {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return OperationResult.invalidPermissions();

        const manager = getManager();
        const organisation = await manager.findOne(Organisation, { id: organisationId });
        if (!organisation) OperationResult.error("invalid-organisation");

        const group = manager.create(UserGroup, {
            name,
            description,
            organisation,
        });

        try {
            await manager.save(group);
        } catch (err) {
            log.e("Error creating a new user group", err);

            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error("name-must-be-unique");
            }

            throw err;
        }

        return OperationResult.as(group);
    }

    async updateGroup(currentUser: User, groupId: number, name: string | undefined, description: string | undefined): Promise<OperationResult<UserGroup>> {

        const manager = getManager();

        // Check current users permission for the group.
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        // A bug in typeorm means passing an object with a property set as undefined will try to update the database column to null. https://github.com/typeorm/typeorm/issues/2331
        // So this avoids defining undefined properties...sigh
        const updateValues: any = {};
        if (name) updateValues.name = name;
        if (description) updateValues.description = description;

        await manager.createQueryBuilder().update(UserGroup).set(updateValues).where("id = :id", { id: group.id }).execute();

        const updatedGroup = await manager.findOne(UserGroup, { id: groupId });
        // The small chance someone else has deleted the group during this update.
        if (!updatedGroup) return OperationResult.error("group-not-found");
        return OperationResult.as(updatedGroup);
    }

    async removeGroup(currentUser: User, groupId: number): Promise<OperationResult<UserGroup>> {

        const manager = getManager();

        // Check current users permission for the group.
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        // Delete the group and all its relations.
        await manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder().delete().from(UserContentAccess).where("userGroupId = :groupId", { groupId }).execute();

            const users: User[] = await trans.createQueryBuilder().relation(UserGroup, "users").of(group).loadMany();
            const content: Content[] = await trans.createQueryBuilder().relation(UserGroup, "content").of(group).loadMany();

            // Record revoked access to content for each user.
            if (content && content.length && users && users.length) {

                const accessLogs: Array<Partial<UserContentAccessLog>> = [];

                for (const u of users) {
                    for (const c of content) {
                        accessLogs.push({
                            contentId: c.id,
                            userId: u.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.UserGroup, userGroupId: group.id }),
                        });
                    }
                }

                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(accessLogs).execute();
            }

            // Log the deletion.
            await trans.createQueryBuilder().insert().into(DeleteLog).values({
                byUser: currentUser,
                entityType: "UserGroup",
                entityId: group.id,
                details: JSON.stringify({ organisationId: group.organisationId, name: group.name }),

            }).execute();

            await trans.remove(group);
        });

        return OperationResult.as(group);
    }

    async addUserGroupMember(currentUser: User, groupId: number, userId: number): Promise<OperationResult<{ group: UserGroup; user: User }>> {

        const manager = getManager();

        // Check current users permission for the group.
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        return manager.transaction("READ COMMITTED", async trans => {

            // Ensure the user is associated with the group's organisation and add a shared lock on the
            // role relation to avoid the role being removed before content access is granted.
            const user = await getOrganisationUser(trans, userId, group.organisationId, true);
            if (!user) return OperationResult.error("user-not-found");

            // Typeorm can't yet add locks to relationship tables TODO: remove this raw query once it can.
            // Add a shared lock to avoid content being removed from the user group while we grant users access to the groups content.
            const results = await trans.query("SELECT contentId FROM `user_group_content` WHERE `userGroupId` = ? LOCK IN SHARE MODE", [group.id]);
            const contentIds: number[] = results.map(r => r.contentId);

            try {
                await trans.createQueryBuilder().relation(UserGroup, "users").of(group).add(user);
            } catch (err) {
                if (err && err.code === "ER_DUP_ENTRY") {
                    // If the user is already a member, return a successful result i.e no error.
                    return OperationResult.as({ group, user });
                }

                throw err;
            }

            // Give the member access to content previously assigned to this user group.
            if (contentIds && contentIds.length) {

                await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                    contentIds.map(cId => ({
                        contentId: cId,
                        userId: user.id,
                        source: AccessSource.UserGroup,
                        userGroupId: group.id,
                    })),
                ).execute();

                // Record access.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    contentIds.map(cId => ({
                        contentId: cId,
                        userId: user.id,
                        action: "access-granted",
                        eventData: JSON.stringify({ via: AccessSource.UserGroup, userGroupId: group.id }),
                    })),
                ).execute();

                // Queue a notification
                this._notificationFactory().queueNewContent(user.id, contentIds, group.organisationId);
            }

            return OperationResult.as({ group, user });
        });
    }

    async removeUserGroupMember(currentUser: User, groupId: number, userId: number): Promise<OperationResult<{ group: UserGroup; user: User }>> {

        // Check current users permission for the group.
        const manager = getManager();
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        const user = await manager.findOne(User, { id: userId });
        if (!user) return OperationResult.error("user-not-found");

        return manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder().relation(UserGroup, "users").of(group).remove(user);

            // Remove the members access to content assigned to this user group.
            // If access if is given elsewhere e.g. via content collection, then the user will still have access.
            const deleteResult = await trans.createQueryBuilder().delete().from(UserContentAccess)
                .where("userId = :userId", { userId: user.id })
                .andWhere("userGroupId = :groupId", { groupId: group.id })
                .execute();

            if (hasDeletedRows(deleteResult)) {
                const content = await trans.createQueryBuilder().relation(UserGroup, "content").of(group).loadMany();
                if (content && content.length) {

                    // Record access.
                    await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                        content.map(c => ({
                            contentId: c.id,
                            userId: user.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.UserGroup, userGroupId: group.id }),
                        })),
                    ).execute();
                }
            }
            return OperationResult.as({ group, user });
        });
    }

    async addUserGroupContent(currentUser: User, groupId: number, contentId: number)
        : Promise<OperationResult<{ group: UserGroup; content: Content }, "invalid-permissions" | "group-not-found" | "content-not-found">> {

        const manager = getManager();

        // Check current users permission for the group.
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        // Check the content is in the same organisation
        const content = await manager.findOne(Content, contentId, { where: { deletedDateUtc: null } });
        if (!content || group.organisationId !== content.organisationId) return OperationResult.error("content-not-found");

        return manager.transaction("READ COMMITTED", async trans => {

            // Add a shared lock to avoid members being removed from the user group during this operation.
            const results = await trans.query("SELECT userId FROM `user_group_member` WHERE `userGroupId` = ? LOCK IN SHARE MODE", [group.id]);
            const userIds: number[] = results.map(r => r.userId);

            try {
                await trans.createQueryBuilder().relation(UserGroup, "content").of(group).add(content);
            } catch (err) {
                if (err && err.code === "ER_DUP_ENTRY") {
                    // If the content is already included, return a successful result i.e no error.
                    return OperationResult.as({ group, content });
                }

                throw err;
            }

            // Grant all users in the group access to the new content.
            if (userIds && userIds.length) {
                await trans.createQueryBuilder().insert().into(UserContentAccess).values(
                    userIds.map(uId => ({
                        contentId: content.id,
                        userId: uId,
                        source: AccessSource.UserGroup,
                        userGroupId: group.id,
                    })),
                ).execute();

                // Record access.
                await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                    userIds.map(uId => ({
                        contentId: content.id,
                        userId: uId,
                        action: "access-granted",
                        eventData: JSON.stringify({ via: AccessSource.UserGroup, userGroupId: group.id }),
                    })),
                ).execute();

                // Queue a notification for each user.
                for (const userId of userIds) {
                    this._notificationFactory().queueNewContent(userId, content.id, content.organisationId);
                }
            }

            return OperationResult.as({ group, content });
        });
    }

    async removeUserGroupContent(currentUser: User, groupId: number, contentId: number)
        : Promise<OperationResult<{ group: UserGroup; content: Content }, "invalid-permissions" | "group-not-found" | "content-not-found">> {

        const manager = getManager();

        // Check current users permission for the group.
        const group = await manager.findOne(UserGroup, groupId);
        if (!group) return OperationResult.error("group-not-found");
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, group.organisationId)) return OperationResult.invalidPermissions();

        // Check the content is in the same organisation
        const content = await manager.findOne(Content, contentId);
        if (!content || group.organisationId !== content.organisationId) return OperationResult.error("content-not-found");

        return manager.transaction("READ COMMITTED", async trans => {

            await trans.createQueryBuilder().relation(UserGroup, "content").of(group).remove(content);

            // Remove all users access.
            const deleteResult = await trans.createQueryBuilder().delete().from(UserContentAccess)
                .where("contentId = :contentId", { contentId: content.id })
                .andWhere("userGroupId = :groupId", { groupId: group.id })
                .execute();

            if (hasDeletedRows(deleteResult)) {
                const users: User[] = await trans.createQueryBuilder().relation(UserGroup, "users").of(group).loadMany();
                if (users && users.length) {

                    // Record access.
                    await trans.createQueryBuilder().insert().into(UserContentAccessLog).values(
                        users.map(user => ({
                            contentId: content.id,
                            userId: user.id,
                            action: "access-revoked",
                            eventData: JSON.stringify({ via: AccessSource.UserGroup, userGroupId: group.id }),
                        })),
                    ).execute();
                }
            }

            return OperationResult.as({ group, content });
        });
    }
}
