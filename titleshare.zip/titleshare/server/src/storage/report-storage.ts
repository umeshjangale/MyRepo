import { ReadStream } from "fs";
import { injectable } from "inversify";
import { Query } from "mysql";
import { getManager } from "typeorm";

import { ObjectReadable } from "../types/object-readable";
import { OperationResult } from "../types/operation-result";

import { BaseStorage } from "./base-storage";
import { Content, RoleType, User } from "./db-entities";
import { ContentStatus } from "./db-entities/enums";
import { UserContentAccess } from "./db-entities/user-content-access";
import { UserContentPlayback } from "./db-entities/user-content-playback";
import { getManageableOrganisationIdsForUser, hasPermission, isSysAdmin } from "./helpers/db-helper";

@injectable()
export class ReportStorage extends BaseStorage {

    async getContentBillingReport(currentUser: User) {

        if (!hasPermission(currentUser, RoleType.SystemAdmin)) {
            return OperationResult.invalidPermissions();
        }

        const mgr = getManager();

        const query = await mgr.createQueryBuilder(Content, "c")
            .innerJoin("c.organisation", "o")
            .where("c.status != :status", { status: ContentStatus.Importing })
            .orderBy("o.id")
            .addOrderBy("c.createdDateUtc")
            .select([
                "o.name organisationName",
                "c.title title",
                "c.subtitle subtitle",
                "c.author author",
                "c.createdDateUtc createdDateUtc",
                "c.nonBillable nonBillable",
                "c.nonBillableReason nonBillableReason",
                "c.deletedDateUtc deletedDateUtc",
            ])
            .stream();

        const stream = this._getObjectStream<{
            title: string;
            subtitle: string;
            author: string;
            organisationName: string;
            createdDateUtc: Date;
            nonBillable: boolean;
            nonBillableReason: string;
            deletedDateUtc: Date | null;
        }>(query);

        return OperationResult.as(stream);
    }

    async getOrganisationUsers(currentUser: User, organisationId: number) {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) {
            return OperationResult.invalidPermissions();
        }

        const mgr = getManager();
        const query = await mgr.createQueryBuilder(User, "u")
            .innerJoin("u.userRoles", "r", "r.organisationId = :organisationId", { organisationId })
            .select([
                "u.id userId",
                "u.firstName firstName",
                "u.lastName lastName",
                "u.email encryptedEmail",
                "u.inviteAcceptedDateUtc inviteAcceptedDateUtc",
                "u.loginCount loginCount",
                "u.lastLoginDateUtc lastLoginDateUtc",
            ])
            .stream();

        const stream = this._getObjectStream<{
            userId: number;
            firstName: string;
            lastName: string;
            encryptedEmail: string;
            inviteAcceptedDateUtc: Date | null;
            loginCount: number;
            lastLoginDateUtc: Date | null;
        }>(query);

        return OperationResult.as(stream);
    }

    async getOrganisationContent(currentUser: User, organisationId: number) {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) {
            return OperationResult.invalidPermissions();
        }

        const mgr = getManager();

        const query = await mgr.createQueryBuilder(Content, "c")
            .where("c.organisationId = :organisationId", { organisationId })
            .andWhere("c.status = :status", { status: ContentStatus.Available })
            .andWhere("c.deletedDateUtc is null")
            .select([
                "c.id contentId",
                "c.title title",
                "c.subtitle subtitle",
                "c.author author",
                "c.narrator narrator",
                "c.publisher publisher",
                "c.releaseDate releaseDate",
                "c.createdDateUtc createdDateUtc",
            ])
            .stream();

        const stream = this._getObjectStream<{
            contentId: number;
            title: string;
            subtitle: string;
            author: string;
            narrator: string;
            publisher: string;
            releaseDate: Date | null;
            createdDateUtc: Date;
        }>(query);

        return OperationResult.as(stream);
    }

    async getContentPlaybackForUser(currentUser: User, userId: number, forOrganisationId: number | null) {

        const mgr = getManager();

        const user = await mgr.findOne(User, userId, { relations: ["userRoles"] });
        if (!user) return OperationResult.invalidPermissions();

        let query = mgr.createQueryBuilder(UserContentAccess, "uca");

        if (isSysAdmin(currentUser) && isSysAdmin(user)) {
            query = query.innerJoin("uca.content", "c");
        } else {
            const orgIds = this._getAccessibleOrganisationIds(currentUser, user, forOrganisationId);
            if (!orgIds.length) return OperationResult.invalidPermissions();
            query = query.innerJoin("uca.content", "c", "c.organisationId in (:orgIds)", { orgIds });
        }

        query = query
            .innerJoin("uca.user", "u")
            .innerJoin("c.organisation", "o")
            .leftJoin("u.userContent", "uc", "uc.contentId = c.id")
            .leftJoin("u.userContentPlayback", "p", "p.contentId = c.id")
            .groupBy("uca.contentId, uca.userId, u.firstName, u.lastName, u.email, c.title, c.subtitle, c.author, c.totalDuration, uc.bookmarkedAudioSectionIndex, uc.bookmarkedAudioSectionTime")
            .where("uca.userId = :userId", { userId })
            .select([
                "uca.userId userId",
                "u.firstName firstName",
                "u.lastName lastName",
                "u.email encryptedEmail",
                "uca.contentId contentId",
                "o.name organisationName",
                "c.title title",
                "c.subtitle subtitle",
                "c.author author",
                "c.totalDuration totalDuration",
                "uc.bookmarkedAudioSectionIndex bookmarkedAudioSectionIndex",
                "uc.bookmarkedAudioSectionTime bookmarkedAudioSectionTime",
                "SUM(p.endTime - p.startTime) playbackTime",
            ]);

        const stream = this._getObjectStream<{
            userId: number;
            firstName: string;
            lastName: string;
            encryptedEmail: string;
            contentId: number;
            organisationName: string;
            title: string;
            subtitle: string;
            author: string;
            totalDuration: number;
            bookmarkedAudioSectionIndex: number | null;
            bookmarkedAudioSectionTime: number | null;
            playbackTime: number | null;
        }>(await query.stream());

        return OperationResult.as(stream);
    }

    async getUsersPlaybackForContent(currentUser: User, contentId: number) {

        const mgr = getManager();

        const content = await mgr.findOne(Content, contentId);
        if (!content) return OperationResult.invalidPermissions();

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, content.organisationId)) {
            return OperationResult.invalidPermissions();
        }

        const query = await mgr.createQueryBuilder(UserContentAccess, "uca")
            .innerJoin("uca.content", "c")
            .innerJoin("uca.user", "u")
            .leftJoin("u.userContent", "uc", "uc.contentId = c.id")
            .leftJoin("u.userContentPlayback", "p", "p.contentId = c.id")
            .groupBy("uca.contentId, uca.userId, u.firstName, u.lastName, u.email, c.title, c.subtitle, c.author, c.totalDuration, uc.bookmarkedAudioSectionIndex, uc.bookmarkedAudioSectionTime")
            .where("uca.contentId = :contentId", { contentId })
            .select([
                "uca.userId userId",
                "u.firstName firstName",
                "u.lastName lastName",
                "u.email encryptedEmail",
                "uca.contentId contentId",
                "c.title title",
                "c.subtitle subtitle",
                "c.author author",
                "c.totalDuration totalDuration",
                "uc.bookmarkedAudioSectionIndex bookmarkedAudioSectionIndex",
                "uc.bookmarkedAudioSectionTime bookmarkedAudioSectionTime",
                "SUM(p.endTime - p.startTime) playbackTime",
            ])
            .stream();

        const stream = this._getObjectStream<{
            userId: number;
            firstName: string;
            lastName: string;
            encryptedEmail: string;
            contentId: number;
            title: string;
            subtitle: string;
            author: string;
            totalDuration: number;
            bookmarkedAudioSectionIndex: number | null;
            bookmarkedAudioSectionTime: number | null;
            playbackTime: number | null;
        }>(query);

        return OperationResult.as(stream);
    }

    private _getAccessibleOrganisationIds(currentUser: User, user: User, forOrganisationId: number | null) {
        if (forOrganisationId) {
            if (!hasPermission(currentUser, RoleType.OrganisationAdmin, forOrganisationId)) {
                return [];
            }

            return [forOrganisationId];
        } else {
            return getManageableOrganisationIdsForUser(currentUser, user);
        }
    }

    private _getObjectStream<T>(query: ReadStream): ObjectReadable<T> {

        // WARNING: typeorm reports the type as a ReadStream, but it is actually a mysql 'Query' type.
        const stream = (query as unknown as Query).stream({ highWaterMark: 5 });
        return stream as ObjectReadable<T>;
    }
}
