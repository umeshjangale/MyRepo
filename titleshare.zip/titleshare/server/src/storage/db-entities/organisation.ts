import { Column, CreateDateColumn, Entity, Generated, Index, JoinTable, ManyToMany, OneToMany, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { ContentCollection } from "./content-collection";
import { Import } from "./import";
import { UserGroup } from "./user-group";
import { UserRole } from "./user-role";

@Entity()
@Index(["importStorageBucket"], { unique: true })
@Index(["name"], { unique: true })
export class Organisation {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    name: string = "";

    @Column("varchar", { nullable: true })
    importStorageBucket: string | null = null;

    @Column()
    importNarrationFilenameRegex: string = "";

    @Column()
    importSoundtrackFilenameRegex: string = "";

    @Column()
    importCoverImageFilenameRegex: string = "";

    @Column("varchar", { nullable: true })
    importSftpUsername: string | null = null;

    @Column("varchar", { nullable: true })
    importSftpPassword: string | null = null;

    @OneToMany(type => UserRole, ur => ur.organisation)
    userRoles: UserRole[] | null = null;

    @OneToMany(type => Content, c => c.organisation)
    content: Content[] | null = null;

    @OneToMany(type => UserGroup, g => g.organisation)
    userGroups: UserGroup[] | null = null;

    @OneToMany(type => ContentCollection, cc => cc.organisation)
    contentCollections: ContentCollection[] | null = null;

    @OneToMany(type => Import, i => i.organisation)
    imports: Import[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
