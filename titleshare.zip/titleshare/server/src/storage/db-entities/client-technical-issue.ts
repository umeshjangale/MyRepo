import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

import { User } from "./user";

@Entity("client_technical_issue")
export class ClientTechnicalIssue {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userAgent: string = "";

    @Column({ length: "8000" })
    data: string = "";

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
