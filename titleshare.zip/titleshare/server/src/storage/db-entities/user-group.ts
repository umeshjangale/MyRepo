import crypto from "crypto";
import { Column, CreateDateColumn, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { Organisation } from "./organisation";
import { User } from "./user";
import { UserContentAccess } from "./user-content-access";

@Entity("user_group")
@Index(["organisationId", "name"], { unique: true })
export class UserGroup {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    name: string = "";

    @Column()
    description: string = "";

    @Column()
    organisationId: number = 0;

    @ManyToOne(type => Organisation, o => o.userGroups)
    organisation: Organisation | null = null;

    @ManyToMany(type => User, user => user.userGroups)
    users: User[] | null = null;

    @OneToMany(type => UserContentAccess, uca => uca.userGroup)
    userContentAccess: UserContentAccess[] | null = null;

    @ManyToMany(type => Content, c => c.userGroups)
    @JoinTable({ name: "user_group_content" })
    content: Content[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
