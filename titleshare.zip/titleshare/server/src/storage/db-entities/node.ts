export interface Node {
    id: number;
}
