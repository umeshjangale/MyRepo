import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

import { Content } from "./content";
import { User } from "./user";

@Entity("user_content_access_log")
export class UserContentAccessLog {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userId: number = 0;

    @ManyToOne(type => User, user => user.userContentAccessLogs)
    user: User | null = null;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.userContentAccessLogs)
    content: Content | null = null;

    @Column()
    action: string = "";

    @Column()
    eventData: string = "";

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
