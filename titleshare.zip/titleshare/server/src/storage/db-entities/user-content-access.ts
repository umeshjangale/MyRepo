import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { ContentCollection } from "./content-collection";
import { AccessSource } from "./enums";
import { User } from "./user";
import { UserGroup } from "./user-group";

@Entity("user_content_access")
export class UserContentAccess {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userId: number = 0;

    @ManyToOne(type => User, user => user.userContentAccess)
    user: User | null = null;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.userContentAccess)
    content: Content | null = null;

    @Column("enum", { enum: AccessSource })
    source: AccessSource | null = null;

    @Column({ nullable: true })
    userGroupId: number | null = null;

    @ManyToOne(type => UserGroup, g => g.userContentAccess)
    userGroup: UserGroup | null = null;

    @Column({ nullable: true })
    contentCollectionId: number | null = null;

    @ManyToOne(type => ContentCollection, cc => cc.userContentAccess)
    contentCollection: ContentCollection | null = null;

    @Column({ default: false })
    omitNotification: boolean = false;

    @Column({ type: "datetime", precision: 3, nullable: true })
    notificationSentDateUtc: Date | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
