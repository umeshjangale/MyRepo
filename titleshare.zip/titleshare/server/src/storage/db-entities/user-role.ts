import { Column, CreateDateColumn, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToOne, PrimaryGeneratedColumn } from "typeorm";

import { RoleType } from "./enums";
import { Organisation } from "./organisation";
import { User } from "./user";

@Entity("user_role")
@Index(["type", "organisation"], { unique: true })
export class UserRole {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    name: string = "";

    @Column("enum", { enum: RoleType })
    type: RoleType = RoleType.Consumer;

    @Column({ nullable: true })
    organisationId: number | null = null;

    @ManyToOne(type => Organisation, o => o.userRoles, { nullable: true })
    organisation: Organisation | null  = null;

    @ManyToMany(type => User, u => u.userRoles)
    users: User[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
