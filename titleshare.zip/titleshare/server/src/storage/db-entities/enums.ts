
export enum ContentType {
    Audiobook = "audiobook",
}

export enum ContentStatus {
    Importing = "importing",
    Unlisted = "unlisted",
    Available = "available",
}

export enum AccessSource {
    Direct = "direct",
    UserGroup = "user-group",
    ContentCollection = "content-collection",
}

export enum RoleType {
    SystemAdmin = "sys-admin",
    OrganisationAdmin = "org-admin",
    OrganisationContentUploader = "org-content-uploader",
    Consumer = "consumer",
}

export enum ImportStatus {
    Waiting = "waiting",
    Transferring = "transferring",
    Validating = "validating",
    Failed = "failed",
    Done = "done",
}
export enum AudioFormat {
    Original = "original",
    Mp3Low = "mp3-low",
    Mp3High = "mp3-high",
}
