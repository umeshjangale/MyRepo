import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { Organisation } from "./organisation";
import { User } from "./user";
import { UserContentAccess } from "./user-content-access";

@Entity("content_collection")
@Index(["organisationId", "name"], { unique: true })
@Index(["signUpCode"], { unique: true })
export class ContentCollection {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    name: string = "";

    @Column()
    description: string = "";

    @Column("varchar", { nullable: true })
    signUpCode: string | null = null;

    @Column()
    signUpCodeEnabled: boolean = false;

    @Column()
    organisationId: number = 0;

    @ManyToOne(type => Organisation, o => o.contentCollections)
    organisation: Organisation | null = null;

    @ManyToMany(type => Content, c => c.contentCollections)
    @JoinTable({ name: "content_collection_item" })
    content: Content[] | null = null;

    @OneToMany(type => UserContentAccess, uca => uca.contentCollection)
    userContentAccess: UserContentAccess[] | null = null;

    @ManyToMany(type => User, c => c.contentCollections)
    @JoinTable({ name: "content_collection_user" })
    users: User[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
