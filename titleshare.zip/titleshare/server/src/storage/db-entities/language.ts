import { Column, CreateDateColumn, Entity, OneToMany, PrimaryColumn } from "typeorm";

import { Content } from "./content";

@Entity()
export class Language {

    @PrimaryColumn()
    code: string = "";

    @Column()
    name: string = "";

    @Column()
    sortOrder: number = 0;

    @OneToMany(type => Content, c => c.language)
    content: Content[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
