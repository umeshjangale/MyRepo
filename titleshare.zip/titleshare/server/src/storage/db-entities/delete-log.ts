import { Column, CreateDateColumn, Entity, Generated, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, Unique } from "typeorm";

import { Organisation } from "./organisation";
import { User } from "./user";

@Entity("delete_log")
export class DeleteLog {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @ManyToOne(type => User, user => user.deleteLogs)
    byUser: User | null = null;

    @Column()
    entityType: string = "";

    @Column()
    entityId: number = 0;

    @Column()
    details: string = "";

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
