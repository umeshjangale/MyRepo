import { Column, CreateDateColumn, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { ImportStatus } from "./enums";
import { ImportJob } from "./import-job";
import { Organisation } from "./organisation";

@Entity()
@Index(["stagingStoragePrefix"], { unique: true })
export class Import {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column({ type: "datetime", precision: 3 })
    timestampReference: Date = new Date(Date.now());

    @Column("enum", { enum: ImportStatus })
    status: ImportStatus = ImportStatus.Waiting;

    @Column({ length: "2047" })
    message: string = "";

    @Column({ nullable: true })
    importStoragePrefix: string = "";

    @Column()
    stagingStoragePrefix: string = "";

    @Column({ type: "datetime", precision: 3 })
    lastFileModifiedDateUtc: Date = new Date(Date.now());

    @Column()
    organisationId: number = 0;

    @ManyToOne(type => Organisation, o => o.imports)
    organisation: Organisation | null = null;

    @Column({ nullable: true })
    contentId: number | null = null;

    @OneToOne(type => Content, c => c.import)
    @JoinColumn()
    content: Content | null = null;

    @OneToMany(type => ImportJob, o => o.import)
    jobs: ImportJob[] | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
