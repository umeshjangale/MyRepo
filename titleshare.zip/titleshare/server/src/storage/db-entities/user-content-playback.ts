import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

import { Content } from "./content";
import { User } from "./user";

@Entity("user_content_playback")
export class UserContentPlayback {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userId: number = 0;

    @ManyToOne(type => User, user => user.userContentPlayback)
    user: User | null = null;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.userContentPlayback)
    content: Content | null = null;

    @Column()
    audioSectionsHash: string = "";

    @Column()
    audioSectionIndex: number = -1;

    @Column("double")
    startTime: number = -1;

    @Column("double")
    endTime: number = -1;

    @Column({ type: "datetime", precision: 3 })
    clientEndTimestamp: Date = new Date(Date.now());

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());
}
