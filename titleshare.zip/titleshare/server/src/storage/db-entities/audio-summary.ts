import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { AudioFile } from "./audio-file";
import { Content } from "./content";
import { AudioFormat } from "./enums";

@Entity("audio_summary")
@Index(["contentId", "format", "type"], { unique: true })
export class AudioSummary {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    type: "narration" | "soundtrack" = "narration";

    @Column("enum", { enum: AudioFormat })
    format: AudioFormat = AudioFormat.Original;

    /*
     WARN: totalBytes could be a string if it cannot be accurately represented with a js number (which happens when it exceeds the [-2^53, +2^53] range)
     however the app only ever saves totalBytes using a js number, so it should always be returned as a js number.
     See supportBigNumbers and bigNumberStrings https://www.npmjs.com/package/mysql#connection-options.
    */
    @Column({ type: "bigint" })
    totalBytes: number = 0;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.audioSummaries)
    content: Content | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
