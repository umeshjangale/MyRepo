import { Column, CreateDateColumn, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { ImportStatus } from "./enums";
import { Import } from "./import";
import { Organisation } from "./organisation";

@Entity()
export class ImportJob {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    pipelineId: string = "";

    @Column()
    stage: string = "";

    @Column()
    jobId: string = "";

    @Column()
    status: string = "";

    @Column({ length: "2047" })
    message: string = "";

    @Column()
    importId: number = 0;

    @ManyToOne(type => Import, o => o.jobs)
    import: Import | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
