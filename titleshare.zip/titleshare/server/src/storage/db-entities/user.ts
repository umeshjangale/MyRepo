import { Column, CreateDateColumn, Entity, JoinTable, ManyToMany, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { ClientTechnicalIssue } from "./client-technical-issue";
import { ContentCollection } from "./content-collection";
import { DeleteLog } from "./delete-log";
import { UserAgent } from "./user-agent";
import { UserContent } from "./user-content";
import { UserContentAccess } from "./user-content-access";
import { UserContentAccessLog } from "./user-content-access-log";
import { UserContentPlayback } from "./user-content-playback";
import { UserGroup } from "./user-group";
import { UserRole } from "./user-role";

@Entity()
export class User {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    firstName: string = "";

    @Column()
    lastName: string = "";

    @Column({ default: false })
    loginAllowed: boolean = false;

    @Column()
    sessionToken: string = "";

    @Column()
    createdReason: "invite" | "sign-up-code" = "invite";

    @Column({ type: "datetime", precision: 3, nullable: true })
    inviteSentDateUtc: Date | null = null;

    @Column({ type: "datetime", precision: 3, nullable: true })
    inviteAcceptedDateUtc: Date | null = null;

    @Column()
    passwordResetNonce: string = "";

    @Column({ unique: true })
    email: string = "";

    @Column({ default: false })
    emailVerified: boolean = false;

    @Column()
    password: string = "";

    @Column({ type: "datetime", precision: 3, nullable: true })
    setPasswordEmailSentDateUtc: Date | null = null;

    @Column({ type: "datetime", precision: 3, nullable: true })
    firstPasswordSetDateUtc: Date | null = null;

    @Column({ type: "datetime", precision: 3, nullable: true })
    lastPasswordSetDateUtc: Date | null = null;

    @ManyToMany(type => UserRole, r => r.users)
    @JoinTable({ name: "user_role_member" })
    userRoles: UserRole[] | null = null;

    @ManyToMany(type => UserGroup, ug => ug.users)
    @JoinTable({ name: "user_group_member" })
    userGroups: UserGroup[] | null = null;

    @OneToMany(type => UserContent, uc => uc.user)
    userContent: UserContent[] | null = null;

    @OneToMany(type => UserContentAccess, uc => uc.user)
    userContentAccess: UserContentAccess[] | null = null;

    @OneToMany(type => UserContentAccessLog, uc => uc.user)
    userContentAccessLogs: UserContentAccessLog[] | null = null;

    @OneToMany(type => UserContentPlayback, ucs => ucs.user)
    userContentPlayback: UserContentPlayback[] | null = null;

    @ManyToMany(type => ContentCollection, r => r.users)
    contentCollections: ContentCollection[] | null = null;

    @OneToMany(type => UserAgent, ua => ua.user)
    userAgents: UserAgent[] | null = null;

    @OneToMany(type => DeleteLog, dl => dl.byUser)
    deleteLogs: DeleteLog[] | null = null;

    @Column()
    ipAddress: string = "";

    @Column()
    loginCount: number = 0;

    @Column({ type: "datetime", precision: 3, nullable: true })
    lastLoginDateUtc: Date | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
