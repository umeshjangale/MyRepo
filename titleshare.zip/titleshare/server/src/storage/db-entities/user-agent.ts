import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { User } from "./user";

@Entity()
@Index(["userId", "value"], { unique: true })
export class UserAgent {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userId: number = 0;

    @ManyToOne(type => User, u => u.userAgents)
    user: User | null = null;

    @Column()
    value: string = "";

    @Column()
    ipAddress: string = "";

    @Column()
    loginCount: number = 0;

    @Column({ type: "datetime", precision: 3, nullable: true })
    lastLoginDateUtc: Date | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
