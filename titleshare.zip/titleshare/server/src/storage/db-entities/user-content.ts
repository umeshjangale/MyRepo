import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { Content } from "./content";
import { User } from "./user";

@Entity("user_content")
@Index(["user", "content"], { unique: true })
export class UserContent {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    userId: number = 0;

    @ManyToOne(type => User, user => user.userContent)
    user: User | null = null;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.userContent)
    content: Content | null = null;

    @Column({ type: "int", nullable: true })
    bookmarkedAudioSectionIndex: number | null = null;

    /** Time in seconds */
    @Column({ type: "double", nullable: true })
    bookmarkedAudioSectionTime: number | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
