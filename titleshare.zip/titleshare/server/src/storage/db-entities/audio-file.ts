import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { AudioSection } from "./audio-section";
import { AudioFormat } from "./enums";

@Entity("audio_file")
@Index(["audioSectionId", "type", "format"], { unique: true })
export class AudioFile {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    bucket: string = "";

    @Column()
    storagePath: string = "";

    @Column("int")
    bytes: number = 0;

    @Column()
    type: "narration" | "soundtrack" = "narration";

    @Column("enum", { enum: AudioFormat })
    format: AudioFormat = AudioFormat.Original;

    @Column()
    audioSectionId: number = 0;

    @ManyToOne(type => AudioSection, c => c.audioFiles)
    audioSection: AudioSection | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
