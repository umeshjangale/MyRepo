import { Column, CreateDateColumn, Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { AudioFile } from "./audio-file";
import { AudioSection } from "./audio-section";
import { AudioSummary } from "./audio-summary";
import { ContentCollection } from "./content-collection";
import { ContentStatus, ContentType } from "./enums";
import { Genre } from "./genre";
import { Import } from "./import";
import { Language } from "./language";
import { Organisation } from "./organisation";
import { UserContent } from "./user-content";
import { UserContentAccess } from "./user-content-access";
import { UserContentAccessLog } from "./user-content-access-log";
import { UserContentPlayback } from "./user-content-playback";
import { UserGroup } from "./user-group";

@Entity()
export class Content {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    title: string = "";

    @Column()
    subtitle: string = "";

    @Column({ length: "2047" })
    description: string = "";

    @Column()
    author: string = "";

    @Column()
    narrator: string = "";

    @Column()
    publisher: string = "";

    @Column({ type: "datetime", nullable: true })
    releaseDate: Date | null = null;

    @Column("double")
    totalDuration: number = 0;

    @Column()
    hasSoundtrack: boolean = false;

    @Column()
    audioSectionsHash: string = "";

    @Column()
    coverImageStoragePath: string = "";

    @Column("enum", { enum: ContentStatus })
    status: ContentStatus = ContentStatus.Importing;

    @Column()
    languageCode: string = "";

    @ManyToOne(type => Language, l => l.content)
    language: Language | null = null;

    @Column()
    genreCode: string = "";

    @ManyToOne(type => Genre, g => g.content)
    genre: Genre | null = null;

    @Column({ nullable: true })
    secondGenreCode: string | null = null;

    @ManyToOne(type => Genre, g => g.secondaryContent, { nullable: true })
    secondGenre: Genre | null = null;

    @Column("enum", { enum: ContentType })
    type: ContentType = ContentType.Audiobook;

    @Column()
    nonBillable: boolean = false;

    @Column()
    nonBillableReason: string = "";

    @Column()
    organisationId: number = 0;

    @ManyToOne(type => Organisation, o => o.content)
    organisation: Organisation | null = null;

    @OneToMany(type => UserContent, uc => uc.content)
    userContent: UserContent[] | null = null;

    @OneToMany(type => UserContentAccess, uc => uc.content)
    userContentAccess: UserContentAccess[] | null = null;

    @OneToMany(type => UserContentAccessLog, uc => uc.content)
    userContentAccessLogs: UserContentAccessLog[] | null = null;

    @OneToMany(type => UserContentPlayback, ucs => ucs.content)
    userContentPlayback: UserContentPlayback[] | null = null;

    @ManyToMany(type => ContentCollection, cc => cc.content)
    contentCollections: ContentCollection[] | null = null;

    @ManyToMany(type => UserGroup, cc => cc.content)
    userGroups: UserGroup[] | null = null;

    @OneToMany(type => AudioSection, as => as.content)
    audioSections: AudioSection[] | null = null;

    @OneToMany(type => AudioSummary, as => as.content)
    audioSummaries: AudioSummary[] | null = null;

    @OneToOne(type => Import, i => i.content)
    import: Import | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());

    @Column({ type: "datetime", precision: 3, nullable: true })
    deletedDateUtc: Date | null = null;
}
