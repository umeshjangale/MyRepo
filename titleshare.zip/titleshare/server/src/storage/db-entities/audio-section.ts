import { Column, CreateDateColumn, Entity, Index, JoinTable, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

import { AudioFile } from "./audio-file";
import { Content } from "./content";

@Entity("audio_section")
@Index(["contentId", "sequence"], { unique: true })
export class AudioSection {

    @PrimaryGeneratedColumn()
    id: number = 0;

    @Column()
    title: string = "";

    @Column()
    sequence: number = 0;

    @Column()
    versionNumber: number = 0;

    @Column("double")
    approximateDuration: number = 0;

    @OneToMany(type => AudioFile, af => af.audioSection)
    audioFiles: AudioFile[] | null = null;

    @Column()
    contentId: number = 0;

    @ManyToOne(type => Content, c => c.audioSections)
    content: Content | null = null;

    @CreateDateColumn()
    createdDateUtc: Date = new Date(Date.now());

    @UpdateDateColumn()
    lastUpdatedDateUtc: Date = new Date(Date.now());
}
