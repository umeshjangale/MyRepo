import { injectable } from "inversify";
import { getManager } from "typeorm";

import { createLogger } from "../logger";
import * as DataProtection from "../security/data-protection";
import { OperationResult } from "../types/operation-result";
import { EMPTY_PAGINATED, Paginated } from "../types/paginated";

import { BaseStorage } from "./base-storage";
import { Content, Organisation, RoleType, User } from "./db-entities";
import { ContentStatus } from "./db-entities/enums";
import { bucketExists } from "./helpers/blob-helper";
import { hasPermission } from "./helpers/db-helper";
import { OrganisationUpdateModel } from "./types/organisation-update-model";

const log = createLogger("OrganisationStorage");

@injectable()
export class OrganisationStorage extends BaseStorage {

    async createOrganisation(currentUser: User, name: string): Promise<OperationResult<Organisation, "invalid-permissions" | "name-must-be-unique">> {

        const manager = getManager();

        // Only system admins can create an organisation.
        if (!hasPermission(currentUser, RoleType.SystemAdmin)) return OperationResult.invalidPermissions();

        const org = manager.create(Organisation, {
            name,
        });

        try {
            await manager.save(org);
        } catch (err) {
            log.e("Error creating a new organisation", err);

            if (err && err.code === "ER_DUP_ENTRY") {
                return OperationResult.error("name-must-be-unique");
            }

            throw err;
        }

        return OperationResult.as(org);
    }

    async updateOrganisation(currentUser: User, id: number, updateModel: OrganisationUpdateModel):
        Promise<OperationResult<Organisation, "invalid-permissions" | "organisation-not-found" | "import-bucket-does-not-exist" | "import-bucket-in-use">> {

        const manager = getManager();

        // Check current users permission for the content.
        const organisation = await manager.findOne(Organisation, id);
        if (!organisation) return OperationResult.error("organisation-not-found");
        if (!hasPermission(currentUser, RoleType.SystemAdmin, organisation)) return OperationResult.invalidPermissions();

        // A bug in typeorm means passing an object with a property set as undefined will try to update the database column to null. https://github.com/typeorm/typeorm/issues/2331
        // So this avoids defining undefined properties...sigh
        const updateValues: any = {};
        if (updateModel.name) updateValues.name = updateModel.name;
        if (updateModel.importCoverImageFilenameRegex) updateValues.importCoverImageFilenameRegex = updateModel.importCoverImageFilenameRegex;
        if (updateModel.importNarrationFilenameRegex) updateValues.importNarrationFilenameRegex = updateModel.importNarrationFilenameRegex;
        if (updateModel.importSoundtrackFilenameRegex) updateValues.importSoundtrackFilenameRegex = updateModel.importSoundtrackFilenameRegex;
        if (updateModel.importStorageBucket) {
            if (organisation.importStorageBucket !== updateModel.importStorageBucket) {

                const exists = await bucketExists(updateModel.importStorageBucket);
                if (!exists) {
                    return OperationResult.error("import-bucket-does-not-exist");
                }

                const otherOrgUsingBucket = await manager.findOne(Organisation, { where: { importStorageBucket: updateModel.importStorageBucket } });
                if (otherOrgUsingBucket) {
                    return OperationResult.error("import-bucket-in-use");
                }

                updateValues.importStorageBucket = updateModel.importStorageBucket;
            }
        }
        if (updateModel.importSftpUsername) updateValues.importSftpUsername = updateModel.importSftpUsername;
        if (updateModel.importSftpPassword) updateValues.importSftpPassword = DataProtection.encryptImportSftpPassword(updateModel.importSftpPassword);

        // Do nothing if nothing to update.
        if (Object.keys(updateValues).length === 0) return OperationResult.as(organisation);

        await manager.createQueryBuilder().update(Organisation).set(updateValues).where("id = :id", { id: organisation.id }).execute();
        const updatedOrg = await manager.findOne(Organisation, id);

        // The small chance someone else has deleted the org during this update.
        if (!updatedOrg) return OperationResult.error("organisation-not-found");
        return OperationResult.as(updatedOrg);
    }

    /** WARN: no authorization checked */
    async getOrganisation(id: number): Promise<Organisation | undefined> {
        return getManager().findOne(Organisation, id);
    }

    async getOrganisationForAdmin(currentUser: User, id: number): Promise<Organisation | undefined> {
        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, id)) return undefined;
        return getManager().findOne(Organisation, id);
    }

    async getOrganisations(currentUser: User, ids: number[]): Promise<Array<Organisation | null>> {
        return super.getOrderedEntities(Organisation, ids, async org => hasPermission(currentUser, RoleType.OrganisationAdmin, org.id));
    }

    async searchOrganisations(currentUser: User, pageSize: number, pageNumber: number): Promise<Paginated<Organisation>> {

        if (hasPermission(currentUser, RoleType.SystemAdmin)) {

            const [organisations, totalCount] = await getManager().createQueryBuilder(Organisation, "org")
                .orderBy("org.name")
                .skip((pageNumber - 1) * pageSize)
                .take(pageSize)
                .getManyAndCount();
            return {
                items: organisations,
                totalCount,
            };
        } else {

            // WARN: There's a lot of overhead in the SQL generated by this query - it can be made better.
            const [organisations, totalCount] = await getManager().createQueryBuilder(Organisation, "org")
                .innerJoin("org.userRoles", "role")
                .innerJoin("role.users", "user")
                .where("user.id = :userId", { userId: currentUser.id })
                .skip((pageNumber - 1) * pageSize)
                .take(pageSize)
                .getManyAndCount();
            return {
                items: organisations,
                totalCount,
            };
        }
    }

    async searchOrganisationContent(currentUser: User, organisationId: number, pageSize: number, pageNumber: number, searchText: string): Promise<Paginated<Content>> {

        if (!hasPermission(currentUser, RoleType.OrganisationAdmin, organisationId)) return EMPTY_PAGINATED;

        const [content, totalCount] = await getManager().createQueryBuilder(Content, "c")
            .where("c.organisationId = :organisationId", { organisationId })
            .andWhere("c.status != :status", { status: ContentStatus.Importing })
            .andWhere("c.deletedDateUtc is null")
            .andWhere("c.title like :textPattern", { textPattern: `%${searchText}%` })
            .skip((pageNumber - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();

        return {
            items: content,
            totalCount,
        };
    }
}
