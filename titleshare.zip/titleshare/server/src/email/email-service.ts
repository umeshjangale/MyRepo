import sgMail from "@sendgrid/mail";
import { injectable } from "inversify";

import config from "../config";
import { createLogger, Logger } from "../logger";

interface BookContent {
    title: string;
    author: string;
    image: Image;
}

interface Image {
    base64: string;
    mimeType: string;
    filename: string;
}

interface Recipient {
    email: string;
    firstName: string;
    lastName: string;
}

/** An email service implementation using send grid */
@injectable()
export class EmailService {

    log: Logger;
    fromAddress: string;
    commonTemplateVariables = {
        env: config.nodeEnv,
        showEnv: !config.isProduction,
    };

    unsubscribeGroups: number[];
    adminUnsubscribeGroups: number[];

    constructor() {
        const apiKey = config.email.sendGridApiKey;
        sgMail.setApiKey(apiKey);

        this.log = createLogger("SendGridEmailProvider");
        this.fromAddress = config.email.fromAddress;
        this.unsubscribeGroups = [
            config.email.unsubscribeGroups.newContentId,
            config.email.unsubscribeGroups.invitationsId,
        ];
        this.adminUnsubscribeGroups = [
            ...this.unsubscribeGroups,
            config.email.unsubscribeGroups.adminId,
        ];
    }

    async sendUserInvite(toAddress: string, firstName: string, lastName: string, organisationName: string, roleName: string, isSubsequentInviteWithoutPassword: boolean, hasAlreadySetPassword: boolean, content: BookContent[], createPasswordUrl: string): Promise<void> {

        const templateId = config.email.template.userInviteId;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: [
                {
                    to: { email: toAddress, name: `${firstName} ${lastName}` },
                    bcc,
                    dynamic_template_data: { // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        firstName,
                        lastName,
                        roleName,
                        organisationName,
                        isSubsequentInviteWithoutPassword,
                        hasAlreadySetPassword,
                        books: this.getBooksSchemaForEmailTemplate(content),
                        createPasswordUrl,
                        ...this.commonTemplateVariables,
                    },
                },
            ],
            attachments: this.getContentImageAttachments(content),
            ...this.getUnsubscribeData(config.email.unsubscribeGroups.invitationsId, this.unsubscribeGroups),
        };

        await sgMail.send(msg);
    }

    async sendSysAdminInvite(toAddress: string, firstName: string, lastName: string, content: BookContent[], createPasswordUrl: string): Promise<void> {

        const templateId = config.email.template.sysAdminInviteId;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: [
                {
                    to: { email: toAddress, name: `${firstName} ${lastName}` },
                    bcc,
                    dynamic_template_data: { // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        firstName,
                        lastName,
                        books: this.getBooksSchemaForEmailTemplate(content),
                        createPasswordUrl,
                        ...this.commonTemplateVariables,
                    },
                },
            ],
            attachments: this.getContentImageAttachments(content),
        };

        await sgMail.send(msg);
    }

    async sendEmailToSetFirstPassword(toAddress: string, firstName: string, lastName: string, organisationName: string, isSubsequentInviteWithoutPassword: boolean, createPasswordUrl: string)
        : Promise<void> {

        const templateId = config.email.template.setFirstPasswordId;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: [
                {
                    to: { email: toAddress, name: `${firstName} ${lastName}` },
                    bcc,
                    dynamic_template_data: { // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        firstName,
                        lastName,
                        organisationName,
                        isSubsequentInviteWithoutPassword,
                        createPasswordUrl,
                        ...this.commonTemplateVariables,
                    },
                },
            ],
        };

        await sgMail.send(msg);
    }

    async sendNewContent(toAddress: string, firstName: string, lastName: string, organisationName: string, roleName: string, content: BookContent[]): Promise<void> {

        const templateId = config.email.template.newContentId;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: [
                {
                    to: { email: toAddress, name: `${firstName} ${lastName}` },
                    bcc,
                    dynamic_template_data: {  // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        firstName,
                        lastName,
                        roleName,
                        organisationName,
                        books: this.getBooksSchemaForEmailTemplate(content),
                        ...this.commonTemplateVariables,
                    },
                },
            ],
            attachments: this.getContentImageAttachments(content),
            ...this.getUnsubscribeData(config.email.unsubscribeGroups.newContentId, this.unsubscribeGroups),
        };

        await sgMail.send(msg);
    }

    async sendPasswordReset(toAddress: string, firstName: string, lastName: string, resetPasswordUrl: string): Promise<void> {
        const templateId = config.email.template.passwordResetId;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: [
                {
                    to: { email: toAddress, name: `${firstName} ${lastName}` },
                    bcc,
                    dynamic_template_data: {  // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        firstName,
                        lastName,
                        resetPasswordUrl,
                        ...this.commonTemplateVariables,
                    },
                },
            ],
        };

        await sgMail.send(msg);
    }

    async sendImportFailed(to: Recipient[], importStoragePrefix: string, organisationName: string, errors: string[]): Promise<void> {

        const templateId = config.email.template.importFailed;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: to.map(recipient =>
                ({
                    to: {
                        email: recipient.email,
                        name: `${recipient.firstName} ${recipient.lastName}`,
                    },
                    bcc,
                    // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                    dynamic_template_data: {
                        importStoragePrefix,
                        organisationName,
                        firstName: recipient.firstName,
                        lastName: recipient.lastName,
                        errors,
                        ...this.commonTemplateVariables,
                    },
                }),
            ),
            ...this.getUnsubscribeData(config.email.unsubscribeGroups.adminId, this.adminUnsubscribeGroups),
        };

        await sgMail.send(msg);
    }

    async sendImportSucceeded(to: Recipient[], importStoragePrefix: string, organisationName: string): Promise<void> {
        const templateId = config.email.template.importSucceeded;
        const bcc = config.email.bccAddress;

        const msg = {
            from: this.fromAddress,
            templateId,
            personalizations: to.map(recipient =>
                ({
                    to: {
                        email: recipient.email,
                        name: `${recipient.firstName} ${recipient.lastName}`,
                    },
                    bcc,
                    dynamic_template_data: { // WARN: Must use 'dynamic_template_data' (not dynamicTemplateData) which is not part of type definition of MailData
                        importStoragePrefix,
                        organisationName,
                        firstName: recipient.firstName,
                        lastName: recipient.lastName,
                        ...this.commonTemplateVariables,
                    },
                }),
            ),
            ...this.getUnsubscribeData(config.email.unsubscribeGroups.adminId, this.adminUnsubscribeGroups),
        };

        await sgMail.send(msg);
    }

    private getBooksSchemaForEmailTemplate(content: BookContent[]) {
        return content.map(c => ({
            title: c.title,
            imageCId: c.image.filename,
        }));
    }

    private getContentImageAttachments(content: BookContent[]) {
        return content.map(c => ({
            content: c.image.base64,
            filename: c.image.filename,
            type: c.image.mimeType,
            content_id: c.image.filename,
            disposition: "inline",
        }));
    }

    private getUnsubscribeData(groupId: number, groupsToDisplay: number[]) {
        // See https://sendgrid.com/docs/API_Reference/Web_API_v3/Mail/index.html
        return {
            asm: {
                groupId,
                groupsToDisplay,
            },
        };
    }
}
