export enum EmailType {
    Invitation = "invitation",
    SysAdminInvitation = "sys-admin-invitation",
    NewContentAvailable = "new-content-available",
    SetFirstPassword = "set-first-password",
}
