export enum QueueType {
    Email = "email",
    ImportFileEvent = "import-file-event",
    ImportBatchTransfer = "import-batch-transfer",
    ImportBatchValidation = "import-batch-validation",
    ProcessAudioSection = "process-audio-section",
    AudioEncoding = "audio-encoding",
    LargeAudioEncoding = "large-audio-encoding",
    EndAudioEncoding = "end-audio-encoding",
}
