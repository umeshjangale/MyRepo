import { inject, injectable } from "inversify";

import { EmailType } from "../email/email-type";
import { SYMBOLS } from "../runtime/symbols";
import { ImportStorage } from "../storage/import-storage";
import { NotificationStorage } from "../storage/notification-storage";
import { assertNever } from "../utils";

import { InviteSysAdminEmailQueueMessage, InviteUserEmailQueueMessage, NewContentEmailQueueMessage, QueueMessage, SetFirstPasswordEmailQueueMessage } from "./queue-message";
import { QueueType } from "./queue-type";

@injectable()
export class MessageHandler {

    constructor(
        @inject(SYMBOLS.NotificationStorage) private readonly _notifications: NotificationStorage,
        @inject(SYMBOLS.ImportStorage) private readonly _import: ImportStorage) {

    }

    async handleMessage(msg: QueueMessage): Promise<void> {

        switch (msg.queue) {
            case QueueType.Email:
                await this.handleEmailMessage(msg);
                break;
            case QueueType.ImportFileEvent:
                const eventsGroupedByBucket = new Map<string, Array<{ key: string; size: number; eventTime: number; callerId: string }>>();

                // This may be unnecessary - is it possible for notifications to be batched across buckets?
                for (const event of msg.Records) {
                    const bucketEvents = eventsGroupedByBucket.get(event.s3.bucket.name);
                    const e = {
                        // Strange encoding from s3 notifications requires us to convert "+" to " " (space)
                        key: decodeURIComponent(event.s3.object.key.replace(/\+/g, "%20")),
                        size: event.s3.object.size,
                        eventTime: Date.parse(event.eventTime),
                        callerId: event.userIdentity.principalId,
                    };
                    if (bucketEvents) {
                        bucketEvents.push(e);
                    } else {
                        eventsGroupedByBucket.set(event.s3.bucket.name, [e]);
                    }
                }

                for (const [bucket, events] of eventsGroupedByBucket) {
                    await this._import.processImportFileEvents(bucket, events);
                }
                break;
            case QueueType.ImportBatchTransfer:
                await this._import.attemptImportFilesTransfer(msg.importId);
                break;
            case QueueType.ImportBatchValidation:
                await this._import.validateImportFilesAndImportContent(msg.importId);
                break;
            case QueueType.ProcessAudioSection:
                await this._import.validateAndImportAudioSection(msg.contentId, msg.pipelineId, msg.sequence, msg.originalNarrationStoragePath, msg.originalNarrationSize, msg.originalSoundtrackStoragePath, msg.originalSoundtrackSize, msg.totalSections);
                break;
            case QueueType.AudioEncoding:
                await this._import.doAudioEncoding(msg);
                break;
            case QueueType.LargeAudioEncoding:
                await this._import.doAudioEncoding(msg);
                break;
            case QueueType.EndAudioEncoding:
                await this._import.endAudioEncoding(msg.contentId, msg.audioSectionId, msg.destinationBucket, msg.destinationStoragePath, msg.fileBytes, msg.duration, msg.format, msg.type, msg.totalFiles);
                break;
            default:
                return assertNever(msg);
        }
    }

    async handleEmailMessage(message: InviteUserEmailQueueMessage | InviteSysAdminEmailQueueMessage | NewContentEmailQueueMessage | SetFirstPasswordEmailQueueMessage): Promise<void> {

        switch (message.emailType) {
            case EmailType.Invitation:
                await this._notifications.sendInvitation(message.userId, message.organisationId);
                break;
            case EmailType.SysAdminInvitation:
                await this._notifications.sendSysAdminInvitation(message.userId);
                break;
            case EmailType.NewContentAvailable:
                await this._notifications.sendNewContent(message.userId, message.content, message.organisationId);
                break;
            case EmailType.SetFirstPassword:
                await this._notifications.sendEmailToSetFirstPassword(message.userId, message.organisationId);
                break;
            default:
                return assertNever(message);
        }
    }
}
