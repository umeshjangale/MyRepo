import AWS, { AWSError } from "aws-sdk";
import { injectable } from "inversify";

import config from "../config";
import { createLogger } from "../logger";

import { QueueMessage, QueueMessageByType } from "./queue-message";
import { QueueType } from "./queue-type";
const log = createLogger("QueueService");

const logInfo = (msg: string, queue: string, msgId?: string, details?: string) => {
    log.i(`${msg}. Queue: '${queue}' Id: '${msgId}' ${details || ""}`);
};

@injectable()
export class QueueService {

    private _sqs: AWS.SQS | undefined;
    private readonly _queueUrls: Map<QueueType, Promise<string>> = new Map();

    async addMessage(message: QueueMessage, delaySeconds?: number): Promise<string> {

        const sqs = this.getSqs();

        const queueUrl = await this.getQueueUrl(message.queue);

        try {
            const result = await sqs.sendMessage({
                QueueUrl: queueUrl,
                DelaySeconds: delaySeconds,
                MessageBody: JSON.stringify(message),
            }).promise();

            if (!result.MessageId) throw new Error(`Failed to sendMessage to queue '${message.queue}'. No messageId returned.`);
            logInfo("Message queued", message.queue, result.MessageId);

            return result.MessageId;
        } catch (err) {
            throw this.serviceErr("sendMessage", err, message);
        }
    }

    async addMessages<T extends QueueMessage["queue"]>(queue: T, messages: Array<QueueMessageByType<QueueMessage, T>>, delaySeconds?: number): Promise<void> {

        const sqs = this.getSqs();

        const queueUrl = await this.getQueueUrl(queue);

        const batchSize = 10;
        for (let i = 0; i < messages.length; i += batchSize) {
            const batch = messages.slice(i, i + batchSize);

            // sendMessageBatch "Delivers up to ten messages to the specified queue"
            try {
                const result = await sqs.sendMessageBatch({
                    QueueUrl: queueUrl,
                    Entries: batch.map((m, num) => ({
                        Id: num.toString(),
                        MessageBody: JSON.stringify(m),
                        DelaySeconds: delaySeconds,
                    })),
                }).promise();

                if (result.Failed.length) {
                    for (const f of result.Failed) {
                        log.e(`Failed to queue message. queue: ${queue}, id: ${f.Id}, code: ${f.Code}, senderFault: ${f.SenderFault}, msg: ${f.Message}`);
                    }

                    // TODO: retry failed messages?
                }
            } catch (err) {
                throw this.serviceErr("sendMessageBatch", err);
            }
        }
    }

    async receiveMessage<T extends QueueMessage["queue"]>(queue: T, process: (msg: QueueMessageByType<QueueMessage, T>) => Promise<void>): Promise<void> {

        const sqs = this.getSqs();

        const queueUrl = await this.getQueueUrl(queue);

        const result = await sqs.receiveMessage({
            QueueUrl: queueUrl,
            VisibilityTimeout: 60 * 2, // TODO: add to config
        }).promise();

        if (!result.Messages) return;

        for (const m of result.Messages) {
            logInfo("Processing message", queue, m.MessageId, JSON.stringify(m));

            if (m.Body) {
                await process({ queue, messageId: m.MessageId, ...JSON.parse(m.Body) });
            }

            logInfo("Processing complete", queue, m.MessageId);

            if (m.ReceiptHandle) {
                // Delete the message.
                const del = await sqs.deleteMessage({
                    ReceiptHandle: m.ReceiptHandle,
                    QueueUrl: queueUrl,
                }).promise();

                logInfo("Message deleted", queue, m.MessageId);
            }
        }
    }

    async getQueueUrl(type: QueueType): Promise<string> {
        const cachedUrl = this._queueUrls[type];
        if (cachedUrl) {
            return cachedUrl;
        }
        const url = this._fetchQueueUrl(type);
        this._queueUrls[type] = url;
        return url;
    }

    private async _fetchQueueUrl(type: QueueType): Promise<string> {
        // When running in elastic beanstalk, only a single queue is used for messages processed by the worker role.
        if (this.useElasticBeanstalkMonoQueue(type) && config.sqs.monoQueueUrl) {
            return config.sqs.monoQueueUrl;
        }

        const sqs = this.getSqs();

        try {
            const result = await sqs.getQueueUrl({ QueueName: this.getQueueName(type) }).promise();

            if (!result.QueueUrl) {
                throw new Error(`Failed to fetch queue of type ${type}. No URL returned.`);
            }

            return result.QueueUrl;
        } catch (err) {
            throw this.serviceErr("getQueueUrl", err);
        }
    }

    private serviceErr(serviceCall: string, awsErr: AWSError, queueMessage?: QueueMessage | undefined): Error {
        const err = new Error(`Error attempting ${serviceCall}. '${queueMessage ? JSON.stringify(queueMessage) : ""}`);
        log.e(err.message, awsErr);
        return err;
    }

    private getQueueName(type: QueueType): string {
        return `${type}`;
    }

    private useElasticBeanstalkMonoQueue(queue: QueueType): boolean {

        if (queue === QueueType.LargeAudioEncoding) {
            return false;
        }

        // Audio encoding messages are processed by aws lambda.
        if (config.app.useLambdaForAudioEncoding && queue === QueueType.AudioEncoding) {
            return false;
        }

        return true;
    }

    private getSqs(): AWS.SQS {

        if (this._sqs) return this._sqs;
        const sqs = new AWS.SQS({
            region: config.sqs.region,
            apiVersion: "2012-11-05",
            endpoint: config.sqs.endpoint,
        });

        this._sqs = sqs;
        return this._sqs;
    }
}
