import { EmailType } from "../email/email-type";
import { AudioFormat as DbAudioFormat } from "../storage/db-entities";

import { QueueType } from "./queue-type";

export type QueueMessage =
    | InviteUserEmailQueueMessage
    | InviteSysAdminEmailQueueMessage
    | NewContentEmailQueueMessage
    | ImportFileEventQueueMessage
    | ImportBatchTransferQueueMessage
    | ImportBatchValidationQueueMessage
    | ProcessAudioSectionQueueMessage
    | AudioEncodingQueueMessage
    | LargeAudioEncodingQueueMessage
    | EndAudioEncodingQueueMessage
    | SetFirstPasswordEmailQueueMessage
    ;

export type QueueMessageByType<QM, QT> = QM extends { queue: QT } ? QM : never;

interface QueueMessageBase {
    messageId?: string;
    queue: QueueType;
    // receiveCount: number;
    // firstReceivedAt: Date;
}

export interface InviteUserEmailQueueMessage extends QueueMessageBase {
    queue: QueueType.Email;
    userId: number;
    emailType: EmailType.Invitation;
    organisationId: number;
}

export interface InviteSysAdminEmailQueueMessage extends QueueMessageBase {
    queue: QueueType.Email;
    userId: number;
    emailType: EmailType.SysAdminInvitation;
}

export interface SetFirstPasswordEmailQueueMessage extends QueueMessageBase {
    queue: QueueType.Email;
    userId: number;
    emailType: EmailType.SetFirstPassword;
    organisationId: number;
}

export interface NewContentEmailQueueMessage extends QueueMessageBase {
    queue: QueueType.Email;
    userId: number;
    emailType: EmailType.NewContentAvailable;
    content: number | number[];
    organisationId: number;
}

export interface ImportFileEventQueueMessage extends QueueMessageBase {
    queue: QueueType.ImportFileEvent;

    // NB: This schema aligns with the queue message format created by AWS S3 notifications. https://docs.aws.amazon.com/AmazonS3/latest/dev/notification-content-structure.html
    Records: [{
        eventName: string;
        eventTime: string;
        userIdentity: {
            principalId: string;
        };
        s3: {
            bucket: {
                arn: string;
                name: string;
            };
            object: {
                key: string;
                size: number;
            };
        };
    }];
}

export interface ImportBatchTransferQueueMessage extends QueueMessageBase {
    queue: QueueType.ImportBatchTransfer;
    importId: number;
}

export interface ImportBatchValidationQueueMessage extends QueueMessageBase {
    queue: QueueType.ImportBatchValidation;
    importId: number;
}

export interface ProcessAudioSectionQueueMessage extends QueueMessageBase {
    queue: QueueType.ProcessAudioSection;
    pipelineId: string;
    contentId: number;
    sequence: number;
    originalNarrationStoragePath: string;
    originalNarrationSize: number;
    originalSoundtrackStoragePath: string | undefined;
    originalSoundtrackSize: number | undefined;
    totalSections: number;
}

// The same data must be passed through/retained for each step of the audio file encoding.
interface AudioEncodingQueueMessageBase extends QueueMessageBase {
    contentId: number;
    audioSectionId: number;
    sourceBucket: string;
    sourceStoragePath: string;
    format: DbAudioFormat;
    type: "narration" | "soundtrack";
    totalFiles: number;
    destinationBucket: string;
    destinationStoragePath: string;
    destinationContentType: string;
    destinationMetadata: { [key: string]: string };
}

export interface AudioEncodingQueueMessage extends AudioEncodingQueueMessageBase {
    queue: QueueType.AudioEncoding;
    completionQueueUrl: string;
    completionQueue: QueueType.EndAudioEncoding;
}

export interface LargeAudioEncodingQueueMessage extends AudioEncodingQueueMessageBase {
    queue: QueueType.LargeAudioEncoding;
    completionQueueUrl: string;
    completionQueue: QueueType.EndAudioEncoding;
}

export interface EndAudioEncodingQueueMessage extends AudioEncodingQueueMessageBase {
    queue: QueueType.EndAudioEncoding;
    fileBytes: number;
    duration: number;
}
