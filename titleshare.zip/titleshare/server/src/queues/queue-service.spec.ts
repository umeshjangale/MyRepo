import "jasmine";

import { EmailType } from "../email/email-type";

import { QueueService } from "./queue-service";
import { QueueType } from "./queue-type";

describe("Queue Service", () => {

    // This is a non-deterministic test due to other messages possibly existing in the queue, therefore disable it (i.e 'xit')
    xit("adds and receives a message via email queue (non-deterministic)", async () => {

        const qs = new QueueService();

        const msgId = await qs.addMessage({ queue: QueueType.Email, userId: 1, emailType: EmailType.SysAdminInvitation });

        await qs.receiveMessage(QueueType.Email, async msg => {

            const message = msg;

            expect(message.messageId).toEqual(msgId);
            expect(message.emailType).toEqual(EmailType.Invitation);
        });
    });
});
