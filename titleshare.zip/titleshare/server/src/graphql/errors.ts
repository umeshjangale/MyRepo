import { ApolloError } from "apollo-server-express";

export class UnsupportedAppVersionError extends ApolloError {
    constructor() {
        super("App version not supported", "UNSUPPORTED_APP_VERSION");

        Object.defineProperty(this, "name", { value: "UnsupportedAppVersionError" });
    }
}
