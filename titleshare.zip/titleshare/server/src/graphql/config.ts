import { AuthenticationError, Config, makeExecutableSchema } from "apollo-server-express";
import { Response } from "express";
import { GraphQLSchema } from "graphql";
import depthLimit from "graphql-depth-limit";

import config from "../config";
import { createLogger } from "../logger";
import { serviceContainer } from "../runtime/inversify.config";
import { SYMBOLS } from "../runtime/symbols";
import { UserRequest } from "../types/jwt-user";
import { assertNever } from "../utils";
import { getUserAgent, isSupportedAppVersion } from "../utils/user-agent-utils";
import { getCurrentUser, setAuthCookie } from "../web/auth";

import { Context, StorageContext } from "./context";
import { ValidateDirective } from "./directives/validate";
import { UnsupportedAppVersionError } from "./errors";
import { resolvers } from "./resolvers";
import typeDefs from "./type-defs";

export const getGqlSchema = (): GraphQLSchema => makeExecutableSchema({
    typeDefs: [typeDefs],
    resolvers: [resolvers],
    // It appears enforcing value restrictions doesn't actually work like the docs say https://www.apollographql.com/docs/apollo-server/features/creating-directives#enforcing-value-restrictions
    schemaDirectives: { validate: ValidateDirective },
});

export const gqlConfig: Config = {
    schema: getGqlSchema(),
    validationRules: [depthLimit(config.graphql.maxQueryDepth)],
    introspection: config.graphql.allowGraphqlIntrospection,
    context: async ({ req, res }: { req: UserRequest; res: Response }): Promise<Context> => {

        const context: Context = {
            storage: serviceContainer.get<StorageContext>(SYMBOLS.StorageContext),
            ipAddress: req.ip ? req.ip : "",
            userAgent: getUserAgent(req.headers),
            hasAuthenticationSignature: req.hasAuthenticationSignature || false,
            setAuthCookie: (value, csrf, validitySeconds) => { setAuthCookie(res, value, csrf, validitySeconds); },
        };

        if (!isSupportedAppVersion(context.userAgent, config.runtime.minimumIosAppVersion, config.runtime.minimumAndroidAppVersion)) {
            throw new UnsupportedAppVersionError();
        }

        const getUserOperation = await getCurrentUser(req, res);

        if (getUserOperation.hasError) {
            switch (getUserOperation.error) {
                case "not-authenticated":
                case "session-expired":
                    return context;
                default:
                    return assertNever(getUserOperation.error);
            }
        }

        context.user = getUserOperation.obj;
        return context;
    },
    formatError: error => {

        const log = createLogger("graphql API");
        const warningCodes = ["UNAUTHENTICATED", "BAD_USER_INPUT", "FORBIDDEN", "UNSUPPORTED_APP_VERSION"];
        if (error.extensions && error.extensions.code && warningCodes.indexOf(error.extensions.code) >= 0) {
            log.w("Graphql WARN", error);
        } else {
            log.e("Graphql ERROR", error);
        }

        if (config.graphql.hideErrorDetailsFromHttpResponse) {
            if (error.extensions && error.extensions.exception) {
                delete error.extensions.exception;
            }
        }

        return error;
    },
    playground: {
        settings: {
            "general.betaUpdates": false,
            "editor.cursorShape": "line", // possible values: 'line', 'block', 'underline'
            "editor.fontSize": 14,
            "editor.fontFamily": "'Source Code Pro', 'Consolas', 'Inconsolata', 'Droid Sans Mono', 'Monaco', monospace",
            "editor.theme": "dark", // possible values: 'dark', 'light'
            "editor.reuseHeaders": true, // new tab reuses headers from last tab
            "request.credentials": "same-origin", // possible values: 'omit', 'include', 'same-origin'
            "tracing.hideTracingResponse": true,
        },
    },
};
