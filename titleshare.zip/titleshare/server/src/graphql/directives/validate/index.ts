import { SchemaDirectiveVisitor, UserInputError } from "apollo-server-express";
import { GraphQLField, GraphQLInputField, GraphQLNonNull, GraphQLScalarType, GraphQLString } from "graphql";

import { ValidatedString } from "./validated-string";

/** The validate directive provides simple input validation for the API e.g minimum and maximum string length */
export class ValidateDirective extends SchemaDirectiveVisitor {

    visitInputFieldDefinition(field: GraphQLInputField) {
        this.wrapType(field);
    }

    visitFieldDefinition(field: GraphQLField<any, any>) {
        this.wrapType(field);
    }

    // Replace field.type with a custom GraphQLScalarType that enforces the validation
    wrapType(field: GraphQLInputField | GraphQLField<any, any>) {
        if (field.type instanceof GraphQLNonNull && field.type.ofType instanceof GraphQLScalarType && field.type.ofType === GraphQLString) {
            field.type = new GraphQLNonNull(new ValidatedString(field.name, field.type.ofType, this.args));
        } else if (field.type instanceof GraphQLScalarType && field.type === GraphQLString) {
            field.type = new ValidatedString(field.name, field.type, this.args);
            // Add more types here
        } else {
            throw new Error(`The @validate directive is not valid on type: ${field.type}. It must be on a string type.`);
        }
    }
}
