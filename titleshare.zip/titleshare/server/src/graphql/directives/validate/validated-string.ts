import { UserInputError } from "apollo-server-express";
import { GraphQLScalarType } from "graphql";
import validator from "validator";

export class ValidatedString extends GraphQLScalarType {
    constructor(fieldName: string, type: GraphQLScalarType, args: { [name: string]: any }) {
        super({
            name: "ValidatedString",

            serialize(value) {
                return type.serialize(value);
            },

            parseValue(value) {
                const v = type.serialize(value);
                if (typeof v !== "string") throw new Error(`Unexpected parsed value type ${v}`);
                validateString(fieldName, v, args);
                return type.parseValue(value);
            },

            parseLiteral(ast) {
                const v = type.parseLiteral(ast, undefined);
                if (typeof v !== "string") throw new Error(`Unexpected parsed value type ${v}`);

                validateString(fieldName, v, args);
                return v;
            },
        });
    }
}

function validateString(fieldName: string, value: string, args: { [name: string]: any }) {

    const trimmedValue = value.trim();
    if (args.minLength && args.maxLength && !validator.isLength(trimmedValue, { min: args.minLength, max: args.maxLength })) {
        throw new UserInputError(`"${fieldName}" must have a length between ${args.minLength} and ${args.maxLength}`);
    }

    if (args.minLength && !validator.isLength(trimmedValue, { min: args.minLength })) {
        throw new UserInputError(`"${fieldName}" must have a length greater than or equal to ${args.minLength}`);
    }

    if (args.maxLength && !validator.isLength(trimmedValue, { max: args.maxLength })) {
        throw new UserInputError(`"${fieldName}" must have a length less than or equal to ${args.maxLength}`);
    }

    if (args.type === "email" && !validator.isEmail(trimmedValue)) {
        throw new UserInputError(`"${fieldName}" must be an email`);
    }
}
