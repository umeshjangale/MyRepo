import { gql } from "apollo-server-express";

export const outputTypes = gql`

    scalar Date
    scalar Long

    interface Node {
        id: ID!
    }

    type LoginResponse {
        token: String!
        user: User!
    }

    union SignUpWithCodeResponse = SignUpWithCodeLoggedInResponse | SignUpWithCodeActionRequiredResponse

    type SignUpWithCodeLoggedInResponse {
        token: String!
        user: User!
    }

    type SignUpWithCodeActionRequiredResponse {
        actionRequired: SignUpWithCodeActionRequired!
    }

    type ResetPasswordResponse {
        user: User!
    }

    type User implements Node {
        id: ID!
        email: String!
        firstName: String!
        lastName: String!
        roles: [UserRole!]!
        content(pageSize: Int!, pageNumber: Int!, organisationId: ID, searchText: String): UserContentAccessList!
        userGroups(pageSize: Int!, pageNumber: Int!, organisationId: ID, searchText: String): UserUserGroups!
        contentCollections(pageSize: Int!, pageNumber: Int!, organisationId: ID, searchText: String): UserContentCollections!
        contentReportUri(organisationId: ID): String!
    }

    type UserUserGroups {
        items: [UserGroup!]!
        totalCount: Int!
    }

    type UserContentCollections {
        items: [ContentCollection!]!
        totalCount: Int!
    }

    type UserRole {
        type: RoleType!
        organisation: Organisation
    }

    type Content implements Node {
        id: ID!
        organisation: Organisation!
        type: ContentType!
        title: String!
        subtitle: String!
        description: String!
        author: String!
        narrator: String!
        publisher: String!
        releaseDate: Date
        "The duration of all audio files in seconds."
        totalDuration: Int!
        hasSoundtrack: Boolean!
        coverImageUris(sizes: [ImageSizeInput!]!): [String!]!
        language: Language!
        genre: Genre!
        secondGenre: Genre
        nonBillable: Boolean!
        nonBillableReason: String!
        "The sum of the number of bytes for all audio files"
        totalBytes(format: AudioFormat!): ContentAudioBytesSummary!

        audioSectionsHash: ID!
        audioSections(pageSize: Int!, pageNumber: Int!): ContentAudioSections!
        users(pageSize: Int!, pageNumber: Int!, accessSource: ContentAccessSource, searchText: String): ContentUsers!
        userGroups(pageSize: Int!, pageNumber: Int!, searchText: String): ContentUserGroups!
        contentCollections(pageSize: Int!, pageNumber: Int!, searchText: String): ContentContentCollections!

        "The bookmarked listening position of the logged in user"
        myBookmark: UserContentBookmark
        usersReportUri: String!
        createdDate: Date!
    }

    type ContentUserGroups {
        items: [UserGroup!]!
        totalCount: Int!
    }

    type ContentContentCollections {
        items: [ContentCollection!]!
        totalCount: Int!
    }

    type UserContentBookmark {
        "The zero based index of the audio section"
        audioSectionIndex: Int!
        "Time in seconds within the audio section"
        time: Float!
    }

    type ContentAudioBytesSummary {
        "The total number of bytes of all narration and soundtrack files"
        total: Long!
    }

    type ContentAudioSections {
        items: [AudioSection!]!
        totalCount: Int!
    }

    type AudioSection {
        title: String!
        narrationUri(format: AudioFormat!): AudioUri!
        soundtrackUri(format: AudioFormat!): AudioUri
    }

    type AudioUri {
        uri: String!
    }

    type Language {
        code: ID!
        name: String!
    }

    type Genre {
        code: ID!
        name: String!
    }

    type Organisation implements Node {
        id: ID!
        name: String!
        importStorageBucket: String
        importCoverImageRegex: String!
        importNarrationRegex: String!
        importSoundtrackRegex: String!
        importSftpUsername: String
        importSftpPassword: String
        content(pageSize: Int!, pageNumber: Int!, searchText: String): OrganisationContent!
        contentCollections(pageSize: Int!, pageNumber: Int!, searchText: String): OrganisationContentCollections!
        userGroups(pageSize: Int!, pageNumber: Int!, searchText: String): OrganisationUserGroups!
        users(pageSize: Int!, pageNumber: Int!, searchText: String): OrganisationUsers!
        usersReportUri: String!
        contentReportUri: String!
    }

    type OrganisationContent {
        items: [Content!]!
        totalCount: Int!
    }

    type OrganisationContentCollections {
        items: [ContentCollection!]!
        totalCount: Int!
    }

    type OrganisationUserGroups {
        items: [UserGroup!]!
        totalCount: Int!
    }

    type OrganisationUsers {
        items: [User!]!
        totalCount: Int!
    }

    type UserGroup implements Node {
        id: ID!
        name: String!
        description: String!
        users(pageSize: Int!, pageNumber: Int!, searchText: String): UserGroupUsers!
        organisation: Organisation!
        content(pageSize: Int!, pageNumber: Int!, searchText: String): UserGroupContent!
    }

    type UserGroupContent {
        items: [Content!]!
        totalCount: Int!
    }

    type ContentCollection implements Node {
        id: ID!
        name: String!
        description: String!
        signUpCode: String
        signUpCodeEnabled: Boolean!
        organisation: Organisation!
        content(pageSize: Int!, pageNumber: Int!, searchText: String): ContentCollectionContent!
        users(pageSize: Int!, pageNumber: Int!, searchText: String): ContentCollectionUsers!
    }

    type ContentCollectionUsers {
        items: [User!]!
        totalCount: Int!
    }

    type InviteSystemAdminResponse {
        user: User!
    }

    type InviteUserResponse {
        user: User!
    }

    type GrantUserSpecialisedOrganisationAdminRoleResponse {
        user: User!
    }

    type RevokeUserSpecialisedOrganisationAdminRoleResponse {
        user: User!
    }

    type NodeSearchResponse {
        items: [Node!]!
        totalCount: Int!
    }

    type ContentSearchResponse {
        items: [Content!]!
        totalCount: Int!
    }

    type OrganisationSearchResponse {
        items: [Organisation!]!
        totalCount: Int!
    }

    type UserSearchResponse {
        items: [User!]!
        totalCount: Int!
    }

    type SysAdminSearchResponse {
        items: [User!]!
        totalCount: Int!
    }

    type UserGroupUsers {
        items: [User!]!
        totalCount: Int!
    }

    type ContentCollectionContent {
        items: [Content!]!
        totalCount: Int!
    }

    type RemoveUserContentAccessResponse {
        user: User!
        content: Content!
    }

    type UserContentAccessList {
        items: [UserContentAccess!]!
        totalCount: Int!
    }

    type UserContentAccess {
        content: Content!
        sources: [UserContentAccessSource!]!
    }

    type UserContentAccessSource {
        source: ContentAccessSource!
    }

    type ContentUsers {
        items: [ContentUser!]!
        totalCount: Int!
    }

    type ContentUser {
        user: User!
        sources: [UserContentAccessSource!]!
    }

    type AddAssociationResponse {
        node: Node!
        associateNode: Node!
    }

    type RemoveAssociationResponse {
        node: Node!
        associateNode: Node!
    }

    type RequestPasswordResetResponse {
        success: Boolean!
    }

    type LogPlaybackResponse {
        content: Content!
    }

    type ContentAccessReasonsResponse {
        direct: Boolean!
        userGroups(pageSize: Int!, pageNumber: Int!): ContentAccessReasonsUserGroups!
        contentCollections(pageSize: Int!, pageNumber: Int!): ContentAccessReasonsContentCollections!
    }

    type ContentAccessReasonsUserGroups {
        items: [UserGroup!]!
        totalCount: Int!
    }

    type ContentAccessReasonsContentCollections {
        items: [ContentCollection!]!
        totalCount: Int!
    }

    type TechnicalIssuesResponse {
        message: String!
    }
`;
