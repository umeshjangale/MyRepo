/* This file is auto generated. Do not edit it */
/* tslint:disable */
import { Context } from "../context";

export type Long = number;

export type ValidatedString = any;

export interface Node {
    __typename: string;
    id:
        | string
        | ((
              this: Node,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface Query {
    me:
        | User
        | ((
              obj: undefined,
              args: {},
              context: Context
          ) => User | Promise<User>);
    node?:
        | Node
        | null
        | ((
              obj: undefined,
              args: NodeQueryArgs,
              context: Context
          ) => Node | null | Promise<Node | null>);
    nodes:
        | (Node | null)[]
        | ((
              obj: undefined,
              args: NodesQueryArgs,
              context: Context
          ) => (Node | null)[] | Promise<(Node | null)[]>);
    searchContent:
        | ContentSearchResponse
        | ((
              obj: undefined,
              args: SearchContentQueryArgs,
              context: Context
          ) =>
              | ContentSearchResponse
              | Promise<
                    ContentSearchResponse
                >) /** For use by any user to fetch all content assigned to them. */;
    searchOrganisations:
        | OrganisationSearchResponse
        | ((
              obj: undefined,
              args: SearchOrganisationsQueryArgs,
              context: Context
          ) =>
              | OrganisationSearchResponse
              | Promise<OrganisationSearchResponse>);
    searchSysAdmins:
        | SysAdminSearchResponse
        | ((
              obj: undefined,
              args: SearchSysAdminsQueryArgs,
              context: Context
          ) => SysAdminSearchResponse | Promise<SysAdminSearchResponse>);
    suggestionsForAssociation:
        | NodeSearchResponse
        | ((
              obj: undefined,
              args: SuggestionsForAssociationQueryArgs,
              context: Context
          ) => NodeSearchResponse | Promise<NodeSearchResponse>);
    contentAccessReasons:
        | ContentAccessReasonsResponse
        | ((
              obj: undefined,
              args: ContentAccessReasonsQueryArgs,
              context: Context
          ) =>
              | ContentAccessReasonsResponse
              | Promise<ContentAccessReasonsResponse>);
    languages:
        | Language[]
        | ((
              obj: undefined,
              args: {},
              context: Context
          ) => Language[] | Promise<Language[]>);
    genres:
        | Genre[]
        | ((
              obj: undefined,
              args: {},
              context: Context
          ) => Genre[] | Promise<Genre[]>);
}

export interface User extends Node {
    email:
        | string
        | ((
              this: User,
              args: {},
              context: Context
          ) => string | Promise<string>);
    firstName:
        | string
        | ((
              this: User,
              args: {},
              context: Context
          ) => string | Promise<string>);
    lastName:
        | string
        | ((
              this: User,
              args: {},
              context: Context
          ) => string | Promise<string>);
    roles:
        | UserRole[]
        | ((
              this: User,
              args: {},
              context: Context
          ) => UserRole[] | Promise<UserRole[]>);
    content:
        | UserContentAccessList
        | ((
              this: User,
              args: ContentUserArgs,
              context: Context
          ) => UserContentAccessList | Promise<UserContentAccessList>);
    userGroups:
        | UserUserGroups
        | ((
              this: User,
              args: UserGroupsUserArgs,
              context: Context
          ) => UserUserGroups | Promise<UserUserGroups>);
    contentCollections:
        | UserContentCollections
        | ((
              this: User,
              args: ContentCollectionsUserArgs,
              context: Context
          ) => UserContentCollections | Promise<UserContentCollections>);
    contentReportUri:
        | string
        | ((
              this: User,
              args: ContentReportUriUserArgs,
              context: Context
          ) => string | Promise<string>);
}

export interface UserRole {
    type:
        | RoleType
        | ((
              this: UserRole,
              args: {},
              context: Context
          ) => RoleType | Promise<RoleType>);
    organisation?:
        | Organisation
        | null
        | ((
              this: UserRole,
              args: {},
              context: Context
          ) => Organisation | null | Promise<Organisation | null>);
}

export interface Organisation extends Node {
    name:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
    importStorageBucket?:
        | string
        | null
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | null | Promise<string | null>);
    importCoverImageRegex:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
    importNarrationRegex:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
    importSoundtrackRegex:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
    importSftpUsername?:
        | string
        | null
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | null | Promise<string | null>);
    importSftpPassword?:
        | string
        | null
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | null | Promise<string | null>);
    content:
        | OrganisationContent
        | ((
              this: Organisation,
              args: ContentOrganisationArgs,
              context: Context
          ) => OrganisationContent | Promise<OrganisationContent>);
    contentCollections:
        | OrganisationContentCollections
        | ((
              this: Organisation,
              args: ContentCollectionsOrganisationArgs,
              context: Context
          ) =>
              | OrganisationContentCollections
              | Promise<OrganisationContentCollections>);
    userGroups:
        | OrganisationUserGroups
        | ((
              this: Organisation,
              args: UserGroupsOrganisationArgs,
              context: Context
          ) => OrganisationUserGroups | Promise<OrganisationUserGroups>);
    users:
        | OrganisationUsers
        | ((
              this: Organisation,
              args: UsersOrganisationArgs,
              context: Context
          ) => OrganisationUsers | Promise<OrganisationUsers>);
    usersReportUri:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
    contentReportUri:
        | string
        | ((
              this: Organisation,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface OrganisationContent {
    items:
        | Content[]
        | ((
              this: OrganisationContent,
              args: {},
              context: Context
          ) => Content[] | Promise<Content[]>);
    totalCount:
        | number
        | ((
              this: OrganisationContent,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface Content extends Node {
    organisation:
        | Organisation
        | ((
              this: Content,
              args: {},
              context: Context
          ) => Organisation | Promise<Organisation>);
    type:
        | ContentType
        | ((
              this: Content,
              args: {},
              context: Context
          ) => ContentType | Promise<ContentType>);
    title:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    subtitle:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    description:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    author:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    narrator:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    publisher:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    releaseDate?:
        | Date
        | null
        | ((
              this: Content,
              args: {},
              context: Context
          ) => Date | null | Promise<Date | null>);
    totalDuration:
        | number
        | ((
              this: Content,
              args: {},
              context: Context
          ) =>
              | number
              | Promise<
                    number
                >) /** The duration of all audio files in seconds. */;
    hasSoundtrack:
        | boolean
        | ((
              this: Content,
              args: {},
              context: Context
          ) => boolean | Promise<boolean>);
    coverImageUris:
        | string[]
        | ((
              this: Content,
              args: CoverImageUrisContentArgs,
              context: Context
          ) => string[] | Promise<string[]>);
    language:
        | Language
        | ((
              this: Content,
              args: {},
              context: Context
          ) => Language | Promise<Language>);
    genre:
        | Genre
        | ((
              this: Content,
              args: {},
              context: Context
          ) => Genre | Promise<Genre>);
    secondGenre?:
        | Genre
        | null
        | ((
              this: Content,
              args: {},
              context: Context
          ) => Genre | null | Promise<Genre | null>);
    nonBillable:
        | boolean
        | ((
              this: Content,
              args: {},
              context: Context
          ) => boolean | Promise<boolean>);
    nonBillableReason:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    totalBytes:
        | ContentAudioBytesSummary
        | ((
              this: Content,
              args: TotalBytesContentArgs,
              context: Context
          ) =>
              | ContentAudioBytesSummary
              | Promise<
                    ContentAudioBytesSummary
                >) /** The sum of the number of bytes for all audio files */;
    audioSectionsHash:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    audioSections:
        | ContentAudioSections
        | ((
              this: Content,
              args: AudioSectionsContentArgs,
              context: Context
          ) => ContentAudioSections | Promise<ContentAudioSections>);
    users:
        | ContentUsers
        | ((
              this: Content,
              args: UsersContentArgs,
              context: Context
          ) => ContentUsers | Promise<ContentUsers>);
    userGroups:
        | ContentUserGroups
        | ((
              this: Content,
              args: UserGroupsContentArgs,
              context: Context
          ) => ContentUserGroups | Promise<ContentUserGroups>);
    contentCollections:
        | ContentContentCollections
        | ((
              this: Content,
              args: ContentCollectionsContentArgs,
              context: Context
          ) => ContentContentCollections | Promise<ContentContentCollections>);
    myBookmark?:
        | UserContentBookmark
        | null
        | ((
              this: Content,
              args: {},
              context: Context
          ) =>
              | UserContentBookmark
              | null
              | Promise<UserContentBookmark | null>) /** The bookmarked listening position of the logged in user */;
    usersReportUri:
        | string
        | ((
              this: Content,
              args: {},
              context: Context
          ) => string | Promise<string>);
    createdDate:
        | Date
        | ((this: Content, args: {}, context: Context) => Date | Promise<Date>);
}

export interface Language {
    code:
        | string
        | ((
              this: Language,
              args: {},
              context: Context
          ) => string | Promise<string>);
    name:
        | string
        | ((
              this: Language,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface Genre {
    code:
        | string
        | ((
              this: Genre,
              args: {},
              context: Context
          ) => string | Promise<string>);
    name:
        | string
        | ((
              this: Genre,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface ContentAudioBytesSummary {
    total:
        | Long
        | ((
              this: ContentAudioBytesSummary,
              args: {},
              context: Context
          ) =>
              | Long
              | Promise<
                    Long
                >) /** The total number of bytes of all narration and soundtrack files */;
}

export interface ContentAudioSections {
    items:
        | AudioSection[]
        | ((
              this: ContentAudioSections,
              args: {},
              context: Context
          ) => AudioSection[] | Promise<AudioSection[]>);
    totalCount:
        | number
        | ((
              this: ContentAudioSections,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface AudioSection {
    title:
        | string
        | ((
              this: AudioSection,
              args: {},
              context: Context
          ) => string | Promise<string>);
    narrationUri:
        | AudioUri
        | ((
              this: AudioSection,
              args: NarrationUriAudioSectionArgs,
              context: Context
          ) => AudioUri | Promise<AudioUri>);
    soundtrackUri?:
        | AudioUri
        | null
        | ((
              this: AudioSection,
              args: SoundtrackUriAudioSectionArgs,
              context: Context
          ) => AudioUri | null | Promise<AudioUri | null>);
}

export interface AudioUri {
    uri:
        | string
        | ((
              this: AudioUri,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface ContentUsers {
    items:
        | ContentUser[]
        | ((
              this: ContentUsers,
              args: {},
              context: Context
          ) => ContentUser[] | Promise<ContentUser[]>);
    totalCount:
        | number
        | ((
              this: ContentUsers,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentUser {
    user:
        | User
        | ((
              this: ContentUser,
              args: {},
              context: Context
          ) => User | Promise<User>);
    sources:
        | UserContentAccessSource[]
        | ((
              this: ContentUser,
              args: {},
              context: Context
          ) => UserContentAccessSource[] | Promise<UserContentAccessSource[]>);
}

export interface UserContentAccessSource {
    source:
        | ContentAccessSource
        | ((
              this: UserContentAccessSource,
              args: {},
              context: Context
          ) => ContentAccessSource | Promise<ContentAccessSource>);
}

export interface ContentUserGroups {
    items:
        | UserGroup[]
        | ((
              this: ContentUserGroups,
              args: {},
              context: Context
          ) => UserGroup[] | Promise<UserGroup[]>);
    totalCount:
        | number
        | ((
              this: ContentUserGroups,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserGroup extends Node {
    name:
        | string
        | ((
              this: UserGroup,
              args: {},
              context: Context
          ) => string | Promise<string>);
    description:
        | string
        | ((
              this: UserGroup,
              args: {},
              context: Context
          ) => string | Promise<string>);
    users:
        | UserGroupUsers
        | ((
              this: UserGroup,
              args: UsersUserGroupArgs,
              context: Context
          ) => UserGroupUsers | Promise<UserGroupUsers>);
    organisation:
        | Organisation
        | ((
              this: UserGroup,
              args: {},
              context: Context
          ) => Organisation | Promise<Organisation>);
    content:
        | UserGroupContent
        | ((
              this: UserGroup,
              args: ContentUserGroupArgs,
              context: Context
          ) => UserGroupContent | Promise<UserGroupContent>);
}

export interface UserGroupUsers {
    items:
        | User[]
        | ((
              this: UserGroupUsers,
              args: {},
              context: Context
          ) => User[] | Promise<User[]>);
    totalCount:
        | number
        | ((
              this: UserGroupUsers,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserGroupContent {
    items:
        | Content[]
        | ((
              this: UserGroupContent,
              args: {},
              context: Context
          ) => Content[] | Promise<Content[]>);
    totalCount:
        | number
        | ((
              this: UserGroupContent,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentContentCollections {
    items:
        | ContentCollection[]
        | ((
              this: ContentContentCollections,
              args: {},
              context: Context
          ) => ContentCollection[] | Promise<ContentCollection[]>);
    totalCount:
        | number
        | ((
              this: ContentContentCollections,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentCollection extends Node {
    name:
        | string
        | ((
              this: ContentCollection,
              args: {},
              context: Context
          ) => string | Promise<string>);
    description:
        | string
        | ((
              this: ContentCollection,
              args: {},
              context: Context
          ) => string | Promise<string>);
    signUpCode?:
        | string
        | null
        | ((
              this: ContentCollection,
              args: {},
              context: Context
          ) => string | null | Promise<string | null>);
    signUpCodeEnabled:
        | boolean
        | ((
              this: ContentCollection,
              args: {},
              context: Context
          ) => boolean | Promise<boolean>);
    organisation:
        | Organisation
        | ((
              this: ContentCollection,
              args: {},
              context: Context
          ) => Organisation | Promise<Organisation>);
    content:
        | ContentCollectionContent
        | ((
              this: ContentCollection,
              args: ContentContentCollectionArgs,
              context: Context
          ) => ContentCollectionContent | Promise<ContentCollectionContent>);
    users:
        | ContentCollectionUsers
        | ((
              this: ContentCollection,
              args: UsersContentCollectionArgs,
              context: Context
          ) => ContentCollectionUsers | Promise<ContentCollectionUsers>);
}

export interface ContentCollectionContent {
    items:
        | Content[]
        | ((
              this: ContentCollectionContent,
              args: {},
              context: Context
          ) => Content[] | Promise<Content[]>);
    totalCount:
        | number
        | ((
              this: ContentCollectionContent,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentCollectionUsers {
    items:
        | User[]
        | ((
              this: ContentCollectionUsers,
              args: {},
              context: Context
          ) => User[] | Promise<User[]>);
    totalCount:
        | number
        | ((
              this: ContentCollectionUsers,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserContentBookmark {
    audioSectionIndex:
        | number
        | ((
              this: UserContentBookmark,
              args: {},
              context: Context
          ) =>
              | number
              | Promise<
                    number
                >) /** The zero based index of the audio section */;
    time:
        | number
        | ((
              this: UserContentBookmark,
              args: {},
              context: Context
          ) =>
              | number
              | Promise<
                    number
                >) /** Time in seconds within the audio section */;
}

export interface OrganisationContentCollections {
    items:
        | ContentCollection[]
        | ((
              this: OrganisationContentCollections,
              args: {},
              context: Context
          ) => ContentCollection[] | Promise<ContentCollection[]>);
    totalCount:
        | number
        | ((
              this: OrganisationContentCollections,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface OrganisationUserGroups {
    items:
        | UserGroup[]
        | ((
              this: OrganisationUserGroups,
              args: {},
              context: Context
          ) => UserGroup[] | Promise<UserGroup[]>);
    totalCount:
        | number
        | ((
              this: OrganisationUserGroups,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface OrganisationUsers {
    items:
        | User[]
        | ((
              this: OrganisationUsers,
              args: {},
              context: Context
          ) => User[] | Promise<User[]>);
    totalCount:
        | number
        | ((
              this: OrganisationUsers,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserContentAccessList {
    items:
        | UserContentAccess[]
        | ((
              this: UserContentAccessList,
              args: {},
              context: Context
          ) => UserContentAccess[] | Promise<UserContentAccess[]>);
    totalCount:
        | number
        | ((
              this: UserContentAccessList,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserContentAccess {
    content:
        | Content
        | ((
              this: UserContentAccess,
              args: {},
              context: Context
          ) => Content | Promise<Content>);
    sources:
        | UserContentAccessSource[]
        | ((
              this: UserContentAccess,
              args: {},
              context: Context
          ) => UserContentAccessSource[] | Promise<UserContentAccessSource[]>);
}

export interface UserUserGroups {
    items:
        | UserGroup[]
        | ((
              this: UserUserGroups,
              args: {},
              context: Context
          ) => UserGroup[] | Promise<UserGroup[]>);
    totalCount:
        | number
        | ((
              this: UserUserGroups,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface UserContentCollections {
    items:
        | ContentCollection[]
        | ((
              this: UserContentCollections,
              args: {},
              context: Context
          ) => ContentCollection[] | Promise<ContentCollection[]>);
    totalCount:
        | number
        | ((
              this: UserContentCollections,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentSearchResponse {
    items:
        | Content[]
        | ((
              this: ContentSearchResponse,
              args: {},
              context: Context
          ) => Content[] | Promise<Content[]>);
    totalCount:
        | number
        | ((
              this: ContentSearchResponse,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface OrganisationSearchResponse {
    items:
        | Organisation[]
        | ((
              this: OrganisationSearchResponse,
              args: {},
              context: Context
          ) => Organisation[] | Promise<Organisation[]>);
    totalCount:
        | number
        | ((
              this: OrganisationSearchResponse,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface SysAdminSearchResponse {
    items:
        | User[]
        | ((
              this: SysAdminSearchResponse,
              args: {},
              context: Context
          ) => User[] | Promise<User[]>);
    totalCount:
        | number
        | ((
              this: SysAdminSearchResponse,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface NodeSearchResponse {
    items:
        | Node[]
        | ((
              this: NodeSearchResponse,
              args: {},
              context: Context
          ) => Node[] | Promise<Node[]>);
    totalCount:
        | number
        | ((
              this: NodeSearchResponse,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentAccessReasonsResponse {
    direct:
        | boolean
        | ((
              this: ContentAccessReasonsResponse,
              args: {},
              context: Context
          ) => boolean | Promise<boolean>);
    userGroups:
        | ContentAccessReasonsUserGroups
        | ((
              this: ContentAccessReasonsResponse,
              args: UserGroupsContentAccessReasonsResponseArgs,
              context: Context
          ) =>
              | ContentAccessReasonsUserGroups
              | Promise<ContentAccessReasonsUserGroups>);
    contentCollections:
        | ContentAccessReasonsContentCollections
        | ((
              this: ContentAccessReasonsResponse,
              args: ContentCollectionsContentAccessReasonsResponseArgs,
              context: Context
          ) =>
              | ContentAccessReasonsContentCollections
              | Promise<ContentAccessReasonsContentCollections>);
}

export interface ContentAccessReasonsUserGroups {
    items:
        | UserGroup[]
        | ((
              this: ContentAccessReasonsUserGroups,
              args: {},
              context: Context
          ) => UserGroup[] | Promise<UserGroup[]>);
    totalCount:
        | number
        | ((
              this: ContentAccessReasonsUserGroups,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface ContentAccessReasonsContentCollections {
    items:
        | ContentCollection[]
        | ((
              this: ContentAccessReasonsContentCollections,
              args: {},
              context: Context
          ) => ContentCollection[] | Promise<ContentCollection[]>);
    totalCount:
        | number
        | ((
              this: ContentAccessReasonsContentCollections,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface Mutation {
    login:
        | LoginResponse
        | ((
              obj: undefined,
              args: LoginMutationArgs,
              context: Context
          ) => LoginResponse | Promise<LoginResponse>);
    logout?:
        | boolean
        | null
        | ((
              obj: undefined,
              args: LogoutMutationArgs,
              context: Context
          ) => boolean | null | Promise<boolean | null>);
    signUpWithCode:
        | SignUpWithCodeResponse
        | ((
              obj: undefined,
              args: SignUpWithCodeMutationArgs,
              context: Context
          ) => SignUpWithCodeResponse | Promise<SignUpWithCodeResponse>);
    updateMe:
        | User
        | ((
              obj: undefined,
              args: UpdateMeMutationArgs,
              context: Context
          ) => User | Promise<User>);
    inviteSystemAdmin:
        | InviteSystemAdminResponse
        | ((
              obj: undefined,
              args: InviteSystemAdminMutationArgs,
              context: Context
          ) => InviteSystemAdminResponse | Promise<InviteSystemAdminResponse>);
    removeSystemAdmin:
        | Query
        | ((
              obj: undefined,
              args: RemoveSystemAdminMutationArgs,
              context: Context
          ) => Query | Promise<Query>);
    createOrganisation:
        | Organisation
        | ((
              obj: undefined,
              args: CreateOrganisationMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    updateOrganisation:
        | Organisation
        | ((
              obj: undefined,
              args: UpdateOrganisationMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    inviteUser:
        | InviteUserResponse
        | ((
              obj: undefined,
              args: InviteUserMutationArgs,
              context: Context
          ) => InviteUserResponse | Promise<InviteUserResponse>);
    grantUserSpecialisedOrganisationAdminRole:
        | GrantUserSpecialisedOrganisationAdminRoleResponse
        | ((
              obj: undefined,
              args: GrantUserSpecialisedOrganisationAdminRoleMutationArgs,
              context: Context
          ) =>
              | GrantUserSpecialisedOrganisationAdminRoleResponse
              | Promise<GrantUserSpecialisedOrganisationAdminRoleResponse>);
    updateUser:
        | User
        | ((
              obj: undefined,
              args: UpdateUserMutationArgs,
              context: Context
          ) => User | Promise<User>);
    removeUserFromOrganisation:
        | Organisation
        | ((
              obj: undefined,
              args: RemoveUserFromOrganisationMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    revokeUserSpecialisedOrganisationAdminRole:
        | RevokeUserSpecialisedOrganisationAdminRoleResponse
        | ((
              obj: undefined,
              args: RevokeUserSpecialisedOrganisationAdminRoleMutationArgs,
              context: Context
          ) =>
              | RevokeUserSpecialisedOrganisationAdminRoleResponse
              | Promise<RevokeUserSpecialisedOrganisationAdminRoleResponse>);
    requestPasswordReset:
        | RequestPasswordResetResponse
        | ((
              obj: undefined,
              args: RequestPasswordResetMutationArgs,
              context: Context
          ) =>
              | RequestPasswordResetResponse
              | Promise<RequestPasswordResetResponse>);
    resetPassword:
        | ResetPasswordResponse
        | ((
              obj: undefined,
              args: ResetPasswordMutationArgs,
              context: Context
          ) => ResetPasswordResponse | Promise<ResetPasswordResponse>);
    createUserGroup:
        | UserGroup
        | ((
              obj: undefined,
              args: CreateUserGroupMutationArgs,
              context: Context
          ) => UserGroup | Promise<UserGroup>);
    updateUserGroup:
        | UserGroup
        | ((
              obj: undefined,
              args: UpdateUserGroupMutationArgs,
              context: Context
          ) => UserGroup | Promise<UserGroup>);
    removeUserGroup:
        | Organisation
        | ((
              obj: undefined,
              args: RemoveUserGroupMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    createContentCollection:
        | ContentCollection
        | ((
              obj: undefined,
              args: CreateContentCollectionMutationArgs,
              context: Context
          ) => ContentCollection | Promise<ContentCollection>);
    updateContentCollection:
        | ContentCollection
        | ((
              obj: undefined,
              args: UpdateContentCollectionMutationArgs,
              context: Context
          ) => ContentCollection | Promise<ContentCollection>);
    removeContentCollection:
        | Organisation
        | ((
              obj: undefined,
              args: RemoveContentCollectionMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    updateContent:
        | Content
        | ((
              obj: undefined,
              args: UpdateContentMutationArgs,
              context: Context
          ) => Content | Promise<Content>);
    removeContent:
        | Organisation
        | ((
              obj: undefined,
              args: RemoveContentMutationArgs,
              context: Context
          ) => Organisation | Promise<Organisation>);
    addAssociation:
        | AddAssociationResponse
        | ((
              obj: undefined,
              args: AddAssociationMutationArgs,
              context: Context
          ) => AddAssociationResponse | Promise<AddAssociationResponse>);
    removeAssociation:
        | RemoveAssociationResponse
        | ((
              obj: undefined,
              args: RemoveAssociationMutationArgs,
              context: Context
          ) => RemoveAssociationResponse | Promise<RemoveAssociationResponse>);
    joinCode:
        | Node
        | ((
              obj: undefined,
              args: JoinCodeMutationArgs,
              context: Context
          ) => Node | Promise<Node>);
    logPlayback:
        | LogPlaybackResponse
        | ((
              obj: undefined,
              args: LogPlaybackMutationArgs,
              context: Context
          ) =>
              | LogPlaybackResponse
              | Promise<
                    LogPlaybackResponse
                >) /** Logs the regions of the book the user has played. The most recent playback region is used as the user's bookmark. */;
    recordTechnicalIssues:
        | TechnicalIssuesResponse
        | ((
              obj: undefined,
              args: RecordTechnicalIssuesMutationArgs,
              context: Context
          ) => TechnicalIssuesResponse | Promise<TechnicalIssuesResponse>);
}

export interface LoginResponse {
    token:
        | string
        | ((
              this: LoginResponse,
              args: {},
              context: Context
          ) => string | Promise<string>);
    user:
        | User
        | ((
              this: LoginResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface SignUpWithCodeLoggedInResponse {
    token:
        | string
        | ((
              this: SignUpWithCodeLoggedInResponse,
              args: {},
              context: Context
          ) => string | Promise<string>);
    user:
        | User
        | ((
              this: SignUpWithCodeLoggedInResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface SignUpWithCodeActionRequiredResponse {
    actionRequired:
        | SignUpWithCodeActionRequired
        | ((
              this: SignUpWithCodeActionRequiredResponse,
              args: {},
              context: Context
          ) =>
              | SignUpWithCodeActionRequired
              | Promise<SignUpWithCodeActionRequired>);
}

export interface InviteSystemAdminResponse {
    user:
        | User
        | ((
              this: InviteSystemAdminResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface InviteUserResponse {
    user:
        | User
        | ((
              this: InviteUserResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface GrantUserSpecialisedOrganisationAdminRoleResponse {
    user:
        | User
        | ((
              this: GrantUserSpecialisedOrganisationAdminRoleResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface RevokeUserSpecialisedOrganisationAdminRoleResponse {
    user:
        | User
        | ((
              this: RevokeUserSpecialisedOrganisationAdminRoleResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface RequestPasswordResetResponse {
    success:
        | boolean
        | ((
              this: RequestPasswordResetResponse,
              args: {},
              context: Context
          ) => boolean | Promise<boolean>);
}

export interface ResetPasswordResponse {
    user:
        | User
        | ((
              this: ResetPasswordResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
}

export interface AddAssociationResponse {
    node:
        | Node
        | ((
              this: AddAssociationResponse,
              args: {},
              context: Context
          ) => Node | Promise<Node>);
    associateNode:
        | Node
        | ((
              this: AddAssociationResponse,
              args: {},
              context: Context
          ) => Node | Promise<Node>);
}

export interface RemoveAssociationResponse {
    node:
        | Node
        | ((
              this: RemoveAssociationResponse,
              args: {},
              context: Context
          ) => Node | Promise<Node>);
    associateNode:
        | Node
        | ((
              this: RemoveAssociationResponse,
              args: {},
              context: Context
          ) => Node | Promise<Node>);
}

export interface LogPlaybackResponse {
    content:
        | Content
        | ((
              this: LogPlaybackResponse,
              args: {},
              context: Context
          ) => Content | Promise<Content>);
}

export interface TechnicalIssuesResponse {
    message:
        | string
        | ((
              this: TechnicalIssuesResponse,
              args: {},
              context: Context
          ) => string | Promise<string>);
}

export interface UserSearchResponse {
    items:
        | User[]
        | ((
              this: UserSearchResponse,
              args: {},
              context: Context
          ) => User[] | Promise<User[]>);
    totalCount:
        | number
        | ((
              this: UserSearchResponse,
              args: {},
              context: Context
          ) => number | Promise<number>);
}

export interface RemoveUserContentAccessResponse {
    user:
        | User
        | ((
              this: RemoveUserContentAccessResponse,
              args: {},
              context: Context
          ) => User | Promise<User>);
    content:
        | Content
        | ((
              this: RemoveUserContentAccessResponse,
              args: {},
              context: Context
          ) => Content | Promise<Content>);
}

export interface ImageSizeInput {
    height: number;
    width: number;
}

export interface LoginInput {
    email: string;
    password: string;
    useCookie?: boolean | null;
}

export interface LogoutInput {
    allDevices: boolean;
}

export interface SignUpWithCodeInput {
    email: string;
    code: string;
    useCookie: boolean;
}

export interface UpdateMeInput {
    firstName?: string | null;
    lastName?: string | null;
    currentPassword?: string | null;
    newPassword?: string | null;
}

export interface InviteSystemAdminInput {
    email: string;
    firstName: string;
    lastName: string;
}

export interface RemoveSystemAdminInput {
    userId: string;
}

export interface CreateOrganisationInput {
    name: string;
}

export interface UpdateOrganisationInput {
    id: string;
    name?: string | null;
    importStorageBucket?: string | null;
    importCoverImageRegex?: string | null;
    importNarrationRegex?: string | null;
    importSoundtrackRegex?: string | null;
    importSftpUsername?: string | null;
    importSftpPassword?: string | null;
}

export interface InviteUserInput {
    email: string;
    firstName: string;
    lastName: string;
    organisationId?: string | null;
    roleType: RoleType;
}

export interface GrantUserSpecialisedOrganisationAdminRoleInput {
    userId: string;
    organisationId: string;
    roleType: RoleType;
}

export interface UpdateUserInput {
    id: string;
    firstName?: string | null;
    lastName?: string | null;
}

export interface RemoveUserFromOrganisationInput {
    userId: string;
    organisationId: string;
}

export interface RevokeUserSpecialisedOrganisationAdminRoleInput {
    userId: string;
    organisationId: string;
    roleType: RoleType;
}

export interface RequestPasswordResetInput {
    email: string;
}

export interface ResetPasswordInput {
    email: string;
    resetToken: string;
    password: string;
}

export interface CreateUserGroupInput {
    name: string;
    description: string;
    organisationId: string;
}

export interface UpdateUserGroupInput {
    id: string;
    name?: string | null;
    description?: string | null;
}

export interface RemoveUserGroupInput {
    id: string;
}

export interface CreateContentCollectionInput {
    name: string;
    description: string;
    organisationId: string;
}

export interface UpdateContentCollectionInput {
    id: string;
    name?: string | null;
    description?: string | null;
    signUpCode?: string | null;
    signUpCodeEnabled?: boolean | null;
}

export interface RemoveContentCollectionInput {
    id: string;
}

export interface UpdateContentInput {
    id: string;
    title?: string | null;
    subtitle?: string | null;
    description?: string | null;
    author?: string | null;
    narrator?: string | null;
    publisher?: string | null;
    releaseDate?: Date | null;
    languageCode?: string | null;
    genreCode?: string | null;
    secondGenreCode?: string | null;
    nonBillable?: boolean | null;
    nonBillableReason?: string | null;
}

export interface RemoveContentInput {
    id: string;
}

export interface AddAssociationInput {
    id: string;
    associateId: string;
}

export interface RemoveAssociationInput {
    id: string;
    associateId: string;
}

export interface JoinCodeInput {
    code: string;
}

export interface LogPlaybackInput {
    contentId: string;
    playbackRegions: PlaybackRegion[];
}

export interface PlaybackRegion {
    audioSectionsHash: string;
    audioSectionIndex: number /** The zero based index of the audio section */;
    startTime: number /** Start time in seconds within the audio section */;
    endTime: number /** End time in seconds within the audio section */;
    endTimestamp: Date;
}

export interface TechnicalIssuesInput {
    data: string[];
}
export interface NodeQueryArgs {
    id: string;
}
export interface NodesQueryArgs {
    ids: string[];
}
export interface SearchContentQueryArgs {
    pageSize: number;
    pageNumber: number;
}
export interface SearchOrganisationsQueryArgs {
    pageSize: number;
    pageNumber: number;
}
export interface SearchSysAdminsQueryArgs {
    pageSize: number;
    pageNumber: number;
}
export interface SuggestionsForAssociationQueryArgs {
    suggestionType: NodeType;
    id: string;
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface ContentAccessReasonsQueryArgs {
    userId: string;
    contentId: string;
}
export interface ContentUserArgs {
    pageSize: number;
    pageNumber: number;
    organisationId?: string | null;
    searchText?: string | null;
}
export interface UserGroupsUserArgs {
    pageSize: number;
    pageNumber: number;
    organisationId?: string | null;
    searchText?: string | null;
}
export interface ContentCollectionsUserArgs {
    pageSize: number;
    pageNumber: number;
    organisationId?: string | null;
    searchText?: string | null;
}
export interface ContentReportUriUserArgs {
    organisationId?: string | null;
}
export interface ContentOrganisationArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface ContentCollectionsOrganisationArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface UserGroupsOrganisationArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface UsersOrganisationArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface CoverImageUrisContentArgs {
    sizes: ImageSizeInput[];
}
export interface TotalBytesContentArgs {
    format: AudioFormat;
}
export interface AudioSectionsContentArgs {
    pageSize: number;
    pageNumber: number;
}
export interface UsersContentArgs {
    pageSize: number;
    pageNumber: number;
    accessSource?: ContentAccessSource | null;
    searchText?: string | null;
}
export interface UserGroupsContentArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface ContentCollectionsContentArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface NarrationUriAudioSectionArgs {
    format: AudioFormat;
}
export interface SoundtrackUriAudioSectionArgs {
    format: AudioFormat;
}
export interface UsersUserGroupArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface ContentUserGroupArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface ContentContentCollectionArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface UsersContentCollectionArgs {
    pageSize: number;
    pageNumber: number;
    searchText?: string | null;
}
export interface UserGroupsContentAccessReasonsResponseArgs {
    pageSize: number;
    pageNumber: number;
}
export interface ContentCollectionsContentAccessReasonsResponseArgs {
    pageSize: number;
    pageNumber: number;
}
export interface LoginMutationArgs {
    input: LoginInput;
}
export interface LogoutMutationArgs {
    input?: LogoutInput | null;
}
export interface SignUpWithCodeMutationArgs {
    input: SignUpWithCodeInput;
}
export interface UpdateMeMutationArgs {
    input: UpdateMeInput;
}
export interface InviteSystemAdminMutationArgs {
    input: InviteSystemAdminInput;
}
export interface RemoveSystemAdminMutationArgs {
    input: RemoveSystemAdminInput;
}
export interface CreateOrganisationMutationArgs {
    input: CreateOrganisationInput;
}
export interface UpdateOrganisationMutationArgs {
    input: UpdateOrganisationInput;
}
export interface InviteUserMutationArgs {
    input: InviteUserInput;
}
export interface GrantUserSpecialisedOrganisationAdminRoleMutationArgs {
    input: GrantUserSpecialisedOrganisationAdminRoleInput;
}
export interface UpdateUserMutationArgs {
    input: UpdateUserInput;
}
export interface RemoveUserFromOrganisationMutationArgs {
    input: RemoveUserFromOrganisationInput;
}
export interface RevokeUserSpecialisedOrganisationAdminRoleMutationArgs {
    input: RevokeUserSpecialisedOrganisationAdminRoleInput;
}
export interface RequestPasswordResetMutationArgs {
    input: RequestPasswordResetInput;
}
export interface ResetPasswordMutationArgs {
    input: ResetPasswordInput;
}
export interface CreateUserGroupMutationArgs {
    input: CreateUserGroupInput;
}
export interface UpdateUserGroupMutationArgs {
    input: UpdateUserGroupInput;
}
export interface RemoveUserGroupMutationArgs {
    input: RemoveUserGroupInput;
}
export interface CreateContentCollectionMutationArgs {
    input: CreateContentCollectionInput;
}
export interface UpdateContentCollectionMutationArgs {
    input: UpdateContentCollectionInput;
}
export interface RemoveContentCollectionMutationArgs {
    input: RemoveContentCollectionInput;
}
export interface UpdateContentMutationArgs {
    input: UpdateContentInput;
}
export interface RemoveContentMutationArgs {
    input: RemoveContentInput;
}
export interface AddAssociationMutationArgs {
    input: AddAssociationInput;
}
export interface RemoveAssociationMutationArgs {
    input: RemoveAssociationInput;
}
export interface JoinCodeMutationArgs {
    input: JoinCodeInput;
}
export interface LogPlaybackMutationArgs {
    input: LogPlaybackInput;
}
export interface RecordTechnicalIssuesMutationArgs {
    input: TechnicalIssuesInput;
}

export enum RoleType {
    SYS_ADMIN = "SYS_ADMIN",
    ORG_ADMIN = "ORG_ADMIN",
    ORG_CONTENT_UPLOADER = "ORG_CONTENT_UPLOADER",
    CONSUMER = "CONSUMER"
}

export enum ContentType {
    AUDIOBOOK = "AUDIOBOOK"
}

export enum AudioFormat {
    MP3_HIGH_QUALITY = "MP3_HIGH_QUALITY"
}

export enum ContentAccessSource {
    DIRECT = "DIRECT",
    CONTENT_COLLECTION = "CONTENT_COLLECTION",
    USER_GROUP = "USER_GROUP"
}

export enum NodeType {
    USER = "USER",
    CONTENT = "CONTENT",
    USER_GROUP = "USER_GROUP",
    CONTENT_COLLECTION = "CONTENT_COLLECTION"
}

export enum SignUpWithCodeActionRequired {
    LOGIN = "LOGIN",
    SET_PASSWORD = "SET_PASSWORD"
}

export type SignUpWithCodeResponse =
    | SignUpWithCodeLoggedInResponse
    | SignUpWithCodeActionRequiredResponse;
