import { gql } from "apollo-server-express";

export const mutations = gql`

    type Mutation {
        login(input: LoginInput!): LoginResponse!
        logout(input: LogoutInput): Boolean
        signUpWithCode(input: SignUpWithCodeInput!): SignUpWithCodeResponse!

        updateMe(input: UpdateMeInput!): User!

        inviteSystemAdmin(input: InviteSystemAdminInput!): InviteSystemAdminResponse!
        removeSystemAdmin(input: RemoveSystemAdminInput!): Query!

        createOrganisation(input: CreateOrganisationInput!): Organisation!
        updateOrganisation(input: UpdateOrganisationInput!): Organisation!

        inviteUser(input: InviteUserInput!): InviteUserResponse!
        grantUserSpecialisedOrganisationAdminRole(input: GrantUserSpecialisedOrganisationAdminRoleInput!): GrantUserSpecialisedOrganisationAdminRoleResponse!
        updateUser(input: UpdateUserInput!): User!
        removeUserFromOrganisation(input: RemoveUserFromOrganisationInput!): Organisation!
        revokeUserSpecialisedOrganisationAdminRole(input: RevokeUserSpecialisedOrganisationAdminRoleInput!): RevokeUserSpecialisedOrganisationAdminRoleResponse!
        requestPasswordReset(input: RequestPasswordResetInput!): RequestPasswordResetResponse!
        resetPassword(input: ResetPasswordInput!): ResetPasswordResponse!

        createUserGroup(input: CreateUserGroupInput!): UserGroup!
        updateUserGroup(input: UpdateUserGroupInput!): UserGroup!
        removeUserGroup(input: RemoveUserGroupInput!): Organisation!

        createContentCollection(input: CreateContentCollectionInput!): ContentCollection!
        updateContentCollection(input: UpdateContentCollectionInput!): ContentCollection!
        removeContentCollection(input: RemoveContentCollectionInput!): Organisation!

        updateContent(input: UpdateContentInput!): Content!
        removeContent(input: RemoveContentInput!): Organisation!

        addAssociation(input: AddAssociationInput!): AddAssociationResponse!
        removeAssociation(input: RemoveAssociationInput!): RemoveAssociationResponse!

        joinCode(input: JoinCodeInput!): Node!

        "Logs the regions of the book the user has played. The most recent playback region is used as the user's bookmark."
        logPlayback(input: LogPlaybackInput!): LogPlaybackResponse!

        recordTechnicalIssues(input: TechnicalIssuesInput!): TechnicalIssuesResponse!
    }

`;
