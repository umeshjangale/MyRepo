import { IMocks, mockServer } from "apollo-server-express";
import { buildClientSchema, getIntrospectionQuery, graphql, introspectionQuery, IntrospectionQuery } from "graphql";
import "jasmine";

import { getGqlSchema } from "../config";

describe("Schema", () => {

    describe("Schema types", () => {

        const testSchema = getGqlSchema();

        it("have valid type definitions", async () => {
            const result = await graphql(testSchema, "{ __schema { types { name } } }");
            expect(result.errors).toBeUndefined();
            expect(result.data).not.toBeNull();
        });

        it("can build client schema from introspection without error", async () => {

            const query = getIntrospectionQuery();
            const schemaData = await graphql(testSchema, query);
            expect(schemaData).toBeTruthy();
            expect(schemaData.errors).toBeFalsy();
            expect(schemaData.data).toBeTruthy();

            buildClientSchema(schemaData.data as any);
        });
    });

    describe("Mocked server", () => {

        const testSchema = getGqlSchema();

        const mockString = "the_mock_string";
        const mocks: IMocks = {
            Boolean: () => true,
            ID: () => "ID1",
            Int: () => 5,
            Float: () => 12.34,
            String: () => mockString,
        };

        const server = mockServer(testSchema, mocks);

        it("returns expected 'me API' schema", async () => {
            const query = `
                  query {
                    me {
                       id email firstName lastName
                    }
                  }
                `;

            const expected = { data: { me: { id: "ID1", email: mockString, firstName: mockString, lastName: mockString } } };
            const result = await server.query(query);
            expect(result).toEqual(expected);
        });
    });

});
