import { gql } from "apollo-server-express";

export const enums = gql`

    enum RoleType {
        SYS_ADMIN
        ORG_ADMIN
        ORG_CONTENT_UPLOADER
        CONSUMER
    }

    enum ContentType {
        AUDIOBOOK
    }

    enum ContentAccessSource {
        DIRECT
        CONTENT_COLLECTION
        USER_GROUP
    }

    enum AudioFormat {
        MP3_HIGH_QUALITY
    }

    enum NodeType {
        USER,
        CONTENT,
        USER_GROUP,
        CONTENT_COLLECTION
    }

    enum SignUpWithCodeActionRequired {
        LOGIN
        SET_PASSWORD
    }

`;
