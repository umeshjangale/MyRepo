import { gql } from "apollo-server-express";
import { concatAST } from "graphql";

import { enums } from "./enums";
import { inputTypes } from "./input-types";
import { mutations } from "./mutations";
import { outputTypes } from "./output-types";
import { queries } from "./queries";

const root = gql`

    schema {
        query: Query
        mutation: Mutation,
    }

`;

export default concatAST([
    enums,
    inputTypes,
    mutations,
    outputTypes,
    queries,
    root,
]);
