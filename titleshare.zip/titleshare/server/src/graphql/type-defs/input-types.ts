import { gql } from "apollo-server-express";

export const inputTypes = gql`

    scalar ValidatedString

    directive @validate(
        minLength: Int
        maxLength: Int

        "set type as 'email' to validate the string matches an email format"
        type: String
    ) on FIELD_DEFINITION | INPUT_FIELD_DEFINITION

    input LoginInput {
        email: String! @validate(type: "email")
        password: String! @validate(minLength: 1, maxLength: 255)
        useCookie: Boolean
    }

    input LogoutInput {
        allDevices: Boolean!
    }

    input SignUpWithCodeInput {
        email: String! @validate(type: "email")
        code: String! @validate(minLength: 1, maxLength: 255)
        useCookie: Boolean!
    }

    input UpdateMeInput {
        firstName: String @validate(minLength: 1, maxLength: 255)
        lastName: String @validate(minLength: 1, maxLength: 255)
        currentPassword: String @validate(minLength: 1, maxLength: 255)
        newPassword: String @validate(minLength: 1, maxLength: 255)
    }

    input InviteSystemAdminInput {
        email: String! @validate(type: "email")
        firstName: String! @validate(minLength: 1, maxLength: 255)
        lastName: String! @validate(minLength: 1, maxLength: 255)
    }

    input InviteUserInput {
        email: String! @validate(type: "email")
        firstName: String! @validate(minLength: 1, maxLength: 255)
        lastName: String! @validate(minLength: 1, maxLength: 255)
        organisationId: ID
        roleType: RoleType!
    }

    input GrantUserSpecialisedOrganisationAdminRoleInput {
        userId: ID!
        organisationId: ID!
        roleType: RoleType!
    }

    input RemoveSystemAdminInput {
        userId: ID!
    }

    input RemoveUserFromOrganisationInput {
        userId: ID!
        organisationId: ID!
    }

    input RevokeUserSpecialisedOrganisationAdminRoleInput {
        userId: ID!
        organisationId: ID!
        roleType: RoleType!
    }

    input ResetPasswordInput {
        email: String! @validate(type: "email")
        resetToken: ID!
        password: String! @validate(minLength: 6, maxLength: 255)
    }

    input CreateUserGroupInput {
        name: String! @validate(minLength: 1, maxLength: 255)
        description: String! @validate(minLength: 1, maxLength: 255)
        organisationId: ID!
    }

    input CreateOrganisationInput {
        name: String! @validate(minLength: 1, maxLength: 255)
    }

    input UpdateUserGroupInput {
        id: ID!
        name: String @validate(minLength: 1, maxLength: 255)
        description: String @validate(minLength: 1, maxLength: 255)
    }

    input CreateContentCollectionInput {
        name: String! @validate(minLength: 1, maxLength: 255)
        description: String! @validate(minLength: 1, maxLength: 255)
        organisationId: ID!
    }

    input UpdateContentCollectionInput {
        id: ID!
        name: String @validate(minLength: 1, maxLength: 255)
        description: String @validate(minLength: 1, maxLength: 255)
        signUpCode: String
        signUpCodeEnabled: Boolean
    }

    input JoinCodeInput {
        code: String!
    }

    input RemoveContentCollectionInput {
        id: ID!
    }

    input RemoveUserGroupInput {
        id: ID!
    }

    input AddAssociationInput {
        id: ID!
        associateId: ID!
    }

    input RemoveAssociationInput {
        id: ID!
        associateId: ID!
    }

    input RequestPasswordResetInput {
        email: String! @validate(type: "email")
    }

    input ImageSizeInput {
        height: Int!
        width: Int!
    }

    input LogPlaybackInput {
        contentId: ID!
        playbackRegions: [PlaybackRegion!]!
    }

    input PlaybackRegion {
        audioSectionsHash: ID!
        "The zero based index of the audio section"
        audioSectionIndex: Int!
        "Start time in seconds within the audio section"
        startTime: Float!
        "End time in seconds within the audio section"
        endTime: Float!
        endTimestamp: Date!
    }

    input UpdateContentInput {
        id: ID!
        title: String @validate(minLength: 1, maxLength: 255)
        subtitle: String @validate(minLength: 1, maxLength: 255)
        description: String @validate(minLength: 1, maxLength: 2047)
        author: String @validate(minLength: 1, maxLength: 255)
        narrator: String @validate(minLength: 1, maxLength: 255)
        publisher: String @validate(minLength: 1, maxLength: 255)
        releaseDate: Date
        languageCode: String @validate(minLength: 1, maxLength: 255)
        genreCode: String @validate(minLength: 1, maxLength: 255)
        secondGenreCode: String @validate(minLength: 1, maxLength: 255)
        nonBillable: Boolean
        nonBillableReason: String
    }

    input UpdateOrganisationInput {
        id: ID!
        name: String @validate(minLength: 1, maxLength: 255)
        importStorageBucket: String @validate(minLength: 1, maxLength: 255)
        importCoverImageRegex: String @validate(minLength: 1, maxLength: 255)
        importNarrationRegex: String @validate(minLength: 1, maxLength: 255)
        importSoundtrackRegex: String @validate(minLength: 1, maxLength: 255)
        importSftpUsername: String @validate(minLength: 1, maxLength: 255)
        importSftpPassword: String @validate(minLength: 1, maxLength: 255)
    }

    input UpdateUserInput {
        id: ID!
        firstName: String @validate(minLength: 1, maxLength: 255)
        lastName: String @validate(minLength: 1, maxLength: 255)
    }

    input RemoveContentInput {
        id: ID!
    }

    input TechnicalIssuesInput {
        data: [String!]!
    }
`;
