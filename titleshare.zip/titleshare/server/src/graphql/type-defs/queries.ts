import { gql } from "apollo-server-express";

export const queries = gql`

    type Query {
        me: User!
        node(id: ID!): Node
        nodes(ids: [ID!]!): [Node]!

        "For use by any user to fetch all content assigned to them."
        searchContent(pageSize: Int!, pageNumber: Int!): ContentSearchResponse!
        searchOrganisations(pageSize: Int!, pageNumber: Int!): OrganisationSearchResponse!
        searchSysAdmins(pageSize: Int!, pageNumber: Int!): SysAdminSearchResponse!

        suggestionsForAssociation(suggestionType: NodeType!, id: ID!, pageSize: Int!, pageNumber: Int!, searchText: String): NodeSearchResponse!

        contentAccessReasons(userId: ID!, contentId: ID!): ContentAccessReasonsResponse!

        languages: [Language!]!
        genres: [Genre!]!
    }
`;
