import { AudioFormat } from "../../audio/audio-format";
import config from "../../config";
import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { NodeType } from "../../types/node-id";
import { assertNever } from "../../utils";
import * as gq from "../type-defs/types";

export function toAudioSection(as: db.AudioSection, hasSoundtrack: boolean): gq.AudioSection {

    const host = config.app.endpoint;
    const contentId = DataProtection.encryptId(NodeType.Content, as.contentId);
    const sectionId = DataProtection.encryptId(NodeType.AudioSection, as.id);

    return {
        title: as.title,
        narrationUri: async (args, context) => {
            const uri = `${host}/audio/${contentId}/${sectionId}/narration/${args.format}/${as.versionNumber}`;
            return { uri };
        },
        soundtrackUri: async (args, context) => {
            if (!hasSoundtrack) return null;

            const uri = `${host}/audio/${contentId}/${sectionId}/soundtrack/${args.format}/${as.versionNumber}`;
            return { uri };
        },
    };
}

export function toAudioFormat(format: gq.AudioFormat): AudioFormat {
    switch (format) {
        case gq.AudioFormat.MP3_HIGH_QUALITY:
            return AudioFormat.mp3HighQuality();
        default:
            return assertNever(format);
    }
}

export function toDbAudioFormat(format: gq.AudioFormat): db.AudioFormat {
    switch (format) {
        case gq.AudioFormat.MP3_HIGH_QUALITY:
            return db.AudioFormat.Mp3High;
        default:
            return assertNever(format);
    }
}
