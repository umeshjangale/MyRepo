import { AuthenticationError } from "apollo-server-express";

import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { NodeType } from "../../types/node-id";
import * as gq from "../type-defs/types";

import { toContent } from "./content";
import { toOrganisation } from "./organisation";
import { toUser } from "./user";

export function toUserGroup(g: db.UserGroup): gq.UserGroup {
    return {
        __typename: "UserGroup",
        id: () => DataProtection.encryptId(NodeType.UserGroup, g.id),
        name: g.name,
        description: g.description,
        organisation: toOrganisation(g.organisation || g.organisationId),
        users: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.userGroups.searchGroupMembers(context.user, g.id, args.pageSize, args.pageNumber, args.searchText || "");
            return {
                items: items.map(toUser),
                totalCount,
            };
        },
        content: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.userGroups.searchGroupContent(context.user, g.id, args.pageSize, args.pageNumber, args.searchText || "");
            return {
                items: items.map(toContent),
                totalCount,
            };
        },
    };
}
