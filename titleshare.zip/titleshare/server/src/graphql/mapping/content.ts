import { AuthenticationError, ForbiddenError } from "apollo-server-express";

import config from "../../config";
import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { AccessSource } from "../../storage/db-entities/enums";
import { hasPermission } from "../../storage/helpers/db-helper";
import { NodeType } from "../../types/node-id";
import * as gq from "../type-defs/types";

import { toAudioSection, toDbAudioFormat } from "./audio-section";
import { toContentCollection } from "./content-collection";
import { toGenre } from "./genre";
import { toLanguage } from "./language";
import { toOrganisation } from "./organisation";
import { toContentUser } from "./user";
import { toUserGroup } from "./user-group";

export function toContent(c: db.Content): gq.Content {
    if (c.type !== db.ContentType.Audiobook) {
        throw new Error(`Unhandled content type ${c.type}`);
    }

    const contentId = DataProtection.encryptId(NodeType.Content, c.id);

    return {
        __typename: "Content",
        id: contentId,
        type: gq.ContentType.AUDIOBOOK,
        title: c.title,
        subtitle: c.subtitle,
        description: c.description,
        author: c.author,
        narrator: c.narrator,
        publisher: c.publisher,
        releaseDate: c.releaseDate,
        createdDate: c.createdDateUtc,
        totalDuration: Math.round(c.totalDuration),
        hasSoundtrack: c.hasSoundtrack,
        nonBillable: c.nonBillable,
        nonBillableReason: c.nonBillableReason,
        coverImageUris: async (args, context) => {

            if (args.sizes.length === 0) return [];

            const uris = args.sizes.map(size => {
                const version = DataProtection.md5Hash(c.coverImageStoragePath);
                const uri = `${config.app.endpoint}/cover-image/${contentId}/${size.height}/${size.width}/${version}`;
                return uri;
            });

            return uris;
        },
        language: toLanguage(c.language || c.languageCode),
        genre: toGenre(c.genre || c.genreCode),
        secondGenre: c.secondGenreCode ? toGenre(c.secondGenre || c.secondGenreCode) : null,
        audioSectionsHash: c.audioSectionsHash,
        audioSections: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.audio.searchAudioSections(context.user, c.id, args.pageSize, args.pageNumber);

            return {
                items: items.map(i => toAudioSection(i, c.hasSoundtrack)),
                totalCount,
            };
        },
        organisation: toOrganisation(c.organisation || c.organisationId),
        totalBytes: async (args, context) => {
            const format = toDbAudioFormat(args.format);

            const total = await context.storage.audio.getTotalBytes(c.id, format);
            return { total };
        },
        users: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const accessSource = args.accessSource ? toDbAccessSource(args.accessSource) : undefined;
            const { items, totalCount } = await context.storage.content.searchUsersWithAccessToContent(context.user, c.id, accessSource, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toContentUser),
                totalCount,
            };
        },
        userGroups: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const { items, totalCount } = await context.storage.content.searchUserGroupsWithAccessToContent(context.user, c.id, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUserGroup),
                totalCount,
            };
        },
        contentCollections: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const { items, totalCount } = await context.storage.content.searchContentCollectionsWithContent(context.user, c.id, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toContentCollection),
                totalCount,
            };
        },
        myBookmark: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const uc = await context.storage.users.getUserContent(context.user, c.id);

            if (!uc || uc.bookmarkedAudioSectionIndex === null) return null;

            return {
                audioSectionIndex: uc.bookmarkedAudioSectionIndex,
                time: uc.bookmarkedAudioSectionTime || 0,
            };
        },
        usersReportUri: (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationAdmin, c.organisationId)) return "";
            return `${config.app.endpoint}/report/users-for-content/${contentId}`;
        },
    };
}

export function toContentAccessSource(source: AccessSource | null): gq.ContentAccessSource {
    if (source === null) throw new Error("Unexpected null access source");

    switch (source) {
        case AccessSource.Direct:
            return gq.ContentAccessSource.DIRECT;
        case AccessSource.ContentCollection:
            return gq.ContentAccessSource.CONTENT_COLLECTION;
        case AccessSource.UserGroup:
            return gq.ContentAccessSource.USER_GROUP;
    }
}

export function toDbAccessSource(source: gq.ContentAccessSource | null): AccessSource {
    if (source === null) throw new Error("Unexpected null access source");

    switch (source) {
        case gq.ContentAccessSource.DIRECT:
            return AccessSource.Direct;
        case gq.ContentAccessSource.CONTENT_COLLECTION:
            return AccessSource.ContentCollection;
        case gq.ContentAccessSource.USER_GROUP:
            return AccessSource.UserGroup;
    }
}

export function toUserContentAccess(c: db.Content): gq.UserContentAccess {

    return {
        content: toContent(c),
        sources: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationAdmin, c.organisationId)) {
                return [];
            }

            if (!c.userContentAccess || !c.userContentAccess.length) throw new Error("Mapping to UserContentAccess requires userContentAccess to be available on the content.");
            return c.userContentAccess.map(a => ({
                source: toContentAccessSource(a.source),
            }));
        },
    };
}

export function toContentAccessReasons(userId: number, contentId: number): gq.ContentAccessReasonsResponse {

    return {
        direct: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const result = await context.storage.content.hasDirectAccess(context.user, userId, contentId);
            if (result.hasError) {
                throw new ForbiddenError(result.error);
            }

            return result.obj;
        },
        userGroups: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const { items, totalCount } = await context.storage.content.searchUserGroupsMakingContentAccessibleToUser(context.user, contentId, userId, args.pageSize, args.pageNumber);

            return {
                items: items.map(toUserGroup),
                totalCount,
            };
        },
        contentCollections: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            const { items, totalCount } = await context.storage.content.searchContentCollectionsMakingContentAccessibleToUser(context.user, contentId, userId, args.pageSize, args.pageNumber);

            return {
                items: items.map(toContentCollection),
                totalCount,
            };
        },
    };
}
