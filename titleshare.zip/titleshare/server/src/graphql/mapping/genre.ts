import * as db from "../../storage/db-entities";
import * as gq from "../type-defs/types";

export function toGenre(g: string | db.Genre): gq.Genre {

    if (typeof g === "string") {
        return {
            code: g,
            name: async (args, context) => {
                const dbGenre = await context.storage.referenceData.getGenre(g);
                if (!dbGenre) throw new Error(`invalid genre code ${g}`);
                return dbGenre.name;
            },
        };
    }

    return {
        code: g.code,
        name: g.name,
    };
}
