import { AuthenticationError } from "apollo-server-express";

import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { NodeType } from "../../types/node-id";
import * as gq from "../type-defs/types";

import { toContent } from "./content";
import { toOrganisation } from "./organisation";
import { toUser } from "./user";

export function toContentCollection(cc: db.ContentCollection): gq.ContentCollection {

    return {
        __typename: "ContentCollection",
        id: () => DataProtection.encryptId(NodeType.ContentCollection, cc.id),
        name: cc.name,
        description: cc.description,
        signUpCode: cc.signUpCode,
        signUpCodeEnabled: cc.signUpCodeEnabled,
        organisation: toOrganisation(cc.organisation || cc.organisationId),
        content: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.contentCollections.searchCollectionContent(context.user, cc.id, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toContent),
                totalCount,
            };
        },
        users: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.contentCollections.searchCollectionUsers(context.user, cc.id, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUser),
                totalCount,
            };
        },
    };
}
