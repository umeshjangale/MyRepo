import * as db from "../../storage/db-entities";
import * as gq from "../type-defs/types";

export function toLanguage(l: string | db.Language): gq.Language {

    if (typeof l === "string") {
        return {
            code: l,
            name: async (args, context) => {
                const dbLang = await context.storage.referenceData.getLanguage(l);
                if (!dbLang) throw new Error(`invalid language code ${l}`);
                return dbLang.name;
            },
        };
    }

    return {
        code: l.code,
        name: l.name,
    };
}
