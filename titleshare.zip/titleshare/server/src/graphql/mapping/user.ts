import { AuthenticationError, UserInputError } from "apollo-server-express";

import config from "../../config";
import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { hasPermission } from "../../storage/helpers/db-helper";
import { NodeType } from "../../types/node-id";
import { assertNever } from "../../utils";
import * as gq from "../type-defs/types";

import { toContentAccessSource, toUserContentAccess } from "./content";
import { toContentCollection } from "./content-collection";
import { toOrganisation } from "./organisation";
import { toUserGroup } from "./user-group";

export function toUser(u: db.User): gq.User {
    const userId = DataProtection.encryptId(NodeType.User, u.id);
    return {
        __typename: "User",
        id: userId,
        email: () => DataProtection.decryptEmail(u.email),
        firstName: u.firstName,
        lastName: u.lastName,
        roles: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const roles = u.userRoles || await context.storage.users.getUserRoles(context.user, u.id, true);
            return toUserRole(roles);
        },
        content: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const organisationId = decryptOrganisationId(args.organisationId);
            const { items, totalCount } = await context.storage.content.searchContentAssignedToUser(context.user, u.id, organisationId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUserContentAccess),
                totalCount,
            };
        },
        userGroups: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const organisationId = decryptOrganisationId(args.organisationId);
            const { items, totalCount } = await context.storage.users.searchUserGroupsUserIsAMemberOf(context.user, u.id, organisationId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUserGroup),
                totalCount,
            };
        },
        contentCollections: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const organisationId = decryptOrganisationId(args.organisationId);
            const { items, totalCount } = await context.storage.users.searchContentCollectionsUserIsAMemberOf(context.user, u.id, organisationId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toContentCollection),
                totalCount,
            };
        },
        contentReportUri: (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            if (args.organisationId) {
                const organisationId = decryptOrganisationId(args.organisationId);
                if (!organisationId || !hasPermission(context.user, db.RoleType.OrganisationAdmin, organisationId)) {
                    return "";
                }

                return `${config.app.endpoint}/report/content-for-user/${userId}?organisationId=${args.organisationId}`;
            }

            return `${config.app.endpoint}/report/content-for-user/${userId}`;
        },
    };
}

function decryptOrganisationId(organisationId: string | null | undefined): number | null {
    let result: number | null = null;
    if (organisationId) {
        result = DataProtection.decryptId(organisationId, NodeType.Organisation);
        if (!result) throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });
    }

    return result;
}

export function toUserRole(roles: db.UserRole[]): gq.UserRole[] {

    return roles.map<gq.UserRole>(r => ({
        type: toRoleType(r.type),
        organisation: r.organisationId ? toOrganisation(r.organisation || r.organisationId) : null,
    }));
}

export function toRoleType(type: db.RoleType): gq.RoleType {
    switch (type) {
        case db.RoleType.SystemAdmin:
            return gq.RoleType.SYS_ADMIN;
        case db.RoleType.OrganisationAdmin:
            return gq.RoleType.ORG_ADMIN;
        case db.RoleType.OrganisationContentUploader:
            return gq.RoleType.ORG_CONTENT_UPLOADER;
        case db.RoleType.Consumer:
            return gq.RoleType.CONSUMER;
        default:
            throw new Error(`Unhandled role type ${type}`);
    }
}

export function toDbRoleType(type: string): db.RoleType {
    switch (type) {
        case gq.RoleType.SYS_ADMIN:
            return db.RoleType.SystemAdmin;
        case gq.RoleType.ORG_ADMIN:
            return db.RoleType.OrganisationAdmin;
        case gq.RoleType.ORG_CONTENT_UPLOADER:
            return db.RoleType.OrganisationContentUploader;
        case gq.RoleType.CONSUMER:
            return db.RoleType.Consumer;
        default:
            throw new Error(`Unhandled role type ${type}`);
    }
}

export function toContentUser(u: db.User): gq.ContentUser {

    if (!u.userContentAccess || !u.userContentAccess.length) throw new Error("Mapping to ContentUser requires userContentAccess to be available on the user.");

    return {
        user: toUser(u),
        sources: u.userContentAccess.map(a => ({
            source: toContentAccessSource(a.source),
        })),
    };
}

export function toSignUpActionRequired(ar: "login" | "set-password") {

    let actionRequired: gq.SignUpWithCodeActionRequired | undefined;
    switch (ar) {
        case "login":
            actionRequired = gq.SignUpWithCodeActionRequired.LOGIN;
            break;
        case "set-password":
            actionRequired = gq.SignUpWithCodeActionRequired.SET_PASSWORD;
            break;
        default:
            return assertNever(ar);
    }

    return {
        __typename: "SignUpWithCodeActionRequiredResponse",
        actionRequired,
    };
}
