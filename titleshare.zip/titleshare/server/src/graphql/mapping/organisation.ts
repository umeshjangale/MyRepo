import { AuthenticationError } from "apollo-server-express";

import config from "../../config";
import * as DataProtection from "../../security/data-protection";
import * as db from "../../storage/db-entities";
import { hasPermission } from "../../storage/helpers/db-helper";
import { NodeType } from "../../types/node-id";
import { Context } from "../context";
import * as gq from "../type-defs/types";

import { toContentCollection, toUser, toUserGroup } from ".";
import { toContent } from "./content";

export function toOrganisation(orgOrId: number | db.Organisation): gq.Organisation {

    const orgId = typeof orgOrId === "number" ? orgOrId : orgOrId.id;
    let o: db.Organisation | undefined = typeof orgOrId === "number" ? undefined : orgOrId;

    // A local function to lazy load the organisation if necessary.
    const getOrg = async (context: Context) => {
        if (o) return o;
        o = await context.storage.organisations.getOrganisation(orgId);
        if (!o) throw new Error(`Invalid org Id ${orgId}`);
        return o;
    };

    return {
        __typename: "Organisation",
        id: () => DataProtection.encryptId(NodeType.Organisation, orgId),
        name: async (args, context) => (await getOrg(context)).name,
        importStorageBucket: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.SystemAdmin, orgId)) return null;

            return (await getOrg(context)).importStorageBucket;
        },
        importCoverImageRegex: async (args, context) => (await getOrg(context)).importCoverImageFilenameRegex || config.import.defaultCoverImageFileRegex,
        importNarrationRegex: async (args, context) => (await getOrg(context)).importNarrationFilenameRegex || config.import.defaultNarrationFileRegex,
        importSoundtrackRegex: async (args, context) => (await getOrg(context)).importSoundtrackFilenameRegex || config.import.defaultSoundtrackFileRegex,
        importSftpUsername: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationContentUploader, orgId)) return null;

            return (await getOrg(context)).importSftpUsername;
        },
        importSftpPassword: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationContentUploader, orgId)) return null;

            const encPassword = (await getOrg(context)).importSftpPassword;
            return encPassword ? DataProtection.decryptImportSftpPassword(encPassword) : null;
        },
        content: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.organisations.searchOrganisationContent(context.user, orgId, args.pageSize, args.pageNumber, args.searchText || "");
            return {
                items: items.map(toContent),
                totalCount,
            };
        },
        contentCollections: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.contentCollections.searchCollections(context.user, orgId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toContentCollection),
                totalCount,
            };
        },
        users: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.users.searchUsers(context.user, orgId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUser),
                totalCount,
            };
        },
        userGroups: async (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");

            const { items, totalCount } = await context.storage.userGroups.searchUserGroups(context.user, orgId, args.pageSize, args.pageNumber, args.searchText || "");

            return {
                items: items.map(toUserGroup),
                totalCount,
            };
        },
        usersReportUri: (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationAdmin, orgId)) return "";
            return `${config.app.endpoint}/report/users-for-organisation/${DataProtection.encryptId(NodeType.Organisation, orgId)}`;
        },
        contentReportUri: (args, context) => {
            if (!context.user) throw new AuthenticationError("authentication required");
            if (!hasPermission(context.user, db.RoleType.OrganisationAdmin, orgId)) return "";
            return `${config.app.endpoint}/report/content-for-organisation/${DataProtection.encryptId(NodeType.Organisation, orgId)}`;
        },
    };
}
