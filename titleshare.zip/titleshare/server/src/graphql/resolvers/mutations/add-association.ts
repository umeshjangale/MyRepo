import { AuthenticationError, ForbiddenError, UserInputError } from "apollo-server-express";
import jwt from "jsonwebtoken";

import config from "../../../config";
import * as DataProtection from "../../../security/data-protection";
import * as db from "../../../storage/db-entities";
import { NodeId, NodeType } from "../../../types/node-id";
import { assertNever } from "../../../utils";
import { Context } from "../../context";
import * as Mapper from "../../mapping";
import * as gq from "../../type-defs/types";

export async function addAssociation(args: gq.AddAssociationMutationArgs, context: Context): Promise<gq.AddAssociationResponse> {
    if (!context.user) throw new AuthenticationError("authentication required");

    const node = DataProtection.decryptNodeId(args.input.id);
    if (!node) throw new UserInputError("Invalid id", { id: "invalid" });

    const associateNode = DataProtection.decryptNodeId(args.input.associateId);
    if (!associateNode) throw new UserInputError("Invalid associateId", { associateId: "invalid" });

    switch (node.type) {
        case NodeType.Content:
            return addContentAssociation(node, associateNode, context);
        case NodeType.User:
            return addUserAssociation(node, associateNode, context);
        case NodeType.ContentCollection:
            return addContentCollectionAssociation(node, associateNode, context);
        case NodeType.UserGroup:
            return addUserGroupAssociation(node, associateNode, context);
        case NodeType.AudioSection:
        case NodeType.Organisation:
            throw new UserInputError("not supported");
        default:
            return assertNever(node.type);
    }
}

async function addContentAssociation(contentNode: NodeId, associateNode: NodeId, context: Context): Promise<{ node: gq.Content; associateNode: gq.Node }> {
    if (!context.user) throw new AuthenticationError("authentication required");
    if (contentNode.type !== NodeType.Content) throw Error(`Unexpected node type. Expected ${NodeType.Content}, but got ${contentNode.type}`);

    switch (associateNode.type) {
        case NodeType.User: {
            const result = await context.storage.content.addUserAccess(context.user, contentNode.id, associateNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toContent(result.obj.content), associateNode: Mapper.toUser(result.obj.user) };
        }
        case NodeType.ContentCollection: {
            const result = await context.storage.contentCollections.addCollectionItem(context.user, associateNode.id, contentNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toContent(result.obj.content), associateNode: Mapper.toContentCollection(result.obj.contentCollection) };
        }
        case NodeType.UserGroup: {
            const result = await context.storage.userGroups.addUserGroupContent(context.user, associateNode.id, contentNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toContent(result.obj.content), associateNode: Mapper.toUserGroup(result.obj.group) };
        }
        case NodeType.Organisation:
        case NodeType.Content:
        case NodeType.AudioSection:
            throw new UserInputError("invalid association");
        default:
            return assertNever(associateNode.type);
    }
}

async function addUserAssociation(userNode: NodeId, associateNode: NodeId, context: Context): Promise<{ node: gq.User; associateNode: gq.Node }> {
    if (!context.user) throw new AuthenticationError("authentication required");
    if (userNode.type !== NodeType.User) throw Error(`Unexpected node type. Expected ${NodeType.User}, but got ${userNode.type}`);

    switch (associateNode.type) {
        case NodeType.Content: {
            const result = await context.storage.content.addUserAccess(context.user, associateNode.id, userNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            const { user, content } = result.obj;
            return { node: Mapper.toUser(user), associateNode: Mapper.toContent(content) };
        }
        case NodeType.ContentCollection: {
            const result = await context.storage.contentCollections.addCollectionUser(context.user, associateNode.id, userNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toUser(result.obj.user), associateNode: Mapper.toContentCollection(result.obj.contentCollection) };
        }
        case NodeType.UserGroup: {
            const result = await context.storage.userGroups.addUserGroupMember(context.user, associateNode.id, userNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toUser(result.obj.user), associateNode: Mapper.toUserGroup(result.obj.group) };
        }
        case NodeType.User:
        case NodeType.Organisation:
        case NodeType.AudioSection:
            throw new UserInputError("invalid association");
        default:
            return assertNever(associateNode.type);
    }
}

async function addContentCollectionAssociation(contentCollectionNode: NodeId, associateNode: NodeId, context: Context): Promise<{ node: gq.ContentCollection; associateNode: gq.Node }> {
    if (!context.user) throw new AuthenticationError("authentication required");
    if (contentCollectionNode.type !== NodeType.ContentCollection) throw Error(`Unexpected node type. Expected ${NodeType.ContentCollection}, but got ${contentCollectionNode.type}`);

    switch (associateNode.type) {
        case NodeType.Content: {
            const result = await context.storage.contentCollections.addCollectionItem(context.user, contentCollectionNode.id, associateNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toContentCollection(result.obj.contentCollection), associateNode: Mapper.toContent(result.obj.content) };
        }
        case NodeType.User: {
            const result = await context.storage.contentCollections.addCollectionUser(context.user, contentCollectionNode.id, associateNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toContentCollection(result.obj.contentCollection), associateNode: Mapper.toUser(result.obj.user) };
        }
        case NodeType.UserGroup:
        case NodeType.Organisation:
        case NodeType.ContentCollection:
        case NodeType.AudioSection:
            throw new UserInputError("invalid association");
        default:
            return assertNever(associateNode.type);
    }
}

async function addUserGroupAssociation(groupNode: NodeId, associateNode: NodeId, context: Context): Promise<{ node: gq.UserGroup; associateNode: gq.Node }> {
    if (!context.user) throw new AuthenticationError("authentication required");
    if (groupNode.type !== NodeType.UserGroup) throw Error(`Unexpected node type. Expected ${NodeType.UserGroup}, but got ${groupNode.type}`);

    switch (associateNode.type) {
        case NodeType.Content: {
            const result = await context.storage.userGroups.addUserGroupContent(context.user, groupNode.id, associateNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toUserGroup(result.obj.group), associateNode: Mapper.toContent(result.obj.content) };
        }
        case NodeType.User: {
            const result = await context.storage.userGroups.addUserGroupMember(context.user, groupNode.id, associateNode.id);
            if (result.hasError) throw new ForbiddenError(result.error);

            return { node: Mapper.toUserGroup(result.obj.group), associateNode: Mapper.toUser(result.obj.user) };
        }
        case NodeType.ContentCollection:
        case NodeType.Organisation:
        case NodeType.UserGroup:
        case NodeType.AudioSection:
            throw new UserInputError("invalid association");
        default:
            return assertNever(associateNode.type);
    }
}
