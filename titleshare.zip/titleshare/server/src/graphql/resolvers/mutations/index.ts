import { AuthenticationError, ForbiddenError, UserInputError } from "apollo-server-express";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import validator from "validator";

import * as DataProtection from "../../../security/data-protection";
import { loginRateHandler } from "../../../security/login-rate-handler";
import * as db from "../../../storage/db-entities";
import { ContentCollectionUpdateModel } from "../../../storage/types/content-collection-update-model";
import { ContentUpdateModel } from "../../../storage/types/content-update-model";
import { JwtUser } from "../../../types/jwt-user";
import { NodeType } from "../../../types/node-id";
import { assertNever } from "../../../utils";
import { Context } from "../../context";
import * as Mapper from "../../mapping";
import * as gq from "../../type-defs/types";
import { query } from "../queries";

import { addAssociation } from "./add-association";
import { removeAssociation } from "./remove-association";

function performLogin(user: db.User, useCookie: boolean, context: Context): { token: string; user: gq.User } {
    const userId = DataProtection.encryptId(NodeType.User, user.id);
    const csrfToken = useCookie ? crypto.randomBytes(16).toString("hex") : null;

    const jwtUser: JwtUser = { sessionToken: user.sessionToken, id: userId, csrfToken };
    const token = jwt.sign(jwtUser, DataProtection.jwtSecret);

    if (useCookie && csrfToken) {
        context.setAuthCookie(token, csrfToken);
    }

    // Set the user on the context as it can be used in Mapper.toUser
    context.user = user;

    return { token, user: Mapper.toUser(user) };
}

export const mutation: gq.Mutation = {
    login: async (_, args, context) => {
        if (context.user) throw new ForbiddenError("User already logged in");
        if (loginRateHandler.hasReachedLimit(context.ipAddress)) throw new ForbiddenError("Login rate limit reached.");

        const { email, password } = args.input;
        const user = await context.storage.users.authenticateUser(email, password, context.ipAddress, context.userAgent);

        if (!user) {
            loginRateHandler.failure(context.ipAddress);
            throw new UserInputError("Invalid username or password.");
        }

        loginRateHandler.success(context.ipAddress);

        const login = performLogin(user, args.input.useCookie || false, context);
        return {
            __typename: "LoginResponse",
            ...login,
        };
    },
    logout: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        // If no input argument is provided, all devices are logged out.
        if (!args.input || args.input.allDevices) {
            await context.storage.users.expireAllUserSessions(context.user);
        }

        // Remove the cookie if it exists.
        context.setAuthCookie("", "", 0);

        return true;
    },
    signUpWithCode: async (_, args, context) => {
        if (context.user) throw new ForbiddenError("User already logged in");
        if (loginRateHandler.hasReachedLimit(context.ipAddress)) throw new ForbiddenError("Sign up rate limit reached.");

        // Code entry requests MUST have a valid request signature to help prevent abuse.
        if (!context.hasAuthenticationSignature) {
            throw new ForbiddenError("Invalid request");
        }

        if (!validator.isEmail(args.input.email)) {
            throw new UserInputError("invalid-email", { email: "invalid" });
        }

        const result = await context.storage.users.signUpWithCode(args.input.email, args.input.code, context.ipAddress, context.userAgent);
        if (result.hasError) {
            loginRateHandler.failure(context.ipAddress);

            switch (result.error) {
                case "invalid-code":
                    throw new UserInputError(result.error);
                default:
                    return assertNever(result.error);
            }
        }

        loginRateHandler.success(context.ipAddress);

        if (result.obj instanceof db.User) {
            const login = performLogin(result.obj, args.input.useCookie || false, context);
            return {
                __typename: "SignUpWithCodeLoggedInResponse",
                ...login,
            };
        }

        return Mapper.toSignUpActionRequired(result.obj.actionRequired);
    },
    updateMe: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const result = await context.storage.users.updateSelf(context.user, args.input.firstName || undefined, args.input.lastName || undefined, args.input.currentPassword || undefined, args.input.newPassword || undefined);
        if (result.hasError) {
            switch (result.error) {
                case "incorrect-password":
                case "password-too-weak":
                    throw new UserInputError(result.error);
                case "user-not-found":
                    throw new ForbiddenError(result.error);
                default:
                    return assertNever(result.error);
            }
        }

        return Mapper.toUser(result.obj);
    },
    createOrganisation: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const result = await context.storage.organisations.createOrganisation(context.user, args.input.name.trim());
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toOrganisation(result.obj);
    },
    updateOrganisation: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const orgId = DataProtection.decryptId(args.input.id, NodeType.Organisation);
        if (!orgId) throw new UserInputError("Invalid organisation Id", { id: "invalid" });

        const updateModel = {
            name: args.input.name ? args.input.name.trim() : undefined,
            importStorageBucket: args.input.importStorageBucket ? args.input.importStorageBucket.trim() : undefined,
            importNarrationFilenameRegex: args.input.importNarrationRegex ? args.input.importNarrationRegex.trim() : undefined,
            importSoundtrackFilenameRegex: args.input.importSoundtrackRegex ? args.input.importSoundtrackRegex.trim() : undefined,
            importCoverImageFilenameRegex: args.input.importCoverImageRegex ? args.input.importCoverImageRegex.trim() : undefined,
            importSftpUsername: args.input.importSftpUsername ? args.input.importSftpUsername.trim() : undefined,
            importSftpPassword: args.input.importSftpPassword ? args.input.importSftpPassword.trim() : undefined,
        };

        const result = await context.storage.organisations.updateOrganisation(context.user, orgId, updateModel);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toOrganisation(result.obj);
    },
    inviteSystemAdmin: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        if (!validator.isEmail(args.input.email)) {
            throw new UserInputError("invalid-email", { email: "invalid" });
        }

        const result = await context.storage.users.inviteSystemAdmin(context.user, args.input.email, args.input.firstName.trim(), args.input.lastName.trim());
        if (result.hasError) throw new ForbiddenError(result.error);

        return { user: Mapper.toUser(result.obj) };
    },
    inviteUser: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        if (!validator.isEmail(args.input.email)) {
            throw new UserInputError("invalid-email", { email: "invalid" });
        }

        const validationErrors: any = {};

        const roleType = Mapper.toDbRoleType(args.input.roleType);

        if (roleType === db.RoleType.SystemAdmin && args.input.organisationId) {
            validationErrors.roleType = "sys-admins cannot be created with an organisation.";
        } else if (roleType !== db.RoleType.SystemAdmin && !args.input.organisationId) {
            validationErrors.roleType = "organisation Id required.";
        }

        if (Object.keys(validationErrors).length > 0) {
            throw new UserInputError("Some request parameters are invalid.", { validationErrors });
        }

        if (roleType === db.RoleType.SystemAdmin) {
            const result = await context.storage.users.inviteSystemAdmin(context.user, args.input.email, args.input.firstName.trim(), args.input.lastName.trim());
            if (result.hasError) throw new ForbiddenError(result.error);
            return { user: Mapper.toUser(result.obj) };
        } else {
            const orgId = args.input.organisationId
                ? DataProtection.decryptId(args.input.organisationId, NodeType.Organisation)
                : null;

            if (!orgId) {
                throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });
            }

            if (roleType === db.RoleType.OrganisationContentUploader) {
                throw new UserInputError("Invalid roleType", { roleType: "invalid" });
            }
            const result = await context.storage.users.inviteUser(context.user, orgId, roleType, args.input.email, args.input.firstName.trim(), args.input.lastName.trim());
            if (result.hasError) throw new ForbiddenError(result.error);
            return { user: Mapper.toUser(result.obj) };
        }
    },
    grantUserSpecialisedOrganisationAdminRole: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const orgId = DataProtection.decryptId(args.input.organisationId, NodeType.Organisation);
        if (!orgId) {
            throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });
        }

        const roleType = Mapper.toDbRoleType(args.input.roleType);
        if (roleType !== db.RoleType.OrganisationContentUploader) {
            throw new UserInputError("Invalid roleType", { roleType: "invalid" });
        }

        const userId = DataProtection.decryptId(args.input.userId, NodeType.User);
        if (!userId) {
            throw new UserInputError("Invalid userId", { id: "invalid" });
        }

        const result = await context.storage.users.grantUserSpecialisedOrganisationAdminRole(context.user, orgId, roleType, userId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return { user: Mapper.toUser(result.obj) };
    },
    updateUser: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const userId = DataProtection.decryptId(args.input.id, NodeType.User);
        if (!userId) throw new UserInputError("Invalid userId", { id: "invalid" });

        const result = await context.storage.users.updateUser(context.user, userId, args.input.firstName || undefined, args.input.lastName || undefined);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toUser(result.obj);
    },
    removeSystemAdmin: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const userId = DataProtection.decryptId(args.input.userId, NodeType.User);
        if (!userId) throw new UserInputError("Invalid userId", { userId: "invalid" });

        const result = await context.storage.users.removeSystemAdmin(context.user, userId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return query;
    },
    removeUserFromOrganisation: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const userId = DataProtection.decryptId(args.input.userId, NodeType.User);
        if (!userId) throw new UserInputError("Invalid userId", { userId: "invalid" });

        const orgId = DataProtection.decryptId(args.input.organisationId, NodeType.Organisation);
        if (!orgId) throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });

        const result = await context.storage.users.removeUserFromOrganisation(context.user, userId, orgId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toOrganisation(orgId);
    },
    revokeUserSpecialisedOrganisationAdminRole: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const orgId = DataProtection.decryptId(args.input.organisationId, NodeType.Organisation);
        if (!orgId) {
            throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });
        }

        const roleType = Mapper.toDbRoleType(args.input.roleType);
        if (roleType !== db.RoleType.OrganisationContentUploader) {
            throw new UserInputError("Invalid roleType", { roleType: "invalid" });
        }

        const userId = DataProtection.decryptId(args.input.userId, NodeType.User);
        if (!userId) {
            throw new UserInputError("Invalid userId", { id: "invalid" });
        }

        const result = await context.storage.users.revokeUserSpecialisedOrganisationAdminRole(context.user, orgId, roleType, userId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return { user: Mapper.toUser(result.obj) };
    },
    requestPasswordReset: async (_, args, context) => {
        const result = await context.storage.users.requestResetPassword(args.input.email);
        if (result.hasError) {
            switch (result.error) {
                case "user-not-found":
                    // For security reasons, don't report whether the user exists or not.
                    break;
                default:
                    return assertNever(result.error);
            }
        }

        return { success: true };
    },
    resetPassword: async (_, args, context) => {

        const result = await context.storage.users.resetPassword(args.input.email, args.input.password, args.input.resetToken);

        if (result.hasError) {
            switch (result.error) {
                case "password-too-weak":
                    throw new UserInputError(result.error);
                case "invalid-email-or-token":
                    throw new ForbiddenError(result.error);
                default:
                    return assertNever(result.error);
            }
        }

        // Set the user on the context as it can be used in Mapper.toUser
        context.user = result.obj;

        return { user: Mapper.toUser(result.obj) };
    },
    createUserGroup: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const orgId = DataProtection.decryptId(args.input.organisationId, NodeType.Organisation);
        if (!orgId) throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });

        const result = await context.storage.userGroups.createGroup(context.user, args.input.name.trim(), args.input.description.trim(), orgId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toUserGroup(result.obj);
    },
    updateUserGroup: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const groupId = DataProtection.decryptId(args.input.id, NodeType.UserGroup);
        if (!groupId) throw new UserInputError("Invalid groupId", { groupId: "invalid" });

        const updatedName = args.input.name ? args.input.name.trim() : undefined;
        const updatedDescription = args.input.description ? args.input.description.trim() : undefined;

        const result = await context.storage.userGroups.updateGroup(context.user, groupId, updatedName, updatedDescription);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toUserGroup(result.obj);
    },
    removeUserGroup: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const groupId = DataProtection.decryptId(args.input.id, NodeType.UserGroup);
        if (!groupId) throw new UserInputError("Invalid id", { id: "invalid" });

        const result = await context.storage.userGroups.removeGroup(context.user, groupId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toOrganisation(result.obj.organisationId);
    },
    createContentCollection: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const orgId = DataProtection.decryptId(args.input.organisationId, NodeType.Organisation);
        if (!orgId) throw new UserInputError("Invalid organisationId", { organisationId: "invalid" });

        const result = await context.storage.contentCollections.createCollection(context.user, args.input.name.trim(), args.input.description.trim(), orgId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toContentCollection(result.obj);
    },
    updateContentCollection: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const ccId = DataProtection.decryptId(args.input.id, NodeType.ContentCollection);
        if (!ccId) throw new UserInputError("Invalid contentCollectionId", { id: "invalid" });

        const updateModel: ContentCollectionUpdateModel = {
            name: args.input.name ? args.input.name.trim() : undefined,
            description: args.input.description ? args.input.description.trim() : undefined,
            signUpCodeEnabled: args.input.signUpCodeEnabled === null ? undefined : args.input.signUpCodeEnabled,
            signUpCode: typeof args.input.signUpCode === "string" ? args.input.signUpCode : undefined,
        };

        const result = await context.storage.contentCollections.updateCollection(context.user, ccId, updateModel);
        if (result.hasError) {
            switch (result.error) {
                case "content-collection-not-found":
                case "invalid-permissions":
                    throw new ForbiddenError(result.error);
                case "invalid-code":
                case "duplicate":
                    throw new UserInputError(result.error);
                default:
                    return assertNever(result.error);
            }
        }

        return Mapper.toContentCollection(result.obj);
    },
    removeContentCollection: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const ccId = DataProtection.decryptId(args.input.id, NodeType.ContentCollection);
        if (!ccId) throw new UserInputError("Invalid contentCollectionId", { id: "invalid" });

        const result = await context.storage.contentCollections.removeCollection(context.user, ccId);
        if (result.hasError) throw new ForbiddenError(result.error);

        return Mapper.toOrganisation(result.obj.organisationId);
    },
    updateContent: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const contentId = DataProtection.decryptId(args.input.id, NodeType.Content);
        if (!contentId) throw new UserInputError("Invalid content Id", { id: "invalid" });

        const updateModel: ContentUpdateModel = {
            title: args.input.title ? args.input.title.trim() : undefined,
            subtitle: args.input.subtitle ? args.input.subtitle.trim() : undefined,
            description: args.input.description ? args.input.description.trim() : undefined,
            author: args.input.author ? args.input.author.trim() : undefined,
            narrator: args.input.narrator ? args.input.narrator.trim() : undefined,
            publisher: args.input.publisher ? args.input.publisher.trim() : undefined,
            releaseDate: args.input.releaseDate,
            genreCode: args.input.genreCode ? args.input.genreCode.trim() : undefined,
            secondGenreCode: args.input.secondGenreCode ? args.input.secondGenreCode.trim() : args.input.secondGenreCode,
            languageCode: args.input.languageCode ? args.input.languageCode.trim() : undefined,
            nonBillable: args.input.nonBillable !== null ? args.input.nonBillable : undefined,
            nonBillableReason: args.input.nonBillableReason !== null ? args.input.nonBillableReason : undefined,
        };

        const result = await context.storage.content.updateContent(context.user, contentId, updateModel);
        if (result.hasError) {
            switch (result.error) {
                case "invalid-genre":
                case "invalid-language":
                case "invalid-second-genre":
                case "non-billable-reason-required":
                    throw new UserInputError(result.error);
                default:
                    throw new ForbiddenError(result.error);
            }
        }

        return Mapper.toContent(result.obj);
    },
    removeContent: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const contentId = DataProtection.decryptId(args.input.id, NodeType.Content);
        if (!contentId) throw new UserInputError("Invalid content Id", { id: "invalid" });

        const result = await context.storage.content.softDeleteContent(context.user, contentId);
        if (result.hasError) {
            throw new ForbiddenError(result.error);
        }

        return Mapper.toOrganisation(result.obj);
    },
    addAssociation: async (_, args, context) => addAssociation(args, context),
    removeAssociation: async (_, args, context) => removeAssociation(args, context),
    joinCode: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");
        if (loginRateHandler.hasReachedLimit(context.ipAddress)) throw new ForbiddenError("Join code rate limit reached.");

        // Code entry requests MUST have a valid request signature to help prevent abuse.
        if (!context.hasAuthenticationSignature) {
            throw new ForbiddenError("Invalid request");
        }

        // Content collections are the only 'things' with codes at this time.
        const result = await context.storage.users.joinContentCollectionWithCode(context.user, args.input.code);
        if (result.hasError) {
            switch (result.error) {
                case "invalid-code":
                    loginRateHandler.failure(context.ipAddress);
                    throw new UserInputError(result.error);
                default:
                    return assertNever(result.error);
            }
        }

        loginRateHandler.success(context.ipAddress);
        return Mapper.toContentCollection(result.obj);
    },
    logPlayback: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const contentId = DataProtection.decryptId(args.input.contentId, NodeType.Content);
        if (!contentId) throw new UserInputError("Invalid contentId", { contentId: "invalid" });

        const result = await context.storage.users.logPlayback(context.user, contentId, args.input.playbackRegions);
        if (result.hasError) throw new ForbiddenError(result.error);

        return { content: Mapper.toContent(result.obj) };
    },
    recordTechnicalIssues: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");
        await context.storage.users.recordTechnicalIssues(context.userAgent, args.input.data);
        return { message: "" };
    },
};
