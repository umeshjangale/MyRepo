import { AuthenticationError, UserInputError } from "apollo-server-express";

import * as DataProtection from "../../../security/data-protection";
import { NodeId, NodeType } from "../../../types/node-id";
import { Context } from "../../context";
import * as Mapper from "../../mapping";
import * as gq from "../../type-defs/types";

export async function getNodes(ids: string[], context: Context): Promise<Array<gq.Node | null>> {
    if (!context.user) throw new AuthenticationError("authentication required");

    const nodeIds: NodeId[] = [];
    const invalidIds: string[] = [];
    for (const id of ids) {
        const n = DataProtection.decryptNodeId(id);
        if (n === null) {
            invalidIds.push(id);
        } else {
            nodeIds.push(n);
        }
    }

    if (invalidIds.length > 0) throw new UserInputError(`Invalid id ${invalidIds.join()}`, { ids: "invalid" });

    const idsGroupedByType: Map<NodeType, number[]> = new Map();
    for (const { id, type } of nodeIds) {
        const groupedIds = idsGroupedByType.get(type);
        if (groupedIds) {
            groupedIds.push(id);
        } else {
            idsGroupedByType.set(type, [id]);
        }
    }

    const nodesGroupedByType: Map<NodeType, Array<gq.Node | null>> = new Map();
    for (const [nodeType, groupedIds] of idsGroupedByType) {
        switch (nodeType) {
            case NodeType.User:
                const users = await context.storage.users.getUsers(context.user, groupedIds);
                const userNodes = users.map(u => u ? Mapper.toUser(u) : null);
                nodesGroupedByType.set(
                    nodeType,
                    userNodes,
                );
                break;
            case NodeType.UserGroup:
                const groups = await context.storage.userGroups.getUserGroups(context.user, groupedIds);
                const groupNodes = groups.map(g => g ? Mapper.toUserGroup(g) : null);
                nodesGroupedByType.set(
                    nodeType,
                    groupNodes,
                );
                break;
            case NodeType.Organisation:
                const orgs = await context.storage.organisations.getOrganisations(context.user, groupedIds);
                const orgNodes = orgs.map(o => o ? Mapper.toOrganisation(o) : null);
                nodesGroupedByType.set(
                    nodeType,
                    orgNodes,
                );
                break;
            case NodeType.Content:
                const contentList = await context.storage.content.getContentList(context.user, groupedIds);
                const contentNodes = contentList.map(c => c ? Mapper.toContent(c) : null);
                nodesGroupedByType.set(
                    nodeType,
                    contentNodes,
                );
                break;
            case NodeType.ContentCollection:
                const collections = await context.storage.contentCollections.getCollections(context.user, groupedIds);
                const collectionNodes = collections.map(c => c ? Mapper.toContentCollection(c) : null);
                nodesGroupedByType.set(
                    nodeType,
                    collectionNodes,
                );
                break;
            default:
                throw new Error(`Unhandled node type '${nodeType}'`);
        }
    }

    const nodes: Array<gq.Node | null> = [];
    for (const { type } of nodeIds) {
        const groupedNodes = nodesGroupedByType.get(type);
        nodes.push(groupedNodes && groupedNodes.shift() || null);
    }
    return nodes;
}
