import { AuthenticationError, UserInputError } from "apollo-server-express";

import * as DataProtection from "../../../security/data-protection";
import { NodeId, NodeType } from "../../../types/node-id";
import { assertNever } from "../../../utils";
import { Context } from "../../context";
import * as Mapper from "../../mapping";
import * as gq from "../../type-defs/types";

export async function suggestionsForAssociation(args: gq.SuggestionsForAssociationQueryArgs, context: Context): Promise<gq.NodeSearchResponse> {

    if (!context.user) throw new AuthenticationError("authentication required");

    const nodeId = DataProtection.decryptNodeId(args.id);
    if (!nodeId) throw new UserInputError("Invalid id", { id: "invalid" });

    switch (nodeId.type) {
        case NodeType.User:
            switch (args.suggestionType) {
                case gq.NodeType.CONTENT: {
                    const { items, totalCount } = await context.storage.users.searchPotentialContentDirectlyAccessibleForUser(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(c => Mapper.toContent(c)),
                        totalCount,
                    };
                }
                case gq.NodeType.CONTENT_COLLECTION: {
                    const { items, totalCount } = await context.storage.users.searchPotentialContentCollectionsForUser(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(cc => Mapper.toContentCollection(cc)),
                        totalCount,
                    };
                }
                case gq.NodeType.USER_GROUP: {
                    const { items, totalCount } = await context.storage.users.searchPotentialUserGroupsForUser(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(g => Mapper.toUserGroup(g)),
                        totalCount,
                    };
                }
                case gq.NodeType.USER:
                    throw new UserInputError("Invalid suggestionType", { suggestionType: "invalid" });
                default:
                    return assertNever(args.suggestionType);
            }
            break;
        case NodeType.Content:
            switch (args.suggestionType) {

                case gq.NodeType.USER: {
                    const { items, totalCount } = await context.storage.content.searchPotentialUsersToDirectlyAccessContent(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(u => Mapper.toUser(u)),
                        totalCount,
                    };
                }
                case gq.NodeType.CONTENT_COLLECTION: {
                    const { items, totalCount } = await context.storage.content.searchPotentialContentCollectionsForContent(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(cc => Mapper.toContentCollection(cc)),
                        totalCount,
                    };
                }
                case gq.NodeType.USER_GROUP: {
                    const { items, totalCount } = await context.storage.content.searchPotentialUserGroupsForContent(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(g => Mapper.toUserGroup(g)),
                        totalCount,
                    };
                }
                case gq.NodeType.CONTENT:
                    throw new UserInputError("Invalid suggestionType", { suggestionType: "invalid" });

                default:
                    return assertNever(args.suggestionType);
            }
            break;
        case NodeType.UserGroup:
            switch (args.suggestionType) {
                case gq.NodeType.CONTENT: {
                    const { items, totalCount } = await context.storage.userGroups.searchPotentialContentForUserGroup(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(c => Mapper.toContent(c)),
                        totalCount,
                    };
                }
                case gq.NodeType.USER: {
                    const { items, totalCount } = await context.storage.userGroups.searchPotentialGroupMembers(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(u => Mapper.toUser(u)),
                        totalCount,
                    };
                }

                case gq.NodeType.CONTENT_COLLECTION:
                case gq.NodeType.USER_GROUP:
                    throw new UserInputError("Invalid suggestionType", { suggestionType: "invalid" });

                default:
                    return assertNever(args.suggestionType);
            }
            break;
        case NodeType.ContentCollection:
            switch (args.suggestionType) {
                case gq.NodeType.CONTENT: {
                    const { items, totalCount } = await context.storage.contentCollections.searchPotentialContentForCollection(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(c => Mapper.toContent(c)),
                        totalCount,
                    };
                }
                case gq.NodeType.USER: {
                    const { items, totalCount } = await context.storage.contentCollections.searchPotentialUsersForContentCollection(context.user, nodeId.id, args.pageSize, args.pageNumber, args.searchText || "");
                    return {
                        items: items.map(u => Mapper.toUser(u)),
                        totalCount,
                    };
                }
                case gq.NodeType.CONTENT_COLLECTION:
                case gq.NodeType.USER_GROUP:
                    throw new UserInputError("Invalid suggestionType", { suggestionType: "invalid" });

                default:
                    return assertNever(args.suggestionType);
            }
            break;
        case NodeType.Organisation:
        case NodeType.AudioSection:
            throw new UserInputError("Invalid id", { id: "invalid" });
        default:
            return assertNever(nodeId.type);
    }
}
