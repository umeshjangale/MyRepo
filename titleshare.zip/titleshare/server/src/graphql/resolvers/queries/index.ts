import { AuthenticationError, Config, ForbiddenError, gql, UserInputError } from "apollo-server-express";

import * as DataProtection from "../../../security/data-protection";
import { AudioId } from "../../../types/audio-id";
import { NodeId, NodeType } from "../../../types/node-id";
import * as Mapper from "../../mapping";
import * as gq from "../../type-defs/types";

import { getNodes } from "./get-nodes";
import { suggestionsForAssociation } from "./suggestions-for-association";

export const query: gq.Query = {
    me: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        return Mapper.toUser(context.user);
    },
    node: async (_, args, context) => {
        const nodes = await getNodes([args.id], context);

        if (!nodes.length) return null;
        return nodes[0];
    },
    nodes: async (_, args, context) => getNodes(args.ids, context),
    searchContent: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const { items, totalCount } = await context.storage.content.searchContent(context.user, args.pageSize, args.pageNumber);
        return {
            items: items.map(c => Mapper.toContent(c)),
            totalCount,
        };
    },
    searchOrganisations: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const { items, totalCount } = await context.storage.organisations.searchOrganisations(context.user, args.pageSize, args.pageNumber);
        return {
            items: items.map(o => Mapper.toOrganisation(o)),
            totalCount,
        };
    },
    searchSysAdmins: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const { items, totalCount } = await context.storage.users.searchSysAdmins(context.user, args.pageSize, args.pageNumber);
        return {
            items: items.map(u => Mapper.toUser(u)),
            totalCount,
        };
    },
    suggestionsForAssociation: async (_, args, context) => suggestionsForAssociation(args, context),
    languages: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const langs = await context.storage.referenceData.getLanguages();
        return langs.map(Mapper.toLanguage);
    },
    genres: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const genres = await context.storage.referenceData.getGenres();
        return genres.map(Mapper.toGenre);
    },
    contentAccessReasons: async (_, args, context) => {
        if (!context.user) throw new AuthenticationError("authentication required");

        const userId = DataProtection.decryptId(args.userId, NodeType.User);
        if (!userId) throw new UserInputError("Invalid user Id", { userId: "invalid" });

        const contentId = DataProtection.decryptId(args.contentId, NodeType.Content);
        if (!contentId) throw new UserInputError("Invalid content Id", { contentId: "invalid" });

        return Mapper.toContentAccessReasons(userId, contentId);
    },
};
