import { UserInputError } from "apollo-server-express";
import { GraphQLScalarType, Kind } from "graphql";

import { mutation } from "./mutations";
import { query } from "./queries";

const customTypeResolvers = {
  Date: new GraphQLScalarType({
    name: "Date",
    description: "Date custom scalar type",
    parseValue(value) {
      // value from the client
      if (isNaN(value)) throw new UserInputError(`Invalid number for date ${value}`);
      const d = new Date(parseInt(value, 10));
      if (isNaN(d.getTime())) throw new UserInputError(`Invalid date ${value}`);
      return d;
    },
    serialize(value: Date) {
      return value.getTime(); // value sent to the client
    },
    parseLiteral(ast) {
      if (ast.kind === Kind.INT) {
        const d = new Date(parseInt(ast.value, 10)); // ast value is always in string format
        if (isNaN(d.getTime())) throw new UserInputError(`Invalid date ${ast.value}`);
        return d;
      }
      return null;
    },
  }),
  Long: new GraphQLScalarType({
    name: "Long",
    description: "52 bit Integer custom scalar type ",
    parseValue(value) {
      // value from the client
      if (isNaN(value)) throw new UserInputError(`Invalid number for Long ${value}`);
      const n = value as number;
      if (n < Number.MIN_SAFE_INTEGER || n > Number.MAX_SAFE_INTEGER) {
        throw new UserInputError(`Long cannot represent non 52-bit signed integer value: ${value}`);
      }

      return n;
    },
    serialize(value) {
      return value; // value sent to the client
    },
    parseLiteral(ast) {
      if (ast.kind === Kind.INT) {
        const n = parseInt(ast.value, 10); // ast value is always in string format
        if (isNaN(n)) throw new UserInputError(`Invalid Long ${ast.value}`);
        return n;
      }
      return null;
    },
  }),
};

export const resolvers: any = {
  Mutation: mutation,
  Query: query,
  ...customTypeResolvers,
  Node: {
    // This is only here to suppress the warning message "Type "Node" is missing a "__resolveType" resolver"
    // It doesn't seem to actually do anything since each object already has a __typename field.
    __resolveType: (obj, context, info) => obj.__typename,
  },
  SignUpWithCodeResponse: {
    __resolveType: (obj, context, info) => obj.__typename,
  },
};
