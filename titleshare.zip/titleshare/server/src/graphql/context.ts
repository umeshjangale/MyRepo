import { inject, injectable } from "inversify";

import { serviceContainer } from "../runtime/inversify.config";
import { FACTORY_SYMBOLS, SYMBOLS } from "../runtime/symbols";
import { AudioStorage } from "../storage/audio-storage";
import { ContentCollectionStorage } from "../storage/content-collection-storage";
import { ContentStorage } from "../storage/content-storage";
import * as db from "../storage/db-entities";
import { OrganisationStorage } from "../storage/organisation-storage";
import { ReferenceDataStorage } from "../storage/reference-data-storage";
import { UserGroupStorage } from "../storage/user-group-storage";
import { UserStorage } from "../storage/user-storage";

/** Defines the shape of the graphql context which is available to the resolvers */
export interface Context {
    user?: db.User | null;
    storage: StorageContext;
    ipAddress: string;
    userAgent: string;
    hasAuthenticationSignature: boolean;
    setAuthCookie(value: string, csrfToken: string, validitySeconds?: number): void;
}

@injectable()
export class StorageContext {
    private _users: UserStorage | undefined;
    private _organisations: OrganisationStorage | undefined;
    private _referenceData: ReferenceDataStorage | undefined;
    private _userGroups: UserGroupStorage | undefined;
    private _content: ContentStorage | undefined;
    private _contentCollections: ContentCollectionStorage | undefined;
    private _audio: AudioStorage | undefined;

    constructor(
        @inject(FACTORY_SYMBOLS.UserStorage) private readonly _usersFactory: () => UserStorage,
        @inject(FACTORY_SYMBOLS.OrganisationStorage) private readonly _organisationsFactory: () => OrganisationStorage,
        @inject(FACTORY_SYMBOLS.ReferenceDataStorage) private readonly _refDataFactory: () => ReferenceDataStorage,
        @inject(FACTORY_SYMBOLS.UserGroupStorage) private readonly _userGroupsFactory: () => UserGroupStorage,
        @inject(FACTORY_SYMBOLS.ContentStorage) private readonly _contentFactory: () => ContentStorage,
        @inject(FACTORY_SYMBOLS.ContentCollectionStorage) private readonly _contentCollectionFactory: () => ContentCollectionStorage,
        @inject(FACTORY_SYMBOLS.AudioStorage) private readonly _audioFactory: () => AudioStorage,
    ) { }

    get users(): UserStorage {
        if (!this._users) this._users = this._usersFactory();
        return this._users;
    }

    get organisations(): OrganisationStorage {
        if (!this._organisations) this._organisations = this._organisationsFactory();
        return this._organisations;
    }

    get referenceData(): ReferenceDataStorage {
        if (!this._referenceData) this._referenceData = this._refDataFactory();
        return this._referenceData;
    }

    get userGroups(): UserGroupStorage {
        if (!this._userGroups) this._userGroups = this._userGroupsFactory();
        return this._userGroups;
    }

    get content(): ContentStorage {
        if (!this._content) this._content = this._contentFactory();
        return this._content;
    }

    get contentCollections(): ContentCollectionStorage {
        if (!this._contentCollections) this._contentCollections = this._contentCollectionFactory();
        return this._contentCollections;
    }

    get audio(): AudioStorage {
        if (!this._audio) this._audio = this._audioFactory();
        return this._audio;
    }
}
