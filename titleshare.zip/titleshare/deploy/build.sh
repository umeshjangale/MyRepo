#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "Building server..."
cd ../server
rm -rf ./dist
yarn tslint -p tsconfig.release.json
yarn tsc -p tsconfig.release.json
node post-build.js
cd ..

echo "Building web..."
cd web
rm -rf ./dist
yarn ng lint
yarn ng build --prod --progress=false
cd ..

# Copy transpiled server and web files to deployment package.
rm -rf deploy/web-server/src
rm -rf deploy/worker/src
rm -rf deploy/transcoder/src
cp -r server/dist/src/ deploy/web-server/src/
cp -r server/dist/src/ deploy/worker/src/
cp -r server/dist/src/ deploy/transcoder/src/
cp server/package.json deploy/web-server/
cp server/package.json deploy/worker/
cp server/package.json deploy/transcoder/
cp server/yarn.lock deploy/web-server/
cp server/yarn.lock deploy/worker/
cp server/yarn.lock deploy/transcoder/

# Update package.json start scripts for web and worker environments
# WARN If running this on osx, sed requires an empty "" after the -i parameter
sed -i "s/\[REPLACED BY CI\]/node .\/src\/index.js/" deploy/web-server/package.json
sed -i "s/\[REPLACED BY CI\]/node .\/src\/worker.js/" deploy/worker/package.json
sed -i "s/\[REPLACED BY CI\]/node .\/src\/transcoder.js/" deploy/transcoder/package.json

# Make sure local config files are removed
find deploy/web-server/src/config/ -type f -name "*local.json" -delete
find deploy/worker/src/config/ -type f -name "*local.json" -delete
find deploy/transcoder/src/config/ -type f -name "*local.json" -delete

# Copy angular app to static file directory of the server
cp -r web/dist/web/* deploy/web-server/src/_static

# To deploy web-server manually run:
# cd ./deploy/web-server/ && eb deploy --staged

# To deploy worker manually run:
# cd ./deploy/worker/ && eb deploy --staged
