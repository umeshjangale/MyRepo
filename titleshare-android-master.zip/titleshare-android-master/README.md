# TitleShare Android App
For developers, copy debug.keystore to ~/.android (optional, just makes it easier for two different developers to deploy to a single device without hassle).

We are using a Google managed certificate for play store releases, thus the upload certificate can be recreated if the passwords to the keychain are lost. The beta release certificate can be recreated if the passwords to the keychain are lost, worst case is that the hockeyapp release will need to be manually installed.

# Preparing a beta release
### Per marketing version
Adjust the version name within `app/build.gradle`.

```
    defaultConfig {
        ...
        versionName "1.0.0"
    }
```

### Per build (inclusive of adjusting the marketing version)
Increase the beta version code within `app/build.gradle` (the last argument to the `makeVersionCode` invocation).

```
// For internal testing via hockeyapp
beta {
    ...
    versionCode makeVersionCode(..., 0)
}
```

Then push to the `beta` branch, this will trigger circle-ci to build the app and automatically upload it to hockeyapp.
