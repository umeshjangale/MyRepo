package com.booktrack.titleshare

import android.app.Application
import com.microsoft.appcenter.AppCenter
import com.microsoft.appcenter.analytics.Analytics
import com.microsoft.appcenter.crashes.Crashes
import com.microsoft.appcenter.distribute.Distribute

fun startAppCenter(application: Application) {
    AppCenter.start(
        application,
        "240340cd-1745-4ef0-a8f6-dd36b85302ea",
        Analytics::class.java,
        Crashes::class.java,
        Distribute::class.java
    )
}
