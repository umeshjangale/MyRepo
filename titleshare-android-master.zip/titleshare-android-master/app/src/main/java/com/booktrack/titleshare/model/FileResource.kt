package com.booktrack.titleshare.model

import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.MainThread
import com.booktrack.titleshare.util.BaseRefCountedDisposable
import com.booktrack.titleshare.util.BufferSizeBugAvoidanceStreamWrapper
import com.booktrack.titleshare.util.TechnicalIssues
import com.booktrack.titleshare.util.Watchable
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonClass
import com.squareup.moshi.adapters.PolymorphicJsonAdapterFactory
import okhttp3.*
import java.io.File
import java.io.IOException

private const val STREAM_CHUNK_SIZE = 16384

typealias FileResourceId = Uri

class FileResource private constructor(
    val remoteUri: Uri,
    private val _crypto: Crypto,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileResourceDirectory: File,
    private val _fileResourceController: FileResourceController,
    private val _okHttpClient: OkHttpClient,
    private val _technicalIssues: TechnicalIssues,
    private var _internalState: InternalState
) : BaseRefCountedDisposable() {

    companion object {
        fun create(
            remoteUri: Uri,
            crypto: Crypto,
            okHttpClient: OkHttpClient,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceDirectory: File,
            fileResourceController: FileResourceController,
            technicalIssues: TechnicalIssues
        ): FileResource {
            val idle = InternalState.Idle(null)
            return FileResource(
                remoteUri,
                crypto,
                downloadRetryTriggers,
                fileResourceDirectory,
                fileResourceController,
                okHttpClient,
                technicalIssues,
                idle
            )
        }

        fun restore(
            memento: Memento,
            crypto: Crypto,
            okHttpClient: OkHttpClient,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceDirectory: File,
            fileResourceController: FileResourceController,
            technicalIssues: TechnicalIssues
        ): FileResource {
            return when (val state = memento.state) {
                is Memento.State.NotDownloaded -> {
                    create(
                        memento.remoteUri,
                        crypto,
                        okHttpClient,
                        downloadRetryTriggers,
                        fileResourceDirectory,
                        fileResourceController,
                        technicalIssues
                    )
                }
                is Memento.State.Downloaded -> {
                    val downloaded = InternalState.Downloaded(
                        file = File(fileResourceDirectory, state.filename),
                        sizeInBytes = state.sizeInBytes
                    )
                    FileResource(
                        memento.remoteUri,
                        crypto,
                        downloadRetryTriggers,
                        fileResourceDirectory,
                        fileResourceController,
                        okHttpClient,
                        technicalIssues,
                        downloaded
                    )
                }
            }
        }

        private fun stateFromInternalState(internalState: InternalState): State {
            return when (internalState) {
                is InternalState.Removed -> State.Pending(0)
                is InternalState.Idle -> State.Pending(0)
                is InternalState.EnqueuedForDownload -> State.Pending(internalState.downloadedSizeInBytes)
                is InternalState.Downloading -> State.Pending(internalState.downloadedSizeInBytes)
                is InternalState.Downloaded -> State.Available(internalState.file, internalState.sizeInBytes)
            }
        }
    }

    sealed class State {
        data class Pending(val downloadedSizeInBytes: Long) : State() {
            override val available = false
            override val finalOrDownloadedSizeInBytes = downloadedSizeInBytes
            override val file: File? = null
        }

        data class Available(override val file: File, val sizeInBytes: Long) : State() {
            override val available = true
            override val finalOrDownloadedSizeInBytes = sizeInBytes
        }

        abstract val available: Boolean
        abstract val finalOrDownloadedSizeInBytes: Long
        abstract val file: File?
    }

    private val _mainHandler = Handler(Looper.getMainLooper())
    private val _state = Watchable.Source(stateFromInternalState(_internalState))

    override fun onDispose() {
        _fileResourceController.unregister(this)
        removeFromDevice()
    }

    val state: Watchable<State>
        get() = _state.watchable

    @MainThread
    @Synchronized
    fun removeFromDevice() {
        transition(_internalState, InternalState.Removed)
    }

    // When network type is favourable, but only after we are ready to download
    // Has effect only if idle
    // Invoked on the main thread
    @Synchronized
    fun enqueueDownload() {
        if (_internalState !is InternalState.Idle) {
            return
        }
        val request = Request.Builder()
            .url(remoteUri.toString())
            .cacheControl(CacheControl.Builder().noCache().noStore().build())
            .build()

        val call = _okHttpClient.newCall(request)
        val initialEnqueuedForDownloadState = InternalState.EnqueuedForDownload(call, 0)
        transition(_internalState, initialEnqueuedForDownloadState)

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                _technicalIssues.report(
                    TechnicalIssues.DownloadOnFailureFailure(
                        message = e.message
                    )
                )
                transition(initialEnqueuedForDownloadState, InternalState.Idle(null))
                downloadFailed(remoteUri)
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                class CancelledException : Exception()

                val newInternalState = InternalState.Downloading(call, 0)
                if (!transition(initialEnqueuedForDownloadState, newInternalState)) {
                    throw CancelledException()
                }
                var lastReportedInternalState: InternalState = newInternalState

                response.body()!!.use { responseBody ->
                    if (!response.isSuccessful) {
                        transition(lastReportedInternalState, InternalState.Idle(response.code()))
                        downloadFailed(remoteUri)
                        return
                    }
                    responseBody.byteStream().use { inputStream ->
                        class ShortFileException : Exception()

                        val file = FileSystem.createUniqueFile(_fileResourceDirectory)
                        var bytesDownloaded: Long = 0
                        try {
                            _crypto.encryptedFileOutputStream(file).use { fileOutputStream ->
                                BufferSizeBugAvoidanceStreamWrapper(fileOutputStream).use { outputStream ->
                                    var bytesRead: Int
                                    val buffer = ByteArray(STREAM_CHUNK_SIZE)
                                    while (true) {
                                        bytesRead = inputStream.read(buffer)
                                        if (bytesRead == -1) {
                                            break
                                        }
                                        outputStream.write(buffer, 0, bytesRead)
                                        bytesDownloaded += bytesRead
                                        val newInternalState = InternalState.Downloading(call, bytesDownloaded)
                                        if (!transition(lastReportedInternalState, newInternalState)) {
                                            throw CancelledException()
                                        }
                                        lastReportedInternalState = newInternalState
                                    }
                                }
                            }

                            // TODO: once we have confidence in the encryptor, we can remove this check
                            val maxAttempts = 5
                            for (attemptCount in 1..maxAttempts) {
                                if (file.length() >= bytesDownloaded) {
                                    if (attemptCount > 1) {
                                        _technicalIssues.report(
                                            TechnicalIssues.DownloadShortFileThenSuccess(
                                                succeededOnAttempt = attemptCount
                                            )
                                        )
                                    }
                                    break
                                }
                                if (attemptCount == maxAttempts) {
                                    _technicalIssues.report(
                                        TechnicalIssues.DownloadShortFileFailure(
                                            wrote = file.length(),
                                            read = bytesDownloaded,
                                            spaceAvailable = file.freeSpace
                                        )
                                    )
                                    throw ShortFileException()
                                }
                                Thread.sleep(100)
                            }

                            if (!transition(
                                    lastReportedInternalState,
                                    InternalState.Downloaded(file, bytesDownloaded)
                                )
                            ) {
                                throw CancelledException()
                            }
                            Unit

                        } catch (e: Throwable) {
                            if (e !is ShortFileException && e !is CancelledException) {
                                _technicalIssues.report(
                                    TechnicalIssues.DownloadFailure(
                                        wrote = file.length(),
                                        read = bytesDownloaded,
                                        spaceAvailable = file.freeSpace,
                                        message = e.message
                                    )
                                )
                            }
                            file.delete()
                            // Setting the state might fail due to cancellation, this isn't a problem
                            transition(
                                lastReportedInternalState,
                                InternalState.Idle(null)
                            )
                            downloadFailed(remoteUri)
                        }
                    }
                }
            }
        })
    }

    // When network type is unfavourable
    // Has effect only if enqueuedForDownload
    // Invoked on the main thread
    @Synchronized
    fun dequeueDownload() {
        if (_internalState !is InternalState.EnqueuedForDownload) {
            return
        }
        (_internalState as InternalState.EnqueuedForDownload).downloadCall.cancel()
        transition(
            _internalState,
            InternalState.Idle(null)
        )
    }

    fun downloadFailed(uri: Uri) {
        _mainHandler.post {
            _downloadRetryTriggers.downloadFailed(uri)
        }
    }

    @Synchronized
    private fun transition(from: InternalState, to: InternalState): Boolean {
        // TODO: sanity check this logic
        val current = _internalState
        if (current is InternalState.Removed) {
            if (to is InternalState.RemovedObserver) {
                to.removed()
            }
            // Cannot transition out of the `Removed` state
            return false
        }
        if (to is InternalState.Removed && current is InternalState.RemovedObserver) {
            current.removed()
        }
        if (from != current) {
            return false
        }
        _internalState = to
        if (to !is InternalState.Removed) {
            _mainHandler.post {
                _state.value = stateFromInternalState(to)
            }
        }
        return true
    }

    private sealed class InternalState {
        interface RemovedObserver {
            fun removed()
        }

        object Removed : InternalState()

        data class Idle(val lastClientHTTPError: Int?/*, val resumable: Resumable?*/) : InternalState()

        data class EnqueuedForDownload(val downloadCall: Call, val downloadedSizeInBytes: Long) : RemovedObserver,
            InternalState() {
            override fun removed() {
                downloadCall.cancel()
            }
        }

        data class Downloading(val downloadCall: Call, val downloadedSizeInBytes: Long) : RemovedObserver,
            InternalState() {
            override fun removed() {
                downloadCall.cancel()
            }
        }

        data class Downloaded(val file: File, val sizeInBytes: Long) : RemovedObserver, InternalState() {
            override fun removed() {
                file.delete()
            }
        }
    }

    val memento: Memento
        @Synchronized
        get() = when (val internalState = _internalState) {
            is InternalState.Downloaded ->
                Memento(
                    remoteUri = remoteUri,
                    state = Memento.State.Downloaded(
                        filename = internalState.file.name,
                        sizeInBytes = internalState.sizeInBytes
                    )
                )
            else ->
                Memento(
                    remoteUri = remoteUri,
                    state = Memento.State.NotDownloaded()
                )
        }

    @JsonClass(generateAdapter = true)
    data class Memento(
        val remoteUri: Uri,
        val state: State
    ) {
        sealed class State(@Json(name = "state") val stateType: StateType) {
            @JsonClass(generateAdapter = true)
            class NotDownloaded : State(stateType = StateType.NotDownloaded)

            @JsonClass(generateAdapter = true)
            data class Downloaded(
                val filename: String,
                val sizeInBytes: Long
            ) : State(stateType = StateType.Downloaded)

            enum class StateType {
                NotDownloaded,
                Downloaded
            }

            companion object {
                fun moshiJsonAdapter(): JsonAdapter.Factory {
                    return PolymorphicJsonAdapterFactory.of(State::class.java, "state")
                        .withSubtype(NotDownloaded::class.java, StateType.NotDownloaded.name)
                        .withSubtype(Downloaded::class.java, StateType.Downloaded.name)
                }
            }
        }
    }
}
