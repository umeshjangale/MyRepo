package com.booktrack.titleshare.util

import androidx.annotation.MainThread
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposables

open class BaseRefCountedDisposable {
    private var _refCount = 0
    protected var _disposables = CompositeDisposable(Disposables.fromAction(::onDispose))

    fun isDisposed(): Boolean = _disposables.isDisposed

    protected open fun onDispose() {
    }

    val retained: Boolean
        get() = _refCount != 0

    @MainThread
    fun retain() {
        _refCount++
    }

    @MainThread
    fun release() {
        _refCount--
        if (_refCount <= 0) {
            _disposables.dispose()
        }
    }
}
