package com.booktrack.titleshare

import android.app.Application
import android.os.Build
import com.booktrack.titleshare.util.encodeAsHeaderCommentContent
import com.booktrack.titleshare.util.encodeAsHeaderToken
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CalculatedConstants @Inject constructor(
    application: Application
) {

    val userAgent: String = {
        val appNameVersion: String = {
            val name = application.packageName
            val version = application.packageManager.getPackageInfo(name, 0).versionName
            "${encodeAsHeaderToken(name)}/${encodeAsHeaderToken(version)}"
        }()

        val osNameVersion: String = {
            val name = "Android"
            val version = Build.VERSION.RELEASE
            "$name/$version"
        }()

        val hardwareModel: String = {
            val manufacturer = Build.MANUFACTURER
            val device = Build.DEVICE
            "$manufacturer/$device"
        }()

        val apolloAndroidNameVersion: String = {
            val version = BuildConfig.APOLLO_VERSION
            "${encodeAsHeaderToken("Apollo-Android")}/${encodeAsHeaderToken(version)}"
        }()

        "$appNameVersion (${encodeAsHeaderCommentContent("$osNameVersion; $hardwareModel")}) $apolloAndroidNameVersion"
    }()
}
