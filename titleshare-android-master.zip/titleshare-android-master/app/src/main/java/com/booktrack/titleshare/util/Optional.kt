package com.booktrack.titleshare.util

// RxJava doesn't allow null values :/ We can use this instead.
sealed class Optional<out T> {
    companion object {
        fun <T> fromNullable(value: T?): Optional<T> {
            return if (value != null) {
                Some(value)
            } else {
                None
            }
        }
    }

    object None : Optional<Nothing>()
    data class Some<T>(val some: T) : Optional<T>()

    val someOrNull: T?
        get() = when (this) {
            is None -> null
            is Some -> this.some
        }
}
