package com.booktrack.titleshare.model

import android.net.Uri
import androidx.annotation.MainThread
import com.booktrack.titleshare.util.TechnicalIssues
import com.squareup.moshi.JsonClass
import io.reactivex.Completable
import okhttp3.OkHttpClient

class FileResourceController(
    memento: Memento?,
    private val _crypto: Crypto,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileSystem: FileSystem,
    private val _technicalIssues: TechnicalIssues,
    private val _okHttpClient: OkHttpClient
) {
    private val _fileResourcesByUri: MutableMap<FileResourceId, FileResource> = HashMap()

    init {
        memento?.run {
            val fileResourceDirectory = _fileSystem.fileResourceDirectory
            fileResources.associateByTo(
                _fileResourcesByUri,
                { fileResource -> fileResource.remoteUri },
                { fileResourceMemento ->
                    FileResource.restore(
                        fileResourceMemento,
                        _crypto,
                        _okHttpClient,
                        _downloadRetryTriggers,
                        fileResourceDirectory,
                        this@FileResourceController,
                        _technicalIssues
                    )
                }
            )
        }
    }

    val fileResources: Iterable<FileResource>
        get() = ArrayList(_fileResourcesByUri.values)

    @MainThread
    fun fileResource(remoteUri: Uri): FileResource {
        return _fileResourcesByUri[remoteUri]
            ?: FileResource.create(
                remoteUri,
                _crypto,
                _okHttpClient,
                _downloadRetryTriggers,
                _fileSystem.fileResourceDirectory,
                this,
                _technicalIssues
            ).also { fileResource ->
                _fileResourcesByUri[remoteUri] = fileResource
            }
    }

    @MainThread
    fun unregister(fileResource: FileResource) {
        _fileResourcesByUri.remove(fileResource.remoteUri)
    }

    fun cleanupOrphanedFileResources() {
        val fileResources = ArrayList(_fileResourcesByUri.values)
        fileResources
            .filter { fileResource ->
                !fileResource.retained
            }
            .forEach { fileResource ->
                fileResource.retain()
                fileResource.release()
            }
    }

    @JsonClass(generateAdapter = true)
    data class Memento(val fileResources: List<FileResource.Memento>)

    val memento: Memento
        get() = Memento(
            fileResources = _fileResourcesByUri.values.map { it.memento }
        )
}
