package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.model.Authentication
import com.booktrack.titleshare.model.Connectivity
import com.booktrack.titleshare.model.DownloadFeedbackTrigger
import com.booktrack.titleshare.server_api.UnsupportedAppVersionInterceptor
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CrossCuttingViewModelFactoryProvider @Inject constructor(
    private val _authentication: Authentication,
    private val _connectivity: Connectivity,
    private val _downloadFeedbackTrigger: DownloadFeedbackTrigger,
    private val _unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor
) {
    inner class Factory : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return CrossCuttingViewModel(
                _authentication,
                _connectivity,
                _downloadFeedbackTrigger,
                _unsupportedAppVersionInterceptor
            ) as T
        }
    }
}
