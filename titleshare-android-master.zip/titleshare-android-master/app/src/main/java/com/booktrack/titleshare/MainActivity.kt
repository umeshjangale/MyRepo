package com.booktrack.titleshare

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.booktrack.titleshare.di.InjectingFragmentFactory
import com.booktrack.titleshare.model.DownloadRetryTriggers
import com.booktrack.titleshare.model.Model
import com.booktrack.titleshare.util.hasDestination
import com.booktrack.titleshare.view_model.CrossCuttingViewModel
import com.booktrack.titleshare.view_model.CrossCuttingViewModelFactoryProvider
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import dagger.android.AndroidInjection
import kotlinx.android.synthetic.main.main_activity.*
import javax.inject.Inject

class MainActivity : AppCompatActivity() {
    @Inject
    lateinit var fragmentFactory: InjectingFragmentFactory
    @Inject
    lateinit var model: Model
    @Inject
    lateinit var crossCuttingViewModelFactoryProvider: CrossCuttingViewModelFactoryProvider
    @Inject
    lateinit var downloadRetryTriggers: DownloadRetryTriggers

    // Can be created normally (ie. from app home screen)
    // or can be created to handle MANAGE_NETWORK_USAGE intent
    // We use two distinct navigation graphs for these cases
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
        setSupportActionBar(toolbar)

        startAppCenter(application)

        val navController = nav_host_fragment.findNavController()
        if (Intent.ACTION_MANAGE_NETWORK_USAGE == intent.action && intent.type == null) {
            navController.setGraph(R.navigation.manage_network_usage_navigation)
            toolbar.setupWithNavController(
                navController
            )
        } else {
            navController.setGraph(R.navigation.main_navigation)
            toolbar.setupWithNavController(
                navController,
                AppBarConfiguration(setOf(R.id.welcome, R.id.audiobooks))
            )
        }

        val defaultToolbarScrollFlags = (toolbar.layoutParams as AppBarLayout.LayoutParams).scrollFlags
        val defaultToolbarVisibility = toolbar.visibility
        val defaultAppBarPaddingLeft = app_bar_layout.paddingLeft
        val defaultAppBarPaddingTop = app_bar_layout.paddingTop
        val defaultAppBarPaddingRight = app_bar_layout.paddingRight
        val defaultAppBarPaddingBottom = app_bar_layout.paddingBottom

        nav_host_fragment.childFragmentManager.registerFragmentLifecycleCallbacks(object :
            FragmentManager.FragmentLifecycleCallbacks() {
            override fun onFragmentViewCreated(fm: FragmentManager, f: Fragment, v: View, savedInstanceState: Bundle?) {
                if (!navController.graph.hasDestination(f)) {
                    return
                }

                app_bar_bottom_view_container.removeAllViews()
                val customChrome = f as? CustomChrome
                customChrome?.onCreateAppBarBottomView(
                    LayoutInflater.from(app_bar_bottom_view_container.context), app_bar_bottom_view_container
                )?.also { view -> app_bar_bottom_view_container.addView(view) }

                val layoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
                layoutParams.scrollFlags = customChrome?.let { it.getToolbarScrollFlags() } ?: defaultToolbarScrollFlags
                toolbar.layoutParams = layoutParams

                toolbar.visibility = customChrome?.let { it.getToolbarVisibility() } ?: defaultToolbarVisibility
                if (toolbar.visibility == View.GONE) {
                    app_bar_layout.setPadding(0, 0, 0, 0)
                } else {
                    app_bar_layout.setPadding(
                        defaultAppBarPaddingLeft,
                        defaultAppBarPaddingTop,
                        defaultAppBarPaddingRight,
                        defaultAppBarPaddingBottom
                    )
                }
            }
        }, false)

        val viewModel = ViewModelProviders.of(this, crossCuttingViewModelFactoryProvider.Factory())
            .get(CrossCuttingViewModel::class.java)
        viewModel.reauthenticationRequired.observe(this, Observer { reauthenticationRequired ->
            if (reauthenticationRequired && navController.currentDestination?.parent?.id != R.id.welcome_navigation) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.main_activity_session_expired_title)
                    .setMessage(R.string.main_activity_session_expired_message)
                    .setPositiveButton(R.string.main_activity_session_expired_login_action) { _, _ ->
                        navController.navigate(
                            R.id.action_global_welcome_navigation
                        )
                    }
                    .setCancelable(false)
                    .show()
            }
        })
        viewModel.unsupportedAppVersion.observe(this, Observer { unsupportedAppVersion ->
            if (unsupportedAppVersion) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.main_activity_unsupported_app_version_title)
                    .setMessage(R.string.main_activity_unsupported_app_version_message)
                    .show()
            }
        })
        viewModel.downloadFeedback.observe(this, Observer { downloadFeedback ->
            downloadFeedback.consume()?.also {
                Snackbar
                    .make(
                        main_activity,
                        when (it) {
                            is CrossCuttingViewModel.DownloadFeedback.DownloadQueued -> if (it.connected) {
                                R.string.main_activity_download_feedback_queued_due_to_metered_network
                            } else {
                                R.string.main_activity_download_feedback_queued_due_to_no_connectivity
                            }
                            is CrossCuttingViewModel.DownloadFeedback.DownloadStarted -> if (it.meteredNetwork) {
                                R.string.main_activity_download_feedback_downloading_over_metered_network
                            } else {
                                R.string.main_activity_download_feedback_downloading_over_unmetered_network
                            }
                        },
                        6000
                    )
                    .setAction(R.string.main_activity_download_feedback_settings_action) {
                        navController.navigate(
                            R.id.action_global_settings_fragment
                        )
                    }
                    .show()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        downloadRetryTriggers.appResumed()
    }

    override fun onPause() {
        super.onPause()
        model.save()
    }

    override fun onStop() {
        super.onStop()
        model.save()
    }
}
