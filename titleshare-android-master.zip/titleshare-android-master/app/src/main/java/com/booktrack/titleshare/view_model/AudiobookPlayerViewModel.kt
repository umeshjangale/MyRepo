package com.booktrack.titleshare.view_model

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.ForegroundService
import com.booktrack.titleshare.model.*
import com.booktrack.titleshare.util.Consumable
import com.booktrack.titleshare.util.Milliseconds
import com.booktrack.titleshare.util.SimpleDisposableObserver
import com.booktrack.titleshare.util.TechnicalIssues
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposables
import io.reactivex.subjects.BehaviorSubject
import java.util.concurrent.TimeUnit

class AudiobookPlayerViewModel(
    private val _context: Context,
    audiobookRegistry: AudiobookRegistry,
    audiobookId: String,
    crypto: Crypto,
    fileSystem: FileSystem,
    technicalIssues: TechnicalIssues
) : ViewModel() {

    data class CoverImageUri(
        val small: Uri?,
        val large: Uri?
    )

    private val _disposables = CompositeDisposable()
    private val _coverImageUri = MutableLiveData<CoverImageUri>()
    private val _title = MutableLiveData<String>()
    private val _subtitle = MutableLiveData<String>()
    private val _audiobook: Audiobook = audiobookRegistry.audiobook(audiobookId)!!
    private var _player: IAudiobookPlayer? = null
    private val _busy = MutableLiveData<Boolean>()
    private val _playing = MutableLiveData<Boolean>()
    private val _displayableElapsedDuration = MutableLiveData<String?>()
    private val _displayableTotalDuration = MutableLiveData<String?>()
    private val _progressInMilliseconds = MutableLiveData<Int?>()
    private val _maxProgressInMilliseconds = MutableLiveData<Int?>()
    private var _userSeeking: Boolean = false
    private val _notEnoughStorageSpace = MutableLiveData<Boolean>()
    private val _weAreVerySorryButThatThereFileIsCorrupt = MutableLiveData<Boolean>()
    private val _cannotGainAudioFocus = MutableLiveData<Consumable<Unit>>()
    private val _hasSoundtrack = MutableLiveData<Boolean>()
    private val _soundtrackEnabled = MutableLiveData<Boolean>()
    private val _soundtrackVolumeBalance = MutableLiveData<Double>()
    private val _sectionIndex = MutableLiveData<Int>()
    private val _sections = MutableLiveData<List<String>>()
        .apply {
            _audiobook.audiobookSections.value.someOrNull?.items?.value?.someOrNull?.also {
                value = it.mapIndexed { index, _ -> "File ${index + 1}" }
            }
        }
    private var _foregroundService: ForegroundService? = null
    private val _foregroundServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as ForegroundService.LocalBinder
            _foregroundService = binder.getService().also {
                it.updateNotification(audiobookTitle = _audiobook.metadata.value.title)
            }
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            _foregroundService = null
        }
    }

    init {
        _audiobook.retain()
        _disposables.add(Disposables.fromAction { _audiobook.release() })

        _audiobook.metadata.subscribeWith(SimpleDisposableObserver { audiobookMetadata ->
            metadataDidChange(audiobookMetadata)
        }).also { _disposables.add(it) }

        _audiobook.fetchBookmark(Audiobook.FetchBookmarkOptions.LocalThenRemote)
            .subscribe { optionalBookmark ->
                _player = _audiobook.audiobookSections.value.someOrNull?.let { audiobookSections ->
                    audiobookSections.audioSectionsHash?.let { audioSectionsHash ->
                        audiobookSections.items.value.someOrNull?.let { items ->
                            if (items.isNotEmpty()) {
                                AudiobookPlayer(
                                    _context,
                                    crypto,
                                    fileSystem,
                                    technicalIssues,
                                    _audiobook,
                                    audioSectionsHash,
                                    items,
                                    optionalBookmark.someOrNull
                                )
                            } else {
                                null
                            }
                        }
                    }
                }

                _player?.apply {
                    playing.subscribeWith(SimpleDisposableObserver { playing ->
                        _playing.value = playing
                    }).also { _disposables.add(it) }

                    atEnd.subscribeWith(SimpleDisposableObserver { atEnd ->
                        if (atEnd) {
                            logPlaybackRegions()
                        }
                    }).also { _disposables.add(it) }

                    cannotGainAudioFocus.subscribeWith(SimpleDisposableObserver {
                        _cannotGainAudioFocus.value?.consume()
                        _cannotGainAudioFocus.value = Consumable(Unit)
                    }).also { _disposables.add(it) }

                    sectionReadiness.subscribeWith(SimpleDisposableObserver { sectionReadiness ->
                        when (sectionReadiness) {
                            is IAudiobookPlayer.SectionReadiness.ErrorNotEnoughStorageSpace -> {
                                _notEnoughStorageSpace.value = true
                            }
                            is IAudiobookPlayer.SectionReadiness.ErrorFailedToDecrypt -> {
                                _weAreVerySorryButThatThereFileIsCorrupt.value = true
                            }
                            is IAudiobookPlayer.SectionReadiness.Ready -> {
                                _displayableTotalDuration.value = formatTime(sectionReadiness.length)
                                _maxProgressInMilliseconds.value = sectionReadiness.length
                                _busy.value = false
                                logPlaybackRegions()
                            }
                            else -> {
                                _displayableTotalDuration.value = null
                                _maxProgressInMilliseconds.value = null
                                _busy.value = true
                            }
                        }
                        _sectionIndex.value = sectionReadiness.audiobookSection.index
                    }).also { _disposables.add(it) }

                    offset(50).subscribeWith(SimpleDisposableObserver { offset ->
                        _displayableElapsedDuration.value = formatTime(offset)
                        if (!_userSeeking) {
                            _progressInMilliseconds.value = offset
                        }
                    }).also { _disposables.add(it) }

                    hasSoundtrack.subscribeWith(SimpleDisposableObserver { enabled ->
                        _hasSoundtrack.value = enabled
                    }).also { _disposables.add(it) }

                    soundtrackEnabled.subscribeWith(SimpleDisposableObserver { enabled ->
                        _soundtrackEnabled.value = enabled
                    }).also { _disposables.add(it) }

                    soundtrackVolumeBalance.subscribeWith(SimpleDisposableObserver { balance ->
                        _soundtrackVolumeBalance.value = balance
                    }).also { _disposables.add(it) }
                }
            }
            .also { _disposables.add(it) }

        Intent(_context, ForegroundService::class.java).also { intent ->
            _context.bindService(intent, _foregroundServiceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onCleared() {
        _disposables.dispose()
        _player?.dispose()
        _context.unbindService(_foregroundServiceConnection)
        logPlaybackRegions()
        super.onCleared()
    }

    val coverImageUri: LiveData<CoverImageUri>
        get() = _coverImageUri

    val title: LiveData<String?>
        get() = _title

    val subtitle: LiveData<String?>
        get() = _subtitle

    val busy: LiveData<Boolean>
        get() = _busy

    val playing: LiveData<Boolean>
        get() = _playing

    val progressInMilliseconds: LiveData<Int?>
        get() = _progressInMilliseconds

    val maxProgressInMilliseconds: LiveData<Int?>
        get() = _maxProgressInMilliseconds

    val displayableElapsedDuration: LiveData<String?>
        get() = _displayableElapsedDuration

    val displayableTotalDuration: LiveData<String?>
        get() = _displayableTotalDuration

    val sections: LiveData<List<String>>
        get() = _sections

    val sectionIndex: LiveData<Int>
        get() = _sectionIndex

    val notEnoughStorageSpace: LiveData<Boolean>
        get() = _notEnoughStorageSpace

    val weAreVerySorryButThatThereFileIsCorrupt: LiveData<Boolean>
        get() = _weAreVerySorryButThatThereFileIsCorrupt

    val cannotGainAudioFocus: LiveData<Consumable<Unit>>
        get() = _cannotGainAudioFocus

    val hasSoundtrack: LiveData<Boolean>
        get() = _hasSoundtrack

    val soundtrackEnabled: LiveData<Boolean>
        get() = _soundtrackEnabled

    fun setSoundtrackEnabled(enabled: Boolean) {
        _player?.setSoundtrackEnabled(enabled)
    }

    val soundtrackVolumeBalance: LiveData<Double>
        get() = _soundtrackVolumeBalance

    fun setSoundtrackVolumeBalance(balance: Double) {
        _player?.setSoundtrackVolumeBalance(balance)
    }

    fun performChangeSectionAction(sectionIndex: Int) {
        _player?.seekToSection(sectionIndex)
    }

    fun performPlayPauseAction() {
        _player?.apply {
            if (playing.value) {
                pause()
                logPlaybackRegions()
            } else {
                play()
            }
        }
    }

    fun performForwardSeekAction() {
        _player?.relativeSeekInSection(30000)
    }

    fun performBackwardSeekAction() {
        _player?.relativeSeekInSection(-30000)
    }

    inner class SeekMutator {
        private val _offsets = BehaviorSubject.create<Milliseconds>()

        init {
            _userSeeking = true
            _player?.interactiveSeekInSection(_offsets)
        }

        fun seek(offset: Milliseconds) {
            _offsets.onNext(offset)
        }

        fun commit() {
            _offsets.onComplete()
            _userSeeking = false
        }
    }

    fun startSeekMutations(): SeekMutator {
        return SeekMutator()
    }

    fun seekWithinSection(offset: Milliseconds) {
        _player?.seekInSection(offset)
    }

    fun playerNotVisible() {
        logPlaybackRegions()
    }

    private fun metadataDidChange(metadata: AudiobookMetadata) {
        _title.value = nullOrNonEmptyString(metadata.title)
        _subtitle.value = nullOrNonEmptyString(metadata.subtitle)
        _coverImageUri.value = CoverImageUri(
            small = metadata.coverImageUrl256x256,
            large = metadata.coverImageUrl1024x1024
        )
    }

    private fun logPlaybackRegions() {
        _player?.consumePlaybackRegions()?.also(_audiobook::logPlaybackRegions)
    }

    companion object {
        private fun formatTime(duration: Int): String {
            val progress = duration.toLong()
            return String.format(
                "%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(progress),
                TimeUnit.MILLISECONDS.toMinutes(progress) - TimeUnit.HOURS.toMinutes(
                    TimeUnit.MILLISECONDS.toHours(
                        progress
                    )
                ),
                TimeUnit.MILLISECONDS.toSeconds(progress) - TimeUnit.MINUTES.toSeconds(
                    TimeUnit.MILLISECONDS.toMinutes(
                        progress
                    )
                )
            )
        }
    }
}

