package com.booktrack.titleshare.model

import com.booktrack.titleshare.util.Consumable
import com.booktrack.titleshare.util.Watchable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadFeedbackTrigger @Inject constructor() {

    private val _userInitiatedDownload: Watchable.Source<Consumable<Unit>> =
        Watchable.Source(Consumable(Unit).also { it.consume() })

    val userInitiatedDownload: Watchable<Consumable<Unit>>
        get() = _userInitiatedDownload.watchable

    fun userDidInitiateDownload() {
        _userInitiatedDownload.value.consume()
        _userInitiatedDownload.value = Consumable(Unit)
    }

}
