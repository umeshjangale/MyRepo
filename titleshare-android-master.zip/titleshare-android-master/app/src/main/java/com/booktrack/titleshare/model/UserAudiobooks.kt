package com.booktrack.titleshare.model

import android.annotation.SuppressLint
import com.booktrack.titleshare.server_api.AudiobookApi
import com.booktrack.titleshare.server_api.AudiobooksApi
import com.booktrack.titleshare.server_api.ExhaustivelyFetchedAudiobooksItem
import com.booktrack.titleshare.util.Watchable
import com.squareup.moshi.JsonClass
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*

// This class is effectively a singleton
class UserAudiobooks(
    memento: Memento?,
    private val _audiobooksApi: AudiobooksApi,
    private val _audiobookRegistry: AudiobookRegistry,
    private val _audiobookApi: AudiobookApi,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileResourceController: FileResourceController
) {
    data class Audiobooks(
        val items: List<Audiobook>,
        val dateFetched: Date
    )

    sealed class LastFetchError {
        data class NetworkError(val dateFetched: Date) : LastFetchError()
        data class ServerError(val dateFetched: Date) : LastFetchError()
    }

    data class State(
        val audiobooks: Audiobooks?,
        val fetching: Boolean,
        val lastFetchError: LastFetchError?
    )

    private val _state = Watchable.Source(
        {
            val audiobooks = memento?.audiobooks
            val dateFetched = memento?.dateFetched
            if (audiobooks != null && dateFetched != null) {
                State(
                    audiobooks = Audiobooks(
                        items = audiobooks.mapNotNull(_audiobookRegistry::audiobook),
                        dateFetched = dateFetched
                    ),
                    fetching = false,
                    lastFetchError = null
                )
            } else {
                State(audiobooks = null, fetching = false, lastFetchError = null)
            }
        }(),
        { oldValue, newValue ->
            newValue?.audiobooks?.items?.forEach { newAudiobook -> newAudiobook.retain() }
            oldValue?.audiobooks?.items?.forEach { oldAudiobook -> oldAudiobook.release() }
        }
    )

    val state: Watchable<State>
        get() = _state.watchable

    @SuppressLint("CheckResult")
    fun refresh() {
        if (_state.value.fetching) {
            return
        }
        _state.value = _state.value.copy(fetching = true)
        _audiobooksApi.exhaustivelyFetchUserAudiobooks()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { result ->
                assert(_state.value.fetching)
                var state = _state.value
                val now = Date()
                state = when (result) {
                    is AudiobooksApi.ExhaustivelyFetchedAudiobooks.Audiobooks -> {
                        val newAudiobooks = transformGraphqlAudiobooks(result.items)
                        state.copy(
                            audiobooks = Audiobooks(items = newAudiobooks, dateFetched = now),
                            lastFetchError = null
                        )
                    }
                    is AudiobooksApi.ExhaustivelyFetchedAudiobooks.Failure.ServerError -> state.copy(
                        lastFetchError = LastFetchError.ServerError(
                            dateFetched = now
                        )
                    )
                    is AudiobooksApi.ExhaustivelyFetchedAudiobooks.Failure.NetworkError -> state.copy(
                        lastFetchError = LastFetchError.NetworkError(
                            dateFetched = now
                        )
                    )
                }
                _state.value = state.copy(fetching = false)
            }
    }

    private fun transformGraphqlAudiobooks(graphqlAudiobooks: List<ExhaustivelyFetchedAudiobooksItem>): List<Audiobook> {
        return graphqlAudiobooks.map { graphqlAudiobook ->
            val id = graphqlAudiobook.id()
            val metadata = AudiobookMetadata.fromGraphql(graphqlAudiobook)
            _audiobookRegistry.audiobook(id)
                ?.also { existingAudiobook ->
                    existingAudiobook.update(metadata)
                }
                ?: Audiobook.create(
                    id,
                    metadata,
                    _audiobookRegistry,
                    _audiobookApi,
                    _downloadRetryTriggers,
                    _fileResourceController
                )
        }
    }

    @JsonClass(generateAdapter = true)
    data class Memento(val audiobooks: List<String>?, val dateFetched: Date?)

    val memento: Memento
        get() = _state.value.audiobooks?.let { audiobooks ->
            Memento(
                audiobooks = audiobooks.items.map { it.id },
                dateFetched = audiobooks.dateFetched
            )
        } ?: Memento(audiobooks = null, dateFetched = null)
}
