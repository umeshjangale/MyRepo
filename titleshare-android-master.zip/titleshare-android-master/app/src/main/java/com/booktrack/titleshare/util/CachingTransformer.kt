package com.booktrack.titleshare.util

/**
 * Repeatedly transforms an iterable to a list, using a one-time configured mapper.
 *
 * The results of a transform are cached and reused upon the next transform.
 * Existing mappings that are unused upon the next transform are "disposed" of using the given unmapper.
 */
class CachingTransformer<From, To>(
    private val _mapper: (From) -> Mapping<To>
) {
    data class Mapping<To>(val mapped: To, val unmapper: (() -> Unit)?)

    private var _mapping: MutableMap<From, Mapping<To>> = HashMap()

    fun transform(things: Iterable<From>): MutableList<To> {
        val unusedMappings = _mapping
        val usedMappings: MutableMap<From, Mapping<To>> = HashMap()
        val mappedThings = ArrayList<To>()
        for (thing in things) {
            val mapping = unusedMappings.remove(thing) ?: _mapper(thing)
            usedMappings[thing] = mapping
            mappedThings.add(mapping.mapped)
        }
        for ((_, mapping) in unusedMappings) {
            mapping.unmapper?.invoke()
        }
        _mapping = usedMappings
        return mappedThings
    }

    fun unmapAll() {
        transform(emptyList())
    }
}
