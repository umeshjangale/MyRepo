package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.server_api.AuthenticationApi
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ResetPasswordViewModelFactoryProvider @Inject constructor(
    private val _authenticationApi: AuthenticationApi
) {
    inner class Factory(private val _initialEmailAddress: String?) : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return ResetPasswordViewModel(_authenticationApi, _initialEmailAddress) as T
        }
    }
}
