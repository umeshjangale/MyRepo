package com.booktrack.titleshare.ui.reset_password

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.ResetPasswordFragmentBinding
import com.booktrack.titleshare.view_model.ResetPasswordViewModel
import com.booktrack.titleshare.view_model.ResetPasswordViewModelFactoryProvider
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.main_activity.*
import javax.inject.Inject

@SuppressLint("ValidFragment")
class ResetPasswordFragment @Inject constructor(
    private val _resetPasswordViewModelFactoryProvider: ResetPasswordViewModelFactoryProvider
) :
    Fragment(), CustomChrome {
    private lateinit var viewModel: ResetPasswordViewModel
    private val args: ResetPasswordFragmentArgs by navArgs()

    override fun onAttach(context: Context) {
        viewModel =
            ViewModelProviders.of(this, _resetPasswordViewModelFactoryProvider.Factory(args.initialEmailAddress))
                .get(ResetPasswordViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: ResetPasswordFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.reset_password_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.navigate.observe(viewLifecycleOwner, Observer { consumableNavigationAction ->
            consumableNavigationAction.consume()?.also { navigationAction ->
                when (navigationAction) {
                    is ResetPasswordViewModel.NavigationAction.Login -> {
                        Snackbar
                            .make(
                                activity!!.main_activity,
                                R.string.reset_password_fragment_reset_password_email_sent_message,
                                10000
                            )
                            .show()
                        Navigation.findNavController(view).popBackStack()
                    }
                }
            }
        })

        viewModel.presentResetPasswordFailure.observe(
            viewLifecycleOwner,
            Observer { consumableResetPasswordFailureReason ->
                consumableResetPasswordFailureReason.consume()?.also { resetPasswordFailureReason ->
                    val message = when (resetPasswordFailureReason) {
                        is ResetPasswordViewModel.ResetPasswordFailureReason.NetworkError -> R.string.reset_password_fragment_reset_password_failed_with_network_error
                        is ResetPasswordViewModel.ResetPasswordFailureReason.ServerError -> R.string.reset_password_fragment_reset_password_failed_with_server_error
                    }
                    Snackbar.make(view, message, Snackbar.LENGTH_SHORT).show()
                }
            })

        return view
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
