package com.booktrack.titleshare.model

import android.app.Application
import android.content.*
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.util.Log
import androidx.preference.PreferenceManager
import com.booktrack.titleshare.util.Watchable
import javax.inject.Inject
import javax.inject.Singleton

private const val allowMeteredNetworkForDownloadsKey = "allowMeteredNetworkForDownloads"

@Singleton
class Connectivity @Inject constructor(
    private val _context: Application
) {
    sealed class State {
        data class NoConnectivity(override val allowMeteredNetworkForDownloads: Boolean) : State() {
            override val canDownload = false
        }

        data class Connectivity(override val allowMeteredNetworkForDownloads: Boolean, val metered: Boolean) : State() {
            override val canDownload = allowMeteredNetworkForDownloads || !metered
        }

        abstract val allowMeteredNetworkForDownloads: Boolean
        abstract val canDownload: Boolean
    }

    private val _connectivityManager: ConnectivityManager =
        _context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val _sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(_context)
    private val _state: Watchable.Source<State> = Watchable.Source(determineState())
    private val _connectivityActionBroadcastReceiver by lazy {
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                updateState()
            }
        }
    }
    private val _networkCallback by lazy {
        object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network?) {
                super.onAvailable(network)
                updateState()
            }

            override fun onLost(network: Network?) {
                super.onLost(network)
                updateState()
            }
        }
    }
    private val _preferenceChangeListener: SharedPreferences.OnSharedPreferenceChangeListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == allowMeteredNetworkForDownloadsKey) {
                updateState()
            }
        }

    val state: Watchable<State>
        get() = _state.watchable

    fun atLeastOneActivityCreated() {
        if (Build.VERSION.SDK_INT >= 26) {
            _connectivityManager.registerDefaultNetworkCallback(_networkCallback)
        } else {
            val filter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
            _context.registerReceiver(_connectivityActionBroadcastReceiver, filter)
        }
        _sharedPreferences.registerOnSharedPreferenceChangeListener(_preferenceChangeListener)
    }

    fun allActivitiesDestroyed() {
        if (Build.VERSION.SDK_INT >= 26) {
            _connectivityManager.unregisterNetworkCallback(_networkCallback)
        } else {
            _context.unregisterReceiver(_connectivityActionBroadcastReceiver)
        }
        _sharedPreferences.unregisterOnSharedPreferenceChangeListener(_preferenceChangeListener)
    }

    private fun updateState() {
        _state.value = determineState()
    }

    private fun determineState(): State {
        val allowMeteredNetworkForDownloads = _sharedPreferences.getBoolean(
            allowMeteredNetworkForDownloadsKey,
            false
        )

        return when {
            _connectivityManager.activeNetworkInfo?.isConnected == true -> {
                State.Connectivity(
                    metered = _connectivityManager.isActiveNetworkMetered,
                    allowMeteredNetworkForDownloads = allowMeteredNetworkForDownloads
                )
            }
            else -> {
                State.NoConnectivity(
                    allowMeteredNetworkForDownloads = allowMeteredNetworkForDownloads
                )
            }
        }
    }
}
