package com.booktrack.titleshare.model

import android.net.Uri
import com.booktrack.titleshare.util.BaseRefCountedDisposable
import com.squareup.moshi.JsonClass

class AudiobookSection private constructor(
    val index: Int,
    val title: String,
    narrationRemoteUri: Uri,
    soundtrackRemoteUri: Uri?,
    fileResourceController: FileResourceController
) : BaseRefCountedDisposable() {

    companion object {
        fun create(
            index: Int,
            title: String,
            narrationRemoteUri: Uri,
            soundtrackRemoteUri: Uri?,
            fileResourceController: FileResourceController
        ): AudiobookSection {
            return AudiobookSection(
                index,
                title,
                narrationRemoteUri,
                soundtrackRemoteUri,
                fileResourceController
            )
        }

        fun restore(
            memento: Memento,
            index: Int,
            fileResourceController: FileResourceController
        ): AudiobookSection {
            return AudiobookSection(
                index,
                memento.title,
                memento.narrationRemoteUri,
                memento.soundtrackRemoteUri,
                fileResourceController
            )
        }
    }

    val narrationFileResource: FileResource
    val soundtrackFileResource: FileResource?

    init {
        narrationFileResource = fileResourceController.fileResource(narrationRemoteUri)
            .also { fileResource -> fileResource.retain() }
        soundtrackFileResource = soundtrackRemoteUri?.let { fileResourceController.fileResource(it) }
            ?.also { fileResource -> fileResource.retain() }
    }

    override fun onDispose() {
        narrationFileResource.release()
        soundtrackFileResource?.release()
    }

    val memento: Memento
        get() = Memento(
            title = title,
            narrationRemoteUri = narrationFileResource.remoteUri,
            soundtrackRemoteUri = soundtrackFileResource?.remoteUri
        )

    @JsonClass(generateAdapter = true)
    data class Memento(
        val title: String,
        val narrationRemoteUri: Uri,
        val soundtrackRemoteUri: Uri?
    )
}
