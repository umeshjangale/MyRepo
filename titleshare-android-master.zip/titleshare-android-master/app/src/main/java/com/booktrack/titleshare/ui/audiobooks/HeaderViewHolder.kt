package com.booktrack.titleshare.ui.audiobooks

import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.Transformations
import androidx.recyclerview.widget.RecyclerView
import com.booktrack.titleshare.R
import com.booktrack.titleshare.util.BoundLifecycle
import com.booktrack.titleshare.util.PeriodicLiveData
import kotlinx.android.synthetic.main.audiobooks_fragment_header.view.*
import java.util.*
import java.util.concurrent.TimeUnit

class HeaderViewHolder
private constructor(
    containerView: View,
    private val _recyclerLifecycleOwner: LifecycleOwner,
    private val _freshnessTextView: TextView
) : RecyclerView.ViewHolder(containerView), LifecycleOwner {

    companion object {
        fun create(parent: ViewGroup, recyclerLifecycleOwner: LifecycleOwner): HeaderViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.audiobooks_fragment_header, parent, false)
            return HeaderViewHolder(
                view,
                recyclerLifecycleOwner,
                view.freshness_text_view
            )
        }
    }

    private var _boundLifecycle = BoundLifecycle(this, _recyclerLifecycleOwner)
    private var _lastRefreshed: LiveData<Date>? = null

    fun bind(lastRefreshed: LiveData<Date>) {
        if (lastRefreshed == _lastRefreshed) {
            return
        }
        _lastRefreshed = lastRefreshed
        _boundLifecycle.destroy()
        _boundLifecycle = BoundLifecycle(this, _recyclerLifecycleOwner)

        Transformations.switchMap(lastRefreshed) { date ->
            Transformations.map(
                PeriodicLiveData(TimeUnit.MINUTES.toMillis(1))
            ) { date }
        }
            .observe(this, Observer { date ->
                updateLastRefreshed(date)
            })
    }

    fun unbind() {
        _lastRefreshed = null
        _boundLifecycle.destroy()
    }

    override fun getLifecycle(): Lifecycle = _boundLifecycle

    private fun updateLastRefreshed(lastRefreshed: Date) {
        val context = _freshnessTextView.context
        val millisSinceRefresh = Date().time - lastRefreshed.time
        _freshnessTextView.setTextColor(
            ContextCompat.getColor(
                context,
                when {
                    millisSinceRefresh < TimeUnit.HOURS.toMillis(1) -> R.color.colorAudiobooksFragmentHeaderFreshnessOkay
                    millisSinceRefresh < TimeUnit.DAYS.toMillis(1) -> R.color.colorAudiobooksFragmentHeaderFreshnessWarning
                    else -> R.color.colorAudiobooksFragmentHeaderFreshnessSerious
                }
            )
        )
        _freshnessTextView.text =
            context.getString(
                R.string.audiobooks_fragment_header_freshness,
                DateUtils.getRelativeTimeSpanString(lastRefreshed.time)
            )
    }
}
