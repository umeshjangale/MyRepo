package com.booktrack.titleshare.server_api

import com.booktrack.titleshare.graphql.Result
import io.reactivex.Completable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.subjects.CompletableSubject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UnsupportedAppVersionInterceptor @Inject constructor(
) : Consumer<Result<*>> {
    private val _unsupported: CompletableSubject = CompletableSubject.create()

    val unsupported: Completable
        get() = _unsupported
            .observeOn(AndroidSchedulers.mainThread())

    override fun accept(result: Result<*>?) {
        when (result) {
            is Result.Failure.HttpStatusError -> {
                if (result.unsupportedAppVersion) {
                    _unsupported.onComplete()
                }
            }
        }
    }
}
