package com.booktrack.titleshare.ui.audiobook_player

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PorterDuff
import android.media.AudioManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.AudiobookPlayerFragmentBinding
import com.booktrack.titleshare.view_model.AudiobookPlayerViewModel
import com.booktrack.titleshare.view_model.AudiobookPlayerViewModelFactoryProvider
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.audiobook_player_fragment.view.*
import kotlinx.android.synthetic.main.audiobook_player_fragment_controls.view.*
import javax.inject.Inject


@SuppressLint("ValidFragment")
class AudiobookPlayerFragment @Inject constructor(
    private val _audiobookPlayerViewModelFactoryProvider: AudiobookPlayerViewModelFactoryProvider
) :
    Fragment(), CustomChrome {

    private lateinit var viewModel: AudiobookPlayerViewModel
    private val args: AudiobookPlayerFragmentArgs by navArgs()

    override fun onAttach(context: Context) {
        viewModel =
            ViewModelProviders.of(this, _audiobookPlayerViewModelFactoryProvider.Factory(args.audiobookId))
                .get(AudiobookPlayerViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: AudiobookPlayerFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.audiobook_player_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.coverImageUri.observe(viewLifecycleOwner, Observer { coverImageUri ->
            Glide.with(this)
                .clear(view.cover_image_view)
            Glide.with(this)
                .load(coverImageUri.large)
                .thumbnail(
                    Glide.with(this)
                        .load(coverImageUri.small)
                        .onlyRetrieveFromCache(true)
                )
                .placeholder(R.drawable.placeholder_audiobook_cover)
//                .diskCacheStrategy(DiskCacheStrategy.NONE) // useful for testing/debugging
                .into(view.cover_image_view)
        })

        val sectionDropdown = view.section_dropdown
        viewModel.sections.observe(viewLifecycleOwner, Observer { sections ->
            val adapter = ArrayAdapter(
                context,
                R.layout.audiobook_player_section_item,
                sections
            )
            sectionDropdown.setAdapter(adapter)
            sectionDropdown.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
                viewModel.performChangeSectionAction(position)
            }
            sectionDropdown.isFocusableInTouchMode = false
        })
        Transformations.switchMap(viewModel.sections) { sections ->
            Transformations.map(viewModel.sectionIndex) { sectionIndex ->
                sections[sectionIndex]
            }
        }.observe(viewLifecycleOwner, Observer { selectedSectionTitle ->
            sectionDropdown.setText(selectedSectionTitle, false)
        })

        var seekMutator: AudiobookPlayerViewModel.SeekMutator? = null
        view.progress_seek_bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                seekMutator?.run {
                    seek(progress)
                } ?: viewModel.seekWithinSection(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                seekMutator?.commit()
                seekMutator = viewModel.startSeekMutations()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seekMutator?.commit()
                seekMutator = null
            }
        })

        viewModel.notEnoughStorageSpace.observe(viewLifecycleOwner, Observer { notEnoughStorageSpace ->
            if (notEnoughStorageSpace) {
                MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.audiobook_player_fragment_not_enough_space_title)
                    .setMessage(R.string.audiobook_player_fragment_not_enough_space_message)
                    .setPositiveButton(R.string.audiobook_player_fragment_not_enough_space_dismiss_action) { _, _ ->
                        Navigation.findNavController(view).popBackStack()
                    }
                    .setCancelable(false)
                    .show()
            }
        })

        // Hopefully, this is just a temporary measure until we resolve the issue with corrupt encryption
        // A "better" solution, rather than forcing re-download of the entire book, would be for us to delete
        // and then re-download just the problematic file
        viewModel.weAreVerySorryButThatThereFileIsCorrupt.observe(
            viewLifecycleOwner,
            Observer { notEnoughStorageSpace ->
                if (notEnoughStorageSpace) {
                    MaterialAlertDialogBuilder(context)
                        .setTitle(R.string.audiobook_player_fragment_corrupt_file_title)
                        .setMessage(R.string.audiobook_player_fragment_corrupt_file_message)
                        .setPositiveButton(R.string.audiobook_player_fragment_corrupt_file_dismiss_action) { _, _ ->
                            Navigation.findNavController(view).popBackStack()
                        }
                        .setCancelable(false)
                        .show()
                }
            })

        viewModel.cannotGainAudioFocus.observe(viewLifecycleOwner, Observer { cannotGainAudioFocus ->
            cannotGainAudioFocus.consume()?.also {
                Snackbar
                    .make(
                        view,
                        R.string.audiobook_player_fragment_cannot_gain_audio_focus_message,
                        Snackbar.LENGTH_LONG
                    )
                    .show()
            }
        })

        view.progress_bar.indeterminateDrawable.setColorFilter(
            ContextCompat.getColor(context!!, R.color.colorPrimary),
            PorterDuff.Mode.SRC_IN
        )

        view.soundtrack_balance_seek_bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                viewModel?.setSoundtrackVolumeBalance(progress / 100.0)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        return view
    }

    override fun onResume() {
        super.onResume()
        activity?.volumeControlStream = AudioManager.STREAM_MUSIC
    }

    override fun onStop() {
        super.onStop()
        viewModel.playerNotVisible()
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
