package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.model.Authentication
import com.booktrack.titleshare.model.DownloadFeedbackTrigger
import com.booktrack.titleshare.model.DownloadRetryTriggers
import com.booktrack.titleshare.model.Model
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AudiobooksViewModelFactoryProvider @Inject constructor(
    private val _authentication: Authentication,
    private val _downloadFeedbackTrigger: DownloadFeedbackTrigger,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _model: Model
) {
    inner class Factory : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return AudiobooksViewModel(_authentication, _downloadFeedbackTrigger, _downloadRetryTriggers, _model) as T
        }
    }
}
