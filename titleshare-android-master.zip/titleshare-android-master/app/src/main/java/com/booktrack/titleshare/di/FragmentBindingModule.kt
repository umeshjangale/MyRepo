package com.booktrack.titleshare.di

import androidx.fragment.app.Fragment
import com.booktrack.titleshare.SettingsFragment
import com.booktrack.titleshare.ui.audiobook_details.AudiobookDetailsFragment
import com.booktrack.titleshare.ui.audiobook_player.AudiobookPlayerFragment
import com.booktrack.titleshare.ui.audiobooks.AudiobooksFragment
import com.booktrack.titleshare.ui.login.LoginFragment
import com.booktrack.titleshare.ui.reset_password.ResetPasswordFragment
import com.booktrack.titleshare.ui.sign_up_with_code.SignUpWithCodeFragment
import com.booktrack.titleshare.ui.welcome.WelcomeFragment
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap
import javax.inject.Named

@Module
abstract class FragmentBindingModule {
    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(AudiobookDetailsFragment::class)
    abstract fun bindAudiobookDetailsFragment(fragment: AudiobookDetailsFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(AudiobookPlayerFragment::class)
    abstract fun bindAudiobookPlayerFragment(fragment: AudiobookPlayerFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(AudiobooksFragment::class)
    abstract fun bindAudiobooksFragment(fragment: AudiobooksFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(WelcomeFragment::class)
    abstract fun bindWelcomeFragment(fragment: WelcomeFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(LoginFragment::class)
    abstract fun bindLoginFragment(fragment: LoginFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(ResetPasswordFragment::class)
    abstract fun bindResetPasswordFragment(fragment: ResetPasswordFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(SignUpWithCodeFragment::class)
    abstract fun bindSignUpWithCodeFragment(fragment: SignUpWithCodeFragment): Fragment

    @Binds
    @Named("fragmentProvidersByClass")
    @IntoMap
    @FragmentClassKey(SettingsFragment::class)
    abstract fun bindSettingsFragment(fragment: SettingsFragment): Fragment
}
