package com.booktrack.titleshare.graphql

import com.apollographql.apollo.api.Error

fun List<Error>.anyWithExtensionCode(code: String): Boolean {
    return this.any { error ->
        val maybeExtensions = error.customAttributes()["extensions"] as? Map<String, *>
        val maybeHasCode = (maybeExtensions?.get("code")?.let { it == code })
        maybeHasCode ?: false
    }
}
