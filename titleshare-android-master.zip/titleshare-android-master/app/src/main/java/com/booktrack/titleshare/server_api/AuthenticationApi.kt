package com.booktrack.titleshare.server_api

import com.apollographql.apollo.ApolloClient
import com.booktrack.titleshare.graphql.*
import com.booktrack.titleshare.graphql.type.SignUpWithCodeActionRequired
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthenticationApi @Inject constructor(
    private val _apolloClient: ApolloClient,
    private val _unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor

) {
    sealed class LoginResult {
        data class Success(val token: String) : LoginResult()
        sealed class Failure : LoginResult() {
            object InvalidCredentials : Failure()
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    sealed class SignUpWithCodeResult {
        data class Success(val token: String) : SignUpWithCodeResult()
        object SuccessButMustLogin : SignUpWithCodeResult()
        object SuccessButMustSetPassword : SignUpWithCodeResult()
        sealed class Failure : SignUpWithCodeResult() {
            object InvalidCode : Failure()
            object Forbidden : Failure()
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    sealed class RequestPasswordResetResult {
        object Success : RequestPasswordResetResult()
        sealed class Failure : RequestPasswordResetResult() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    fun login(email: String, password: String): Single<LoginResult> {
        return _apolloClient.mutateAsRxSingle(LoginUserMutation(email, password))
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .map { result ->
                when (result) {
                    is Result.Success -> result.data?.let { data ->
                        LoginResult.Success(data.login().token())
                    } ?: if (result.errors.anyWithExtensionCode("BAD_USER_INPUT")) {
                        LoginResult.Failure.InvalidCredentials
                    } else {
                        LoginResult.Failure.ServerError
                    }
                    is Result.Failure.NetworkError -> LoginResult.Failure.NetworkError
                    else -> LoginResult.Failure.ServerError
                }
            }
    }

    fun signUpWithCode(email: String, code: String): Single<SignUpWithCodeResult> {
        return _apolloClient.mutateAsRxSingle(SignUpWithCodeMutation(email, code))
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .map { result ->
                when (result) {
                    is Result.Success -> result.data?.let { data ->
                        when (val signUpWithCode = data.signUpWithCode()) {
                            is SignUpWithCodeMutation.AsSignUpWithCodeLoggedInResponse -> SignUpWithCodeResult.Success(
                                signUpWithCode.token()
                            )
                            is SignUpWithCodeMutation.AsSignUpWithCodeActionRequiredResponse -> when (signUpWithCode.actionRequired()) {
                                SignUpWithCodeActionRequired.LOGIN -> SignUpWithCodeResult.SuccessButMustLogin
                                SignUpWithCodeActionRequired.SET_PASSWORD -> SignUpWithCodeResult.SuccessButMustSetPassword
                                else -> SignUpWithCodeResult.Failure.ServerError // should really be a "client doesn't understand server" error, but meh
                            }
                            else -> SignUpWithCodeResult.Failure.ServerError
                        }
                    } ?: when {
                        result.errors.anyWithExtensionCode("BAD_USER_INPUT") -> SignUpWithCodeResult.Failure.InvalidCode
                        result.errors.anyWithExtensionCode("FORBIDDEN") -> SignUpWithCodeResult.Failure.Forbidden
                        else -> SignUpWithCodeResult.Failure.ServerError
                    }
                    is Result.Failure.NetworkError -> SignUpWithCodeResult.Failure.NetworkError
                    else -> SignUpWithCodeResult.Failure.ServerError
                }
            }
    }

    fun requestPasswordReset(email: String): Single<RequestPasswordResetResult> {
        return _apolloClient.mutateAsRxSingle(RequestPasswordResetMutation(email))
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .map { result ->
                when (result) {
                    is Result.Success -> result.data?.let { _ ->
                        RequestPasswordResetResult.Success
                    } ?: RequestPasswordResetResult.Failure.ServerError
                    is Result.Failure.NetworkError -> RequestPasswordResetResult.Failure.NetworkError
                    else -> RequestPasswordResetResult.Failure.ServerError
                }
            }
    }

}
