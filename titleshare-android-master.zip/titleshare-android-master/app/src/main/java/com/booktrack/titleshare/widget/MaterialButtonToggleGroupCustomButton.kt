package com.booktrack.titleshare.widget

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.button.MaterialButton

/**
 * MaterialButtonToggleGroup does have a single selection mode, but,
 * it should perhaps be called "maximum single selection mode" because it allows no buttons to be selected.
 * Ideally it'd also have an "exactly one selection mode".
 * (for com.google.android.material:material:1.1.0-alpha05)
 * Feature request for this behaviour to be built-in: https://issuetracker.google.com/issues/129492493
 */
class MaterialButtonToggleGroupCustomButton(context: Context?, attrs: AttributeSet?) : MaterialButton(context, attrs) {
    private var _clicking: Int = 0

    override fun setChecked(checked: Boolean) {
        if (_clicking != 0 && isChecked) {
            // Avoid transitioning from checked to unchecked when clicked
            return
        }
        super.setChecked(checked)
    }

    override fun performClick(): Boolean {
        _clicking++
        try {
            return super.performClick()
        } finally {
            _clicking--
        }
    }
}
