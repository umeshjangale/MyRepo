package com.booktrack.titleshare.model

import android.app.Application
import android.content.Context
import java.io.File
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FileSystem @Inject constructor(
    private val _application: Application
) {

    companion object {
        fun createUniqueFile(parentDirectory: File): File {
            while (true) {
                val file = File(parentDirectory, UUID.randomUUID().toString())
                if (!file.exists()) {
                    return file
                }
            }
        }
    }

    val fileResourceDirectory: File
    val modelFile: File
    val modelFileTemp: File
    val cryptReadyFile: File

    init {
        val cacheDirectory = _application.getDir("Cache_1", Context.MODE_PRIVATE)
        fileResourceDirectory = File(cacheDirectory, "FileResources")
        assert(fileResourceDirectory.mkdirs())
        modelFile = File(cacheDirectory, "Model")
        modelFileTemp = File(cacheDirectory, "Model.temp")
        cryptReadyFile = File(cacheDirectory, "Hash.temp")
    }

    fun cleanFileResourceDirectory(fileResourcesToKeep: Iterable<FileResource>) {
        val filePathsToKeep = HashSet<String>()
        for (fileResource in fileResourcesToKeep) {
            fileResource.state.value.file?.also {
                filePathsToKeep.add(it.canonicalPath)
            }
        }
        for (foundFile in fileResourceDirectory.listFiles()) {
            if (!filePathsToKeep.contains(foundFile.canonicalPath)) {
                try {
                    foundFile.delete()
                } catch (e: Throwable) {
                    // Intentionally do nothing
                }
            }
        }
    }

    fun cleanSupersededCaches() {
        cleanPreV2()
        cleanPreV2dot0dot1()
    }

    private fun cleanPreV2dot0dot1() {
        try {
            // Yes, this is as bad as it looks: we create the directory (if it doesn't exist) then we nuke it
            // Android gives these directories funky names, and I don't want to assume a format
            // TODO: record whether we've attempted the upgrade tasks, and skip if done once
            _application.getDir("Cache_0", Context.MODE_PRIVATE).deleteRecursively()
        } catch (e: Throwable) {
            // Intentionally do nothing
        }
    }

    private fun cleanPreV2() {
        try {
            _application.deleteFile("my_audiobooks.json")
            _application.deleteFile("free_audiobooks.json")
            _application.getExternalFilesDir(null)
                ?.let { File(it, "audios") }
                ?.also {
                    it.deleteRecursively()
                }
        } catch (e: Throwable) {
            // Intentionally do nothing
        }
    }
}
