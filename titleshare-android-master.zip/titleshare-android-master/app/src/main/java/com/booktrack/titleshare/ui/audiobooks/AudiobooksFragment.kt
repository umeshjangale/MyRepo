package com.booktrack.titleshare.ui.audiobooks

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.*
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.AudiobooksFragmentBinding
import com.booktrack.titleshare.view_model.AudiobooksItemViewModel
import com.booktrack.titleshare.view_model.AudiobooksViewModel
import com.booktrack.titleshare.view_model.AudiobooksViewModelFactoryProvider
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposables
import kotlinx.android.synthetic.main.audiobooks_fragment.view.*
import kotlinx.android.synthetic.main.audiobooks_fragment_app_bar_bottom_view.view.*
import java.lang.ref.WeakReference
import javax.inject.Inject
import kotlin.math.roundToInt

@SuppressLint("ValidFragment")
class AudiobooksFragment @Inject constructor(
    private val _audiobooksViewModelFactoryProvider: AudiobooksViewModelFactoryProvider
) : Fragment(), CustomChrome {

    private lateinit var viewModel: AudiobooksViewModel
    private var viewDisposables: CompositeDisposable? = null
    private lateinit var viewManager: RecyclerView.LayoutManager

    override fun onAttach(context: Context) {
        setHasOptionsMenu(true)
        viewModel =
            ViewModelProviders.of(this, _audiobooksViewModelFactoryProvider.Factory())
                .get(AudiobooksViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewDisposables = CompositeDisposable()

        val binding: AudiobooksFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.audiobooks_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.navigate.observe(viewLifecycleOwner, Observer { consumableNavigationAction ->
            consumableNavigationAction.consume()?.also { navigationAction ->
                when (navigationAction) {
                    is AudiobooksViewModel.NavigationAction.Welcome -> {
                        Navigation.findNavController(view).navigate(
                            AudiobooksFragmentDirections.actionAudiobooksToWelcomeNavigation()
                        )
                    }
                }
            }
        })

        val recyclerView = view.audiobooks_recycler_view
        recyclerView.setHasFixedSize(true)
        val spanCount = context?.resources?.configuration?.run {
            (screenWidthDp / 200.0).roundToInt()
        } ?: 2
        viewManager = GridLayoutManager(context, spanCount).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (position == 0 && viewModel.filter.value is AudiobooksViewModel.Filter.Cloud) spanCount else 1
                }
            }
        }
        recyclerView.layoutManager = viewManager

        viewModel.filteredItemViewModels.observe(viewLifecycleOwner, Observer { itemViewModels ->
            val lastRefreshed =
                if (viewModel.filter.value is AudiobooksViewModel.Filter.Cloud) viewModel.lastRefreshed else null
            recyclerView.swapAdapter(AudiobookItemsAdapter(viewLifecycleOwner, itemViewModels, lastRefreshed), false)
        })

        viewModel.audiobookItemEvents.observe(viewLifecycleOwner, Observer { consumableAudiobookItemEvent ->
            consumableAudiobookItemEvent.consume()?.also { audiobookEvent ->
                when (audiobookEvent) {
                    is AudiobooksItemViewModel.AudiobookEvent.PresentAudiobookPlayer -> {
                        Navigation.findNavController(view).navigate(
                            AudiobooksFragmentDirections.actionAudiobooksToAudiobookPlayer(audiobookId = audiobookEvent.audiobook.id)
                        )
                    }
                    is AudiobooksItemViewModel.AudiobookEvent.PresentAudiobookDetails -> {
                        Navigation.findNavController(view).navigate(
                            AudiobooksFragmentDirections.actionAudiobooksToAudiobookDetails(audiobookId = audiobookEvent.audiobook.id)
                        )
                    }
                    is AudiobooksItemViewModel.AudiobookEvent.ConfirmAudiobookAction -> {
                        val alertDialog = MaterialAlertDialogBuilder(context).run {
                            setTitle(R.string.audiobooks_fragment_audiobook_action_dialog_title)
                            when (val removeAction = audiobookEvent.removeAction) {
                                is AudiobooksItemViewModel.AudiobookEvent.RemoveAction.CancelDownloadAndRemoveFromDevice -> {
                                    setPositiveButton(R.string.audiobooks_fragment_audiobook_action_dialog_cancel_download_action) { _, _ -> removeAction.action() }
                                }
                                is AudiobooksItemViewModel.AudiobookEvent.RemoveAction.RemoveFromDevice -> {
                                    setPositiveButton(R.string.audiobooks_fragment_audiobook_action_dialog_remove_from_device_action) { _, _ -> removeAction.action() }
                                }
                            }
                            audiobookEvent.updateAction?.also { updateAction ->
                                setNeutralButton(R.string.audiobooks_fragment_audiobook_action_dialog_update_action) { _, _ -> updateAction() }
                            }
                            setNegativeButton(R.string.audiobooks_fragment_audiobook_action_dialog_dismiss_action) { _, _ -> }
                            setCancelable(true)
                            create()
                        }
                        alertDialog.show()
                    }
                }
            }
        })

        viewModel.refreshing.observe(viewLifecycleOwner, Observer { fetching ->
            view.swipe_refresh.isRefreshing = fetching
        })
        view.swipe_refresh.setOnRefreshListener {
            viewModel.refresh(userInitiated = true)
        }

        viewModel.refresh(userInitiated = false)

        return view
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.audiobooks_fragment_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.refresh_menu_item) {
            viewModel.refresh(userInitiated = true)
            return true
        }
        if (item.itemId == R.id.logout_menu_item) {
            viewModel.logout()
            return true
        }
        if (item.itemId == R.id.settings_menu_item) {
            Navigation.findNavController(view!!).navigate(
                AudiobooksFragmentDirections.actionGlobalSettingsFragment()
            )
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        val view = layoutInflater.inflate(R.layout.audiobooks_fragment_app_bar_bottom_view, viewGroup, false)
        val buttonGroup = view.cloud_or_device_button_group
        buttonGroup.check(
            when (viewModel.filter.value!!) {
                is AudiobooksViewModel.Filter.Cloud -> R.id.cloud_button
                is AudiobooksViewModel.Filter.Device -> R.id.device_button
            }
        )
        val listener: (MaterialButtonToggleGroup, Int, Boolean) -> Unit = { _, checkedId, isChecked ->
            if (isChecked) {
                viewModel.filter.value = when (checkedId) {
                    R.id.cloud_button -> AudiobooksViewModel.Filter.Cloud
                    R.id.device_button -> AudiobooksViewModel.Filter.Device
                    else -> throw Exception()
                }
            }
        }
        buttonGroup.addOnButtonCheckedListener(listener)
        val weakButtonGroup = WeakReference(buttonGroup)
        viewDisposables?.add(Disposables.fromAction {
            weakButtonGroup.get()?.removeOnButtonCheckedListener(listener)
        })
        return view
    }

    override fun onDestroyView() {
        viewDisposables?.dispose()
        super.onDestroyView()
    }

    override fun getToolbarScrollFlags(): Int? {
        return AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
