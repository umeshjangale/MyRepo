package com.booktrack.titleshare.ui.welcome

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.view_model.WelcomeViewModel
import kotlinx.android.synthetic.main.welcome_fragment.view.*
import javax.inject.Inject

class WelcomeFragment @Inject constructor() : Fragment(), CustomChrome {
    private lateinit var viewModel: WelcomeViewModel

    override fun onAttach(context: Context) {
        viewModel = ViewModelProviders.of(this).get(WelcomeViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.welcome_fragment, container, false)
        view.login_button.setOnClickListener {
            Navigation.findNavController(view)
                .navigate(WelcomeFragmentDirections.actionWelcomeToLogin(initialEmailAddress = null))
        }
        view.enter_code_button.setOnClickListener {
            Navigation.findNavController(view).navigate(WelcomeFragmentDirections.actionWelcomeToSignUpWithCode())
        }
        view.more_info_button.setOnClickListener {
            context?.also { c ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.getString(R.string.website_url))))
            }
        }
        return view
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return View.GONE
    }
}
