package com.booktrack.titleshare.di

import com.booktrack.titleshare.TitleshareGlideModule
import dagger.Subcomponent

@Subcomponent(modules = [ImageLoadingModule::class])
interface AppGlideModuleComponent {

    fun inject(titleshareGlideModule: TitleshareGlideModule)

    @Subcomponent.Builder
    interface Builder {
        fun build(): AppGlideModuleComponent
    }
}
