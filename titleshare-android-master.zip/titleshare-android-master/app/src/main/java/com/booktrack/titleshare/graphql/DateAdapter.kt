package com.booktrack.titleshare.graphql

import com.apollographql.apollo.response.CustomTypeAdapter
import com.apollographql.apollo.response.CustomTypeValue
import java.util.*

class DateAdapter : CustomTypeAdapter<Date> {
    override fun encode(value: Date): CustomTypeValue<*> {
        return CustomTypeValue.GraphQLNumber(value.time)
    }

    override fun decode(value: CustomTypeValue<*>): Date {
        if (value is CustomTypeValue.GraphQLNumber) {
            return Date(value.value.toLong())
        } else {
            throw java.lang.RuntimeException("Cannot parse date")
        }
    }
}
