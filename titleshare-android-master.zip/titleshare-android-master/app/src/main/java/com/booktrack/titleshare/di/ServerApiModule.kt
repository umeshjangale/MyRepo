package com.booktrack.titleshare.di

import android.app.Application
import com.apollographql.apollo.ApolloClient
import com.booktrack.titleshare.CalculatedConstants
import com.booktrack.titleshare.R
import com.booktrack.titleshare.graphql.DateAdapter
import com.booktrack.titleshare.graphql.type.CustomType
import com.booktrack.titleshare.server_api.AuthenticationTokenInterceptor
import com.booktrack.titleshare.server_api.RequestSigningInterceptor
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
class ServerApiModule {
    companion object {
        fun createOkHttpClient(
            authenticationTokenInterceptor: AuthenticationTokenInterceptor,
            application: Application,
            calculatedConstants: CalculatedConstants,
            maximumLoggingLevel: HttpLoggingInterceptor.Level
        ): OkHttpClient {
            val logging = HttpLoggingInterceptor()
            logging.level =
                if (application.resources.getBoolean(R.bool.http_logging_enabled)) maximumLoggingLevel else HttpLoggingInterceptor.Level.NONE
            return OkHttpClient.Builder()
                .addInterceptor(logging)
                .addInterceptor(authenticationTokenInterceptor)
                .addNetworkInterceptor { chain ->
                    chain.proceed(
                        chain.request()
                            .newBuilder()
                            .header("User-Agent", calculatedConstants.userAgent)
                            .build()
                    )
                }
                .addNetworkInterceptor(RequestSigningInterceptor())
                .connectTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()
        }
    }

    @Singleton
    @Provides
    fun provideOkHttpClient(
        authenticationTokenInterceptor: AuthenticationTokenInterceptor,
        application: Application,
        calculatedConstants: CalculatedConstants
    ): OkHttpClient {
        // The "general purpose" OkHttpClient (never logs the http body, they can be huge for audio downloads)
        return createOkHttpClient(
            authenticationTokenInterceptor,
            application,
            calculatedConstants,
            HttpLoggingInterceptor.Level.HEADERS
        )
    }

    @Singleton
    @Provides
    fun provideApolloClient(
        authenticationTokenInterceptor: AuthenticationTokenInterceptor,
        application: Application,
        calculatedConstants: CalculatedConstants
    ): ApolloClient {
        // A custom OkHttpClient (logs the http body when debugging)
        val okHttpClient =
            createOkHttpClient(
                authenticationTokenInterceptor,
                application,
                calculatedConstants,
                HttpLoggingInterceptor.Level.BODY
            )

        val serverUrl = application.resources.getString(R.string.server_url)
        return ApolloClient.builder()
            .serverUrl("$serverUrl/graphql")
            .okHttpClient(okHttpClient)
            .addCustomTypeAdapter(CustomType.DATE, DateAdapter())
            .build()
    }
}
