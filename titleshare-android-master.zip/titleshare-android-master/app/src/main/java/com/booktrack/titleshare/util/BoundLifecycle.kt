package com.booktrack.titleshare.util

import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

/**
 * A lifecycle which tracks another parent lifecycle,
 * and which provides a means to enter the destroyed state
 * independently of the parent lifecycle.
 */
class BoundLifecycle(owner: LifecycleOwner, private val parentOwner: LifecycleOwner) : LifecycleRegistry(owner),
    LifecycleEventObserver {

    init {
        parentOwner.lifecycle.addObserver(this)
    }

    override fun onStateChanged(source: LifecycleOwner, event: Event) {
        handleLifecycleEvent(event)
    }

    fun destroy() {
        parentOwner.lifecycle.removeObserver(this)
        currentState = State.DESTROYED
    }
}
