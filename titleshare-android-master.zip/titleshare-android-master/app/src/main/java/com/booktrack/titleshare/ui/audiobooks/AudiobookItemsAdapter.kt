package com.booktrack.titleshare.ui.audiobooks

import android.view.ViewGroup
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.recyclerview.widget.RecyclerView
import com.booktrack.titleshare.view_model.AudiobooksItemViewModel
import java.util.*

private const val audiobookItemType = 0
private const val headerType = 1

class AudiobookItemsAdapter(
    private val _recyclerLifecycleOwner: LifecycleOwner,
    private var _itemViewModels: List<AudiobooksItemViewModel>,
    private var _lastRefreshed: LiveData<Date>?
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return when (viewType) {
            audiobookItemType -> AudiobookItemViewHolder.create(parent, _recyclerLifecycleOwner)
            headerType -> HeaderViewHolder.create(parent, _recyclerLifecycleOwner)
            else -> throw Error()
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val type = type(position)) {
            is Type.Header -> (holder as HeaderViewHolder).bind(_lastRefreshed!!)
            is Type.AudiobookItem -> (holder as AudiobookItemViewHolder).bind(_itemViewModels[type.position])
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        when (holder) {
            is AudiobookItemViewHolder -> holder.unbind()
            is HeaderViewHolder -> holder.unbind()
        }
    }

    override fun getItemCount(): Int {
        return if (_lastRefreshed == null) {
            _itemViewModels.size
        } else {
            _itemViewModels.size + 1
        }
    }

    override fun getItemId(position: Int): Long {
        return when (val type = type(position)) {
            is Type.Header -> -1
            is Type.AudiobookItem -> _itemViewModels[type.position].stableId
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (type(position)) {
            is Type.Header -> headerType
            is Type.AudiobookItem -> audiobookItemType
        }
    }

    private sealed class Type {
        object Header : Type()
        data class AudiobookItem(val position: Int) : Type()
    }

    private fun type(position: Int): Type {
        return when {
            _lastRefreshed == null -> Type.AudiobookItem(position = position)
            position == 0 -> Type.Header
            else -> Type.AudiobookItem(position = position - 1)
        }
    }
}
