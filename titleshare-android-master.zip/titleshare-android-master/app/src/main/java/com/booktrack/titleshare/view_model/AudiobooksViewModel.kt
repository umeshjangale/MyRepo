package com.booktrack.titleshare.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.model.*
import com.booktrack.titleshare.util.CachingTransformer
import com.booktrack.titleshare.util.Consumable
import com.booktrack.titleshare.util.SimpleDisposableObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import java.util.*

class AudiobooksViewModel(
    private val _authentication: Authentication,
    downloadFeedbackTrigger: DownloadFeedbackTrigger,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _model: Model
) : ViewModel() {

    sealed class Filter {
        object Cloud : Filter()
        object Device : Filter()
    }

    sealed class NavigationAction {
        object Welcome : NavigationAction()
    }

    private val _disposables = CompositeDisposable()
    private val _itemViewModelCachingTransformer = CachingTransformer<Audiobook, AudiobooksItemViewModel> { audiobook ->
        val disposable = watchAudiobookAudiobookSections(audiobook)
        val itemViewModel = AudiobooksItemViewModel(audiobook, downloadFeedbackTrigger, ::dispatchAudiobookEvent)
        CachingTransformer.Mapping(itemViewModel) {
            disposable.dispose()
            itemViewModel.dispose()
        }
    }
    private val _allItemViewModels: MutableLiveData<List<AudiobooksItemViewModel>> = MutableLiveData(emptyList())
    private val _deviceItemViewModels: MutableLiveData<List<AudiobooksItemViewModel>> = MutableLiveData(emptyList())
    private val _audiobookItemEvents: MutableLiveData<Consumable<AudiobooksItemViewModel.AudiobookEvent>> =
        MutableLiveData()
    private val _navigate = MutableLiveData<Consumable<NavigationAction>>(
        Consumable(
            if (_authentication.token == null) {
                NavigationAction.Welcome
            } else {
                null
            }
        )
    )
    private val _lastRefreshed: MutableLiveData<Date> = MutableLiveData()
    private val _refreshing: MutableLiveData<Boolean> = MutableLiveData()

    init {
        _model.userAudiobooks.state.subscribe { state ->
            _refreshing.value = state.fetching
            state.audiobooks?.dateFetched?.also { dateFetched -> _lastRefreshed.value = dateFetched }
        }
            .also { _disposables.add(it) }
    }

    val lastRefreshed: LiveData<Date>
        get() = _lastRefreshed

    val refreshing: LiveData<Boolean>
        get() = _refreshing

    val navigate: LiveData<Consumable<NavigationAction>>
        get() = _navigate

    val filter: MutableLiveData<Filter> = MutableLiveData(Filter.Cloud)
    val filteredItemViewModels = Transformations.switchMap(filter) {
        when (it) {
            Filter.Cloud -> _allItemViewModels
            Filter.Device -> _deviceItemViewModels
        }
    }.let { Transformations.distinctUntilChanged(it) }
    val audiobookItemEvents: LiveData<Consumable<AudiobooksItemViewModel.AudiobookEvent>>
        get() = _audiobookItemEvents

    init {
        _model.userAudiobooks.state.subscribeWith(SimpleDisposableObserver {
            audiobooksDidChange()
        }).also { _disposables.add(it) }
    }

    private fun watchAudiobookAudiobookSections(audiobook: Audiobook): Disposable {
        return audiobook.audiobookSections.skip(1)
            .subscribeWith(SimpleDisposableObserver {
                audiobookLocalAvailabilityDidChange()
            })
    }

    private fun audiobooksDidChange() {
        _allItemViewModels.value =
            _model.userAudiobooks.state.value.audiobooks?.items?.let { _itemViewModelCachingTransformer.transform(it) }
                ?: emptyList()
        audiobookLocalAvailabilityDidChange()
    }

    private fun audiobookLocalAvailabilityDidChange() {
        _deviceItemViewModels.value = _allItemViewModels.value?.filter { itemViewModel ->
            itemViewModel.markedForOnDevice
        }
    }

    private fun dispatchAudiobookEvent(audiobookEvent: AudiobooksItemViewModel.AudiobookEvent) {
        _audiobookItemEvents.value?.consume()
        _audiobookItemEvents.value = Consumable(audiobookEvent)
    }

    fun refresh(userInitiated: Boolean) {
        _model.userAudiobooks.refresh()
        if (userInitiated) {
            _downloadRetryTriggers.userRefreshed()
        }
    }

    fun logout() {
        _authentication.logout()
    }

    override fun onCleared() {
        _itemViewModelCachingTransformer.unmapAll()
        _disposables.dispose()
        super.onCleared()
    }
}
