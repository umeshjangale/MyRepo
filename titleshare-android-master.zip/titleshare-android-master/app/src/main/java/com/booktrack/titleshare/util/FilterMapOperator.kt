package com.booktrack.titleshare.util

import io.reactivex.Observable
import io.reactivex.ObservableOperator
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class FilterMapOperator<Downstream, Upstream>(private var _fn: (Upstream) -> Downstream?) :
    ObservableOperator<Downstream, Upstream> {
    override fun apply(observer: Observer<in Downstream>): Observer<in Upstream> {
        return Op(observer, _fn)
    }

    class Op<Upstream, Downstream>(val child: Observer<in Downstream>, private var _fn: (Upstream) -> Downstream?) :
        Observer<Upstream> {
        override fun onSubscribe(s: Disposable) {
            child.onSubscribe(s)
        }

        override fun onNext(t: Upstream) {
            _fn(t)?.also { mapped -> child.onNext(mapped) }
        }

        override fun onError(e: Throwable) {
            child.onError(e)
        }

        override fun onComplete() {
            child.onComplete()
        }
    }
}

fun <Downstream, Upstream> Observable<Upstream>.filterMap(fn: (Upstream) -> Downstream?): Observable<Downstream> {
    return this.lift(FilterMapOperator(fn))
}

