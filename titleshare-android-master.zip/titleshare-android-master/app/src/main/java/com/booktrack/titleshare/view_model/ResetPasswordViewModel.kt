package com.booktrack.titleshare.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.server_api.AuthenticationApi
import com.booktrack.titleshare.util.Consumable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable

class ResetPasswordViewModel(private val _authenticationApi: AuthenticationApi, initialEmailAddress: String?) :
    ViewModel() {
    sealed class NavigationAction {
        object Login : NavigationAction()
    }

    sealed class ResetPasswordFailureReason {
        object NetworkError : ResetPasswordFailureReason()
        object ServerError : ResetPasswordFailureReason()
    }

    private val _disposables = CompositeDisposable()
    private val _isEmailError = MutableLiveData<Boolean>()
    private val _isResetPasswordEnabled = MutableLiveData<Boolean>()
    private val _navigationAction = MutableLiveData<Consumable<NavigationAction>>()
    private val _presentResetPasswordFailure = MutableLiveData<Consumable<ResetPasswordFailureReason>>()

    var email: String? = null
        set(value) {
            field = value
            _isEmailError.value = !value.isNullOrEmpty() && !emailValid(value)
            synchroniseIsResetPasswordEnabled()
        }

    init {
        _isEmailError.value = false
        email = initialEmailAddress
        synchroniseIsResetPasswordEnabled()
        _presentResetPasswordFailure.value = Consumable(null)
    }

    override fun onCleared() {
        _disposables.dispose()
        super.onCleared()
    }

    val isEmailError: LiveData<Boolean>
        get() = _isEmailError

    val isResetPasswordEnabled: LiveData<Boolean>
        get() = _isResetPasswordEnabled

    fun resetPassword() {
        if (!_isResetPasswordEnabled.value!!) {
            return
        }
        _authenticationApi.requestPasswordReset(email!!)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { result ->
                when (result) {
                    is AuthenticationApi.RequestPasswordResetResult.Success -> {
                        _navigationAction.value?.consume()
                        _navigationAction.value = Consumable(NavigationAction.Login)
                    }
                    is AuthenticationApi.RequestPasswordResetResult.Failure.NetworkError -> {
                        _presentResetPasswordFailure.value?.consume()
                        _presentResetPasswordFailure.value = Consumable(ResetPasswordFailureReason.NetworkError)
                    }
                    is AuthenticationApi.RequestPasswordResetResult.Failure.ServerError -> {
                        _presentResetPasswordFailure.value?.consume()
                        _presentResetPasswordFailure.value = Consumable(ResetPasswordFailureReason.ServerError)
                    }
                }
            }
            .also { _disposables.add(it) }
    }

    val navigate: LiveData<Consumable<NavigationAction>>
        get() = _navigationAction

    val presentResetPasswordFailure: LiveData<Consumable<ResetPasswordFailureReason>>
        get() = _presentResetPasswordFailure

    private fun synchroniseIsResetPasswordEnabled() {
        _isResetPasswordEnabled.value = emailValid(email)
    }
}

private fun emailValid(value: String?): Boolean {
    return value?.contains('@') ?: false
}
