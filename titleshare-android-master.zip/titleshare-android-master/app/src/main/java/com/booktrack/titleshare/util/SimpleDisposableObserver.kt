package com.booktrack.titleshare.util

import android.util.Log
import io.reactivex.observers.DisposableObserver

class SimpleDisposableObserver<T>(private val _onNext: (T) -> Unit) : DisposableObserver<T>() {
    override fun onComplete() {
        // Don't care
    }

    override fun onNext(t: T) {
        _onNext(t)
    }

    override fun onError(e: Throwable) {
        Log.e("SimpleDisposableObserve", "Unhandled onError", e)
    }
}
