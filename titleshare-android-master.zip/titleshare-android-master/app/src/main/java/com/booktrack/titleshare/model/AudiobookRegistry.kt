package com.booktrack.titleshare.model

import androidx.annotation.MainThread
import com.booktrack.titleshare.server_api.AudiobookApi
import com.booktrack.titleshare.util.Optional
import com.squareup.moshi.JsonClass

class AudiobookRegistry(
    memento: Memento?,
    private val _audiobookApi: AudiobookApi,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileResourceController: FileResourceController
) {
    private val _audiobooksById: MutableMap<AudiobookId, Audiobook> = HashMap()

    init {
        memento?.run {
            audiobooks.associateByTo(
                _audiobooksById,
                { audiobook -> audiobook.id },
                { audiobookMemento ->
                    Audiobook.restore(
                        audiobookMemento,
                        this@AudiobookRegistry,
                        _audiobookApi,
                        _downloadRetryTriggers,
                        _fileResourceController
                    )
                }
            )
        }
    }

    val audiobooks: List<Audiobook>
        @MainThread
        get() = _audiobooksById.values.toList()

    val audiobooksAddedToDevice: List<Audiobook>
        @MainThread
        get() = _audiobooksById.values
            .filter { audiobook -> audiobook.audiobookSections.value is Optional.Some }
            .sortedBy { audiobook -> audiobook.audiobookSections.value.someOrNull!!.dateAddedToDevice }

    @MainThread
    fun audiobook(id: AudiobookId): Audiobook? {
        return _audiobooksById[id]
    }

    @MainThread
    fun register(audiobook: Audiobook) {
        _audiobooksById[audiobook.id] = audiobook
    }

    @MainThread
    fun unregister(audiobook: Audiobook) {
        _audiobooksById.remove(audiobook.id)
    }

    @JsonClass(generateAdapter = true)
    data class Memento(val audiobooks: List<Audiobook.Memento>)

    val memento: Memento
        get() = Memento(
            audiobooks = _audiobooksById.values.map { it.memento }
        )
}
