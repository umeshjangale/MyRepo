package com.booktrack.titleshare.model

import com.booktrack.titleshare.server_api.AudiobookApi
import com.booktrack.titleshare.util.BaseRefCountedDisposable
import com.booktrack.titleshare.util.Optional
import com.booktrack.titleshare.util.Watchable
import com.squareup.moshi.JsonClass
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*

typealias AudiobookId = String

class Audiobook private constructor(
    val id: AudiobookId,
    audiobookMetadata: AudiobookMetadata,
    audiobooksSections: AudiobookSections?,
    bookmark: AudiobookBookmark?,
    playbackRegions: List<AudiobookPlaybackRegion>?,
    private val _audiobookRegistry: AudiobookRegistry,
    private val _audiobookApi: AudiobookApi,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileResourceController: FileResourceController
) : BaseRefCountedDisposable() {

    companion object {
        fun create(
            id: AudiobookId,
            audiobookMetadata: AudiobookMetadata,
            audiobookRegistry: AudiobookRegistry,
            audiobookApi: AudiobookApi,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceController: FileResourceController
        ): Audiobook {
            return Audiobook(
                id,
                audiobookMetadata,
                null,
                null,
                null,
                audiobookRegistry,
                audiobookApi,
                downloadRetryTriggers,
                fileResourceController
            )
        }

        fun restore(
            memento: Memento,
            audiobookRegistry: AudiobookRegistry,
            audiobookApi: AudiobookApi,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceController: FileResourceController
        ): Audiobook {
            return Audiobook(
                memento.id,
                memento.metadata,
                memento.audiobookSections?.let {
                    AudiobookSections.restore(
                        it,
                        memento.id,
                        audiobookApi,
                        downloadRetryTriggers,
                        fileResourceController
                    )
                },
                memento.bookmark,
                memento.playbackRegions,
                audiobookRegistry,
                audiobookApi,
                downloadRetryTriggers,
                fileResourceController
            )
        }
    }

    private val _metadata = Watchable.Source(audiobookMetadata)
    private val _audiobookSections = Watchable.Source(
        Optional.fromNullable(audiobooksSections),
        { oldValue, newValue ->
            newValue?.someOrNull?.retain()
            oldValue?.someOrNull?.release()
        }
    )
    private val _audiobookSectionsUpdateAvailable: Watchable.Source<Boolean> = Watchable.Source(false)
    private var _bookmark: AudiobookBookmark? = bookmark
    private var _playbackRegions: List<AudiobookPlaybackRegion>? = playbackRegions

    init {
        _audiobookRegistry.register(this)
        synchroniseAudiobookSectionsUpdateAvailable()
    }

    override fun onDispose() {
        _audiobookSections.dispose()
        _audiobookRegistry.unregister(this)
    }

    val metadata: Watchable<AudiobookMetadata>
        get() = _metadata.watchable

    sealed class FetchBookmarkOptions {
        object LocalThenRemote : FetchBookmarkOptions()
    }

    fun fetchBookmark(options: FetchBookmarkOptions): Single<Optional<AudiobookBookmark>> {
        return when (options) {
            is FetchBookmarkOptions.LocalThenRemote -> {
                _bookmark?.let { localBookmark -> Single.just(Optional.fromNullable(localBookmark)) }
                    ?: _audiobookApi.fetchBookmark(id)
                        .observeOn(AndroidSchedulers.mainThread())
            }
        }
    }

    fun fetchAudiobookSections() {
        if (_audiobookSections.value is Optional.Some) {
            return
        }
        _audiobookSections.value = Optional.Some(AudiobookSections.create(Date(), id, _audiobookApi, _downloadRetryTriggers, _fileResourceController))
    }

    fun updateAudiobookSections() {
        if (!_audiobookSectionsUpdateAvailable.value) {
            return
        }
        _audiobookSections.value = Optional.Some(AudiobookSections.create(Date(), id, _audiobookApi, _downloadRetryTriggers, _fileResourceController))
        // TODO: important to force a save here (if we keep the current deletion strategy)
        synchroniseAudiobookSectionsUpdateAvailable()
    }

    fun removeAudiobookSections() {
        _audiobookSections.value = Optional.None
        // TODO: important to force a save here (if we keep the current deletion strategy)
        synchroniseAudiobookSectionsUpdateAvailable()
    }

    /**
    Whether there are updated audiobook sections available for download.
     */
    val audiobookSectionsUpdateAvailable: Watchable<Boolean>
        get() = _audiobookSectionsUpdateAvailable.watchable

    val audiobookSections: Watchable<Optional<AudiobookSections>>
        get() = _audiobookSections.watchable

    fun update(metadata: AudiobookMetadata) {
        _metadata.value = metadata
        synchroniseAudiobookSectionsUpdateAvailable()
    }

    fun logPlaybackRegions(playbackRegions: List<AudiobookPlaybackRegion>) {
        playbackRegions.lastOrNull()?.also { latestPlaybackRegion ->
            _bookmark = AudiobookBookmark(
                audioSectionIndex = latestPlaybackRegion.audioSectionIndex,
                offsetInSeconds = latestPlaybackRegion.endTime
            )
        }
        val playbackRegionsToSend =
            _playbackRegions?.let { failedPlaybackRegions -> failedPlaybackRegions + playbackRegions }
                ?: playbackRegions
        _playbackRegions = null
        _audiobookApi.sendPlaybackRegions(id, playbackRegionsToSend)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { result ->
                if (result is AudiobookApi.SendPlaybackRegionsResult.Failure) {
                    _playbackRegions =
                        _playbackRegions?.let { otherFailedPlaybackRegions -> playbackRegionsToSend + otherFailedPlaybackRegions }
                            ?: playbackRegionsToSend
                }
            }
            .also { _disposables.add(it) }
    }

    private fun synchroniseAudiobookSectionsUpdateAvailable() {
        _audiobookSectionsUpdateAvailable.value =
            _audiobookSections.value.someOrNull?.stale(_metadata.value.audioSectionsHash) ?: false
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Audiobook

        if (id != other.id) return false

        return true
    }

    override fun hashCode(): Int {
        return id.hashCode()
    }

    @JsonClass(generateAdapter = true)
    data class Memento(
        val id: AudiobookId,
        val metadata: AudiobookMetadata,
        val bookmark: AudiobookBookmark?,
        val playbackRegions: List<AudiobookPlaybackRegion>?,
        val audiobookSections: AudiobookSections.Memento?
    )

    val memento: Memento
        get() = Memento(
            id = id,
            metadata = _metadata.value,
            bookmark = _bookmark,
            playbackRegions = _playbackRegions,
            audiobookSections = _audiobookSections.value.someOrNull?.memento
        )
}
