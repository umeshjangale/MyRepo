package com.booktrack.titleshare.di

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentFactory
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Provider

class InjectingFragmentFactory @Inject constructor(
    @Named("fragmentProvidersByClass") private val creators: Map<Class<out Fragment>, @JvmSuppressWildcards Provider<Fragment>>
) : FragmentFactory() {
    override fun instantiate(classLoader: ClassLoader, className: String): Fragment {
        val fragmentClass = loadFragmentClass(classLoader, className)
        return creators[fragmentClass]?.run { get() }
            ?: super.instantiate(classLoader, className)
    }
}
