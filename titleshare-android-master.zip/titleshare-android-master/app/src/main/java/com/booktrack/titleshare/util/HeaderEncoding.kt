package com.booktrack.titleshare.util

private const val unencodablePlaceholder = '$'

// See:
//  https://tools.ietf.org/html/rfc7230#section-3.2.6
//  https://tools.ietf.org/html/rfc7231#section-5.5.3
//  https://tools.ietf.org/html/rfc5234#appendix-B.1

fun encodeAsHeaderToken(s: String): String {
    fun isTchar(c: Char): Boolean {
        return when (c) {
            in 'a'..'z' -> true
            in 'A'..'Z' -> true
            in '0'..'9' -> true
            '!' -> true
            '#' -> true
            '$' -> true
            '%' -> true
            '&' -> true
            '\'' -> true
            '*' -> true
            '+' -> true
            '-' -> true
            '.' -> true
            '^' -> true
            '_' -> true
            '`' -> true
            '|' -> true
            '~' -> true
            else -> false
        }
    }

    val stringBuilder = StringBuilder()
    for (c in s) {
        stringBuilder.append(
            if (isTchar(c)) {
                c
            } else {
                unencodablePlaceholder
            }
        )
    }
    return stringBuilder.toString()
}

fun encodeAsHeaderCommentContent(s: String): String {
    fun isUnescapedCommentChar(c: Char): Boolean {
        // Note: this could be expressed more simply, but this better matches the RFC text
        return when (c) {
            in '\u0021'..'\u0027' -> true
            in '\u002A'..'\u005B' -> true
            in '\u005D'..'\u007E' -> true
            in '\u0080'..'\u00FF' -> true
            '\t' -> true
            ' ' -> true
            else -> false
        }
    }

    fun isEscapedCommentChar(c: Char): Boolean {
        return when (c) {
            '(' -> true
            ')' -> true
            '\\' -> true
            else -> false
        }
    }

    val stringBuilder = StringBuilder()
    for (c in s) {
        when {
            isUnescapedCommentChar(c) -> stringBuilder.append(c)
            isEscapedCommentChar(c) -> {
                stringBuilder.append('\\')
                stringBuilder.append(c)
            }
            else -> stringBuilder.append(unencodablePlaceholder)
        }
    }
    return stringBuilder.toString()
}
