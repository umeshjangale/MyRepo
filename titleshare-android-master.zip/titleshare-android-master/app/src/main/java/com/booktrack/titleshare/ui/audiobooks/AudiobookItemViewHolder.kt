package com.booktrack.titleshare.ui.audiobooks

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.booktrack.titleshare.R
import com.booktrack.titleshare.util.BoundLifecycle
import com.booktrack.titleshare.view_model.AudiobooksItemViewModel
import com.booktrack.titleshare.widget.CircularProgressView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import kotlinx.android.synthetic.main.audiobooks_fragment_item.view.*

class AudiobookItemViewHolder
private constructor(
    containerView: View,
    private val _recyclerLifecycleOwner: LifecycleOwner,
    private val _coverImageView: ImageView,
    private val _titleTextView: TextView,
    private val _updatableTextView: TextView,
    private val _secondaryActionImageView: ImageView,
    private val _playableTextView: TextView,
    private val _circularProgressView: CircularProgressView,
    moreInfoButton: Button
) : RecyclerView.ViewHolder(containerView), LifecycleOwner {

    companion object {
        fun create(parent: ViewGroup, recyclerLifecycleOwner: LifecycleOwner): AudiobookItemViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.audiobooks_fragment_item, parent, false)
            return AudiobookItemViewHolder(
                view,
                recyclerLifecycleOwner,
                view.cover_image_view,
                view.title_text_view,
                view.updatable_text_view,
                view.secondary_action_image_view,
                view.playable_text_view,
                view.circular_progress,
                view.more_info_button
            )
        }
    }

    private var _boundLifecycle = BoundLifecycle(this, _recyclerLifecycleOwner)
    private var _viewModel: AudiobooksItemViewModel? = null

    init {
        _coverImageView.setOnClickListener { _viewModel?.performPrimaryAction() }
        _secondaryActionImageView.setOnClickListener { _viewModel?.performSecondaryAction() }
        moreInfoButton.setOnClickListener { _viewModel?.presentAudiobookDetails() }
    }

    fun bind(viewModel: AudiobooksItemViewModel) {
        if (viewModel == _viewModel) {
            return
        }
        _viewModel = viewModel
        _boundLifecycle.destroy()
        _boundLifecycle = BoundLifecycle(this, _recyclerLifecycleOwner)

        viewModel.title.observe(this, Observer {
            _titleTextView.text = it
        })
        val coverImageUri = viewModel.coverImageUri
        if (coverImageUri != null) {
            Glide.with(itemView)
                .load(coverImageUri)
                .placeholder(R.drawable.placeholder_audiobook_cover)
                // .diskCacheStrategy(DiskCacheStrategy.NONE) // useful for testing/debugging
                .addListener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        _titleTextView.visibility = View.INVISIBLE
                        return false
                    }
                })
                .into(_coverImageView)
        }
        viewModel.state.observe(this, Observer { state ->
            adjustForState(state)
        })
    }

    fun unbind() {
        Glide.with(itemView)
            .clear(_coverImageView)
        _viewModel = null
        _boundLifecycle.destroy()
    }

    override fun getLifecycle(): Lifecycle = _boundLifecycle

    private fun adjustForState(state: AudiobooksItemViewModel.State) {
        _updatableTextView.visibility = if (state.downloadedAndUpdatable) View.VISIBLE else View.INVISIBLE

        when (state.secondaryAction) {
            is AudiobooksItemViewModel.State.SecondaryAction.Download -> {
                _secondaryActionImageView.setImageResource(R.drawable.audiobooks_fragment_item_download_badge)
            }
            is AudiobooksItemViewModel.State.SecondaryAction.More -> {
                _secondaryActionImageView.setImageResource(R.drawable.audiobooks_fragment_item_more_badge)
            }
            is AudiobooksItemViewModel.State.SecondaryAction.Remove -> {
                _secondaryActionImageView.setImageResource(R.drawable.audiobooks_fragment_item_remove_badge)
            }
        }

        _playableTextView.visibility = if (state.downloadingButPlayable) View.VISIBLE else View.INVISIBLE

        when (val progress = state.progress) {
            is Double -> {
                _circularProgressView.progress = progress.toFloat()
                _circularProgressView.visibility = View.VISIBLE
            }
            null -> _circularProgressView.visibility = View.INVISIBLE
        }
    }
}
