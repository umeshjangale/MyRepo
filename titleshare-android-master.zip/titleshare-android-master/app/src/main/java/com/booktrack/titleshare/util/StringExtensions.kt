package com.booktrack.titleshare.util

fun String.snip(maximumLength: Int): String {
    return if (this.length <= maximumLength) {
        this
    } else {
        this.take(maximumLength) + "<<snip>>"
    }
}
