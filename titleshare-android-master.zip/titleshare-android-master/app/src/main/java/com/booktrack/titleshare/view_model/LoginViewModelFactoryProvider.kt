package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.model.Authentication
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LoginViewModelFactoryProvider @Inject constructor(
    private val _authentication: Authentication
) {
    inner class Factory(private val _initialEmailAddress: String?) : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return LoginViewModel(_authentication, _initialEmailAddress) as T
        }
    }
}
