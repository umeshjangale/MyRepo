package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel

class WelcomeViewModel : ViewModel() {

}
