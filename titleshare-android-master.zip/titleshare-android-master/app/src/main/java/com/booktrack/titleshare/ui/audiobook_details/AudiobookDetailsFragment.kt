package com.booktrack.titleshare.ui.audiobook_details

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.AudiobookDetailsFragmentBinding
import com.booktrack.titleshare.view_model.AudiobookDetailsViewModel
import com.booktrack.titleshare.view_model.AudiobookDetailsViewModelFactoryProvider
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.audiobook_details_fragment.view.*
import javax.inject.Inject

@SuppressLint("ValidFragment")
class AudiobookDetailsFragment @Inject constructor(
    private val _audiobookDetailsViewModelFactoryProvider: AudiobookDetailsViewModelFactoryProvider
) :
    Fragment(), CustomChrome {

    private lateinit var viewModel: AudiobookDetailsViewModel
    private val args: AudiobookDetailsFragmentArgs by navArgs()

    override fun onAttach(context: Context) {
        viewModel =
            ViewModelProviders.of(this, _audiobookDetailsViewModelFactoryProvider.Factory(args.audiobookId))
                .get(AudiobookDetailsViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: AudiobookDetailsFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.audiobook_details_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.navigate.observe(viewLifecycleOwner, Observer { consumableNavigationAction ->
            consumableNavigationAction.consume()?.also { navigationAction ->
                when (navigationAction) {
                    is AudiobookDetailsViewModel.NavigationAction.Play -> {
                        Navigation.findNavController(view).navigate(
                            AudiobookDetailsFragmentDirections.actionAudiobookDetailsToAudiobookPlayer(audiobookId = navigationAction.audiobookId)
                        )
                    }
                }
            }
        })

        viewModel.coverImageUri.observe(viewLifecycleOwner, Observer { coverImageUri ->
            Glide.with(this)
                .clear(view.cover_image_view)
            Glide.with(this)
                .load(coverImageUri.large)
                .thumbnail(
                    Glide.with(this)
                        .load(coverImageUri.small)
                        .onlyRetrieveFromCache(true)
                )
                .placeholder(R.drawable.placeholder_audiobook_cover)
//                .diskCacheStrategy(DiskCacheStrategy.NONE) // useful for testing/debugging
                .into(view.cover_image_view)
        })

        return view
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
