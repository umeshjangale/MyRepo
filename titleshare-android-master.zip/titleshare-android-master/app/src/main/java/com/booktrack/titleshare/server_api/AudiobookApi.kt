package com.booktrack.titleshare.server_api

import com.apollographql.apollo.ApolloClient
import com.booktrack.titleshare.graphql.*
import com.booktrack.titleshare.graphql.type.PlaybackRegion
import com.booktrack.titleshare.model.AudiobookBookmark
import com.booktrack.titleshare.model.AudiobookPlaybackRegion
import com.booktrack.titleshare.util.Optional
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

private const val maximumInconsistentResultRetries = 2

typealias ExhaustivelyFetchedAudiobookSectionsItem = ContentItemAudioSectionsQuery.Item

@Singleton
class AudiobookApi @Inject constructor(
    private val _apolloClient: ApolloClient,
    private val _authenticationTokenFailureInterceptor: AuthenticationTokenFailureInterceptor,
    private val _unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor
) {

    sealed class ExhaustivelyFetchedAudiobookSections {
        data class Sections(
            val items: List<ExhaustivelyFetchedAudiobookSectionsItem>,
            val audioSectionsHash: String,
            val totalBytes: Long
        ) : ExhaustivelyFetchedAudiobookSections()

        sealed class Failure : ExhaustivelyFetchedAudiobookSections() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    fun exhaustivelyFetchAudiobookSections(contentItemId: String): Single<ExhaustivelyFetchedAudiobookSections> {
        return fetchAllPages(contentItemId, 1, emptyList(), null, null, 0)
    }

    fun fetchBookmark(contentItemId: String): Single<Optional<AudiobookBookmark>> {
        return _apolloClient.queryAsRxSingle(
            MyBookmarkQuery(
                contentItemId
            )
        )
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .doOnSuccess(_authenticationTokenFailureInterceptor)
            .map { result ->
                Optional.fromNullable(
                    ((result as? Result.Success)?.data?.node() as? MyBookmarkQuery.AsContent)?.myBookmark()?.run {
                        AudiobookBookmark(
                            audioSectionIndex = audioSectionIndex(),
                            offsetInSeconds = time()
                        )
                    }
                )
            }
    }

    sealed class SendPlaybackRegionsResult {
        object Success : SendPlaybackRegionsResult()
        sealed class Failure : SendPlaybackRegionsResult() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    fun sendPlaybackRegions(
        contentItemId: String,
        playbackRegions: List<AudiobookPlaybackRegion>
    ): Single<SendPlaybackRegionsResult> {
        return _apolloClient.mutateAsRxSingle(
            LogPlaybackMutation(
                contentItemId,
                playbackRegions.map { model ->
                    PlaybackRegion.builder()
                        .audioSectionsHash(model.audioSectionsHash)
                        .audioSectionIndex(model.audioSectionIndex)
                        .startTime(model.startTime)
                        .endTime(model.endTime)
                        .endTimestamp(model.endTimestamp)
                        .build()
                }
            )
        )
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .doOnSuccess(_authenticationTokenFailureInterceptor)
            .map { result ->
                when (result) {
                    is Result.Success -> if (result.data != null) {
                        SendPlaybackRegionsResult.Success
                    } else {
                        SendPlaybackRegionsResult.Failure.ServerError
                    }
                    is Result.Failure.NetworkError -> SendPlaybackRegionsResult.Failure.NetworkError
                    else -> SendPlaybackRegionsResult.Failure.ServerError
                }
            }
    }

    private fun fetchAllPages(
        contentItemId: String,
        oneBasedPageNumber: Int,
        previousItems: List<ExhaustivelyFetchedAudiobookSectionsItem>,
        previousTotalItems: Int?,
        previousHash: String?,
        inconsistentResultRetryCount: Int
    ): Single<ExhaustivelyFetchedAudiobookSections> {
        return fetchPage(contentItemId, oneBasedPageNumber)
            .flatMap { result ->
                when (result) {
                    is FetchedAudiobookSectionsPage.Sections -> {
                        if ((previousTotalItems != null && result.totalItems != previousTotalItems) || (previousHash != null && result.hash != previousHash)) {
                            // Hmm, the server is now reporting a different number of total items/hash...
                            // probably caused by a server-side mutation concurrent with our exhaustive fetch
                            // Reset everything and try again
                            if (inconsistentResultRetryCount <= maximumInconsistentResultRetries) {
                                fetchAllPages(
                                    contentItemId,
                                    1,
                                    emptyList(),
                                    null,
                                    null,
                                    inconsistentResultRetryCount + 1
                                )
                            } else {
                                // So slim an edge case that we (ab)use the server error variant
                                Single.just<ExhaustivelyFetchedAudiobookSections>(ExhaustivelyFetchedAudiobookSections.Failure.ServerError)
                            }
                        } else {
                            val accumulatedItems = previousItems + result.items
                            if (accumulatedItems.size < result.totalItems) {
                                fetchAllPages(
                                    contentItemId,
                                    oneBasedPageNumber + 1,
                                    accumulatedItems,
                                    result.totalItems,
                                    result.hash,
                                    inconsistentResultRetryCount
                                )
                            } else {
                                Single.just<ExhaustivelyFetchedAudiobookSections>(
                                    ExhaustivelyFetchedAudiobookSections.Sections(
                                        accumulatedItems,
                                        result.hash,
                                        result.totalBytes
                                    )
                                )
                            }
                        }
                    }
                    is FetchedAudiobookSectionsPage.Failure.ServerError -> Single.just<ExhaustivelyFetchedAudiobookSections>(
                        ExhaustivelyFetchedAudiobookSections.Failure.ServerError
                    )
                    is FetchedAudiobookSectionsPage.Failure.NetworkError -> Single.just<ExhaustivelyFetchedAudiobookSections>(
                        ExhaustivelyFetchedAudiobookSections.Failure.NetworkError
                    )
                }
            }
    }

    private sealed class FetchedAudiobookSectionsPage {
        data class Sections(
            val items: List<ExhaustivelyFetchedAudiobookSectionsItem>,
            val totalItems: Int,
            val hash: String,
            val totalBytes: Long
        ) : FetchedAudiobookSectionsPage()

        sealed class Failure : FetchedAudiobookSectionsPage() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    private fun fetchPage(contentItemId: String, oneBasedPageNumber: Int): Single<FetchedAudiobookSectionsPage> {
        return _apolloClient.queryAsRxSingle(
            ContentItemAudioSectionsQuery(
                contentItemId,
                20,
                oneBasedPageNumber
            )
        )
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .doOnSuccess(_authenticationTokenFailureInterceptor)
            .map { result ->
                val x: FetchedAudiobookSectionsPage = when (result) {
                    is Result.Success -> when (val content =
                        result.data?.node() as? ContentItemAudioSectionsQuery.AsContent) {
                        null -> FetchedAudiobookSectionsPage.Failure.ServerError
                        else -> FetchedAudiobookSectionsPage.Sections(
                            content.audioSections().items(),
                            content.audioSections().totalCount(),
                            content.audioSectionsHash(),
                            content.totalBytes().total().toLong()
                        )
                    }
                    is Result.Failure -> when (result) {
                        is Result.Failure.NetworkError -> FetchedAudiobookSectionsPage.Failure.NetworkError
                        else -> FetchedAudiobookSectionsPage.Failure.ServerError
                    }
                }
                x
            }
    }
}
