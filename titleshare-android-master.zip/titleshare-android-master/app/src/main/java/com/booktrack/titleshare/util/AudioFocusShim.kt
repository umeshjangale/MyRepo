package com.booktrack.titleshare.util

import android.annotation.TargetApi
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import io.reactivex.disposables.Disposable
import io.reactivex.disposables.Disposables

class AudioFocusShim(context: Context) {
    private val _audioManager: AudioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    sealed class AudioFocusRequestResponse {
        data class Granted(val disposable: Disposable) : AudioFocusRequestResponse()
        object Failed : AudioFocusRequestResponse()
    }

    sealed class AudioFocusChange {
        object Gain : AudioFocusChange()
        object Loss : AudioFocusChange()
        object LossTransient : AudioFocusChange()
        object LossTransientCanDuck : AudioFocusChange()
    }

    fun requestAudioFocus(changeHandler: (AudioFocusChange) -> Unit): AudioFocusRequestResponse {
        return if (Build.VERSION.SDK_INT < 26) {
            requestAudioFocusPreApiLevel26(changeHandler)
        } else {
            requestAudioFocusOnOrAfterApiLevel26(changeHandler)
        }
    }

    private fun requestAudioFocusPreApiLevel26(changeHandler: (AudioFocusChange) -> Unit): AudioFocusRequestResponse {
        val onAudioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
            convertFocusChange(focusChange)?.also { audioFocusChange ->
                changeHandler(audioFocusChange)
            } ?: Log.e("AudioFocusShim", "Ignoring unexpected focus change $focusChange")
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        return if (_audioManager.requestAudioFocus(
                onAudioFocusChangeListener,
                audioAttributes.flags,
                AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        ) {
            AudioFocusRequestResponse.Granted(
                disposable = Disposables.fromAction { _audioManager.abandonAudioFocus(onAudioFocusChangeListener) }
            )
        } else {
            AudioFocusRequestResponse.Failed
        }
    }

    @TargetApi(26)
    private fun requestAudioFocusOnOrAfterApiLevel26(changeHandler: (AudioFocusChange) -> Unit): AudioFocusRequestResponse {
        val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAcceptsDelayedFocusGain(false)
            .setWillPauseWhenDucked(true)
            .setOnAudioFocusChangeListener(
                { focusChange ->
                    convertFocusChange(focusChange)?.also { audioFocusChange ->
                        changeHandler(audioFocusChange)
                    } ?: Log.e("AudioFocusShim", "Ignoring unexpected focus change $focusChange")
                },
                Handler(Looper.getMainLooper())
            )
            .build()

        return if (_audioManager.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            AudioFocusRequestResponse.Granted(
                disposable = Disposables.fromAction { _audioManager.abandonAudioFocusRequest(focusRequest) }
            )
        } else {
            AudioFocusRequestResponse.Failed
        }
    }

    private fun convertFocusChange(focusChange: Int): AudioFocusChange? {
        return when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> AudioFocusChange.Gain
            AudioManager.AUDIOFOCUS_LOSS -> AudioFocusChange.Loss
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> AudioFocusChange.LossTransient
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> AudioFocusChange.LossTransientCanDuck
            else -> null
        }
    }

}
