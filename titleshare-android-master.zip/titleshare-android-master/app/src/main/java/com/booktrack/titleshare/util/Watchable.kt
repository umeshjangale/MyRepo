package com.booktrack.titleshare.util

import android.util.Log
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.disposables.Disposable
import io.reactivex.subjects.BehaviorSubject
import java.util.concurrent.atomic.AtomicReference


/**
 * An observable with the ability to peek at the latest value (of which there is always one).
 *
 * Split into two parts, the read-write part and the read-only part.
 */
class Watchable<T> private constructor(
    private val _source: Source<T>,
    private val _behaviorSubject: BehaviorSubject<T>
) : Observable<T>() {
    class Source<T>(
        initialValue: T,
        private val _onChange: ((oldValue: T?, newValue: T?) -> Unit)? = null
    ) : Disposable {

        init {
            _onChange?.invoke(null, initialValue)
        }

        private val _behaviorSubject = BehaviorSubject.createDefault(initialValue)
        private var _isDisposed = AtomicReference(false)

        val watchable: Watchable<T> = Watchable(this, _behaviorSubject)

        var value: T
            get() = _behaviorSubject.value!!
            set(v) {
                if (isDisposed) {
                    Log.w("Watchable", "Ignored attempt to set value on disposed watchable")
                    return
                }
                _onChange?.invoke(_behaviorSubject.value!!, v)
                _behaviorSubject.onNext(v)
            }

        override fun dispose() {
            if (!_isDisposed.get()) {
                if (!_isDisposed.getAndSet(true)) {
                    disposeOnce()
                }
            }
        }

        override fun isDisposed(): Boolean {
            return _isDisposed.get()
        }

        private fun disposeOnce() {
            _onChange?.invoke(_behaviorSubject.value!!, null)
            _behaviorSubject.onComplete()
        }
    }

    val value: T
        get() = _source.value

    override fun subscribeActual(observer: Observer<in T>?) {
        _behaviorSubject.subscribe(observer!!)
    }
}
