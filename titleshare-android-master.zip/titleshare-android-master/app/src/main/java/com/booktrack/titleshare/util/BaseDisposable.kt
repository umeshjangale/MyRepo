package com.booktrack.titleshare.util

import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable

open class BaseDisposable : Disposable {
    protected var _disposables = CompositeDisposable()
    override fun isDisposed(): Boolean = _disposables.isDisposed
    override fun dispose() = _disposables.dispose()
}
