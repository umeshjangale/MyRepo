package com.booktrack.titleshare.model

class Account {
}
