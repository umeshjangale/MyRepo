package com.booktrack.titleshare.view_model

import com.booktrack.titleshare.model.Audiobook
import com.booktrack.titleshare.model.AudiobookSections
import com.booktrack.titleshare.util.Optional
import io.reactivex.Observable
import io.reactivex.functions.Function3

sealed class AudiobookState {
    object Remote : AudiobookState()
    data class Downloading(val progress: Double, val playable: Boolean) : AudiobookState()
    data class Local(val updatable: Boolean) : AudiobookState()

    companion object {
        fun forAudiobook(audiobook: Audiobook): Observable<AudiobookState> {
            val stateChanges: Observable<AudiobookState> = Observable.combineLatest(
                audiobook.audiobookSections,
                audiobook.audiobookSectionsUpdateAvailable,
                audiobook.audiobookSections.switchMap { audiobookSections ->
                    when (audiobookSections) {
                        is Optional.None -> Observable.just(Optional.None)
                        is Optional.Some -> audiobookSections.some.progress.map { progress -> Optional.Some(progress) }
                    }
                },
                Function3 { audiobookSections, updateAvailable, progress ->
                    when (audiobookSections) {
                        is Optional.Some -> {
                            when (val audiobookSectionsProgress = audiobookSections.some.progress.value) {
                                is AudiobookSections.Progress.WaitingForMetadata -> {
                                    Downloading(
                                        progress = 0.0,
                                        playable = false
                                    )
                                }
                                is AudiobookSections.Progress.Downloading -> {
                                    Downloading(
                                        progress = audiobookSectionsProgress.bytesDownloaded.toDouble() / audiobookSectionsProgress.bytesTotal.toDouble(),
                                        playable = audiobookSections.some.items.value.someOrNull?.firstOrNull()?.let {
                                            it.narrationFileResource.state.value.available
                                                    && (it.soundtrackFileResource?.state?.value?.available ?: true)
                                        } ?: false
                                    )
                                }
                                is AudiobookSections.Progress.Complete -> {
                                    Local(
                                        updatable = updateAvailable
                                    )
                                }
                            }
                        }
                        is Optional.None -> {
                            Remote
                        }
                    }
                }
            )
            return stateChanges.distinctUntilChanged()
        }
    }
}
