package com.booktrack.titleshare

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder

class ForegroundService : Service() {
    private val _binder = LocalBinder()
    private val foregroundServiceNotificationId = 1
    private val foregroundNotificationChannelId = "foreground_notification_channel"

    override fun onCreate() {
        startForeground(foregroundServiceNotificationId, buildNotification(audiobookTitle = null))
    }

    override fun onBind(intent: Intent?): IBinder? {
        return _binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        return false
    }

    fun updateNotification(audiobookTitle: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(foregroundServiceNotificationId, buildNotification(audiobookTitle = audiobookTitle))
    }

    private fun buildNotification(audiobookTitle: String?): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel = NotificationChannel(
                foregroundNotificationChannelId,
                getString(R.string.foreground_service_notification_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationChannel.description =
                getString(R.string.foreground_service_notification_channel_description)
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(notificationChannel)
            Notification.Builder(this, foregroundNotificationChannelId)
        } else {
            Notification.Builder(this)
        }
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentTitle(getText(R.string.foreground_service_notification_title))
            .let {
                if (audiobookTitle != null) {
                    it.setContentText(getString(R.string.foreground_service_notification_message, audiobookTitle))
                } else {
                    it
                }
            }
            .setSmallIcon(R.drawable.ic_notification_foreground)
            .setContentIntent(Intent(this, MainActivity::class.java).let { notificationIntent ->
                notificationIntent.action = Intent.ACTION_MAIN
                notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER)
                PendingIntent.getActivity(this, 0, notificationIntent, 0)
            })
            .build()
    }

    inner class LocalBinder : Binder() {
        fun getService(): ForegroundService = this@ForegroundService
    }
}
