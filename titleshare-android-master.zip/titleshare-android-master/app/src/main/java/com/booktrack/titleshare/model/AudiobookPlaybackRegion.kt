package com.booktrack.titleshare.model

import com.squareup.moshi.JsonClass
import java.util.*

@JsonClass(generateAdapter = true)
data class AudiobookPlaybackRegion(
    val audioSectionsHash: String,
    val audioSectionIndex: Int,
    val startTime: Double,
    val endTime: Double,
    val endTimestamp: Date
)
