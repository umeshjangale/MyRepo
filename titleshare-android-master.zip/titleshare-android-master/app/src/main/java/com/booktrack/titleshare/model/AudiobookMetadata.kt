package com.booktrack.titleshare.model

import android.net.Uri
import com.booktrack.titleshare.graphql.ContentItemsQuery
import com.squareup.moshi.JsonClass
import java.util.*

@JsonClass(generateAdapter = true)
data class AudiobookMetadata(
    val organisationName: String,
    val title: String,
    val subtitle: String,
    val desc: String,
    val author: String,
    val narrator: String,
    val publisher: String,
    val releaseDate: Date?,
    val totalDuration: Double,
    val hasSoundtrack: Boolean,
    val coverImageUrl256x256: Uri?,
    val coverImageUrl1024x1024: Uri?,
    val language: String,
    val genre: String,
    val secondGenre: String?,
    val audioSectionsHash: String
) {
    companion object {
        fun fromGraphql(graphql: ContentItemsQuery.Item): AudiobookMetadata {
            return AudiobookMetadata(
                organisationName = graphql.organisation().name(),
                title = graphql.title(),
                subtitle = graphql.subtitle(),
                desc = graphql.description(),
                author = graphql.author(),
                narrator = graphql.narrator(),
                publisher = graphql.publisher(),
                releaseDate = graphql.releaseDate(),
                totalDuration = graphql.totalDuration().toDouble(),
                hasSoundtrack = graphql.hasSoundtrack(),
                coverImageUrl256x256 = graphql.coverImageUris().firstOrNull()?.let { Uri.parse(it) },
                coverImageUrl1024x1024 = graphql.coverImageUris().lastOrNull()?.let { Uri.parse(it) },
                language = graphql.language().name(),
                genre = graphql.genre().name(),
                secondGenre = graphql.secondGenre()?.name(),
                audioSectionsHash = graphql.audioSectionsHash()
            )
        }
    }
}
