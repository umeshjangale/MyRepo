package com.booktrack.titleshare.server_api

import android.os.Handler
import android.os.Looper
import com.booktrack.titleshare.graphql.Result
import com.booktrack.titleshare.graphql.anyWithExtensionCode
import com.booktrack.titleshare.model.Authentication
import io.reactivex.functions.Consumer
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthenticationTokenFailureInterceptor @Inject constructor(
    private val _lazyAuthentication: dagger.Lazy<Authentication>
) : Consumer<Result<*>> {
    private val _handler = Handler(Looper.getMainLooper())

    override fun accept(result: Result<*>?) {
        when (result) {
            is Result.Success -> {
                if (result.errors.anyWithExtensionCode("UNAUTHENTICATED")) {
                    _handler.post {
                        _lazyAuthentication.get().tokenDidFail()
                    }
                }
            }
            is Result.Failure.HttpStatusError -> {
                if (result.status == 401) {
                    _handler.post {
                        _lazyAuthentication.get().tokenDidFail()
                    }
                }
            }
        }
    }
}
