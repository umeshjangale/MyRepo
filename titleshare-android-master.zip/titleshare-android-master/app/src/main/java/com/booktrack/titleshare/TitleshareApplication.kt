package com.booktrack.titleshare

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.multidex.MultiDexApplication
import com.booktrack.titleshare.di.AppGlideModuleComponent
import com.booktrack.titleshare.di.DaggerApplicationComponent
import com.booktrack.titleshare.model.Connectivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import javax.inject.Inject

class TitleshareApplication : MultiDexApplication(), HasActivityInjector {
    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Activity>
    @Inject
    lateinit var appGlideModuleComponentBuilder: AppGlideModuleComponent.Builder
    @Inject
    lateinit var connectivity: Connectivity
    private var _aliveActivityCount = 0

    override fun onCreate() {
        super.onCreate()

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityPaused(activity: Activity?) {
            }

            override fun onActivityResumed(activity: Activity?) {
            }

            override fun onActivityStarted(activity: Activity?) {
            }

            override fun onActivityDestroyed(activity: Activity?) {
                _aliveActivityCount--
                if (_aliveActivityCount == 0) {
                    connectivity.allActivitiesDestroyed()
                }
            }

            override fun onActivitySaveInstanceState(activity: Activity?, outState: Bundle?) {
            }

            override fun onActivityStopped(activity: Activity?) {
            }

            override fun onActivityCreated(activity: Activity?, savedInstanceState: Bundle?) {
                _aliveActivityCount++
                if (_aliveActivityCount == 1) {
                    connectivity.atLeastOneActivityCreated()
                }
            }
        })

        DaggerApplicationComponent.builder().application(this).build().inject(this)
    }


    override fun activityInjector() = dispatchingAndroidInjector
}
