package com.booktrack.titleshare.widget

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.booktrack.titleshare.R

class CircularProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    init {
        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.CircularProgressView,
            0, 0
        ).apply {
            try {
                val trackBlurRadius = getFloat(R.styleable.CircularProgressView_trackBlurRadius, 8f)
                val trackThicknessToRadiusPercent =
                    getFloat(R.styleable.CircularProgressView_trackThicknessToRadiusPercent, 10f)
                val indicatorToTrackThicknessPercent =
                    getFloat(R.styleable.CircularProgressView_indicatorToTrackThicknessPercent, 80f)
                val trackBlurColor = getColor(R.styleable.CircularProgressView_trackBlurColor, Color.DKGRAY)
                val trackColor = getColor(R.styleable.CircularProgressView_trackColor, Color.LTGRAY)
                val indicatorColor = getColor(R.styleable.CircularProgressView_indicatorColor, Color.BLUE)
                val textBlurRadius = getFloat(R.styleable.CircularProgressView_textBlurRadius, 8f)
                val textToTrackHeightPercent = getFloat(R.styleable.CircularProgressView_textToTrackHeightPercent, 10f)
                val textBlurColor = getColor(R.styleable.CircularProgressView_textBlurColor, Color.DKGRAY)
                val textColor = getColor(R.styleable.CircularProgressView_textColor, Color.LTGRAY)

                _userAttributes = UserAttributes(
                    trackBlurRadius = trackBlurRadius,
                    trackThicknessToRadiusPercent = trackThicknessToRadiusPercent,
                    indicatorToTrackThicknessPercent = indicatorToTrackThicknessPercent,
                    trackBlurColor = trackBlurColor,
                    trackColor = trackColor,
                    indicatorColor = indicatorColor,
                    textBlurRadius = textBlurRadius,
                    textToTrackHeightPercent = textToTrackHeightPercent,
                    textBlurColor = textBlurColor,
                    textColor = textColor
                )
            } finally {
                recycle()
            }
        }
    }

    private data class UserAttributes(
        val trackBlurRadius: Float,
        val trackThicknessToRadiusPercent: Float,
        val indicatorToTrackThicknessPercent: Float,
        val trackBlurColor: Int,
        val trackColor: Int,
        val indicatorColor: Int,
        val textBlurRadius: Float,
        val textToTrackHeightPercent: Float,
        val textBlurColor: Int,
        val textColor: Int
    )

    private data class MeasuredDimensions(
        val diameter: Float,
        val centreX: Float,
        val centreY: Float
    )

    private data class PaintableState(
        val userAttributes: UserAttributes,
        val measuredDimensions: MeasuredDimensions
    ) {
        private val _sansBlurDiameter = measuredDimensions.diameter - 2f * userAttributes.trackBlurRadius
        private val _sansBlurMaxRadius = _sansBlurDiameter / 2f
        private val _trackStrokeWidth = _sansBlurMaxRadius * userAttributes.trackThicknessToRadiusPercent / 100f
        private val _indicatorStrokeWidth = _trackStrokeWidth * userAttributes.indicatorToTrackThicknessPercent / 100f
        val radius = _sansBlurMaxRadius - (_trackStrokeWidth / 2f)
        val indicatorRect = RectF(
            measuredDimensions.centreX - radius,
            measuredDimensions.centreY - radius,
            measuredDimensions.centreX + radius,
            measuredDimensions.centreY + radius
        )

        val trackPaintBlur = Paint(0).apply {
            color = userAttributes.trackBlurColor
            maskFilter = BlurMaskFilter(userAttributes.trackBlurRadius, BlurMaskFilter.Blur.OUTER)
            strokeWidth = _trackStrokeWidth
            style = Paint.Style.STROKE
        }

        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = userAttributes.trackColor
            strokeWidth = _trackStrokeWidth
            style = Paint.Style.STROKE
        }

        val indicatorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = userAttributes.indicatorColor
            strokeWidth = _indicatorStrokeWidth
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val _textSize = measuredDimensions.diameter * userAttributes.textToTrackHeightPercent / 100f

        val textPaintBlur = Paint(0).apply {
            color = userAttributes.textBlurColor
            maskFilter = BlurMaskFilter(userAttributes.textBlurRadius, BlurMaskFilter.Blur.NORMAL)
            textAlign = Paint.Align.CENTER
            textSize = _textSize
        }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = userAttributes.textColor
            textAlign = Paint.Align.CENTER
            textSize = _textSize
        }

        val textY = {
            val rect = Rect()
            val text = "100%"
            textPaint.getTextBounds(text, 0, text.length, rect)
            measuredDimensions.centreY + rect.height() / 2f
        }()
    }

    private var _userAttributes: UserAttributes?
        set(value) {
            field = value
            _paintableState = null
        }
    private var _measuredDimensions: MeasuredDimensions? = null
        set(value) {
            field = value
            _paintableState = null
        }
    private var _paintableState: PaintableState? = null
        get() {
            if (field == null) {
                val userAttributes = _userAttributes
                val measuredDimensions = _measuredDimensions
                if (userAttributes != null && measuredDimensions != null) {
                    field = PaintableState(userAttributes = userAttributes, measuredDimensions = measuredDimensions)
                }
            }
            return field
        }

    var progress: Float = 0f
        set(value) {
            field = Math.min(1f, Math.max(0f, value))
            invalidate()
        }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        val paddedW = (w - (paddingLeft + paddingRight)).toFloat()
        val paddedH = (h - (paddingTop + paddingBottom)).toFloat()

        // Maintain 1:1 aspect ratio, centered
        val diameter = Math.min(paddedW, paddedH)
        if (diameter <= 0) {
            // Disable drawing
            _measuredDimensions = null
            return
        }
        val centreX = paddingLeft + paddedW / 2.0f
        val centreY = paddingTop + paddedH / 2.0f
        _measuredDimensions = MeasuredDimensions(diameter = diameter, centreX = centreX, centreY = centreY)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val p = _paintableState ?: return
        val d = p.measuredDimensions
        canvas.apply {
            canvas.drawCircle(d.centreX, d.centreY, p.radius, p.trackPaintBlur)
            canvas.drawCircle(d.centreX, d.centreY, p.radius, p.trackPaint)
            canvas.drawArc(p.indicatorRect, -90.0f, progress * 360f, false, p.indicatorPaint)
            val text = "${Math.round(progress * 100f)}%"
            canvas.drawText(text, d.centreX, p.textY, p.textPaintBlur)
            canvas.drawText(text, d.centreX, p.textY, p.textPaint)
        }
    }
}
