package com.booktrack.titleshare.ui.login

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.LoginFragmentBinding
import com.booktrack.titleshare.view_model.LoginViewModel
import com.booktrack.titleshare.view_model.LoginViewModelFactoryProvider
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.login_fragment.view.*
import javax.inject.Inject

@SuppressLint("ValidFragment")
class LoginFragment @Inject constructor(
    private val _loginViewModelFactoryProvider: LoginViewModelFactoryProvider
) : Fragment(), CustomChrome {
    private lateinit var viewModel: LoginViewModel
    private val args: LoginFragmentArgs by navArgs()

    override fun onAttach(context: Context) {
        viewModel =
            ViewModelProviders.of(this, _loginViewModelFactoryProvider.Factory(args.initialEmailAddress))
                .get(LoginViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: LoginFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.login_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.navigate.observe(viewLifecycleOwner, Observer { consumableNavigationAction ->
            consumableNavigationAction.consume()?.also { navigationAction ->
                when (navigationAction) {
                    is LoginViewModel.NavigationAction.Audiobooks -> Navigation.findNavController(view).navigate(
                        LoginFragmentDirections.actionLoginPopToMainNavigation()
                    )
                    is LoginViewModel.NavigationAction.ResetPassword -> Navigation.findNavController(view).navigate(
                        LoginFragmentDirections.actionLoginToResetPassword(initialEmailAddress = navigationAction.initialEmailAddress)
                    )
                }
            }
        })

        viewModel.presentLoginFailure.observe(viewLifecycleOwner, Observer { consumableLoginFailureReason ->
            consumableLoginFailureReason.consume()?.also { loginFailureReason ->
                val message = when (loginFailureReason) {
                    is LoginViewModel.LoginFailureReason.InvalidCredentials -> R.string.login_fragment_login_failed_with_invalid_credentials
                    is LoginViewModel.LoginFailureReason.NetworkError -> R.string.login_fragment_login_failed_with_network_error
                    is LoginViewModel.LoginFailureReason.ServerError -> R.string.login_fragment_login_failed_with_server_error
                }
                Snackbar.make(view, message, Snackbar.LENGTH_LONG).show()
            }
        })

        view.progress_bar.indeterminateDrawable.setColorFilter(
            ContextCompat.getColor(context!!, R.color.colorPrimary),
            PorterDuff.Mode.SRC_IN
        )

        view.terms_of_service_button.setOnClickListener {
            context?.also { c ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.getString(R.string.terms_and_conditions_url))))
            }
        }

        view.privacy_policy_button.setOnClickListener {
            context?.also { c ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.getString(R.string.privacy_policy_url))))
            }
        }

        view.help_button.setOnClickListener {
            context?.also { c ->
                c.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse(c.getString(R.string.support_url))
                })
            }
        }

        return view
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
