package com.booktrack.titleshare.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.model.Authentication
import com.booktrack.titleshare.model.Connectivity
import com.booktrack.titleshare.model.DownloadFeedbackTrigger
import com.booktrack.titleshare.server_api.UnsupportedAppVersionInterceptor
import com.booktrack.titleshare.util.Consumable
import io.reactivex.disposables.CompositeDisposable

class CrossCuttingViewModel(
    authentication: Authentication,
    private val _connectivity: Connectivity,
    downloadFeedbackTrigger: DownloadFeedbackTrigger,
    unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor
) : ViewModel() {

    private val _disposables = CompositeDisposable()
    private val _reauthenticationRequired = MutableLiveData<Boolean>(false)
    private val _unsupportedAppVersion = MutableLiveData<Boolean>()
    private val _downloadFeedback = MutableLiveData<Consumable<DownloadFeedback>>()

    init {
        val loggedInOrNot = authentication.state
            .map { state -> state is Authentication.State.LoggedIn }
        val wasLoggedInOnce = loggedInOrNot
            .skipWhile { loggedIn -> !loggedIn }
            .skipWhile { loggedIn -> loggedIn }
        val loggedOut = wasLoggedInOnce
            .map { loggedIn -> !loggedIn }
            .distinctUntilChanged()
        loggedOut.subscribe { reauthenticate ->
            _reauthenticationRequired.value = reauthenticate
        }
            .also { _disposables.add(it) }

        unsupportedAppVersionInterceptor.unsupported.subscribe {
            _unsupportedAppVersion.value = true
        }
            .also { _disposables.add(it) }

        downloadFeedbackTrigger.userInitiatedDownload.subscribe { consumable ->
            consumable.consume()?.also { fireDownloadFeedbackForUserInitiatedDownload() }
        }
            .also { _disposables.add(it) }
    }

    override fun onCleared() {
        _disposables.dispose()
        super.onCleared()
    }

    val reauthenticationRequired: LiveData<Boolean>
        get() = _reauthenticationRequired

    val unsupportedAppVersion: LiveData<Boolean>
        get() = _unsupportedAppVersion

    sealed class DownloadFeedback {
        data class DownloadQueued(val connected: Boolean) : DownloadFeedback()
        data class DownloadStarted(val meteredNetwork: Boolean) : DownloadFeedback()
    }

    val downloadFeedback: LiveData<Consumable<DownloadFeedback>>
        get() = _downloadFeedback

    private fun fireDownloadFeedbackForUserInitiatedDownload() {
        _downloadFeedback.value?.consume()
        _downloadFeedback.value = Consumable(
            when (val state = _connectivity.state.value) {
                is Connectivity.State.NoConnectivity -> {
                    DownloadFeedback.DownloadQueued(connected = false)
                }
                is Connectivity.State.Connectivity -> {
                    if (!state.canDownload) {
                        DownloadFeedback.DownloadQueued(connected = true)
                    } else {
                        DownloadFeedback.DownloadStarted(meteredNetwork = state.metered)
                    }
                }
            }
        )
    }
}
