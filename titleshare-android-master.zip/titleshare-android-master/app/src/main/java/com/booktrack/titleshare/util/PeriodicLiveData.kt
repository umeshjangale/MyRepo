package com.booktrack.titleshare.util

import android.os.Handler
import androidx.lifecycle.LiveData
import java.util.*

class PeriodicLiveData(private val _periodInMilliseconds: Long, private val _delayFirst: Boolean = false) :
    LiveData<Long>() {
    private var _handler = Handler()
    private var _startTimeInMillis: Long? = null
    private var _periodicUpdate: Runnable = object : Runnable {
        override fun run() {
            _startTimeInMillis?.also { startTimeInMillis ->
                value = Date().time - startTimeInMillis
                _handler.postDelayed(this, _periodInMilliseconds)
            }
        }
    }

    override fun onActive() {
        _startTimeInMillis = Date().time
        if (_delayFirst) {
            _handler.postDelayed(_periodicUpdate, _periodInMilliseconds)
        } else {
            _handler.post(_periodicUpdate)
        }
    }

    override fun onInactive() {
        _handler.removeCallbacks(_periodicUpdate)
        _startTimeInMillis = null
    }
}
