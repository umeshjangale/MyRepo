package com.booktrack.titleshare.server_api

import com.apollographql.apollo.ApolloClient
import com.booktrack.titleshare.graphql.RecordTechnicalIssuesMutation
import com.booktrack.titleshare.graphql.Result
import com.booktrack.titleshare.graphql.mutateAsRxSingle
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TechnicalIssuesApi @Inject constructor(
    private val _apolloClient: ApolloClient,
    private val _unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor
) {
    fun recordTechnicalIssues(technicalIssues: List<String>): Single<Boolean> {
        return _apolloClient.mutateAsRxSingle(RecordTechnicalIssuesMutation(technicalIssues))
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .map { result ->
                (result as? Result.Success)?.let { result.data != null } ?: false
            }
    }
}
