package com.booktrack.titleshare.util

import androidx.fragment.app.Fragment
import androidx.navigation.NavGraph
import androidx.navigation.fragment.FragmentNavigator

fun NavGraph.hasDestination(fragment: Fragment): Boolean {
    for (destination in this) {
        when (destination) {
            is FragmentNavigator.Destination -> {
                if (destination.className == fragment.javaClass.canonicalName) {
                    return true
                }
            }
            is NavGraph -> {
                if (destination.hasDestination(fragment)) {
                    return true
                }
            }
        }
    }
    return false
}
