package com.booktrack.titleshare.server_api

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import okio.Buffer
import okio.ByteString
import java.util.*

class RequestSigningInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val operation = originalRequest.header("X-APOLLO-OPERATION-NAME")
        return chain.proceed(
            if (operation == "signUpWithCode" || operation == "joinCode") {
                signRequest(originalRequest)
            } else {
                originalRequest
            }
        )
    }

    private fun signRequest(request: Request): Request {
        val timestamp = Date().time
        val envelope = Buffer()
        envelope.writeUtf8(timestamp.toString())
        envelope.writeUtf8(request.method())
        envelope.writeUtf8(request.url().encodedPath()) // TODO: should this be encoded path? or decoded path? check what nodejs does, check what ios does.
        request.header("User-Agent")?.also { envelope.writeUtf8(it) }
        request.header("Authorization")?.also { envelope.writeUtf8(it) }
        request.body()?.writeTo(envelope)

        val signature = envelope.hmacSha256(key)
        return request
            .newBuilder()
            .header("X-Signature", "v1 $timestamp ${signature.base64()}")
            .build()
    }

}

private val key = byteStringOfInts(
    0xB0,
    0xFB,
    0x1D,
    0x3A,
    0x3E,
    0x87,
    0xD6,
    0xCB,
    0x12,
    0x26,
    0x11,
    0xC2,
    0x29,
    0x75,
    0x72,
    0xC6,
    0x06,
    0xAC,
    0x0E,
    0x9A,
    0x3A,
    0xB2,
    0x3D,
    0x89,
    0x3F,
    0x65,
    0x09,
    0xC1,
    0xA7,
    0xFA,
    0x43,
    0xC9,
    0x59,
    0x3B,
    0xFE,
    0xD1,
    0xB2,
    0x1E,
    0x22,
    0xAF,
    0xB3,
    0x0B
)

fun byteStringOfInts(vararg ints: Int): ByteString {
    val bytes = ByteArray(ints.size) { pos -> ints[pos].toByte() }
    return ByteString.of(bytes, 0, bytes.size)
}
