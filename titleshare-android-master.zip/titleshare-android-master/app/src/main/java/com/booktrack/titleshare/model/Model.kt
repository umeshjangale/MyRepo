package com.booktrack.titleshare.model

import android.app.Application
import android.net.Uri
import android.system.Os
import android.util.Log
import androidx.annotation.MainThread
import com.booktrack.titleshare.server_api.AudiobookApi
import com.booktrack.titleshare.server_api.AudiobooksApi
import com.booktrack.titleshare.util.TechnicalIssues
import com.squareup.moshi.*
import com.squareup.moshi.adapters.Rfc3339DateJsonAdapter
import okhttp3.OkHttpClient
import okio.Buffer
import okio.Okio
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Model @Inject constructor(
    private val _context: Application,
    private val _audiobooksApi: AudiobooksApi,
    private val _audiobookApi: AudiobookApi,
    private val _connectivity: Connectivity,
    private val _crypto: Crypto,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private val _fileSystem: FileSystem,
    private val _okHttpClient: OkHttpClient,
    private val _technicalIssues: TechnicalIssues
) {
    private val _fileResourceController: FileResourceController
    val audiobookRegistry: AudiobookRegistry

    val userAudiobooks: UserAudiobooks

    init {
        // TODO: loading the model should probably be as error tolerant as possible
        val memento: Memento? = load(_fileSystem.modelFile)
        _fileResourceController =
            FileResourceController(
                memento?.fileResources,
                _crypto,
                _downloadRetryTriggers,
                _fileSystem,
                _technicalIssues,
                _okHttpClient
            )
        audiobookRegistry =
            AudiobookRegistry(memento?.audiobooks, _audiobookApi, _downloadRetryTriggers, _fileResourceController)
        userAudiobooks = UserAudiobooks(
            memento?.userAudiobooks,
            _audiobooksApi,
            audiobookRegistry,
            _audiobookApi,
            _downloadRetryTriggers,
            _fileResourceController
        )
        _fileResourceController.cleanupOrphanedFileResources()
        _fileSystem.cleanFileResourceDirectory(_fileResourceController.fileResources)
        _fileSystem.cleanSupersededCaches()

        @Suppress("UNUSED_VARIABLE") val infinite = _downloadRetryTriggers.retryDownloads
            .throttleLatest(5, TimeUnit.SECONDS)
            .subscribe {
                enqueueDownloadsIfPossible()
            }
    }

    @MainThread
    private fun enqueueDownloadsIfPossible() {
        val state = _connectivity.state.value
        if (state is Connectivity.State.NoConnectivity) {
            return
        }
        fetchUnresolvedAudiobookSections()

        if (state.canDownload) {
            enqueueDownloads()
        } else {
            dequeueDownloads()
        }
    }

    private fun fetchUnresolvedAudiobookSections() {
        audiobookRegistry.audiobooks.forEach { audiobook ->
            audiobook.audiobookSections.value.someOrNull?.fetchMetadata()
        }
    }

    @MainThread
    private fun enqueueDownloads() {
        audiobookRegistry.audiobooksAddedToDevice.forEach { audiobook ->
            audiobook.audiobookSections.value.someOrNull?.items?.value?.someOrNull?.forEach { audiobookSection ->
                audiobookSection.narrationFileResource.enqueueDownload()
                audiobookSection.soundtrackFileResource?.enqueueDownload()
            }
        }
    }

    @MainThread
    private fun dequeueDownloads() {
        audiobookRegistry.audiobooks.forEach { audiobook ->
            audiobook.audiobookSections.value.someOrNull?.items?.value?.someOrNull?.forEach { audiobookSection ->
                audiobookSection.narrationFileResource.dequeueDownload()
                audiobookSection.soundtrackFileResource?.dequeueDownload()
            }
        }
    }

    @JsonClass(generateAdapter = true)
    data class Memento(
        val fileResources: FileResourceController.Memento,
        val audiobooks: AudiobookRegistry.Memento,
        val userAudiobooks: UserAudiobooks.Memento
    )

    private val memento: Memento
        get() = Memento(
            fileResources = _fileResourceController.memento,
            audiobooks = audiobookRegistry.memento,
            userAudiobooks = userAudiobooks.memento
        )

    companion object {
        // TODO: shift this into DI (maybe)
        private val _moshi = Moshi.Builder()
            .add(Date::class.java, Rfc3339DateJsonAdapter().nullSafe())
            .add(Uri::class.java, object : JsonAdapter<Uri>() {
                override fun fromJson(reader: JsonReader): Uri? {
                    return Uri.parse(reader.nextString())
                }

                override fun toJson(writer: JsonWriter, value: Uri?) {
                    writer.value(value!!.toString())
                }
            }.nullSafe())
            .add(AudiobookSections.Memento.moshiJsonAdapter())
            .add(FileResource.Memento.State.moshiJsonAdapter())
            .build()

        private fun load(modelFile: File): Memento? {
            val jsonAdapter = _moshi.adapter<Memento>(Memento::class.java)
            return try {
                Okio.buffer(Okio.source(modelFile)).use { source ->
                    jsonAdapter.fromJson(source)
                }
            } catch (e: IOException) {
                null
            }
        }
    }

    fun save() {
        // TODO: only indent on debug builds
        val jsonAdapter: JsonAdapter<Memento> = _moshi.adapter(Memento::class.java).indent("  ")
        val initialSpaceAvailable = _fileSystem.modelFileTemp.freeSpace
        var bytesExpected: Long? = null
        try {
            Buffer().use { buffer ->
                jsonAdapter.toJson(buffer, memento)
                val jsonLengthInBytes = buffer.size()
                bytesExpected = jsonLengthInBytes
                if (jsonLengthInBytes == 0L) {
                    throw Exception("Zero length json")
                }
                FileOutputStream(_fileSystem.modelFileTemp, false).use { outputStream ->
                    buffer.writeTo(outputStream)
                    outputStream.flush()
                }
            }
            if (_fileSystem.modelFileTemp.length() != bytesExpected) {
                throw Exception("Model round-trip failure")
            }
            // Atomically replace the model file with the new one
            Os.rename(_fileSystem.modelFileTemp.canonicalPath, _fileSystem.modelFile.canonicalPath)
        } catch (e: Throwable) {
            _technicalIssues.report(
                TechnicalIssues.ModelWriteFailure(
                    spaceRequired = bytesExpected,
                    spaceAvailable = initialSpaceAvailable,
                    message = e.message
                )
            )
            // TODO: sending might fail for any number of reasons, not authed, no connection, etc. Long term we should persist them to a pre-allocated (to avoid low storage issues, which might be what we are trying to diagnose!) circular file buffer.
        }
    }
}
