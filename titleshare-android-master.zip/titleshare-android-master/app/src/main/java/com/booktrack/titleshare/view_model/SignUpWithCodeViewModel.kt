package com.booktrack.titleshare.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.model.Authentication
import com.booktrack.titleshare.util.Consumable

class SignUpWithCodeViewModel(private val _authentication: Authentication) : ViewModel() {
    sealed class NavigationAction {
        object Audiobooks : NavigationAction()
        data class Login(val initialEmailAddress: String?) : NavigationAction()
    }

    sealed class SignedUpInformation {
        object LogIntoExistingAccount : SignedUpInformation()
        object SetPasswordForExistingAccount : SignedUpInformation()
        object SetPasswordForNewAccount : SignedUpInformation()
    }

    sealed class SignUpFailureReason {
        object Forbidden : SignUpFailureReason()
        object InvalidCode : SignUpFailureReason()
        object NetworkError : SignUpFailureReason()
        object ServerError : SignUpFailureReason()
    }

    private val _isEmailError = MutableLiveData<Boolean>()
    private val _isSignUpEnabled = MutableLiveData<Boolean>()
    private val _isBusy = MutableLiveData<Boolean>()
    private val _navigationAction = MutableLiveData<Consumable<NavigationAction>>()
    private val _presentSignedUpInformation = MutableLiveData<Consumable<SignedUpInformation>>()
    private val _presentSignUpFailure = MutableLiveData<Consumable<SignUpFailureReason>>()

    var email: String? = null
        set(value) {
            field = value
            _isEmailError.value = !value.isNullOrEmpty() && !emailValid(value)
            synchroniseIsSignUpEnabled()
        }

    var code: String? = null
        set(value) {
            field = value
            synchroniseIsSignUpEnabled()
        }

    init {
        _isEmailError.value = false
        _isBusy.value = false
        synchroniseIsSignUpEnabled()
        _presentSignedUpInformation.value = Consumable(null)
        _presentSignUpFailure.value = Consumable(null)
    }

    val isEmailError: LiveData<Boolean>
        get() = _isEmailError

    val isSignUpEnabled: LiveData<Boolean>
        get() = _isSignUpEnabled

    val isBusy: LiveData<Boolean>
        get() = _isBusy

    fun signUp() {
        if (!_isSignUpEnabled.value!!) {
            return
        }
        _isBusy.value = true
        _authentication.signUpWithCode(email!!, code!!) { result ->
            _isBusy.value = false
            if (result != null) {
                when (result) {
                    is Authentication.SignUpWithCodeResult.SignedUp.LoggedIn -> {
                        _presentSignedUpInformation.value = Consumable(SignedUpInformation.SetPasswordForNewAccount)
                        _navigationAction.value = Consumable(NavigationAction.Audiobooks)
                    }
                    is Authentication.SignUpWithCodeResult.SignedUp.MustLogin -> {
                        _presentSignedUpInformation.value = Consumable(SignedUpInformation.LogIntoExistingAccount)
                        _navigationAction.value = Consumable(NavigationAction.Login(initialEmailAddress = email))
                    }
                    is Authentication.SignUpWithCodeResult.SignedUp.MustSetPasswordThenLogin -> {
                        _presentSignedUpInformation.value =
                            Consumable(SignedUpInformation.SetPasswordForExistingAccount)
                        _navigationAction.value = Consumable(NavigationAction.Login(initialEmailAddress = email))
                    }
                    is Authentication.SignUpWithCodeResult.NotSignedUp -> {
                        _presentSignUpFailure.value!!.consume()
                        _presentSignUpFailure.value = Consumable(
                            when (result) {
                                is Authentication.SignUpWithCodeResult.NotSignedUp.ServerError -> SignUpFailureReason.ServerError
                                is Authentication.SignUpWithCodeResult.NotSignedUp.NetworkError -> SignUpFailureReason.NetworkError
                                is Authentication.SignUpWithCodeResult.NotSignedUp.InvalidCode -> SignUpFailureReason.InvalidCode
                                is Authentication.SignUpWithCodeResult.NotSignedUp.Forbidden -> SignUpFailureReason.Forbidden
                            }
                        )
                    }
                }
            }
        }
    }

    val navigate: LiveData<Consumable<NavigationAction>>
        get() = _navigationAction

    val presentSignedUpInformation: LiveData<Consumable<SignedUpInformation>>
        get() = _presentSignedUpInformation

    val presentSignUpFailure: LiveData<Consumable<SignUpFailureReason>>
        get() = _presentSignUpFailure

    private fun synchroniseIsSignUpEnabled() {
        _isSignUpEnabled.value = emailValid(email) && !code.isNullOrEmpty()
    }
}

private fun emailValid(value: String?): Boolean {
    return value?.contains('@') ?: false
}
