package com.booktrack.titleshare.view_model

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.booktrack.titleshare.model.Audiobook
import com.booktrack.titleshare.model.DownloadFeedbackTrigger
import com.booktrack.titleshare.util.BaseDisposable
import com.booktrack.titleshare.util.Optional
import com.booktrack.titleshare.util.SimpleDisposableObserver
import io.reactivex.disposables.CompositeDisposable

class AudiobooksItemViewModel(
    private val _audiobook: Audiobook,
    private val _downloadFeedbackTrigger: DownloadFeedbackTrigger,
    private val _eventDispatcher: (AudiobookEvent) -> Unit
) : BaseDisposable() {

    sealed class AudiobookEvent {
        data class PresentAudiobookDetails(val audiobook: Audiobook) : AudiobookEvent()
        data class PresentAudiobookPlayer(val audiobook: Audiobook) : AudiobookEvent()
        data class ConfirmAudiobookAction(
            val audiobook: Audiobook,
            val removeAction: RemoveAction,
            val updateAction: (() -> Unit)?
        ) : AudiobookEvent()

        sealed class RemoveAction {
            data class CancelDownloadAndRemoveFromDevice(val action: () -> Unit) : RemoveAction()
            data class RemoveFromDevice(val action: () -> Unit) : RemoveAction()
        }
    }

    data class State(
        val secondaryAction: SecondaryAction,
        val downloadingButPlayable: Boolean,
        val downloadedAndUpdatable: Boolean,
        val progress: Double?,
        val _downloadable: Boolean,
        val _removable: Boolean,
        val _playable: Boolean
    ) {

        sealed class SecondaryAction {
            object Download : SecondaryAction()
            object Remove : SecondaryAction()
            object More : SecondaryAction()
        }
    }

    companion object {
        private var nextId: Long = 0
    }

    private val _title = MutableLiveData<String>()
    private val _state = MutableLiveData<State>()
    private var _perAudioSectionsDisposables = CompositeDisposable()
    val stableId: Long = nextId++

    init {
        _disposables.add(_perAudioSectionsDisposables)
        _audiobook.metadata.subscribeWith(SimpleDisposableObserver {
            _title.value = it.title
        }).also { _disposables.add(it) }
        AudiobookState.forAudiobook(_audiobook).subscribeWith(SimpleDisposableObserver { audiobookState ->
            _state.value = when (audiobookState) {
                is AudiobookState.Remote -> State(
                    secondaryAction = State.SecondaryAction.Download,
                    downloadingButPlayable = false,
                    downloadedAndUpdatable = false,
                    progress = null,
                    _downloadable = true,
                    _removable = false,
                    _playable = false
                )
                is AudiobookState.Downloading -> State(
                    secondaryAction = State.SecondaryAction.Remove,
                    downloadingButPlayable = audiobookState.playable,
                    downloadedAndUpdatable = false,
                    progress = audiobookState.progress,
                    _downloadable = false,
                    _removable = true,
                    _playable = audiobookState.playable
                )
                is AudiobookState.Local -> State(
                    secondaryAction = if (audiobookState.updatable) State.SecondaryAction.More else State.SecondaryAction.Remove,
                    downloadingButPlayable = false,
                    // legacy app only allowed updating when fully downloaded,
                    // we mimic that behaviour (model does allow updating whilst downloading)
                    downloadedAndUpdatable = audiobookState.updatable,
                    progress = null,
                    _downloadable = false,
                    _removable = true,
                    _playable = true
                )
            }
        }).also { _disposables.add(it) }
    }

    val markedForOnDevice: Boolean
        get() = _audiobook.audiobookSections.value is Optional.Some

    val title: LiveData<String>
        get() = _title

    val coverImageUri: Uri?
        get() = _audiobook.metadata.value.coverImageUrl256x256

    val state: LiveData<State>
        get() = _state

    fun performPrimaryAction() {
        val state = _state.value!!
        when {
            state._downloadable -> {
                _audiobook.fetchAudiobookSections()
                _downloadFeedbackTrigger.userDidInitiateDownload()
            }
            state._playable -> {
                _eventDispatcher(
                    AudiobookEvent.PresentAudiobookPlayer(
                        audiobook = _audiobook
                    )
                )
            }
            else -> // should be unreachable, but might as well have a sensible default
                presentAudiobookDetails()
        }
    }

    fun performSecondaryAction() {
        when (_state.value!!.secondaryAction) {
            is State.SecondaryAction.Download -> {
                _audiobook.fetchAudiobookSections()
                _downloadFeedbackTrigger.userDidInitiateDownload()
            }
            is State.SecondaryAction.Remove -> {
                _eventDispatcher(
                    AudiobookEvent.ConfirmAudiobookAction(
                        audiobook = _audiobook,
                        removeAction = if (_state.value!!.progress != null) {
                            AudiobookEvent.RemoveAction.CancelDownloadAndRemoveFromDevice(
                                action = _audiobook::removeAudiobookSections
                            )
                        } else {
                            AudiobookEvent.RemoveAction.RemoveFromDevice(
                                action = _audiobook::removeAudiobookSections
                            )
                        },
                        updateAction = null
                    )
                )
            }
            is State.SecondaryAction.More ->
                _eventDispatcher(
                    AudiobookEvent.ConfirmAudiobookAction(
                        audiobook = _audiobook,
                        removeAction = AudiobookEvent.RemoveAction.RemoveFromDevice(
                            action = _audiobook::removeAudiobookSections
                        ),
                        updateAction = _audiobook::updateAudiobookSections
                    )
                )
        }
    }

    fun presentAudiobookDetails() {
        _eventDispatcher(
            AudiobookEvent.PresentAudiobookDetails(
                audiobook = _audiobook
            )
        )
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AudiobooksItemViewModel

        if (_audiobook != other._audiobook) return false

        return true
    }

    override fun hashCode(): Int {
        return _audiobook.hashCode()
    }
}
