package com.booktrack.titleshare.util

import android.media.MediaPlayer
import io.reactivex.disposables.Disposables

typealias Milliseconds = Int

/*
 can initialise (createController) anytime, takes immediate effect, invalidates all existing Controllers, initially paused, takes callbacks for observing completion and for observing the length (Controller is passed in to both callbacks)
  returns a ComboPlayer.Controller which allows seek/play/pause and offset retrieval
 can seek anytime, most recent seek wins and displaces any pending seek, seeking immediately affects the offset - can set seek to anything (no explicit clamping is applied, except via the underlying MediaPlayer),
  once ready the latest seek offset will be applied to the player
  internally, seek will pause both MediaPlayers, then seek to each, then await seek confirmation for both, then play both (depending on the state of play/pause)
 can play/pause anytime (has no effect if completed), most recent wins
 completion is signaled to the observer, and requires a within-bounds seek to reverse
  observer initialising, seeking or playing within the completion callback is okay
 SINGLE THREADED ONLY! ONLY INVOKE ON THE MAIN THREAD!
 */
class ComboPlayer : BaseDisposable() {

    interface Controller {
        val invalidated: Boolean
        var masterVolume: Double
        var slaveVolume: Double
        val offset: Milliseconds
        fun seek(offset: Milliseconds)
        fun play()
        fun pause()
    }

    private val _rootMutator = MediaPlayers.Mutator(null, null, MediaPlayers(MediaPlayer(), MediaPlayer()))
    private var _controller: ControllerImpl? = null

    init {
        _disposables.add(Disposables.fromAction {
            _controller?.willBeReplaced()
            _controller = null
            _rootMutator.mediaPlayers!!.apply {
                master.release()
                slave!!.release()
            }
            _rootMutator.invalidate()
        })
    }

    fun createController(
        masterFilePath: String,
        slaveFilePath: String?,
        ready: (Controller, offset: Milliseconds) -> Unit,
        playStateChanged: (Controller, offset: Milliseconds, playing: Boolean) -> Unit,
        didReachEnd: (Controller) -> Unit
    ): Controller {
        _controller?.willBeReplaced()
        _controller = null
        return _rootMutator.mediaPlayers!!.run {
            ControllerImpl(
                masterFilePath,
                slaveFilePath,
                ready,
                playStateChanged,
                didReachEnd,
                _rootMutator.spawnExclusiveChild(slaveFilePath == null)!!
            )
                .also {
                    _controller = it
                }
        }
    }
}

private data class MediaPlayers(
    val master: MediaPlayer,
    val slave: MediaPlayer?
) {
    val count = if (slave == null) 1 else 2

    class Mutator(
        var parent: Mutator?,
        var child: Mutator?,
        var mediaPlayers: MediaPlayers?
    ) {
        fun retireInto(): Mutator? {
            return parent?.let { parent ->
                parent.spawnExclusiveChild()
            }
        }

        fun spawnExclusiveChild(inhibitSlave: Boolean = false): Mutator? {
            return mediaPlayers?.let { mediaPlayers ->
                val childMediaPlayers = if (inhibitSlave) mediaPlayers.copy(slave = null) else mediaPlayers
                Mutator(this, null, childMediaPlayers).also { newChild ->
                    child?.invalidate()
                    child = newChild
                }
            }
        }

        fun invalidate() {
            mediaPlayers = null
            child?.invalidate()
            parent = null
            child = null
        }
    }
}

private class ControllerImpl(
    private val _masterFilePath: String,
    private val _slaveFilePath: String?,
    private val _ready: (ComboPlayer.Controller, Milliseconds) -> Unit,
    private val _playStateChanged: (ComboPlayer.Controller, offset: Milliseconds, playing: Boolean) -> Unit,
    private val _didReachEnd: (ComboPlayer.Controller) -> Unit,
    private val _controllerMutator: MediaPlayers.Mutator
) : ComboPlayer.Controller {

    private var _targetSeekOffset: Milliseconds? = null
    private var _targetIsPlaying: Boolean = false
    var mediaPlayerState: MediaPlayerState = Unprepared(_controllerMutator.spawnExclusiveChild()!!)
        set(newState) {
            val oldState = field
            field = newState
            if (oldState is Playing || newState is Playing) {
                _playStateChanged(
                    this,
                    _controllerMutator.mediaPlayers?.master?.currentPosition ?: 0,
                    newState is Playing
                )
            }
            if (newState is Completed) {
                _targetSeekOffset = null
                _targetIsPlaying = false
                _didReachEnd(this)
            } else {
                moveTowardsTarget(currentState = newState)
                if (oldState is Preparing) {
                    _controllerMutator.mediaPlayers?.master?.duration?.also { length -> _ready(this, length) }
                }
            }
        }

    init {
        (mediaPlayerState as Unprepared).prepare()
    }

    override val invalidated: Boolean
        get() = _controllerMutator.mediaPlayers == null

    override var masterVolume: Double = 1.0
        set(volume) {
            field = volume
            _controllerMutator.mediaPlayers?.master?.setVolume(volume.toFloat(), volume.toFloat())
        }

    override var slaveVolume: Double = 1.0
        set(volume) {
            field = volume
            _controllerMutator.mediaPlayers?.slave?.setVolume(volume.toFloat(), volume.toFloat())
        }

    override val offset: Milliseconds
        get() = _targetSeekOffset ?: _controllerMutator.mediaPlayers?.master?.currentPosition ?: 0

    override fun seek(offset: Milliseconds) {
        _targetSeekOffset = offset
        moveTowardsTarget(currentState = mediaPlayerState)
    }

    override fun play() {
        if (mediaPlayerState !is Completed) {
            _targetIsPlaying = true
            moveTowardsTarget(currentState = mediaPlayerState)
        }
    }

    override fun pause() {
        if (mediaPlayerState !is Completed) {
            _targetIsPlaying = false
            moveTowardsTarget(currentState = mediaPlayerState)
        }
    }

    private fun moveTowardsTarget(currentState: MediaPlayerState) {
        val targetSeekOffset = _targetSeekOffset
        val targetIsPlaying = _targetIsPlaying
        if (targetSeekOffset != null) {
            // We need to seek, lets move towards the paused state
            when (currentState) {
                is Unprepared -> currentState.prepare()
                is Completed -> currentState.prepare()
                is Preparing -> { /* do nothing but wait */
                }
                is Playing -> currentState.pause()
                is Paused -> {
                    _targetSeekOffset = null
                    currentState.seek(targetSeekOffset)
                }
                is Seeking -> { /* do nothing but wait */
                }
            }
        } else if (targetIsPlaying && currentState is Paused) {
            currentState.play()
        } else if (!targetIsPlaying && currentState is Playing) {
            currentState.pause()
        }
    }

    fun willBeReplaced() {
        if (mediaPlayerState is Playing) {
            _playStateChanged(
                this,
                _controllerMutator.mediaPlayers?.master?.currentPosition ?: 0,
                false
            )
        }
    }

    interface MediaPlayerState

    open inner class Unprepared(private var _mutator: MediaPlayers.Mutator) : MediaPlayerState {
        fun prepare() {
            _mutator.mediaPlayers?.apply {
                master.reset()
                slave?.reset()

                master.setDataSource(_masterFilePath)
                _slaveFilePath?.also { slave?.setDataSource(it) }

                var preparesPending = count
                fun didPrepare() {
                    preparesPending--
                    if (preparesPending == 0) {
                        // We spawn a sub-mutator which we can later invalidate (if the MediaPlayer completes)
                        _mutator.spawnExclusiveChild()?.also { subMutator ->
                            mediaPlayerState = Paused(subMutator)
                        }
                    }
                }
                master.setOnPreparedListener {
                    didPrepare()
                }
                slave?.setOnPreparedListener {
                    didPrepare()
                }

                var anyComplete = false
                fun didComplete() {
                    if (!anyComplete) {
                        anyComplete = true
                        // We spawn a sub-mutator which invalidates the Paused mutator above
                        _mutator.spawnExclusiveChild()?.also { subMutator ->
                            subMutator.mediaPlayers?.apply {
                                master.stop()
                                slave?.stop()
                            }
                            mediaPlayerState = Completed(subMutator)
                        }
                    }
                }
                master.setOnCompletionListener {
                    didComplete()
                }
                slave?.setOnCompletionListener {
                    didComplete()
                }

                master.prepareAsync()
                slave?.prepareAsync()

                mediaPlayerState = Preparing()
            }
        }
    }

    inner class Completed(mutator: MediaPlayers.Mutator) : Unprepared(mutator)

    class Preparing : MediaPlayerState

    inner class Playing(private var _mutator: MediaPlayers.Mutator) : MediaPlayerState {
        fun pause() {
            _mutator.mediaPlayers?.apply {
                master.pause()
                slave?.pause()
                _mutator.retireInto()?.also { replacementMutator ->
                    mediaPlayerState = Paused(replacementMutator)
                }
            }
        }
    }

    inner class Paused(private var _mutator: MediaPlayers.Mutator) : MediaPlayerState {
        fun play() {
            _mutator.mediaPlayers?.apply {
                master.start()
                slave?.start()
                _mutator.retireInto()?.also { replacementMutator ->
                    mediaPlayerState = Playing(replacementMutator)
                }
            }
        }

        fun seek(offset: Milliseconds) {
            _mutator.mediaPlayers?.apply {
                var seeksPending = count
                fun didSeek() {
                    seeksPending--
                    if (seeksPending == 0) {
                        _mutator.retireInto()?.also { replacementMutator ->
                            mediaPlayerState = Paused(replacementMutator)
                        }
                    }
                }
                master.setOnSeekCompleteListener {
                    didSeek()
                }
                slave?.setOnSeekCompleteListener {
                    didSeek()
                }
                master.seekTo(offset)
                slave?.seekTo(offset)
                mediaPlayerState = Seeking()
            }
        }
    }

    class Seeking : MediaPlayerState
}
