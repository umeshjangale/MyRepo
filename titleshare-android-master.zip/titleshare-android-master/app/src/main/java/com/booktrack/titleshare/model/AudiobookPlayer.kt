package com.booktrack.titleshare.model

import android.content.Context
import android.util.Log
import com.booktrack.titleshare.util.*
import com.booktrack.titleshare.util.Optional
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.SingleEmitter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.disposables.Disposables
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import java.io.*
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList
import kotlin.math.min

interface IAudiobookPlayer : Disposable {
    sealed class SectionReadiness {
        abstract val audiobookSection: AudiobookSection

        // One day... could switch `Loading` for these to give the user more specific messaging
        //        data class AwaitingAudioFileDownload(override val audiobookSection: AudiobookSection) : SectionReadiness()
        //        data class AwaitingAudioFileDecryption(override val audiobookSection: AudiobookSection) : SectionReadiness()
        //        data class AwaitingMediaPlayerInit(override val audiobookSection: AudiobookSection) : SectionReadiness()

        data class ErrorNotEnoughStorageSpace(override val audiobookSection: AudiobookSection) : SectionReadiness()
        data class ErrorFailedToDecrypt(override val audiobookSection: AudiobookSection) : SectionReadiness()
        data class Loading(override val audiobookSection: AudiobookSection) : SectionReadiness()
        data class Ready(override val audiobookSection: AudiobookSection, val length: Milliseconds) : SectionReadiness()
    }

    val cannotGainAudioFocus: Observable<Unit>
    val sectionReadiness: Observable<SectionReadiness>
    val hasSoundtrack: Watchable<Boolean>
    val soundtrackEnabled: Watchable<Boolean>
    fun setSoundtrackEnabled(enabled: Boolean)
    val soundtrackVolumeBalance: Watchable<Double>
    fun setSoundtrackVolumeBalance(balance: Double)
    fun offset(minimumUpdatePeriod: Milliseconds): Observable<Milliseconds>
    val playing: Watchable<Boolean>
    val atEnd: Watchable<Boolean>
    fun play()
    fun pause()
    fun seekToSection(sectionIndex: Int)
    fun relativeSeekInSection(relativeOffset: Milliseconds)
    fun seekInSection(offset: Milliseconds)
    fun interactiveSeekInSection(offsets: Observable<Milliseconds>)
    fun consumePlaybackRegions(): List<AudiobookPlaybackRegion>
}

class AudiobookPlayer(
    context: Context,
    private val _crypto: Crypto,
    private val _fileSystem: FileSystem,
    private val _technicalIssues: TechnicalIssues,
    private val _audiobook: Audiobook,
    private val _audioSectionsHash: String,
    private val _audiobookSectionItems: List<AudiobookSection>,
    bookmark: AudiobookBookmark?
) : BaseDisposable(), IAudiobookPlayer {

    private val _audioFocusShim = AudioFocusShim(context)
    private val _audioFocusDisposables = CompositeDisposable()
        .also { _disposables.add(it) }
    private var _hasAudioFocus: Boolean = false
    private var _isInteractiveSeeking: Boolean = false
    private val _interactiveSeekingDisposables = CompositeDisposable()
        .also { _disposables.add(it) }
    private val _alive: Observable<Unit> = BehaviorSubject.createDefault(Unit)
        .also { alive -> _disposables.add(Disposables.fromAction { alive.onComplete() }) }
    private val _comboPlayer: ComboPlayer = ComboPlayer()
        .also { _disposables.add(it) }
    private var _comboPlayerController: ComboPlayer.Controller? = null
    private var _sectionIndex: Watchable.Source<Optional<Int>> = Watchable.Source(Optional.None)
    private val _currentSectionDisposables = CompositeDisposable()
        .also { _disposables.add(it) }
    private val _playing = Watchable.Source(false)
    private val _atEnd = Watchable.Source(false)
    private val _sectionReadiness: Subject<IAudiobookPlayer.SectionReadiness> = BehaviorSubject.create()
    private val _cannotGainAudioFocus: Subject<Unit> = PublishSubject.create()
    private val _hasSoundtrack: Watchable.Source<Boolean> = Watchable.Source(_audiobook.metadata.value.hasSoundtrack)
    private val _soundtrackEnabled: Watchable.Source<Boolean> = Watchable.Source(true)
    private val _soundtrackVolumeBalance: Watchable.Source<Double> = Watchable.Source(0.5)
    private var _playbackStart: AudiobookPosition? = null
    private var _playbackRegions: MutableList<AudiobookPlaybackRegion> = ArrayList()

    private data class AudiobookPosition(
        val audiobookSection: AudiobookSection,
        val offset: Milliseconds
    )

    init {
        if (_audiobookSectionItems.isEmpty()) throw Exception("Must be at least one section")
        if (bookmark != null) {
            seekToSectionAndOffset(bookmark.audioSectionIndex, (bookmark.offsetInSeconds * 1000.0).toInt())
        } else {
            seekToSectionAndOffset(0, 0)
        }
    }

    override val playing: Watchable<Boolean>
        get() = _playing.watchable

    override val atEnd: Watchable<Boolean>
        get() = _atEnd.watchable

    override val sectionReadiness: Observable<IAudiobookPlayer.SectionReadiness>
        get() = _sectionReadiness

    override val cannotGainAudioFocus: Observable<Unit>
        get() = _cannotGainAudioFocus

    override val hasSoundtrack: Watchable<Boolean>
        get() = _hasSoundtrack.watchable

    override val soundtrackEnabled: Watchable<Boolean>
        get() = _soundtrackEnabled.watchable

    override fun setSoundtrackEnabled(enabled: Boolean) {
        _soundtrackEnabled.value = enabled
        this._comboPlayerController?.also {
            synchroniseComboPlayerControllerVolume(it)
        }
    }

    override val soundtrackVolumeBalance: Watchable<Double>
        get() = _soundtrackVolumeBalance.watchable

    override fun setSoundtrackVolumeBalance(balance: Double) {
        _soundtrackVolumeBalance.value = balance
        this._comboPlayerController?.also {
            synchroniseComboPlayerControllerVolume(it)
        }
    }

    override fun offset(minimumUpdatePeriod: Milliseconds): Observable<Milliseconds> {
        return Observable.combineLatest<Unit, Long, Unit>(
            _alive,
            Observable.interval(minimumUpdatePeriod.toLong(), TimeUnit.MILLISECONDS)
                .observeOn(AndroidSchedulers.mainThread()),
            BiFunction { _, _ -> })
            .filterMap {
                _comboPlayerController?.offset
            }
    }

    override fun play() {
        if (_playing.value) return
        if (_atEnd.value) return
        val audioFocusResult = _audioFocusShim.requestAudioFocus { audioFocusChange ->
            when (audioFocusChange) {
                is AudioFocusShim.AudioFocusChange.Gain -> {
                    _hasAudioFocus = true
                    if (_playing.value && !_atEnd.value && !_isInteractiveSeeking) {
                        relativeSeekInSection(-5000)
                        _comboPlayerController?.play()
                    }
                }
                is AudioFocusShim.AudioFocusChange.Loss -> {
                    _hasAudioFocus = false
                    pause()
                }
                is AudioFocusShim.AudioFocusChange.LossTransient -> {
                    _hasAudioFocus = false
                    if (_playing.value && !_isInteractiveSeeking) {
                        _comboPlayerController?.pause()
                    }
                }
                is AudioFocusShim.AudioFocusChange.LossTransientCanDuck -> {
                    _hasAudioFocus = false
                    if (_playing.value && !_isInteractiveSeeking) {
                        _comboPlayerController?.pause()
                    }
                }
            }
        }
        when (audioFocusResult) {
            is AudioFocusShim.AudioFocusRequestResponse.Failed -> {
                _audioFocusDisposables.clear()
                _hasAudioFocus = false
                _cannotGainAudioFocus.onNext(Unit)
            }
            is AudioFocusShim.AudioFocusRequestResponse.Granted -> {
                _audioFocusDisposables.clear()
                _audioFocusDisposables.add(audioFocusResult.disposable)
                _hasAudioFocus = true
                _playing.value = true
                _comboPlayerController?.apply {
                    play()
                }
            }
        }
    }

    override fun pause() {
        if (!_playing.value) return
        _audioFocusDisposables.clear()
        _playing.value = false
        _comboPlayerController?.apply {
            pause()
        }
    }

    override fun relativeSeekInSection(relativeOffset: Milliseconds) {
        _atEnd.value = false
        _comboPlayerController?.apply {
            seek(offset + relativeOffset)
        }
    }

    override fun seekInSection(offset: Milliseconds) {
        _atEnd.value = false
        _comboPlayerController?.seek(offset)
    }

    override fun seekToSection(sectionIndex: Int) {
        if (sectionIndex == _sectionIndex.value.someOrNull) return
        _atEnd.value = false
        seekToSectionAndOffset(sectionIndex, 0)
    }

    override fun interactiveSeekInSection(offsets: Observable<Milliseconds>) {
        // TODO: what happens if this is invoked twice within the same run loop iteration? Is the ordering of destruction of the prior disposable as intended?
        _interactiveSeekingDisposables.clear()
        val comboPlayerController = _comboPlayerController ?: return
        _isInteractiveSeeking = true
        val playing = _playing.value
        comboPlayerController.pause()
        offsets
            .doOnTerminate {
                _isInteractiveSeeking = false
                if (playing && _hasAudioFocus) {
                    comboPlayerController.play()
                }
            }
            .subscribe { offset ->
                comboPlayerController.seek(offset)
                _atEnd.value = false
            }
            .also { _interactiveSeekingDisposables.add(it) }
    }

    override fun consumePlaybackRegions(): List<AudiobookPlaybackRegion> {
        val playbackRegions = _playbackRegions
        if (playbackRegions.isEmpty()) {
            return Collections.emptyList()
        }
        _playbackRegions = ArrayList()
        return playbackRegions
    }

    private sealed class Files {
        object ErrorNotEnoughSpace : Files()
        object ErrorFailedToDecrypt : Files()
        data class Okay(
            val narrationFile: File,
            val soundtrackFile: File?
        ) : Files()
    }

    private fun seekToSectionAndOffset(sectionIndex: Int, offset: Milliseconds) {
        _comboPlayerController?.pause()
        _comboPlayerController = null
        _currentSectionDisposables.clear()
        val decryptedFileLifetime = CompositeDisposable()
        _currentSectionDisposables.add(decryptedFileLifetime)

        val clampedAudiobookPosition = when {
            sectionIndex >= 0 && sectionIndex < _audiobookSectionItems.size ->
                AudiobookPosition(
                    audiobookSection = _audiobookSectionItems[sectionIndex],
                    offset = offset
                )
            else ->
                AudiobookPosition(
                    audiobookSection = _audiobookSectionItems[0],
                    offset = 0
                )
        }
        _sectionIndex.value = Optional.Some(clampedAudiobookPosition.audiobookSection.index)
        _sectionReadiness.onNext(
            IAudiobookPlayer.SectionReadiness.Loading(
                audiobookSection = clampedAudiobookPosition.audiobookSection
            )
        )

        val narrationFile = clampedAudiobookPosition.audiobookSection.narrationFileResource.state
            .filterMap { state -> state.file }
            .firstOrError()

        val soundtrackFile =
            clampedAudiobookPosition.audiobookSection.soundtrackFileResource?.state?.run {
                filterMap { state -> state.file }
                    .map { file -> Optional.Some(file) }
                    .firstOrError()
            }
                ?: Single.just(Optional.None)

        Single.zip(
            narrationFile,
            soundtrackFile,
            BiFunction { narrationFile: File, optionalSoundtrackFile: Optional<File> ->
                Files.Okay(
                    narrationFile = narrationFile,
                    soundtrackFile = optionalSoundtrackFile.someOrNull
                )
            }
        )
            .flatMap { files ->
                Single.zip<DecryptedFile, Optional<DecryptedFile>, Files>(
                    decryptFile(
                        files.narrationFile,
                        _crypto,
                        _technicalIssues,
                        _fileSystem.fileResourceDirectory,
                        decryptedFileLifetime
                    ),
                    if (files.soundtrackFile != null) {
                        decryptFile(
                            files.soundtrackFile,
                            _crypto,
                            _technicalIssues,
                            _fileSystem.fileResourceDirectory,
                            decryptedFileLifetime
                        )
                            .map { decryptedFile -> Optional.Some(decryptedFile) }
                    } else {
                        Single.just(Optional.None)
                    },
                    BiFunction { decryptedNarrationFile, optionalDecryptedSoundtrackFile ->
                        when {
                            decryptedNarrationFile is DecryptedFile.ErrorNotEnoughSpace || optionalDecryptedSoundtrackFile.someOrNull is DecryptedFile.ErrorNotEnoughSpace -> Files.ErrorNotEnoughSpace
                            decryptedNarrationFile is DecryptedFile.ErrorFailedToDecrypt || optionalDecryptedSoundtrackFile.someOrNull is DecryptedFile.ErrorFailedToDecrypt -> Files.ErrorFailedToDecrypt
                            decryptedNarrationFile is DecryptedFile.Okay -> Files.Okay(
                                narrationFile = decryptedNarrationFile.file,
                                soundtrackFile = (optionalDecryptedSoundtrackFile.someOrNull as? DecryptedFile.Okay)?.file
                            )
                            else -> Files.ErrorFailedToDecrypt
                        }
                    }
                )
            }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { files ->
                when (files) {
                    is Files.ErrorNotEnoughSpace -> {
                        _sectionReadiness.onNext(
                            IAudiobookPlayer.SectionReadiness.ErrorNotEnoughStorageSpace(
                                audiobookSection = clampedAudiobookPosition.audiobookSection
                            )
                        )
                    }
                    is Files.ErrorFailedToDecrypt -> {
                        _sectionReadiness.onNext(
                            IAudiobookPlayer.SectionReadiness.ErrorFailedToDecrypt(
                                audiobookSection = clampedAudiobookPosition.audiobookSection
                            )
                        )
                    }
                    is Files.Okay -> {
                        _comboPlayerController = _comboPlayer.createController(
                            masterFilePath = files.narrationFile.path,
                            slaveFilePath = files.soundtrackFile?.run { path },
                            ready = { _, length ->
                                _sectionReadiness.onNext(
                                    IAudiobookPlayer.SectionReadiness.Ready(
                                        audiobookSection = clampedAudiobookPosition.audiobookSection,
                                        length = length
                                    )
                                )
                            },
                            playStateChanged = { _, offset, playing ->
                                if (playing) {
                                    playbackDidStart(clampedAudiobookPosition.audiobookSection, offset)
                                } else {
                                    playbackDidEnd(clampedAudiobookPosition.audiobookSection, offset)
                                }
                            },
                            didReachEnd = {
                                val nextSectionIndex = clampedAudiobookPosition.audiobookSection.index + 1
                                if (nextSectionIndex < _audiobookSectionItems.size) {
                                    seekToSectionAndOffset(nextSectionIndex, 0)
                                } else {
                                    // Reached end of book
                                    _atEnd.value = true
                                    pause()
                                }
                            }
                        )
                            .apply {
                                synchroniseComboPlayerControllerVolume(this)
                                seek(offset)
                                if (_playing.value && _hasAudioFocus && !_isInteractiveSeeking) {
                                    play()
                                }
                            }
                    }
                }
            }
            .also { _currentSectionDisposables.add(it) }
    }

    private fun playbackDidStart(section: AudiobookSection, offset: Int) {
        _playbackStart = AudiobookPosition(section, offset)
    }

    private fun playbackDidEnd(section: AudiobookSection, offset: Int) {
        val minimumDurationMillis = 2000
        try {
            val playbackStart = _playbackStart ?: return
            if (offset - playbackStart.offset < minimumDurationMillis) {
                return
            }
            _playbackRegions.add(
                AudiobookPlaybackRegion(
                    audioSectionsHash = _audioSectionsHash,
                    audioSectionIndex = section.index,
                    startTime = playbackStart.offset.toDouble() / 1000.0,
                    endTime = offset.toDouble() / 1000.0,
                    endTimestamp = Date()
                )
            )
        } finally {
            _playbackStart = null
        }
    }

    private fun synchroniseComboPlayerControllerVolume(comboPlayerController: ComboPlayer.Controller) {
        if (!_hasSoundtrack.value) return
        val balance = _soundtrackVolumeBalance.value
        comboPlayerController.masterVolume = min((1.0 - balance) * 2.0, 1.0)
        comboPlayerController.slaveVolume = if (_soundtrackEnabled.value) {
            min(balance * 2.0, 1.0)
        } else {
            0.0
        }
    }
}

private sealed class DecryptedFile {
    object ErrorNotEnoughSpace : DecryptedFile()
    object ErrorFailedToDecrypt : DecryptedFile()
    data class Okay(val file: File) : DecryptedFile()
}

private fun decryptFile(
    cryptFile: File,
    crypto: Crypto,
    technicalIssues: TechnicalIssues,
    fileResourceDirectory: File,
    maximumFileLifetime: CompositeDisposable
): Single<DecryptedFile> {
    fun copyStreams(
        inputStream: InputStream,
        outputStream: OutputStream,
        lifetime: SingleEmitter<*>
    ): Boolean {
        val bufferLength = 16384
        val buffer = ByteArray(bufferLength)
        while (!lifetime.isDisposed) {
            var read = inputStream.read(buffer)
            if (read == -1) {
                return true
            }
            outputStream.write(buffer, 0, read)
        }
        return false
    }

    val initialSpaceAvailable = cryptFile.freeSpace
    return Single.create<DecryptedFile> { emitter ->
        var clearFile: File? = null
        try {
            clearFile = FileSystem.createUniqueFile(fileResourceDirectory)
            val successful = FileOutputStream(clearFile, false).use { outputStream ->
                crypto.decryptedFileInputStream(cryptFile).use { inputStream ->
                    copyStreams(inputStream, outputStream, emitter)
                }
            }
            if (successful) {
                emitter.onSuccess(DecryptedFile.Okay(clearFile))
            }
        } catch (e: Throwable) {
            val probableNoSpaceError =
                ((e as? IOException)?.cause as? android.system.ErrnoException)?.run { errno == android.system.OsConstants.ENOSPC }
                    ?: false

            technicalIssues.report(
                TechnicalIssues.DecryptFailure(
                    spaceRequired = cryptFile.length(),
                    spaceAvailable = initialSpaceAvailable,
                    message = e.message,
                    isIOException = e is IOException,
                    probableNoSpaceError = probableNoSpaceError
                )
            )

            if (probableNoSpaceError) {
                emitter.onSuccess(DecryptedFile.ErrorNotEnoughSpace)
            } else {
                emitter.onSuccess(DecryptedFile.ErrorFailedToDecrypt)
            }
        } finally {
            maximumFileLifetime.add(Disposables.fromAction {
                try {
//                    Log.d("AudiobookPlayer", "will delete ${clearFile?.name}")
                    clearFile?.delete()
//                    Log.d("AudiobookPlayer", "did delete ${clearFile?.name}")
                } catch (e: Throwable) {
                    Log.e("AudiobookPlayer", "failed to delete")
                }
            })
        }
    }
}
