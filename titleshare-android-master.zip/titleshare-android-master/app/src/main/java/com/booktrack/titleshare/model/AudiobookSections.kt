package com.booktrack.titleshare.model

import android.net.Uri
import android.util.Log
import androidx.annotation.MainThread
import com.booktrack.titleshare.server_api.AudiobookApi
import com.booktrack.titleshare.server_api.ExhaustivelyFetchedAudiobookSectionsItem
import com.booktrack.titleshare.util.BaseRefCountedDisposable
import com.booktrack.titleshare.util.Optional
import com.booktrack.titleshare.util.SimpleDisposableObserver
import com.booktrack.titleshare.util.Watchable
import com.squareup.moshi.Json
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonClass
import com.squareup.moshi.adapters.PolymorphicJsonAdapterFactory
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*

class AudiobookSections private constructor(
    val dateAddedToDevice: Date,
    audiobookSectionItems: List<AudiobookSection>?,
    audioSectionsHash: String?,
    totalBytes: Long?,
    private val _audiobookApi: AudiobookApi,
    private val _fileResourceController: FileResourceController,
    private val _downloadRetryTriggers: DownloadRetryTriggers,
    private var _metadataDownloadState: MetadataDownloadState,
    private val _audiobookId: String
) : BaseRefCountedDisposable() {

    companion object {
        fun create(
            dateAddedToDevice: Date,
            audiobookId: AudiobookId,
            audiobookApi: AudiobookApi,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceController: FileResourceController
        ): AudiobookSections {
            return AudiobookSections(
                dateAddedToDevice,
                null,
                null,
                null,
                audiobookApi,
                fileResourceController,
                downloadRetryTriggers,
                MetadataDownloadState.NotDownloading,
                audiobookId
            )
                .apply { fetchMetadata() }
        }

        fun restore(
            memento: Memento,
            audiobookId: AudiobookId,
            audiobookApi: AudiobookApi,
            downloadRetryTriggers: DownloadRetryTriggers,
            fileResourceController: FileResourceController
        ): AudiobookSections {
            return when (memento) {
                is Memento.Unresolved -> create(
                    memento.dateAddedToDevice ?: Date(),
                    audiobookId,
                    audiobookApi,
                    downloadRetryTriggers,
                    fileResourceController
                )
                is Memento.Resolved -> AudiobookSections(
                    memento.dateAddedToDevice ?: Date(),
                    memento.items.mapIndexed { index, audiobookSectionMemento ->
                        AudiobookSection.restore(
                            audiobookSectionMemento,
                            index,
                            fileResourceController
                        )
                    },
                    memento.audioSectionsHash,
                    memento.totalBytes,
                    audiobookApi,
                    fileResourceController,
                    downloadRetryTriggers,
                    MetadataDownloadState.Downloaded,
                    audiobookId
                )
                    .apply { watchFileResources() }
            }
        }
    }

    sealed class Progress {
        object WaitingForMetadata : Progress()
        data class Downloading(val bytesDownloaded: Long, val bytesTotal: Long) : Progress()
        object Complete : Progress()
    }

    private val _items = Watchable.Source(
        Optional.fromNullable(audiobookSectionItems),
        { oldValue, newValue ->
            newValue?.someOrNull?.forEach { newAudiobookSection -> newAudiobookSection.retain() }
            oldValue?.someOrNull?.forEach { oldAudiobookSection -> oldAudiobookSection.release() }
        }
    )
    private var _audioSectionsHash: String? = audioSectionsHash
    private var _totalBytes: Long? = totalBytes
    private val _progress = Watchable.Source<Progress>(Progress.WaitingForMetadata)

    private sealed class MetadataDownloadState {
        object NotDownloading : MetadataDownloadState()
        object Downloading : MetadataDownloadState()
        object Downloaded : MetadataDownloadState()
    }

    override fun onDispose() {
        _items.dispose()
    }

    val items: Watchable<Optional<List<AudiobookSection>>>
        get() = _items.watchable

    val audioSectionsHash: String?
        get() = _audioSectionsHash

    val progress: Watchable<Progress>
        get() = _progress.watchable

    fun stale(latestAudioSectionHash: String): Boolean {
        return _audioSectionsHash != null && _audioSectionsHash != latestAudioSectionHash
    }

    @MainThread
    fun fetchMetadata() {
        if (_metadataDownloadState !is MetadataDownloadState.NotDownloading) {
            return
        }
        _metadataDownloadState = MetadataDownloadState.Downloading
        @Suppress("UNUSED_VARIABLE") val infinite = _audiobookApi
            .exhaustivelyFetchAudiobookSections(_audiobookId)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { result ->
                when (result) {
                    is AudiobookApi.ExhaustivelyFetchedAudiobookSections.Sections -> {
                        _metadataDownloadState = MetadataDownloadState.Downloaded
                        _items.value = Optional.Some(result.items.mapIndexed(this::audiobookSectionFromFetchedItem))
                        _audioSectionsHash = result.audioSectionsHash
                        _totalBytes = result.totalBytes
                        watchFileResources()
                        _downloadRetryTriggers.metadataReady()
                    }
                    is AudiobookApi.ExhaustivelyFetchedAudiobookSections.Failure.ServerError -> {
                        _metadataDownloadState = MetadataDownloadState.NotDownloading
                        _downloadRetryTriggers.metadataFailed(_audiobookId)
                    }
                    is AudiobookApi.ExhaustivelyFetchedAudiobookSections.Failure.NetworkError -> {
                        _metadataDownloadState = MetadataDownloadState.NotDownloading
                        _downloadRetryTriggers.metadataFailed(_audiobookId)
                    }
                }
            }
    }

    private fun audiobookSectionFromFetchedItem(
        index: Int,
        item: ExhaustivelyFetchedAudiobookSectionsItem
    ): AudiobookSection {
        val narrationRemoteUri = Uri.parse(item.narrationUri().uri())
        val soundtrackRemoteUri = item.soundtrackUri()?.uri()?.let { Uri.parse(it) }
        return AudiobookSection.create(
            index,
            item.title(),
            narrationRemoteUri,
            soundtrackRemoteUri,
            _fileResourceController
        )
    }

    private fun watchFileResources() {
        var inhibit = true
        for (item in _items.value.someOrNull!!) {
            item.narrationFileResource.state.subscribeWith(SimpleDisposableObserver {
                if (!inhibit) synchroniseProgress()
            }).also { _disposables.add(it) }

            item.soundtrackFileResource?.state?.subscribeWith(SimpleDisposableObserver {
                if (!inhibit) synchroniseProgress()
            })?.also { _disposables.add(it) }
        }
        synchroniseProgress()
        inhibit = false
    }

    private fun synchroniseProgress() {
        var bytesDownloaded: Long = 0
        var allComplete = true
        for (item in _items.value.someOrNull ?: Collections.emptyList()) {
            val narrationState: FileResource.State = item.narrationFileResource.state.value
            val soundtrackState: FileResource.State? = item.soundtrackFileResource?.state?.value
            bytesDownloaded += narrationState.finalOrDownloadedSizeInBytes + (soundtrackState?.finalOrDownloadedSizeInBytes
                ?: 0)
            allComplete = allComplete && narrationState.available && (soundtrackState?.available ?: true)
        }
        if (allComplete) {
            _progress.value = Progress.Complete
        } else {
            _progress.value = Progress.Downloading(bytesDownloaded, _totalBytes!!)
        }
    }

    val memento: Memento
        get() {
            val items = _items.value.someOrNull
            val audioSectionsHash = _audioSectionsHash
            val totalBytes = _totalBytes
            return if (items != null && audioSectionsHash != null && totalBytes != null) {
                Memento.Resolved(
                    dateAddedToDevice = dateAddedToDevice,
                    audioSectionsHash = audioSectionsHash,
                    items = items.map { it.memento },
                    totalBytes = totalBytes
                )
            } else {
                Memento.Unresolved(
                    dateAddedToDevice = dateAddedToDevice
                )
            }
        }

    sealed class Memento(@Json(name = "state") val mementoType: MementoType) {
        @JsonClass(generateAdapter = true)
        data class Unresolved(
            val dateAddedToDevice: Date?  // added in v2.0.2
        ) : Memento(mementoType = MementoType.Unresolved)

        @JsonClass(generateAdapter = true)
        data class Resolved(
            val dateAddedToDevice: Date?, // added in v2.0.2
            val audioSectionsHash: String,
            val items: List<AudiobookSection.Memento>,
            val totalBytes: Long
        ) : Memento(mementoType = MementoType.Resolved)

        enum class MementoType {
            Unresolved,
            Resolved
        }

        companion object {
            fun moshiJsonAdapter(): JsonAdapter.Factory {
                return PolymorphicJsonAdapterFactory.of(Memento::class.java, "state")
                    .withSubtype(Unresolved::class.java, MementoType.Unresolved.name)
                    .withSubtype(Resolved::class.java, MementoType.Resolved.name)
            }
        }
    }
}
