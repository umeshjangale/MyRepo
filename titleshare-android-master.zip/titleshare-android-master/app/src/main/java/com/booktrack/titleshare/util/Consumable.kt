package com.booktrack.titleshare.util

import java.util.concurrent.atomic.AtomicReference

class Consumable<T>(value: T?) {
    private val _value = AtomicReference<T>(value)
    fun consume(): T? {
        return _value.getAndSet(null)
    }
}
