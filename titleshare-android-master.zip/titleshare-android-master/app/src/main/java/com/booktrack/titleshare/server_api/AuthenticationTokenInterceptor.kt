package com.booktrack.titleshare.server_api

import com.booktrack.titleshare.model.Authentication
import dagger.Lazy
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthenticationTokenInterceptor @Inject constructor(
    private val _lazyAuthentication: Lazy<Authentication>
) :
    Interceptor {
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = _lazyAuthentication.get().token
        return chain.proceed(
            if (token != null) {
                chain.request().newBuilder()
                    .header("Authorization", "Bearer $token")
                    .build()

            } else {
                chain.request()
            }
        )
    }
}
