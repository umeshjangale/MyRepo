package com.booktrack.titleshare.model

import androidx.annotation.MainThread
import com.booktrack.titleshare.server_api.AuthenticationApi
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.subjects.BehaviorSubject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Authentication @Inject constructor(
    private val _authenticationApi: AuthenticationApi,
    private val _crypto: Crypto
) {
    companion object {
        private const val USER_AUTH_TOKEN_KEY = "USER_AUTH_TOKEN_KEY"
    }

    sealed class State {
        object LoggedOut : State()
        object LoggingIn : State()
        data class LoggedIn(val token: String) : State()
        object LoggingOut : State()
    }

    sealed class LoginResult {
        object LoggedIn : LoginResult()
        sealed class NotLoggedIn : LoginResult() {
            object InvalidCredentials : NotLoggedIn()
            object NetworkError : NotLoggedIn()
            object ServerError : NotLoggedIn()
        }
    }

    sealed class SignUpWithCodeResult {
        sealed class SignedUp : SignUpWithCodeResult() {
            object LoggedIn : SignedUp()
            object MustLogin : SignedUp()
            object MustSetPasswordThenLogin : SignedUp()
        }
        sealed class NotSignedUp : SignUpWithCodeResult() {
            object Forbidden : NotSignedUp()
            object InvalidCode : NotSignedUp()
            object NetworkError : NotSignedUp()
            object ServerError : NotSignedUp()
        }
    }

    private var _loginLogoutOperations: BehaviorSubject<Observable<State>> = BehaviorSubject.create()
    private val _state: BehaviorSubject<State> = BehaviorSubject.createDefault(
        when (val token = _crypto.sharedPreferences.getString(USER_AUTH_TOKEN_KEY, null)) {
            null -> State.LoggedOut
            else -> State.LoggedIn(token = token)
        }
    )

    init {
        _loginLogoutOperations.switchMapDelayError { operation -> operation }
            .doOnNext { state ->
                when (state) {
                    is State.LoggedIn -> {
                        _crypto.sharedPreferences.edit().apply {
                            putString(USER_AUTH_TOKEN_KEY, state.token)
                            apply()
                        }
                    }
                    else -> {
                        _crypto.sharedPreferences.edit().apply {
                            remove(USER_AUTH_TOKEN_KEY)
                            apply()
                        }
                    }
                }
            }
            .subscribe(_state)
    }

    val state: Observable<State>
        get() = _state.hide()

    val token: String?
        get() = (_state.value as? State.LoggedIn)?.token

    @MainThread
    fun login(email: String, password: String, handler: (LoginResult?) -> Unit) {
        var completed = false
        val logIn = _authenticationApi.login(email, password)
            .observeOn(AndroidSchedulers.mainThread())
            .doAfterSuccess { result ->
                completed = true
                handler(
                    when (result) {
                        is AuthenticationApi.LoginResult.Success -> {
                            LoginResult.LoggedIn
                        }
                        is AuthenticationApi.LoginResult.Failure.InvalidCredentials -> {
                            LoginResult.NotLoggedIn.InvalidCredentials
                        }
                        is AuthenticationApi.LoginResult.Failure.NetworkError -> {
                            LoginResult.NotLoggedIn.NetworkError
                        }
                        is AuthenticationApi.LoginResult.Failure.ServerError -> {
                            LoginResult.NotLoggedIn.ServerError
                        }
                    }
                )
            }
            .doOnDispose {
                if (!completed) {
                    handler(null)
                }
            }
            .map { result ->
                when (result) {
                    is AuthenticationApi.LoginResult.Success -> {
                        State.LoggedIn(result.token)
                    }
                    is AuthenticationApi.LoginResult.Failure.InvalidCredentials -> {
                        State.LoggedOut
                    }
                    is AuthenticationApi.LoginResult.Failure.NetworkError -> {
                        State.LoggedOut
                    }
                    is AuthenticationApi.LoginResult.Failure.ServerError -> {
                        State.LoggedOut
                    }
                }
            }
        _loginLogoutOperations.onNext(Observable.just<State>(State.LoggingIn).concatWith(logIn))
    }

    @MainThread
    fun signUpWithCode(email: String, code: String, handler: (SignUpWithCodeResult?) -> Unit) {
        var completed = false
        val signUp = _authenticationApi.signUpWithCode(email, code)
            .observeOn(AndroidSchedulers.mainThread())
            .doAfterSuccess { result ->
                completed = true
                handler(
                    when (result) {
                        is AuthenticationApi.SignUpWithCodeResult.Success -> {
                            SignUpWithCodeResult.SignedUp.LoggedIn
                        }
                        is AuthenticationApi.SignUpWithCodeResult.SuccessButMustSetPassword -> {
                            SignUpWithCodeResult.SignedUp.MustSetPasswordThenLogin
                        }
                        is AuthenticationApi.SignUpWithCodeResult.SuccessButMustLogin -> {
                            SignUpWithCodeResult.SignedUp.MustLogin
                        }
                        is AuthenticationApi.SignUpWithCodeResult.Failure.InvalidCode -> {
                            SignUpWithCodeResult.NotSignedUp.InvalidCode
                        }
                        is AuthenticationApi.SignUpWithCodeResult.Failure.Forbidden -> {
                            SignUpWithCodeResult.NotSignedUp.Forbidden
                        }
                        is AuthenticationApi.SignUpWithCodeResult.Failure.NetworkError -> {
                            SignUpWithCodeResult.NotSignedUp.NetworkError
                        }
                        is AuthenticationApi.SignUpWithCodeResult.Failure.ServerError -> {
                            SignUpWithCodeResult.NotSignedUp.ServerError
                        }
                    }
                )
            }
            .doOnDispose {
                if (!completed) {
                    handler(null)
                }
            }
            .flatMapObservable { result ->
                when (result) {
                    is AuthenticationApi.SignUpWithCodeResult.Success -> {
                        Observable.just<State>(State.LoggedIn(result.token))
                    }
                    else -> Observable.empty()
                }
            }
        _loginLogoutOperations.onNext(signUp)
    }

    @MainThread
    fun logout() {
        _loginLogoutOperations.onNext(Observable.just(State.LoggingOut, State.LoggedOut))
    }

    fun tokenDidFail() {
        _loginLogoutOperations.onNext(Observable.just(State.LoggingOut, State.LoggedOut))
    }
}
