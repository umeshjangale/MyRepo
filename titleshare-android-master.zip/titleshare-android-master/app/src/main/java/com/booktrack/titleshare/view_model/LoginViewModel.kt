package com.booktrack.titleshare.view_model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.model.Authentication
import com.booktrack.titleshare.util.Consumable

class LoginViewModel(private val _authentication: Authentication, initialEmailAddress: String?) : ViewModel() {
    sealed class NavigationAction {
        object Audiobooks : NavigationAction()
        data class ResetPassword(val initialEmailAddress: String?) : NavigationAction()
    }

    sealed class LoginFailureReason {
        object InvalidCredentials : LoginFailureReason()
        object NetworkError : LoginFailureReason()
        object ServerError : LoginFailureReason()
    }

    private val _isEmailError = MutableLiveData<Boolean>()
    private val _isLoginEnabled = MutableLiveData<Boolean>()
    private val _isBusy = MutableLiveData<Boolean>()
    private val _navigationAction = MutableLiveData<Consumable<NavigationAction>>()
    private val _presentLoginFailure = MutableLiveData<Consumable<LoginFailureReason>>()

    var email: String? = null
        set(value) {
            field = value
            _isEmailError.value = !value.isNullOrEmpty() && !emailValid(value)
            synchroniseIsLoginEnabled()
        }

    var password: String? = null
        set(value) {
            field = value
            synchroniseIsLoginEnabled()
        }

    init {
        _isEmailError.value = false
        email = initialEmailAddress
        _isBusy.value = false
        synchroniseIsLoginEnabled()
        _presentLoginFailure.value = Consumable(null)
    }

    val isEmailError: LiveData<Boolean>
        get() = _isEmailError

    val isLoginEnabled: LiveData<Boolean>
        get() = _isLoginEnabled

    val isBusy: LiveData<Boolean>
        get() = _isBusy

    fun login() {
        if (!_isLoginEnabled.value!!) {
            return
        }
        _isBusy.value = true
        _authentication.login(email!!, password!!) { result ->
            _isBusy.value = false
            if (result != null) {
                when (result) {
                    is Authentication.LoginResult.LoggedIn -> {
                        _navigationAction.value = Consumable(NavigationAction.Audiobooks)
                    }
                    is Authentication.LoginResult.NotLoggedIn -> {
                        _presentLoginFailure.value!!.consume()
                        _presentLoginFailure.value = Consumable(
                            when (result) {
                                is Authentication.LoginResult.NotLoggedIn.ServerError -> LoginFailureReason.ServerError
                                is Authentication.LoginResult.NotLoggedIn.NetworkError -> LoginFailureReason.NetworkError
                                is Authentication.LoginResult.NotLoggedIn.InvalidCredentials -> LoginFailureReason.InvalidCredentials
                            }
                        )
                    }
                }
            }
        }
    }

    val navigate: LiveData<Consumable<NavigationAction>>
        get() = _navigationAction

    val presentLoginFailure: LiveData<Consumable<LoginFailureReason>>
        get() = _presentLoginFailure

    fun resetPassword() {
        _navigationAction.value = Consumable(NavigationAction.ResetPassword(email))
    }

    private fun synchroniseIsLoginEnabled() {
        _isLoginEnabled.value = emailValid(email) && !password.isNullOrEmpty()
    }
}

private fun emailValid(value: String?): Boolean {
    return value?.contains('@') ?: false
}
