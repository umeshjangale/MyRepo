package com.booktrack.titleshare.graphql

import com.apollographql.apollo.ApolloCall
import com.apollographql.apollo.ApolloClient
import com.apollographql.apollo.api.*
import com.apollographql.apollo.exception.ApolloException
import com.apollographql.apollo.exception.ApolloHttpException
import com.apollographql.apollo.exception.ApolloNetworkException
import com.apollographql.apollo.exception.ApolloParseException
import com.apollographql.apollo.internal.util.Cancelable
import io.reactivex.Single
import io.reactivex.disposables.Disposable
import io.reactivex.exceptions.Exceptions
import okio.ByteString

sealed class Result<in R> {
    data class Success<T>(val data: T?, var errors: List<Error>) : Result<T>()
    sealed class Failure : Result<Any?>() {
        data class HttpStatusError(val status: Int, val unsupportedAppVersion: Boolean) : Failure()
        object NetworkError : Failure()
        object GraphqlParseError : Failure()
        object UnknownError : Failure()
    }
}

fun <D : Operation.Data, T, V : Operation.Variables> ApolloClient.queryAsRxSingle(query: Query<D, T, V>): Single<Result<T>> {
    val apolloCall = this.query(query)
    return apolloCallAsRxSingle<T>(apolloCall)
}

fun <D : Operation.Data, T, V : Operation.Variables> ApolloClient.mutateAsRxSingle(mutation: Mutation<D, T, V>): Single<Result<T>> {
    val apolloCall = this.mutate(mutation)
    return apolloCallAsRxSingle<T>(apolloCall)
}

private fun <T> apolloCallAsRxSingle(apolloCall: ApolloCall<T>): Single<Result<T>> {
    return Single.create { emitter ->
        emitter.setDisposable(DisposableCancelable(apolloCall))
        apolloCall.enqueue(object : ApolloCall.Callback<T>() {
            override fun onResponse(response: Response<T>) {
                if (!emitter.isDisposed) {
                    emitter.onSuccess(Result.Success(response.data(), response.errors()))
                }
            }

            override fun onFailure(e: ApolloException) {
                Exceptions.throwIfFatal(e)
                if (!emitter.isDisposed) {
                    emitter.onSuccess(
                        when (e) {
                            is ApolloHttpException -> {
                                val unsupportedAppVersion = if (e.code() == 400) {
                                    e.rawResponse()?.use { rawResponse ->
                                        rawResponse.body()?.use { responseBody ->
                                            responseBody.source().use { bufferedSource ->
                                                bufferedSource.indexOf(ByteString.encodeUtf8("UNSUPPORTED_APP_VERSION")) != -1L
                                            }
                                        }
                                    }
                                        ?: false
                                } else {
                                    false
                                }
                                Result.Failure.HttpStatusError(e.code(), unsupportedAppVersion)
                            }
                            is ApolloNetworkException -> Result.Failure.NetworkError
                            is ApolloParseException -> Result.Failure.GraphqlParseError
                            else -> Result.Failure.UnknownError
                        }
                    )
                }
            }
        })
    }
}

internal class DisposableCancelable(private val _cancelable: Cancelable) : Disposable {
    override fun dispose() {
        _cancelable.cancel()
    }

    override fun isDisposed(): Boolean {
        return _cancelable.isCanceled
    }
}
