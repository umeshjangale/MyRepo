package com.booktrack.titleshare.util

import java.io.FilterOutputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import kotlin.math.min

// Avoids an Android API level 23 specific bug caused by... well, it's complicated
// See:
// https://issuetracker.google.com/issues/136693238
// https://github.com/google/tink/issues/229
//
class BufferSizeBugAvoidanceStreamWrapper(out: OutputStream) : FilterOutputStream(out) {

    private val _buffer: ByteBuffer = ByteBuffer.allocate(4080)
        .apply {
            limit(4041)
        }

    @Synchronized
    @Throws(IOException::class)
    override fun write(bytes: ByteArray, offset: Int, length: Int) {
        var inputOffset = offset
        var inputRemaining = length
        while (inputRemaining > 0) {
            val transfer = min(_buffer.remaining(), inputRemaining)
            _buffer.put(bytes, inputOffset, transfer)
            inputOffset += transfer
            inputRemaining -= transfer
            if (!_buffer.hasRemaining()) {
                _buffer.flip()
                out.write(_buffer.array(), _buffer.position(), _buffer.remaining())
                _buffer.limit(4080)
            }
        }
    }

    @Synchronized
    @Throws(IOException::class)
    override fun close() {
        _buffer.flip()
        if (_buffer.hasRemaining()) {
            out.write(_buffer.array(), _buffer.position(), _buffer.remaining())
        }
        super.close()
    }

}
