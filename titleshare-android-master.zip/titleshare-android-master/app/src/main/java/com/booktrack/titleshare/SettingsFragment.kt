package com.booktrack.titleshare

import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import javax.inject.Inject

class SettingsFragment @Inject constructor() : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)
    }

    override fun onResume() {
        super.onResume()
        // This isn't ideal, but there doesn't seem to be a sensible way to otherwise refresh the screen
        //  so, it'll do for now
        setPreferencesFromResource(R.xml.root_preferences, null)
    }
}
