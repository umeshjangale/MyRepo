package com.booktrack.titleshare.ui.sign_up_with_code

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.booktrack.titleshare.CustomChrome
import com.booktrack.titleshare.R
import com.booktrack.titleshare.databinding.SignUpWithCodeFragmentBinding
import com.booktrack.titleshare.view_model.SignUpWithCodeViewModel
import com.booktrack.titleshare.view_model.SignUpWithCodeViewModelFactoryProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.sign_up_with_code_fragment.view.*
import javax.inject.Inject

@SuppressLint("ValidFragment")
class SignUpWithCodeFragment @Inject constructor(
    private val _loginViewModelFactoryProvider: SignUpWithCodeViewModelFactoryProvider
) : Fragment(), CustomChrome {
    private lateinit var viewModel: SignUpWithCodeViewModel

    override fun onAttach(context: Context) {
        viewModel =
            ViewModelProviders.of(this, _loginViewModelFactoryProvider.Factory())
                .get(SignUpWithCodeViewModel::class.java)
        super.onAttach(context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: SignUpWithCodeFragmentBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.sign_up_with_code_fragment, container, false)
        val view = binding.root
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        viewModel.presentSignedUpInformation.observe(this, Observer { signedUpInformation ->
            signedUpInformation.consume()?.also {
                MaterialAlertDialogBuilder(this.context)
                    .setTitle(R.string.sign_up_with_code_fragment_signed_up_info_title)
                    .setMessage(
                        when (it) {
                            is SignUpWithCodeViewModel.SignedUpInformation.SetPasswordForNewAccount -> R.string.sign_up_with_code_fragment_signed_up_info_set_password_for_new_account
                            is SignUpWithCodeViewModel.SignedUpInformation.LogIntoExistingAccount -> R.string.sign_up_with_code_fragment_signed_up_info_log_into_existing_account
                            is SignUpWithCodeViewModel.SignedUpInformation.SetPasswordForExistingAccount -> R.string.sign_up_with_code_fragment_signed_up_info_set_password_for_existing_account
                        }
                    )
                    .setPositiveButton(R.string.sign_up_with_code_fragment_signed_up_info_dismiss_action) { dialog, _ ->
                        dialog.dismiss()
                    }
                    .setCancelable(false)
                    .show()
            }
        })

        viewModel.navigate.observe(viewLifecycleOwner, Observer { consumableNavigationAction ->
            consumableNavigationAction.consume()?.also { navigationAction ->
                when (navigationAction) {
                    is SignUpWithCodeViewModel.NavigationAction.Audiobooks -> Navigation.findNavController(view).navigate(
                        SignUpWithCodeFragmentDirections.actionSignUpWithCodePopToMainNavigation()
                    )
                    is SignUpWithCodeViewModel.NavigationAction.Login -> Navigation.findNavController(view).navigate(
                        SignUpWithCodeFragmentDirections.actionSignUpWithCodeToLogin(initialEmailAddress = navigationAction.initialEmailAddress)
                    )
                }
            }
        })

        viewModel.presentSignUpFailure.observe(viewLifecycleOwner, Observer { consumableSignUpFailureReason ->
            consumableSignUpFailureReason.consume()?.also { failureReason ->
                val message = when (failureReason) {
                    is SignUpWithCodeViewModel.SignUpFailureReason.InvalidCode -> R.string.sign_up_with_code_fragment_sign_up_failed_with_invalid_code
                    is SignUpWithCodeViewModel.SignUpFailureReason.Forbidden -> R.string.sign_up_with_code_fragment_sign_up_failed_with_forbidden
                    is SignUpWithCodeViewModel.SignUpFailureReason.NetworkError -> R.string.sign_up_with_code_fragment_sign_up_failed_with_network_error
                    is SignUpWithCodeViewModel.SignUpFailureReason.ServerError -> R.string.sign_up_with_code_fragment_sign_up_failed_with_server_error
                }
                Snackbar.make(view, message, Snackbar.LENGTH_LONG).show()
            }
        })

        view.progress_bar.indeterminateDrawable.setColorFilter(
            ContextCompat.getColor(context!!, R.color.colorPrimary),
            PorterDuff.Mode.SRC_IN
        )

        view.terms_of_service_button.setOnClickListener {
            context?.also { c ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.getString(R.string.terms_and_conditions_url))))
            }
        }

        view.privacy_policy_button.setOnClickListener {
            context?.also { c ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.getString(R.string.privacy_policy_url))))
            }
        }

        view.help_button.setOnClickListener {
            context?.also { c ->
                c.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse(c.getString(R.string.support_url))
                })
            }
        }

        return view
    }

    override fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View? {
        return null
    }

    override fun getToolbarScrollFlags(): Int? {
        return null
    }

    override fun getToolbarVisibility(): Int? {
        return null
    }
}
