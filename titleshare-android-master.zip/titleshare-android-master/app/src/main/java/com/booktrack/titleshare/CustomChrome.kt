package com.booktrack.titleshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

interface CustomChrome {

    /**
     * Returns a view to install in the bottom of the app bar, or null if no view is required.
     * The returned view will be automatically removed upon navigation change.
     * This method is invoked after onCreateView.
     */
    fun onCreateAppBarBottomView(layoutInflater: LayoutInflater, viewGroup: ViewGroup): View?

    /**
     * Returns custom scroll flags, or null if the initial scroll flags should be used.
     */
    fun getToolbarScrollFlags(): Int?

    /**
     * Returns the toolbar visibility, or null if the initial toolbar visibility should be used.
     */
    fun getToolbarVisibility(): Int?

}
