package com.booktrack.titleshare.util

import android.view.View
import android.view.ViewParent
import android.widget.EditText
import androidx.databinding.BindingAdapter
import com.booktrack.titleshare.R
import com.google.android.material.textfield.TextInputLayout

object BindingAdapters {
    /**
     * Conditionally shows a TextInputLayout error when the contained EditText is unfocussed.
     *
     * It is assumed that the EditText is somewhere within the view hierarchy of the TextInputLayout.
     */
    @BindingAdapter("unfocussedError")
    @JvmStatic
    fun unfocussedError(textInputLayout: TextInputLayout, msg: String?) {
        maybeAttachTextInputLayoutEditTextFocusListener(textInputLayout)
        textInputLayout.setTag(R.id.error_text, msg)
        if (!textInputLayout.editText!!.isFocused) {
            textInputLayout.error = msg
        }
    }

    private val textInputLayoutEditTextOnFocusChangeListener = View.OnFocusChangeListener { target, hasFocus ->
        val editText = target as EditText
        var parent: ViewParent = editText.parent
        while (parent !is TextInputLayout) {
            parent = parent.parent
        }
        val textInputLayout = parent
        textInputLayout.error = if (hasFocus) null else textInputLayout.getTag(R.id.error_text) as String?
    }

    private fun maybeAttachTextInputLayoutEditTextFocusListener(textInputLayout: TextInputLayout) {
        val editText = textInputLayout.editText!!
        if (editText.onFocusChangeListener == null) {
            editText.onFocusChangeListener = textInputLayoutEditTextOnFocusChangeListener
        }
    }
}
