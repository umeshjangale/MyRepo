package com.booktrack.titleshare.view_model

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.booktrack.titleshare.model.Audiobook
import com.booktrack.titleshare.model.AudiobookMetadata
import com.booktrack.titleshare.model.AudiobookRegistry
import com.booktrack.titleshare.model.DownloadFeedbackTrigger
import com.booktrack.titleshare.util.Consumable
import com.booktrack.titleshare.util.SimpleDisposableObserver
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposables

class AudiobookDetailsViewModel(
    audiobookRegistry: AudiobookRegistry,
    audiobookId: String,
    private val _downloadFeedbackTrigger: DownloadFeedbackTrigger
) : ViewModel() {

    sealed class NavigationAction {
        data class Play(val audiobookId: String) : NavigationAction()
    }

    data class CoverImageUri(
        val small: Uri?,
        val large: Uri?
    )

    private val _disposables = CompositeDisposable()
    private val _coverImageUri = MutableLiveData<CoverImageUri>()
    private val _title = MutableLiveData<String>()
    private val _subtitle = MutableLiveData<String>()
    private val _author = MutableLiveData<String>()
    private val _narrator = MutableLiveData<String>()
    private val _publisher = MutableLiveData<String>()
    private val _description = MutableLiveData<String>()
    private val _primaryAction = MutableLiveData<PrimaryAction>()
    private val _navigationAction = MutableLiveData<Consumable<NavigationAction>>()
    private val _audiobook: Audiobook = audiobookRegistry.audiobook(audiobookId)!!

    init {
        _audiobook.retain()
        _disposables.add(Disposables.fromAction { _audiobook.release() })

        _audiobook.metadata.subscribeWith(SimpleDisposableObserver { audiobookMetadata ->
            metadataDidChange(audiobookMetadata)
        }).also { _disposables.add(it) }

        AudiobookState.forAudiobook(_audiobook).subscribeWith(SimpleDisposableObserver { audiobookState ->
            _primaryAction.value = when {
                audiobookState is AudiobookState.Remote -> PrimaryAction.Download
                audiobookState is AudiobookState.Downloading && !audiobookState.playable -> PrimaryAction.ListenDisabled
                else -> PrimaryAction.Listen
            }
        }).also { _disposables.add(it) }
    }

    sealed class PrimaryAction {
        object Download : PrimaryAction()
        object Listen : PrimaryAction()
        object ListenDisabled : PrimaryAction()
    }

    val coverImageUri: LiveData<CoverImageUri>
        get() = _coverImageUri

    val title: LiveData<String?>
        get() = _title

    val subtitle: LiveData<String?>
        get() = _subtitle

    val author: LiveData<String?>
        get() = _author

    val narrator: LiveData<String?>
        get() = _narrator

    val publisher: LiveData<String?>
        get() = _publisher

    val description: LiveData<String?>
        get() = _description

    val primaryAction: LiveData<PrimaryAction>
        get() = _primaryAction

    val navigate: LiveData<Consumable<NavigationAction>>
        get() = _navigationAction

    fun performPrimaryAction() {
        when (_primaryAction.value!!) {
            is PrimaryAction.Listen -> _navigationAction.value = Consumable(NavigationAction.Play(_audiobook.id))
            is PrimaryAction.Download -> {
                _audiobook.fetchAudiobookSections()
                _downloadFeedbackTrigger.userDidInitiateDownload()
            }
        }
    }

    private fun metadataDidChange(metadata: AudiobookMetadata) {
        _title.value = nullOrNonEmptyString(metadata.title)
        _subtitle.value = nullOrNonEmptyString(metadata.subtitle)
        _author.value = nullOrNonEmptyString(metadata.author)
        _narrator.value = nullOrNonEmptyString(metadata.narrator)
        _publisher.value = nullOrNonEmptyString(metadata.publisher)
        _description.value = nullOrNonEmptyString(metadata.desc)
        _coverImageUri.value = CoverImageUri(
            small = metadata.coverImageUrl256x256,
            large = metadata.coverImageUrl1024x1024
        )
    }

    override fun onCleared() {
        _disposables.dispose()
        super.onCleared()
    }
}

fun nullOrNonEmptyString(s: String): String? {
    val trimmed = s.trim()
    if (trimmed.isEmpty()) return null
    return trimmed
}
