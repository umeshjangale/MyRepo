package com.booktrack.titleshare.widget

import android.content.Context
import androidx.navigation.fragment.NavHostFragment
import com.booktrack.titleshare.MainActivity

// Enables fragments within the nav host fragment to be injected
class InjectingNavHostFragment : NavHostFragment() {
    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is MainActivity) {
            childFragmentManager.fragmentFactory = context.fragmentFactory
        }
    }
}
