package com.booktrack.titleshare.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AudiobookBookmark(
    val audioSectionIndex: Int,
    val offsetInSeconds: Double
)
