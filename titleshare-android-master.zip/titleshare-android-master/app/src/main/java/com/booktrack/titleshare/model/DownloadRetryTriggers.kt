package com.booktrack.titleshare.model

import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.MainThread
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadRetryTriggers @Inject constructor(
    connectivity: Connectivity
) {

    private val _retryDownloads: Subject<Unit> = PublishSubject.create()
    private val _handler: Handler = Handler(Looper.getMainLooper())
    // Simple backoff strategy which is reset after app restart, and which batches failures together into single retry attempts
    private val _retryAttemptsById: MutableMap<String, Int> = HashMap()

    val retryDownloads: Observable<Unit>
        get() = _retryDownloads

    init {
        @Suppress("UNUSED_VARIABLE") val infinite = connectivity.state
            .distinctUntilChanged()
            .subscribe {
                connectivityChanged()
            }
    }

    @MainThread
    fun userRefreshed() {
        retryImmediately()
    }

    @MainThread
    fun metadataReady() {
        retryImmediately()
    }

    @MainThread
    fun appResumed() {
        retryImmediately()
    }

    @MainThread
    fun connectivityChanged() {
        // testing shows that the network is unreliable immediately after connectivity change
        retryAfterDelay(5000)
    }

    @MainThread
    fun metadataFailed(audiobookId: String) {
        retryWithLimitAndBackoff(audiobookId, 5)
    }

    @MainThread
    fun downloadFailed(uri: Uri) {
        retryWithLimitAndBackoff(uri.toString(), 2)
    }

    private fun retryImmediately() {
        _retryDownloads.onNext(Unit)
    }

    private fun retryAfterDelay(milliseconds: Long) {
        _handler.postDelayed({
            retryImmediately()
        }, milliseconds)
    }

    private fun retryWithLimitAndBackoff(id: String, maximumAllowableAutoRetries: Int) {
        val retryAttempts = _retryAttemptsById[id] ?: 0
        if (retryAttempts >= maximumAllowableAutoRetries) {
            return
        }
        val thisRetryAttempt = retryAttempts + 1
        val milliseconds: Long = 60000 * thisRetryAttempt.toLong()
        // Remove previous timeout, it might have been shorter or longer, it might be just about to elapse, meh.
        // This algorithm doesn't need to be perfect, it just needs to mostly work.
        // The user can pull down to refresh (or via menu option) if needed.
        // Failing that, app restoration or app restart will also retrigger.
        _handler.removeCallbacks(_autoRetryRunnable)
        _handler.postDelayed(_autoRetryRunnable, milliseconds)
        _retryAttemptsById[id] = thisRetryAttempt
    }

    private val _autoRetryRunnable: Runnable = Runnable {
        retryImmediately()
    }
}
