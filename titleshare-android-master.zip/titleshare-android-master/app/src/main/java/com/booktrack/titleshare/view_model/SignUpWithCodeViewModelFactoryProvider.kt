package com.booktrack.titleshare.view_model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.model.Authentication
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SignUpWithCodeViewModelFactoryProvider @Inject constructor(
    private val _authentication: Authentication
) {
    inner class Factory : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return SignUpWithCodeViewModel(_authentication) as T
        }
    }
}
