package com.booktrack.titleshare.util

import android.annotation.SuppressLint
import android.net.Uri
import android.util.Log
import com.booktrack.titleshare.server_api.TechnicalIssuesApi
import com.squareup.moshi.*
import com.squareup.moshi.adapters.Rfc3339DateJsonAdapter
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TechnicalIssues @Inject constructor(
    private val _technicalIssuesApi: TechnicalIssuesApi
) {
    private val _moshi = Moshi.Builder()
        .add(Date::class.java, Rfc3339DateJsonAdapter().nullSafe())
        .add(Uri::class.java, object : JsonAdapter<Uri>() {
            override fun fromJson(reader: JsonReader): Uri? {
                return Uri.parse(reader.nextString())
            }

            override fun toJson(writer: JsonWriter, value: Uri?) {
                writer.value(value!!.toString())
            }
        }.nullSafe())
        .build()
    private var _downloadFailureRemaining = AtomicCountDown(1)
    private var _downloadOnFailureFailureRemaining = AtomicCountDown(1)
    private var _downloadShortFileThenSuccess = AtomicCountDown(2)

    interface TechnicalIssue<T> {
        fun truncated(): T
    }

    @JsonClass(generateAdapter = true)
    data class CryptoReadinessFailure(
        val type: String = "CryptoReadinessFailure",
        val message: String?
    ) : TechnicalIssue<CryptoReadinessFailure> {
        override fun truncated() = this.copy(
            message = this.message?.snip(1000)
        )
    }

    @JsonClass(generateAdapter = true)
    data class DecryptFailure(
        val type: String = "DecryptFailure",
        val spaceRequired: Long?,
        val spaceAvailable: Long,
        val message: String?,
        val isIOException: Boolean,
        val probableNoSpaceError: Boolean
    ) : TechnicalIssue<DecryptFailure> {
        override fun truncated() = this.copy(
            message = this.message?.snip(1000)
        )
    }

    @JsonClass(generateAdapter = true)
    data class DownloadFailure(
        val type: String = "DownloadFailure",
        val wrote: Long?,
        val read: Long?,
        val spaceAvailable: Long,
        val message: String?
    ) : TechnicalIssue<DownloadFailure> {
        override fun truncated() = this.copy(
            message = this.message?.snip(1000)
        )
    }

    @JsonClass(generateAdapter = true)
    data class DownloadOnFailureFailure(
        val type: String = "DownloadOnFailureFailure",
        val message: String?
    ) : TechnicalIssue<DownloadOnFailureFailure> {
        override fun truncated() = this.copy(
            message = this.message?.snip(1000)
        )
    }

    @JsonClass(generateAdapter = true)
    data class DownloadShortFileFailure(
        val type: String = "DownloadShortFileFailure",
        val wrote: Long?,
        val read: Long?,
        val spaceAvailable: Long
    ) : TechnicalIssue<DownloadShortFileFailure> {
        override fun truncated() = this
    }

    @JsonClass(generateAdapter = true)
    data class DownloadShortFileThenSuccess(
        val type: String = "DownloadShortFileThenSuccess",
        val succeededOnAttempt: Int
    ) : TechnicalIssue<DownloadShortFileThenSuccess> {
        override fun truncated() = this
    }

    @JsonClass(generateAdapter = true)
    data class ModelWriteFailure(
        val type: String = "ModelWriteFailure",
        val spaceRequired: Long?,
        val spaceAvailable: Long,
        val message: String?
    ) : TechnicalIssue<ModelWriteFailure> {
        override fun truncated() = this.copy(
            message = this.message?.snip(1000)
        )
    }

    fun report(technicalIssue: DownloadFailure) {
        report(technicalIssue as TechnicalIssue<*>, _downloadFailureRemaining.countDown())
    }

    fun report(technicalIssue: DownloadOnFailureFailure) {
        report(technicalIssue as TechnicalIssue<*>, _downloadOnFailureFailureRemaining.countDown())
    }

    fun report(technicalIssue: DownloadShortFileThenSuccess) {
        report(technicalIssue as TechnicalIssue<*>, _downloadShortFileThenSuccess.countDown())
    }

    @SuppressLint("CheckResult")
    fun report(technicalIssue: TechnicalIssue<*>, send: Boolean = true) {
        val jsonAdapter = _moshi.adapter(technicalIssue.javaClass)

        val jsonString = try {
            jsonAdapter.toJson(technicalIssue)
        } catch (e: Throwable) {
            Log.e("TechnicalIssues", "failed to serialize to json", e)
            return
        }
        Log.w("TechnicalIssue", "${technicalIssue.javaClass.name}: $jsonString")
        if (send) {
            _technicalIssuesApi.recordTechnicalIssues(listOf(jsonString))
                .subscribe { success ->
                    if (!success) {
                        Log.e("TechnicalIssues", "failed to send report")
                    }
                }
        }
    }
}
