package com.booktrack.titleshare.util

class AtomicCountDown(private var _remaining: Int) {
    @Synchronized fun countDown(): Boolean {
        if (_remaining == 0) {
            return false
        }
        _remaining--
        return true
    }
}
