package com.booktrack.titleshare.server_api

import com.apollographql.apollo.ApolloClient
import com.booktrack.titleshare.graphql.ContentItemsQuery
import com.booktrack.titleshare.graphql.Result
import com.booktrack.titleshare.graphql.queryAsRxSingle
import com.booktrack.titleshare.graphql.type.ImageSizeInput
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

private const val maximumInconsistentResultRetries = 2

typealias ExhaustivelyFetchedAudiobooksItem = ContentItemsQuery.Item

@Singleton
class AudiobooksApi @Inject constructor(
    private val _apolloClient: ApolloClient,
    private val _authenticationTokenFailureInterceptor: AuthenticationTokenFailureInterceptor,
    private val _unsupportedAppVersionInterceptor: UnsupportedAppVersionInterceptor

) {

    sealed class ExhaustivelyFetchedAudiobooks {
        data class Audiobooks(val items: List<ExhaustivelyFetchedAudiobooksItem>) : ExhaustivelyFetchedAudiobooks()
        sealed class Failure : ExhaustivelyFetchedAudiobooks() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    fun exhaustivelyFetchUserAudiobooks(): Single<ExhaustivelyFetchedAudiobooks> {
        return fetchAllPages(1, emptyList(), null, 0)
    }

    private fun fetchAllPages(
        oneBasedPageNumber: Int,
        previousItems: List<ExhaustivelyFetchedAudiobooksItem>,
        previousTotalItems: Int?,
        inconsistentResultRetryCount: Int
    ): Single<ExhaustivelyFetchedAudiobooks> {
        return fetchPage(oneBasedPageNumber)
            .flatMap { result ->
                when (result) {
                    is FetchedAudiobooksPage.Audiobooks -> {
                        if (previousTotalItems != null && result.totalItems != previousTotalItems) {
                            // Hmm, the server is now reporting a different number of total audiobooks...
                            // probably caused by a server-side mutation concurrent with our exhaustive fetch
                            // Reset everything and try again
                            if (inconsistentResultRetryCount <= maximumInconsistentResultRetries) {
                                fetchAllPages(1, emptyList(), null, inconsistentResultRetryCount + 1)
                            } else {
                                // So slim an edge case that we (ab)use the server error variant
                                Single.just<ExhaustivelyFetchedAudiobooks>(ExhaustivelyFetchedAudiobooks.Failure.ServerError)
                            }
                        } else {
                            val accumulatedItems = previousItems + result.items
                            if (accumulatedItems.size < result.totalItems) {
                                fetchAllPages(
                                    oneBasedPageNumber + 1,
                                    accumulatedItems,
                                    result.totalItems,
                                    inconsistentResultRetryCount
                                )
                            } else {
                                Single.just<ExhaustivelyFetchedAudiobooks>(
                                    ExhaustivelyFetchedAudiobooks.Audiobooks(
                                        accumulatedItems
                                    )
                                )
                            }
                        }
                    }
                    is FetchedAudiobooksPage.Failure.ServerError -> Single.just<ExhaustivelyFetchedAudiobooks>(
                        ExhaustivelyFetchedAudiobooks.Failure.ServerError
                    )
                    is FetchedAudiobooksPage.Failure.NetworkError -> Single.just<ExhaustivelyFetchedAudiobooks>(
                        ExhaustivelyFetchedAudiobooks.Failure.NetworkError
                    )
                }
            }
    }

    private sealed class FetchedAudiobooksPage {
        data class Audiobooks(val items: List<ExhaustivelyFetchedAudiobooksItem>, val totalItems: Int) :
            FetchedAudiobooksPage()

        sealed class Failure : FetchedAudiobooksPage() {
            object NetworkError : Failure()
            object ServerError : Failure()
        }
    }

    private fun fetchPage(oneBasedPageNumber: Int): Single<FetchedAudiobooksPage> {
        return _apolloClient.queryAsRxSingle(
            ContentItemsQuery(
                20,
                oneBasedPageNumber,
                listOf(
                    ImageSizeInput.builder().width(256).height(256).build(),
                    ImageSizeInput.builder().width(1024).height(1024).build()
                )
            )
        )
            .doOnSuccess(_unsupportedAppVersionInterceptor)
            .doOnSuccess(_authenticationTokenFailureInterceptor)
            .map { result ->
                when (result) {
                    is Result.Success -> when (val searchContent = result.data?.searchContent()) {
                        null -> FetchedAudiobooksPage.Failure.ServerError
                        else -> FetchedAudiobooksPage.Audiobooks(searchContent.items(), searchContent.totalCount())
                    }
                    is Result.Failure -> when (result) {
                        is Result.Failure.NetworkError -> FetchedAudiobooksPage.Failure.NetworkError
                        else -> FetchedAudiobooksPage.Failure.ServerError
                    }
                }
            }
    }
}
