package com.booktrack.titleshare.model

import android.app.Application
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.booktrack.titleshare.util.TechnicalIssues
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Crypto @Inject constructor(
    private val _context: Application,
    private val _fileSystem: FileSystem,
    private val _technicalIssues: TechnicalIssues
) {
    private val _masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)

    init {
        // There appears to be a thread race issue in the androidx.security.crypto.EncryptedFile class
        //  on a fresh install whereby multiple keys can be generated (and used to encrypt) but where only
        //  one will ultimately win, making decryption of the other files impossible.
        // This chunk of code horror is an attempt to force a key to be written prior to us encrypting audio files
        _fileSystem.cryptReadyFile.delete()
        try {
            val bufferSize = 2048
            encryptedFileOutputStream(_fileSystem.cryptReadyFile).use { outputStream ->
                val buffer = ByteArray(bufferSize)
                outputStream.write(buffer, 0, buffer.size)
                outputStream.flush()
            }
            decryptedFileInputStream(_fileSystem.cryptReadyFile).use { inputStream ->
                val buffer = ByteArray(bufferSize)
                inputStream.read(buffer)
            }
            for (i in 0..4) {
                if (_fileSystem.cryptReadyFile.delete()) {
                    break
                }
                Thread.sleep(5)
            }
        } catch (e: Throwable) {
            _technicalIssues.report(
                TechnicalIssues.CryptoReadinessFailure(
                    message = e.message
                )
            )
        }
    }

    val sharedPreferences: SharedPreferences = EncryptedSharedPreferences
        .create(
            "value_store",
            _masterKeyAlias,
            _context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    fun decryptedFileInputStream(file: File): FileInputStream {
        return encryptedFile(file).openFileInput()
    }

    fun encryptedFileOutputStream(file: File): FileOutputStream {
        return encryptedFile(file).openFileOutput()
    }

    private fun encryptedFile(file: File): EncryptedFile {
        return EncryptedFile.Builder(
            file,
            _context,
            _masterKeyAlias,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
    }
}
