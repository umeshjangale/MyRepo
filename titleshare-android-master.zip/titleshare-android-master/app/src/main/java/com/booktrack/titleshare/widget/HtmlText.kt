package com.booktrack.titleshare.widget

import android.content.Context
import android.os.Build
import android.text.Html
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.booktrack.titleshare.R

// See: https://stackoverflow.com/a/39629633
class HtmlText(context: Context?, attrs: AttributeSet?) : AppCompatTextView(context, attrs) {
    var htmlText: String? = null
        set(value) {
            field = value
            if (value == null) {
                text = null
                return
            }
            text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)
            } else {
                Html.fromHtml(value)
            }
        }

    init {
        val styledAttributes = getContext().obtainStyledAttributes(attrs, R.styleable.HtmlText, 0, 0)
        try {
            htmlText = styledAttributes.getString(R.styleable.HtmlText_htmlText)
        } finally {
            styledAttributes.recycle()
        }
    }
}
