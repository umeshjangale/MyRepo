package com.booktrack.titleshare.view_model

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.booktrack.titleshare.model.Crypto
import com.booktrack.titleshare.model.FileSystem
import com.booktrack.titleshare.model.Model
import com.booktrack.titleshare.util.TechnicalIssues
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AudiobookPlayerViewModelFactoryProvider @Inject constructor(
    private val _context: Application,
    private val _crypto: Crypto,
    private val _fileSystem: FileSystem,
    private val _technicalIssues: TechnicalIssues,
    private val _model: Model
) {
    inner class Factory(private val _audiobookId: String) : ViewModelProvider.Factory {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return AudiobookPlayerViewModel(
                _context,
                _model.audiobookRegistry,
                _audiobookId,
                _crypto,
                _fileSystem,
                _technicalIssues
            ) as T
        }
    }
}
