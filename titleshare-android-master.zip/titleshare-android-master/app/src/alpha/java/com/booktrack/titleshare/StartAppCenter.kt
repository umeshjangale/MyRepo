package com.booktrack.titleshare

import android.app.Application

fun startAppCenter(@Suppress("UNUSED_PARAMETER") application: Application) {
    // No app center in alpha builds
}
