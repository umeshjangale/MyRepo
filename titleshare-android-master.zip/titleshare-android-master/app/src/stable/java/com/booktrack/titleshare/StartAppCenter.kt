package com.booktrack.titleshare

import android.app.Application
import com.microsoft.appcenter.AppCenter
import com.microsoft.appcenter.analytics.Analytics
import com.microsoft.appcenter.crashes.Crashes

fun startAppCenter(application: Application) {
    AppCenter.start(
        application,
        "cf230f17-89d6-48a9-9c60-38d8f86fd02a",
        Analytics::class.java,
        Crashes::class.java
    )
}
